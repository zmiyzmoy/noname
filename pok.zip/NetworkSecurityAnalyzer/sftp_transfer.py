#!/usr/bin/env python3
"""
SFTP Transfer script for Poker AI System
This script will directly transfer the Poker AI System to your A100 server via SFTP.
"""

import os
import sys
import paramiko
import getpass
import time

def transfer_file(hostname, username, password, port=22, 
                  local_file="poker_ai_system_slim.tar.gz", 
                  remote_path="~/"):
    """Transfer file via SFTP"""
    try:
        print(f"Connecting to {username}@{hostname}:{port}...")
        
        # Create SSH client
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname, port, username, password)
        
        # Start SFTP session
        sftp = ssh.open_sftp()
        
        # Get file size
        filesize = os.path.getsize(local_file)
        remote_file = os.path.join(remote_path, os.path.basename(local_file))
        
        # Upload with progress
        print(f"Uploading {local_file} to {remote_file} ({filesize/1024/1024:.2f} MB)...")
        
        start = time.time()
        sftp.put(local_file, remote_file, callback=lambda x, y: 
                 print(f"\rProgress: {x/filesize*100:.1f}% ({x/1024/1024:.2f} MB / {filesize/1024/1024:.2f} MB)",
                       end=""))
        elapsed = time.time() - start
        
        print(f"\nTransfer completed in {elapsed:.1f} seconds ({filesize/elapsed/1024/1024:.2f} MB/s)")
        
        # Execute commands to extract and set up
        print("\nExtracting file on remote server...")
        mkdir_cmd = f"mkdir -p ~/poker_ai"
        extract_cmd = f"tar -xzf {remote_file} -C ~/poker_ai"
        
        stdin, stdout, stderr = ssh.exec_command(mkdir_cmd)
        stdout.channel.recv_exit_status()
        
        stdin, stdout, stderr = ssh.exec_command(extract_cmd)
        exit_status = stdout.channel.recv_exit_status()
        
        if exit_status != 0:
            print("Error extracting file on remote server:")
            print(stderr.read().decode())
        else:
            print("File extracted successfully on remote server")
            print("\nYou can now run the following commands:")
            print("cd ~/poker_ai")
            print("pip install -r requirements.txt")
            print("python main.py")
        
        # Close connections
        sftp.close()
        ssh.close()
        
        return True
    
    except Exception as e:
        print(f"Error: {e}")
        return False

def main():
    """Main function to gather parameters and transfer file"""
    print("Poker AI System SFTP Transfer")
    print("============================\n")
    
    if not os.path.exists("poker_ai_system_slim.tar.gz"):
        print("Error: poker_ai_system_slim.tar.gz not found")
        return
    
    # Get connection parameters
    hostname = input("Enter A100 server hostname or IP: ")
    username = input("Enter username: ")
    password = getpass.getpass("Enter password: ")
    port = input("Enter SSH port [22]: ") or 22
    try:
        port = int(port)
    except ValueError:
        print("Invalid port, using default port 22")
        port = 22
    
    # Transfer the file
    transfer_file(hostname, username, password, port)

if __name__ == "__main__":
    main()