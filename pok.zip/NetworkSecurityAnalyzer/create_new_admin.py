import os
import sys
import logging
from werkzeug.security import generate_password_hash
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Configure the SQLAlchemy part of the app
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/postgres')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'poker-ai-dashboard-secret-key'

# Initialize database
db = SQLAlchemy(app)

# Define minimal User model
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

def create_new_admin():
    """Create a new admin user."""
    with app.app_context():
        # Create admin user
        try:
            admin_user = User(
                username='pokeradmin',
                email='pokeradmin@example.com',
                password=generate_password_hash('pokerpwd123'),
                is_admin=True
            )
            db.session.add(admin_user)
            db.session.commit()
            logger.info("New admin user created successfully")
            logger.info("Username: pokeradmin")
            logger.info("Password: pokerpwd123")
            return True
        except Exception as e:
            logger.error(f"Error creating admin user: {str(e)}")
            return False

if __name__ == '__main__':
    if create_new_admin():
        logger.info("New admin user created successfully")
        sys.exit(0)
    else:
        logger.error("Failed to create new admin user")
        sys.exit(1)