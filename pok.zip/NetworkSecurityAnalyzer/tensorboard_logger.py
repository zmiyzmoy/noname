"""
TensorBoard Logger for Poker AI Training

This module provides a wrapper around TensorBoard for tracking and
visualizing poker AI training metrics.
"""

import os
import time
import logging
import socket
import psutil
import numpy as np
from torch.utils.tensorboard import SummaryWriter

class TensorBoardLogger:
    """
    A utility class for logging training metrics to TensorBoard.
    This helps visualize poker AI training progress.
    """
    
    def __init__(self, log_dir=None, run_name=None):
        """
        Initialize the TensorBoard logger.
        
        Args:
            log_dir: Directory to store TensorBoard logs
            run_name: Name for this training run
        """
        # Set default log directory if not provided
        if log_dir is None:
            log_dir = os.path.join("runs", "poker_training")
        
        # Create the log directory if it doesn't exist
        os.makedirs(log_dir, exist_ok=True)
        
        # Set run name (useful for comparing multiple training runs)
        if run_name is None:
            timestamp = int(time.time())
            hostname = socket.gethostname()
            run_name = f"run_{timestamp}_{hostname}"
        
        # Initialize TensorBoard writer
        self.log_dir = os.path.join(log_dir, run_name)
        self.writer = SummaryWriter(log_dir=self.log_dir)
        self.step = 0
        
        logging.info(f"TensorBoard logging initialized at {self.log_dir}")

    def log_metrics(self, metrics, step=None):
        """
        Log multiple metrics to TensorBoard.
        
        Args:
            metrics: Dictionary of metrics to log
            step: Step/iteration number (if None, uses internal counter)
        """
        if step is None:
            step = self.step
            self.step += 1
        
        # Log each metric to TensorBoard
        for name, value in metrics.items():
            # Skip non-numeric values
            if not isinstance(value, (int, float, np.number)):
                continue
                
            # Group metrics by category using slashes in name
            if '/' not in name:
                # Add default category based on metric name
                if 'loss' in name:
                    category = 'Losses'
                elif 'win' in name or 'reward' in name:
                    category = 'Rewards'
                elif 'rate' in name:
                    category = 'Rates'
                elif 'exploit' in name:
                    category = 'Exploitability'
                elif 'time' in name or 'duration' in name:
                    category = 'Timing'
                else:
                    category = 'Metrics'
                
                # Format tag with category
                tag = f"{category}/{name}"
            else:
                # Use provided category/name format
                tag = name
            
            # Log scalar value
            self.writer.add_scalar(tag, value, step)

    def log_system_metrics(self, step=None):
        """Log system resource usage."""
        if step is None:
            step = self.step
            self.step += 1
        
        # CPU usage (percent)
        cpu_percent = psutil.cpu_percent(interval=0.1)
        self.writer.add_scalar('System/cpu_percent', cpu_percent, step)
        
        # Memory usage
        memory = psutil.virtual_memory()
        self.writer.add_scalar('System/memory_used_gb', memory.used / (1024**3), step)
        self.writer.add_scalar('System/memory_percent', memory.percent, step)
        
        # Disk usage
        disk = psutil.disk_usage('/')
        self.writer.add_scalar('System/disk_used_gb', disk.used / (1024**3), step)
        self.writer.add_scalar('System/disk_percent', disk.percent, step)
        
        # Log number of Python processes
        python_process_count = len([p for p in psutil.process_iter(['name']) 
                                  if 'python' in p.info['name'].lower()])
        self.writer.add_scalar('System/python_processes', python_process_count, step)

    def log_model_weights(self, model, step=None):
        """
        Log model weights and gradients.
        
        Args:
            model: PyTorch model
            step: Step/iteration number
        """
        if step is None:
            step = self.step
        
        try:
            # Log model parameter histograms
            for name, param in model.named_parameters():
                if param.requires_grad:
                    self.writer.add_histogram(f"Weights/{name}", param.data, step)
                    
                    # Log gradients if they exist
                    if param.grad is not None:
                        self.writer.add_histogram(f"Gradients/{name}", param.grad, step)
        except Exception as e:
            logging.warning(f"Failed to log model weights: {e}")

    def log_poker_game_results(self, game_results, step=None):
        """
        Log poker-specific game results.
        
        Args:
            game_results: Dictionary of poker game results
            step: Step/iteration number
        """
        if step is None:
            step = self.step
            self.step += 1
            
        # Expected format of game_results:
        # {
        #   'actions': {'fold': 10, 'call': 15, 'raise': 8, 'check': 12},
        #   'win_by_street': {'preflop': 5, 'flop': 8, 'turn': 10, 'river': 12},
        #   'avg_reward': 1.5,
        #   'hands_played': 45,
        #   'exploitability': 0.25
        # }
        
        # Log action distribution
        if 'actions' in game_results:
            actions = game_results['actions']
            total_actions = sum(actions.values())
            
            if total_actions > 0:
                # Log as percentages
                for action, count in actions.items():
                    percentage = (count / total_actions) * 100
                    self.writer.add_scalar(f'Actions/{action}_pct', percentage, step)
        
        # Log street-level win data
        if 'win_by_street' in game_results:
            for street, count in game_results['win_by_street'].items():
                self.writer.add_scalar(f'WinRate/at_{street}', count, step)
        
        # Log other metrics directly
        for key, value in game_results.items():
            if key not in ('actions', 'win_by_street') and isinstance(value, (int, float)):
                category = 'PokerMetrics'
                self.writer.add_scalar(f'{category}/{key}', value, step)

    def log_text(self, tag, text_string, step=None):
        """
        Log text information.
        
        Args:
            tag: Tag for the text
            text_string: Text to log
            step: Step/iteration number
        """
        if step is None:
            step = self.step
        
        self.writer.add_text(tag, text_string, step)

    def close(self):
        """Close the TensorBoard writer."""
        if hasattr(self, 'writer'):
            self.writer.close()
            logging.info(f"TensorBoard logger closed: {self.log_dir}")

    def __del__(self):
        """Ensure writer is closed on garbage collection."""
        self.close()