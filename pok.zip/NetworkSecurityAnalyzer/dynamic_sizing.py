#!/usr/bin/env python3
import os
import logging
import numpy as np
from typing import List, Dict, Any, Tuple, Optional

class DynamicBetSizing:
    """
    Dynamic bet sizing helper for poker AI.
    This class handles calculating optimal bet sizes based on game state,
    pot odds, stack-to-pot ratio, and opponent tendencies.
    """
    
    # Standard bet sizing options as pot percentages
    BET_SIZES = {
        'min_bet': 0.5,         # Minimum bet (0.5 BB)
        'micro': 0.25,          # Quarter pot
        'small': 0.33,          # 1/3 pot
        'medium': 0.50,         # 1/2 pot
        'standard': 0.75,       # 3/4 pot
        'pot': 1.0,            # Pot-sized bet
        'overbet': 1.5,        # 1.5x pot
        'large_overbet': 2.0,  # 2x pot
        'max_pressure': 2.5,   # 2.5x pot
    }
    
    # Define position categories
    POSITION_CATEGORIES = {
        'early': ['UTG', 'UTG+1', 'MP'],
        'middle': ['MP+1', 'HJ', 'CO'],
        'late': ['BTN', 'SB'],
        'blinds': ['BB']
    }
    
    def __init__(self, stack_sizes: List[float], config=None):
        self.stack_sizes = stack_sizes
        self.config = config
        self.bb = 2.0 if config is None else config.BB
        self.min_bet_size = 0.5 * self.bb  # Minimum bet is 0.5 BB
        
        # Initialize logger
        self.logger = logging.getLogger('DynamicBetSizing')
        
    def calculate_bet_options(self, 
                             game_state: Any, 
                             pot_size: float, 
                             player_position: int,
                             position_name: str,
                             board: List[str], 
                             hole_cards: List[str],
                             opponent_stats: Optional[Dict] = None,
                             round_idx: int = 0,
                             is_raise: bool = False) -> Dict[str, float]:
        """
        Calculate appropriate bet sizes based on the current game state.
        
        Args:
            game_state: OpenSpiel game state object
            pot_size: Current pot size
            player_position: Position of the acting player
            position_name: Position name (e.g., 'BTN', 'SB', 'BB')
            board: List of board cards 
            hole_cards: Player's hole cards
            opponent_stats: Dictionary of opponent statistics
            round_idx: Betting round index (0=preflop, 1=flop, 2=turn, 3=river)
            is_raise: Whether this is a raise (vs. initial bet)
            
        Returns:
            Dictionary of bet size options with descriptive keys and bet amounts
        """
        # Get available stack (effective stack)
        player_stack = self.stack_sizes[player_position]
        min_opponent_stack = min([s for i, s in enumerate(self.stack_sizes) 
                                 if i != player_position and s > 0])
        effective_stack = min(player_stack, min_opponent_stack)
        
        # Calculate stack-to-pot ratio
        spr = effective_stack / max(pot_size, self.bb)
        
        # Calculate position category
        position_category = self._get_position_category(position_name)
        
        # Determine board texture
        is_draw_heavy = self._is_draw_heavy_board(board)
        is_high_card = self._is_high_card_board(board)
        
        # Determine hand strength (simplified)
        hand_strength = self._estimate_hand_strength(hole_cards, board)
        
        # Adjust bet sizing based on game context
        bet_options = {}
        
        # Always include fold and check/call options
        bet_options['fold'] = 0.0
        bet_options['call'] = 0.0  # This value will be updated by the caller
        
        # Preflop sizing
        if round_idx == 0:
            bet_options.update(self._get_preflop_sizing(
                pot_size, spr, hand_strength, position_category, is_raise))
        
        # Postflop sizing
        else:
            bet_options.update(self._get_postflop_sizing(
                pot_size, spr, hand_strength, position_category, 
                is_draw_heavy, is_high_card, round_idx, is_raise))
            
        # Opponent-based adjustments
        if opponent_stats:
            bet_options = self._adjust_for_opponents(bet_options, opponent_stats, round_idx)
        
        # Add all-in option if SPR is low
        if spr < 3:
            bet_options['all_in'] = effective_stack
        
        # Ensure all bets are at least the min bet size and at most the effective stack
        for key in list(bet_options.keys()):
            if key not in ['fold', 'call']:
                # Round to 2 decimal places for clarity
                amount = round(bet_options[key], 2)
                
                # Enforce minimum bet size
                if 0 < amount < self.min_bet_size:
                    amount = self.min_bet_size
                
                # Enforce maximum bet size
                if amount > effective_stack:
                    amount = effective_stack
                    
                bet_options[key] = amount
                
        self.logger.debug(f"Calculated bet options: {bet_options}")
        return bet_options
    
    def _get_preflop_sizing(self, pot_size: float, spr: float, 
                           hand_strength: float, position_category: str,
                           is_raise: bool) -> Dict[str, float]:
        """Calculate preflop bet sizing options."""
        options = {}
        
        # Base open-raise sizes
        if not is_raise:
            if position_category == 'early':
                # Early position uses larger sizing
                options['raise_3bb'] = 3 * self.bb
                options['raise_4bb'] = 4 * self.bb
            elif position_category == 'middle':
                options['raise_2.5bb'] = 2.5 * self.bb
                options['raise_3bb'] = 3 * self.bb
            elif position_category == 'late':
                # Late position can use smaller sizing
                options['raise_2bb'] = 2 * self.bb
                options['raise_2.5bb'] = 2.5 * self.bb
                options['raise_3bb'] = 3 * self.bb
            else:  # blinds
                options['raise_3bb'] = 3 * self.bb
                options['raise_4bb'] = 4 * self.bb
        
        # 3-bet sizing (responding to a raise)
        else:
            # Standard 3-bet size is around 3x the previous raise
            prev_raise = pot_size / 2.5  # Approximate the last raise size
            options['reraise_3x'] = 3 * prev_raise
            
            # Add 4-bet option for strong hands
            if hand_strength > 0.8:
                options['reraise_4x'] = 4 * prev_raise
                
            # If SPR is low, consider shoving
            if spr < 10:
                effective_stack = spr * pot_size
                options['shove'] = effective_stack
        
        return options
    
    def _get_postflop_sizing(self, pot_size: float, spr: float, 
                            hand_strength: float, position_category: str,
                            is_draw_heavy: bool, is_high_card: bool,
                            round_idx: int, is_raise: bool) -> Dict[str, float]:
        """Calculate postflop bet sizing options."""
        options = {}
        
        # Initial bet sizing options vary based on factors
        if not is_raise:
            # Add standard bet size options
            if is_draw_heavy:
                # On draw-heavy boards, bet bigger to charge draws
                options['bet_66pct'] = 0.66 * pot_size
                options['bet_pot'] = 1.0 * pot_size
            elif is_high_card:
                # On high card boards, smaller bets can be effective
                options['bet_33pct'] = 0.33 * pot_size
                options['bet_50pct'] = 0.5 * pot_size
            else:
                # Mixed texture boards
                options['bet_50pct'] = 0.5 * pot_size
                options['bet_66pct'] = 0.66 * pot_size
            
            # Strong hands may want to bet larger
            if hand_strength > 0.8:
                options['bet_pot'] = 1.0 * pot_size
                
            # On the river (round_idx 3), polarize sizing more
            if round_idx == 3:
                if hand_strength > 0.9:  # Very strong hands
                    options['bet_pot'] = 1.0 * pot_size
                    options['overbet_150pct'] = 1.5 * pot_size
                elif hand_strength < 0.2:  # Bluffs
                    options['bet_66pct'] = 0.66 * pot_size
                    options['bet_pot'] = 1.0 * pot_size
        
        # Raise sizing
        else:
            # Standard raise size is often 2.5-3x the bet
            last_bet = pot_size / 3.0  # Approximate the last bet
            options['raise_2.5x'] = 2.5 * last_bet
            options['raise_3x'] = 3.0 * last_bet
            
            # Add larger raise options for strong hands
            if hand_strength > 0.8:
                options['raise_4x'] = 4.0 * last_bet
                
            # On the river, polarize more
            if round_idx == 3:
                if hand_strength > 0.9 or hand_strength < 0.2:  # Value or bluff
                    options['raise_pot'] = pot_size
        
        return options
    
    def _adjust_for_opponents(self, bet_options: Dict[str, float], 
                             opponent_stats: Dict, round_idx: int) -> Dict[str, float]:
        """Adjust bet sizing based on opponent tendencies."""
        # Clone the bet options to avoid modifying the original
        adjusted_options = bet_options.copy()
        
        # Check if opponent_stats is a valid dictionary with sub-dictionaries
        if not opponent_stats or not all(isinstance(stats, dict) for stats in opponent_stats.values()):
            self.logger.warning(f"Invalid opponent_stats format: {opponent_stats}")
            return adjusted_options  # Return unadjusted options if stats are invalid
            
        # Get average stats across all opponents
        # Use safe extraction with type checking
        avg_vpip_values = []
        avg_pfr_values = []
        avg_af_values = []
        avg_fold_to_3bet_values = []
        
        for player_id, stats in opponent_stats.items():
            if isinstance(stats, dict):
                # Extract values safely
                if 'vpip' in stats and isinstance(stats['vpip'], (int, float)):
                    avg_vpip_values.append(stats['vpip'])
                else:
                    avg_vpip_values.append(25)  # Default
                    
                if 'pfr' in stats and isinstance(stats['pfr'], (int, float)):
                    avg_pfr_values.append(stats['pfr'])
                else:
                    avg_pfr_values.append(18)  # Default
                    
                if 'af' in stats and isinstance(stats['af'], (int, float)):
                    avg_af_values.append(stats['af'])
                else:
                    avg_af_values.append(2)  # Default
                    
                if 'fold_to_3bet' in stats and isinstance(stats['fold_to_3bet'], (int, float)):
                    avg_fold_to_3bet_values.append(stats['fold_to_3bet'])
                else:
                    avg_fold_to_3bet_values.append(50)  # Default
        
        # Calculate means only if we have values
        avg_vpip = np.mean(avg_vpip_values) if avg_vpip_values else 25
        avg_pfr = np.mean(avg_pfr_values) if avg_pfr_values else 18  
        avg_af = np.mean(avg_af_values) if avg_af_values else 2
        avg_fold_to_3bet = np.mean(avg_fold_to_3bet_values) if avg_fold_to_3bet_values else 50
        
        # Against passive opponents (low aggression factor)
        if avg_af < 1.5:
            # Prefer smaller bets for value to induce calls
            if 'bet_pot' in adjusted_options:
                adjusted_options.pop('bet_pot')
            if 'overbet_150pct' in adjusted_options:
                adjusted_options.pop('overbet_150pct')
            
            # Add smaller bet sizes
            if round_idx > 0:  # Postflop
                adjusted_options['bet_33pct'] = 0.33 * max(bet_options.values())
                adjusted_options['bet_50pct'] = 0.5 * max(bet_options.values())
        
        # Against aggressive opponents (high aggression factor)
        if avg_af > 3:
            # Use larger bets to discourage aggression
            if 'bet_33pct' in adjusted_options:
                adjusted_options.pop('bet_33pct')
            
            # Add larger sizes
            if round_idx > 0:  # Postflop
                adjusted_options['bet_75pct'] = 0.75 * max(bet_options.values())
                adjusted_options['bet_pot'] = 1.0 * max(bet_options.values())
        
        # Against loose opponents (high VPIP)
        if avg_vpip > 30:
            # Use larger bet sizes as they'll call with weaker hands
            if round_idx == 0:  # Preflop
                if 'raise_2bb' in adjusted_options:
                    adjusted_options.pop('raise_2bb')
                if 'raise_2.5bb' in adjusted_options:
                    adjusted_options.pop('raise_2.5bb')
                
                # Add larger raise sizes
                adjusted_options['raise_4bb'] = 4 * self.bb
                adjusted_options['raise_5bb'] = 5 * self.bb
        
        # Against tight opponents (low VPIP)
        if avg_vpip < 20:
            # Prefer smaller bet sizes for bluffs
            if round_idx > 0:  # Postflop
                adjusted_options['min_bet'] = self.min_bet_size
                adjusted_options['bet_33pct'] = 0.33 * max(bet_options.values())
        
        return adjusted_options
    
    def _get_position_category(self, position_name: str) -> str:
        """Map position name to category."""
        for category, positions in self.POSITION_CATEGORIES.items():
            if position_name in positions:
                return category
        
        # Default to middle position if unknown
        return 'middle'
    
    def _is_draw_heavy_board(self, board: List[str]) -> bool:
        """Check if the board has many potential draws."""
        if len(board) < 3:
            return False
            
        # Count suits for flush draws
        suits = [card[1] for card in board]
        suit_counts = {suit: suits.count(suit) for suit in set(suits)}
        flush_draw = any(count >= 3 for count in suit_counts.values())
        
        # Check for straight draws (simplified)
        ranks = [self._card_rank_to_int(card[0]) for card in board]
        ranks.sort()
        straight_draw = False
        
        # Check for connected cards
        for i in range(len(ranks) - 1):
            if ranks[i+1] - ranks[i] <= 2:  # Connected or one gap
                straight_draw = True
                break
                
        return flush_draw or straight_draw
    
    def _is_high_card_board(self, board: List[str]) -> bool:
        """Check if the board is primarily high cards."""
        if len(board) < 3:
            return False
            
        high_cards = ['T', 'J', 'Q', 'K', 'A']
        high_card_count = sum(1 for card in board if card[0] in high_cards)
        
        return high_card_count >= len(board) / 2
    
    def _estimate_hand_strength(self, hole_cards: List[str], board: List[str]) -> float:
        """
        Simplified hand strength estimation.
        Returns a value between 0 (weak) and 1 (strong).
        In a real implementation, this would use more sophisticated hand evaluation.
        """
        if not hole_cards or len(hole_cards) != 2:
            return 0.5  # Default to medium strength
            
        # Check for pocket pairs
        if hole_cards[0][0] == hole_cards[1][0]:
            rank = self._card_rank_to_int(hole_cards[0][0])
            # High pocket pairs are strong
            if rank >= 10:  # Ten or higher
                return 0.9
            elif rank >= 7:  # Medium pairs
                return 0.7
            else:  # Small pairs
                return 0.5
                
        # Check for strong high cards
        if all(card[0] in ['A', 'K', 'Q', 'J', 'T'] for card in hole_cards):
            return 0.8
            
        # Check for suited cards
        if hole_cards[0][1] == hole_cards[1][1]:
            return 0.6
            
        # Check for connected cards
        rank1 = self._card_rank_to_int(hole_cards[0][0])
        rank2 = self._card_rank_to_int(hole_cards[1][0])
        if abs(rank1 - rank2) <= 2:
            return 0.55
            
        # Default weak hand
        return 0.3
    
    def _card_rank_to_int(self, rank: str) -> int:
        """Convert card rank to integer value."""
        if rank == 'T':
            return 10
        elif rank == 'J':
            return 11
        elif rank == 'Q':
            return 12
        elif rank == 'K':
            return 13
        elif rank == 'A':
            return 14
        else:
            return int(rank)

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.DEBUG)
    
    # Example game state
    stack_sizes = [100, 95, 98, 105, 100, 102]
    pot_size = 10.0
    player_position = 0
    position_name = 'BTN'
    board = ['Ah', 'Ks', 'Qd']
    hole_cards = ['Jh', 'Td']
    
    opponent_stats = {
        1: {'vpip': 25, 'pfr': 18, 'af': 2.5, 'fold_to_3bet': 55},
        2: {'vpip': 35, 'pfr': 12, 'af': 1.2, 'fold_to_3bet': 40},
        3: {'vpip': 18, 'pfr': 14, 'af': 1.8, 'fold_to_3bet': 65}
    }
    
    # Create bet sizing calculator
    bet_sizer = DynamicBetSizing(stack_sizes)
    
    # Calculate betting options
    options = bet_sizer.calculate_bet_options(
        None, pot_size, player_position, position_name, 
        board, hole_cards, opponent_stats, round_idx=1, is_raise=False
    )
    
    print("Available bet sizing options:")
    for action, amount in options.items():
        print(f"{action}: {amount}")