import os
import logging
import sys
import json
from pathlib import Path
from datetime import datetime

from flask import Flask, redirect, url_for, render_template, flash, request
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend for matplotlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('flask_app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Check if system is initialized
def check_first_run():
    """Check if this is the first run of the system."""
    wizard_state_file = Path("onboarding_wizard_state.json")
    return not wizard_state_file.exists()

def create_app():
    """Initialize and configure the Flask application."""
    # Initialize the Flask app
    app = Flask(__name__)
    
    # Configure the app
    app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "a_secure_secret_key_for_poker_ai"
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    
    # Initialize database and related extensions
    from models.db import init_app
    init_app(app)
        
    # Register blueprints
    from blueprints.admin import admin_bp
    from blueprints.monitor import monitor_bp
    from blueprints.training_room import training_bp
    from blueprints.unified import unified_bp
    from blueprints.advanced import advanced_bp
    from blueprints.poker_menu import poker_menu_bp
    from blueprints.onboarding import onboarding_bp
    
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(monitor_bp, url_prefix='/monitor')
    app.register_blueprint(training_bp, url_prefix='/training-room')
    app.register_blueprint(unified_bp)  # This will use its prefix '/training'
    app.register_blueprint(advanced_bp, url_prefix='/advanced')
    app.register_blueprint(poker_menu_bp, url_prefix='/poker-menu')
    app.register_blueprint(onboarding_bp, url_prefix='/onboarding')
    
    # Create directory for templates if it doesn't exist
    os.makedirs(os.path.join(app.root_path, 'templates'), exist_ok=True)
    
    # Create onboarding welcome template if it doesn't exist
    onboarding_template_path = os.path.join(app.root_path, 'templates', 'onboarding.html')
    if not os.path.exists(onboarding_template_path):
        with open(onboarding_template_path, 'w') as f:
            f.write("""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poker AI Onboarding</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-top: 30px;
        }
        h1 {
            color: #3498db;
            margin-top: 0;
        }
        .btn {
            display: inline-block;
            font-weight: 500;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
            border: 1px solid transparent;
            padding: 10px 20px;
            font-size: 16px;
            line-height: 1.5;
            border-radius: 4px;
            transition: all 0.15s ease-in-out;
            text-decoration: none;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        .btn-primary {
            color: #fff;
            background-color: #3498db;
            border-color: #3498db;
        }
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        .btn-secondary {
            color: #fff;
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .feature {
            background-color: #f8f9fa;
            border-radius: 6px;
            padding: 20px;
            border: 1px solid #dee2e6;
        }
        .feature h3 {
            margin-top: 0;
            color: #3498db;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Poker AI</h1>
        <p>This is your first time using the Poker AI system. Let's get you set up quickly!</p>
        
        <p>The Onboarding Wizard will guide you through the setup process, including:</p>
        <ul>
            <li>Checking your system configuration</li>
            <li>Installing required dependencies</li>
            <li>Setting up the database</li>
            <li>Creating an admin user</li>
            <li>Starting necessary services</li>
            <li>Running a quick training session</li>
        </ul>
        
        <a href="{{ url_for('start_onboarding') }}" class="btn btn-primary">Start Onboarding Wizard</a>
        <a href="{{ url_for('skip_onboarding') }}" class="btn btn-secondary">Skip Onboarding</a>
        
        <div class="features">
            <div class="feature">
                <h3>Training</h3>
                <p>Train sophisticated poker AIs using reinforcement learning and PSRO algorithms.</p>
            </div>
            <div class="feature">
                <h3>Monitoring</h3>
                <p>Monitor your training progress with real-time metrics and visualizations.</p>
            </div>
            <div class="feature">
                <h3>Administration</h3>
                <p>Manage your system, users, and configurations through an easy-to-use interface.</p>
            </div>
        </div>
    </div>
</body>
</html>""")
    
    # Root route checks if onboarding is needed
    @app.route('/')
    def root():
        if check_first_run():
            return redirect(url_for('onboarding.index'))
        return redirect(url_for('unified.index'))
    
    # Route to start onboarding wizard
    @app.route('/start-onboarding')
    def start_onboarding():
        try:
            import subprocess
            import threading
            
            # Start onboarding wizard in a separate process
            threading.Thread(target=lambda: subprocess.Popen(
                ["python", "run_onboarding_wizard.py", "--web", "--port", "5060"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )).start()
            
            flash("Onboarding wizard started. Please complete the setup process.", "info")
            return redirect(url_for('monitor.index'))
        except Exception as e:
            logger.error(f"Error starting onboarding wizard: {e}")
            flash(f"Error starting onboarding wizard: {e}", "error")
            return redirect(url_for('monitor.index'))
    
    # Route to skip onboarding
    @app.route('/skip-onboarding')
    def skip_onboarding():
        # Create onboarding wizard state file to indicate setup is complete
        with open("onboarding_wizard_state.json", "w") as f:
            json.dump({
                "skipped": True,
                "completion_time": str(datetime.now())
            }, f)
            
        flash("Onboarding wizard skipped. You can start using the system now.", "info")
        return redirect(url_for('monitor.index'))
    
    # Route for server transfer guide
    @app.route('/server-transfer')
    def server_transfer_guide():
        return render_template('server_transfer_guide.html')
    
    # Route to execute server transfer actions
    @app.route('/server-transfer/execute', methods=['POST'])
    def execute_server_transfer():
        action = request.form.get('action')
        
        if action == 'pack':
            try:
                # Import here to avoid loading at startup
                from server_transfer_toolkit import create_package
                package_filename = create_package()
                if package_filename:
                    flash(f"Deployment package created successfully: {package_filename}", "success")
                else:
                    flash("Failed to create deployment package. Check logs for details.", "error")
            except Exception as e:
                flash(f"Error creating deployment package: {str(e)}", "error")
                logger.error(f"Error in server transfer pack: {e}")
                
        elif action == 'config':
            try:
                # Start configuration in a separate process
                import subprocess
                import threading
                
                threading.Thread(target=lambda: subprocess.Popen(
                    ["python", "server_transfer_toolkit.py", "config"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )).start()
                
                flash("Configuration wizard started. Follow the prompts in the terminal.", "info")
            except Exception as e:
                flash(f"Error starting configuration wizard: {str(e)}", "error")
                logger.error(f"Error in server transfer config: {e}")
                
        elif action == 'all':
            try:
                # Start complete process in a separate process
                import subprocess
                import threading
                
                threading.Thread(target=lambda: subprocess.Popen(
                    ["python", "server_transfer_toolkit.py", "all"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )).start()
                
                flash("Server transfer process started. Follow the prompts in the terminal.", "info")
            except Exception as e:
                flash(f"Error starting server transfer process: {str(e)}", "error")
                logger.error(f"Error in server transfer all: {e}")
                
        return redirect(url_for('server_transfer_guide'))
    
    return app

# Create the Flask application instance
app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5010, debug=True)