# Poker AI Functional Tests Report

Generated: 2025-04-22 16:55:52

## Summary

- Total Tests: 1
- Successful Tests: 1
- Failed Tests: 0

## Overall Assessment

✅ All core modes (`train`, `eval`, `selfplay`) appear to be functional based on these minimal tests.

## Detailed Test Results

### Test Case 1: Functional Test - Selfplay Mode (1 Episode)

- **Command**: `python poker_rl.py --mode selfplay --num_episodes 1 --verbose`
- **Exit Code**: 0 (Success)
- **Duration**: 4.07 seconds
- **Success Pattern Found**: Yes

#### Standard Output (last lines)

```
2025-04-22 16:55:52,038 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,040 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,040 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,042 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,042 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,046 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,046 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_2bb': 4, 'raise_2.5bb': 5.0, 'raise_3bb': 6}
2025-04-22 16:55:52,048 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_2bb': 4, 'raise_2.5bb': 5.0, 'raise_3bb': 6}
2025-04-22 16:55:52,049 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,050 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,051 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,052 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,053 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,054 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,054 - INFO - Episode 1 complete
2025-04-22 16:55:52,054 - INFO -   Final returns: [-100.0, -100.0, -100.0, -100.0, 500.0, -100.0]
2025-04-22 16:55:52,054 - INFO -   Actions: [(0, 2, 'exploitative', 4.0, 3.0835821628570557), (0, 2), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448), (5, 1, 'exploitative', 0.0, 0.38840633630752563), (0, 1, 'exploration', 0.0, 0.0), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448), (5, 1, 'exploitative', 0.0, 0.38840633630752563), (0, 1, 'exploitative', 0.0, 0.20162707567214966), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448), (5, 3, 'exploration', 0.0, 0.0), (0, 1, 'exploitative', 0.0, 0.20162707567214966), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448)]
2025-04-22 16:55:52,057 - INFO - Opponent model saved to ./poker/models/opponent_models.json
2025-04-22 16:55:52,057 - INFO - Opponent models saved to ./poker/models/opponent_models.json
2025-04-22 16:55:52,057 - INFO - Selfplay demonstration with opponent modeling complete
```

#### Standard Error

```
/home/runner/workspace/psro.py:43: FutureWarning: `torch.cuda.amp.GradScaler(args...)` is deprecated. Please use `torch.amp.GradScaler('cuda', args...)` instead.
self.scaler = GradScaler('cuda') if torch.cuda.is_available() else GradScaler()
/home/runner/workspace/.pythonlibs/lib/python3.11/site-packages/torch/amp/grad_scaler.py:132: UserWarning: torch.cuda.amp.GradScaler is enabled, but CUDA is not available.  Disabling.
warnings.warn(
```

#### Log Files

**poker_rl.log** (last 20 lines):

```
2025-04-22 16:55:52,038 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,040 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,040 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,042 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,042 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,046 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,046 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_2bb': 4, 'raise_2.5bb': 5.0, 'raise_3bb': 6}
2025-04-22 16:55:52,048 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_2bb': 4, 'raise_2.5bb': 5.0, 'raise_3bb': 6}
2025-04-22 16:55:52,049 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,050 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,051 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,052 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,053 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:55:52,054 - DEBUG - Calculated bet options: {'fold': 0.0, 'call': 0.0, 'raise_3bb': 6, 'raise_4bb': 8}
2025-04-22 16:55:52,054 - INFO - Episode 1 complete
2025-04-22 16:55:52,054 - INFO -   Final returns: [-100.0, -100.0, -100.0, -100.0, 500.0, -100.0]
2025-04-22 16:55:52,054 - INFO -   Actions: [(0, 2, 'exploitative', 4.0, 3.0835821628570557), (0, 2), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448), (5, 1, 'exploitative', 0.0, 0.38840633630752563), (0, 1, 'exploration', 0.0, 0.0), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448), (5, 1, 'exploitative', 0.0, 0.38840633630752563), (0, 1, 'exploitative', 0.0, 0.20162707567214966), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448), (5, 3, 'exploration', 0.0, 0.0), (0, 1, 'exploitative', 0.0, 0.20162707567214966), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.20162707567214966), (3, 1, 'exploitative', 0.0, 0.4426453113555908), (4, 1, 'exploitative', 0.0, 0.5655478239059448)]
2025-04-22 16:55:52,057 - INFO - Opponent model saved to ./poker/models/opponent_models.json
2025-04-22 16:55:52,057 - INFO - Opponent models saved to ./poker/models/opponent_models.json
2025-04-22 16:55:52,057 - INFO - Selfplay demonstration with opponent modeling complete
```

#### Log Errors

No errors found in logs.

---

