#!/usr/bin/env python3
"""
Simple direct download script for the Poker AI system.
Run this on your A100 server to download the package directly.
"""

import os
import requests
import hashlib
import sys
import time

REPLIT_URL = "https://77b2eb61-43f1-42a2-a5c5-6c4ce33fc5a3-00-250d4ddm7qp7e.worf.replit.dev"
OUTPUT_FILE = "poker_ai_system_slim.tar.gz"
EXPECTED_SIZE = 36 * 1024 * 1024  # Approximately 36MB

def calculate_sha256(filename):
    """Calculate SHA256 hash of file"""
    sha256_hash = hashlib.sha256()
    with open(filename, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

def download_file():
    """Download the file directly"""
    print(f"Downloading Poker AI system to {OUTPUT_FILE}...")
    
    try:
        response = requests.get(f"{REPLIT_URL}/download", stream=True)
        
        if not response.ok:
            print(f"Error: Server responded with status code {response.status_code}")
            return False
        
        total_size = int(response.headers.get('content-length', 0))
        if total_size == 0:
            print("Warning: Content length is 0 or not provided")
        
        with open(OUTPUT_FILE, 'wb') as f:
            downloaded = 0
            start_time = time.time()
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    
                    # Print progress
                    if total_size > 0:
                        percent = int(100 * downloaded / total_size)
                        sys.stdout.write(f"\rProgress: {percent}% ({downloaded/1024/1024:.1f} MB)")
                        sys.stdout.flush()
            
            elapsed = time.time() - start_time
            print(f"\nDownload completed in {elapsed:.1f} seconds")
        
        # Verify file size
        file_size = os.path.getsize(OUTPUT_FILE)
        print(f"Downloaded file size: {file_size/1024/1024:.1f} MB")
        
        if file_size < 1024*1024:  # Less than 1MB
            print("Warning: File is too small, likely not downloaded correctly")
            return False
            
        return True
    
    except Exception as e:
        print(f"Error downloading file: {e}")
        return False

def main():
    """Main function"""
    success = download_file()
    
    if success:
        print("\nNext steps:")
        print(f"1. Extract the package: tar -xzf {OUTPUT_FILE}")
        print("2. Install dependencies: cd poker_ai && pip install -r requirements.txt")
        print("3. Run the application: python main.py")
    else:
        print("\nDownload failed.")

if __name__ == "__main__":
    main()