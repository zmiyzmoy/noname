#!/usr/bin/env python3
"""
Admin Dashboard for Poker AI System

This web application provides an administrative interface for managing
the Poker AI training system, including configuration, monitoring,
and management of training sessions.
"""
import os
import json
import logging
import subprocess
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_migrate import Migrate
import psycopg2

# Import database models
from models.database import (
    db, User, HardwareConfig, TrainingConfig, TrainingSession, 
    TrainingMetrics, TrainingLog, TrainingAction, SystemSetting
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('admin_dashboard.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Configure the SQLAlchemy part of the app
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/postgres')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'poker-ai-dashboard-secret-key')

# Initialize database
db.init_app(app)
migrate = Migrate(app, db)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Administrator access required', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

###############################
# Routes
###############################

@app.route('/')
def index():
    """Dashboard home page."""
    if current_user.is_authenticated:
        # Get active training sessions
        active_sessions = TrainingSession.query.filter(
            TrainingSession.status.in_(['pending', 'running']),
            TrainingSession.user_id == current_user.id
        ).all()
        
        # Get recent completed sessions
        completed_sessions = TrainingSession.query.filter(
            TrainingSession.status == 'completed',
            TrainingSession.user_id == current_user.id
        ).order_by(TrainingSession.end_time.desc()).limit(5).all()
        
        # Get hardware configurations
        hardware_configs = HardwareConfig.query.filter_by(user_id=current_user.id).all()
        
        # Get training configurations
        training_configs = TrainingConfig.query.all()
        
        return render_template(
            'dashboard.html',
            active_sessions=active_sessions,
            completed_sessions=completed_sessions,
            hardware_configs=hardware_configs,
            training_configs=training_configs
        )
    return render_template('welcome.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page."""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Log out the current user."""
    logout_user()
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page."""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        new_user = User(
            username=username,
            email=email,
            password=generate_password_hash(password),
            is_admin=False  # Default to regular user
        )
        
        # Make first user an admin
        if User.query.count() == 0:
            new_user.is_admin = True
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

###############################
# Hardware Configuration Routes
###############################

@app.route('/hardware', methods=['GET'])
@login_required
def hardware_configs():
    """List hardware configurations."""
    configs = HardwareConfig.query.filter_by(user_id=current_user.id).all()
    return render_template('hardware/list.html', configs=configs)

@app.route('/hardware/create', methods=['GET', 'POST'])
@login_required
def hardware_create():
    """Create a new hardware configuration."""
    if request.method == 'POST':
        name = request.form.get('name')
        num_cpus = int(request.form.get('num_cpus', 8))
        num_gpus = int(request.form.get('num_gpus', 1))
        gpu_memory = int(request.form.get('gpu_memory', 8))
        cpu_memory = int(request.form.get('cpu_memory', 16))
        gpu_type = request.form.get('gpu_type', 'default')
        use_cuda = 'use_cuda' in request.form
        
        # Create new hardware config
        config = HardwareConfig(
            name=name,
            user_id=current_user.id,
            num_cpus=num_cpus,
            num_gpus=num_gpus,
            gpu_memory=gpu_memory,
            cpu_memory=cpu_memory,
            gpu_type=gpu_type,
            use_cuda=use_cuda
        )
        
        db.session.add(config)
        db.session.commit()
        
        flash(f'Hardware configuration "{name}" created successfully', 'success')
        return redirect(url_for('hardware_configs'))
    
    return render_template('hardware/create.html')

@app.route('/hardware/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
def hardware_edit(config_id):
    """Edit a hardware configuration."""
    config = HardwareConfig.query.get_or_404(config_id)
    
    # Check ownership
    if config.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to edit this configuration', 'danger')
        return redirect(url_for('hardware_configs'))
    
    if request.method == 'POST':
        config.name = request.form.get('name')
        config.num_cpus = int(request.form.get('num_cpus', 8))
        config.num_gpus = int(request.form.get('num_gpus', 1))
        config.gpu_memory = int(request.form.get('gpu_memory', 8))
        config.cpu_memory = int(request.form.get('cpu_memory', 16))
        config.gpu_type = request.form.get('gpu_type', 'default')
        config.use_cuda = 'use_cuda' in request.form
        config.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        flash(f'Hardware configuration "{config.name}" updated successfully', 'success')
        return redirect(url_for('hardware_configs'))
    
    return render_template('hardware/edit.html', config=config)

@app.route('/hardware/<int:config_id>/delete', methods=['POST'])
@login_required
def hardware_delete(config_id):
    """Delete a hardware configuration."""
    config = HardwareConfig.query.get_or_404(config_id)
    
    # Check ownership
    if config.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to delete this configuration', 'danger')
        return redirect(url_for('hardware_configs'))
    
    # Check if it's being used in any active training sessions
    active_sessions = TrainingSession.query.filter_by(
        hardware_config_id=config_id
    ).filter(TrainingSession.status.in_(['pending', 'running'])).first()
    
    if active_sessions:
        flash('Cannot delete configuration that is being used in active training sessions', 'danger')
        return redirect(url_for('hardware_configs'))
    
    db.session.delete(config)
    db.session.commit()
    
    flash(f'Hardware configuration "{config.name}" deleted successfully', 'success')
    return redirect(url_for('hardware_configs'))

###############################
# Training Configuration Routes
###############################

@app.route('/training-configs', methods=['GET'])
@login_required
def training_configs():
    """List training configurations."""
    configs = TrainingConfig.query.all()
    return render_template('training/list.html', configs=configs)

@app.route('/training-configs/create', methods=['GET', 'POST'])
@login_required
def training_config_create():
    """Create a new training configuration."""
    if request.method == 'POST':
        # Extract form data
        name = request.form.get('name')
        game_type = request.form.get('game_type', 'nl_holdem')
        num_players = int(request.form.get('num_players', 6))
        batch_size = int(request.form.get('batch_size', 64))
        learning_rate = float(request.form.get('learning_rate', 0.0001))
        num_episodes = int(request.form.get('num_episodes', 1000))
        stack_size = int(request.form.get('stack_size', 100))
        
        # PSRO and CFR settings
        use_cfr = 'use_cfr' in request.form
        cfr_alternation_freq = int(request.form.get('cfr_alternation_freq', 2))
        cfr_iters_per_step = int(request.form.get('cfr_iters_per_step', 5))
        use_advantage_weighted = 'use_advantage_weighted' in request.form
        use_immediate_cfr = 'use_immediate_cfr' in request.form
        advantage_weight = float(request.form.get('advantage_weight', 0.1))
        
        # Checkpoint settings
        save_interval = int(request.form.get('save_interval', 5))
        eval_interval = int(request.form.get('eval_interval', 10))
        
        # Create new training config
        config = TrainingConfig(
            name=name,
            game_type=game_type,
            num_players=num_players,
            batch_size=batch_size,
            learning_rate=learning_rate,
            num_episodes=num_episodes,
            stack_size=stack_size,
            use_cfr=use_cfr,
            cfr_alternation_freq=cfr_alternation_freq,
            cfr_iters_per_step=cfr_iters_per_step,
            use_advantage_weighted=use_advantage_weighted,
            use_immediate_cfr=use_immediate_cfr,
            advantage_weight=advantage_weight,
            save_interval=save_interval,
            eval_interval=eval_interval
        )
        
        db.session.add(config)
        db.session.commit()
        
        flash(f'Training configuration "{name}" created successfully', 'success')
        return redirect(url_for('training_configs'))
    
    return render_template('training/create.html')

@app.route('/training-configs/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
def training_config_edit(config_id):
    """Edit a training configuration."""
    config = TrainingConfig.query.get_or_404(config_id)
    
    if request.method == 'POST':
        # Extract form data
        config.name = request.form.get('name')
        config.game_type = request.form.get('game_type', 'nl_holdem')
        config.num_players = int(request.form.get('num_players', 6))
        config.batch_size = int(request.form.get('batch_size', 64))
        config.learning_rate = float(request.form.get('learning_rate', 0.0001))
        config.num_episodes = int(request.form.get('num_episodes', 1000))
        config.stack_size = int(request.form.get('stack_size', 100))
        
        # PSRO and CFR settings
        config.use_cfr = 'use_cfr' in request.form
        config.cfr_alternation_freq = int(request.form.get('cfr_alternation_freq', 2))
        config.cfr_iters_per_step = int(request.form.get('cfr_iters_per_step', 5))
        config.use_advantage_weighted = 'use_advantage_weighted' in request.form
        config.use_immediate_cfr = 'use_immediate_cfr' in request.form
        config.advantage_weight = float(request.form.get('advantage_weight', 0.1))
        
        # Checkpoint settings
        config.save_interval = int(request.form.get('save_interval', 5))
        config.eval_interval = int(request.form.get('eval_interval', 10))
        
        config.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        flash(f'Training configuration "{config.name}" updated successfully', 'success')
        return redirect(url_for('training_configs'))
    
    return render_template('training/edit.html', config=config)

@app.route('/training-configs/<int:config_id>/delete', methods=['POST'])
@login_required
def training_config_delete(config_id):
    """Delete a training configuration."""
    config = TrainingConfig.query.get_or_404(config_id)
    
    # Check if it's being used in any active training sessions
    active_sessions = TrainingSession.query.filter_by(
        training_config_id=config_id
    ).filter(TrainingSession.status.in_(['pending', 'running'])).first()
    
    if active_sessions:
        flash('Cannot delete configuration that is being used in active training sessions', 'danger')
        return redirect(url_for('training_configs'))
    
    db.session.delete(config)
    db.session.commit()
    
    flash(f'Training configuration "{config.name}" deleted successfully', 'success')
    return redirect(url_for('training_configs'))

###############################
# Training Session Routes
###############################

@app.route('/training', methods=['GET'])
@login_required
def training_sessions():
    """List training sessions."""
    # Get query parameters for filtering
    status = request.args.get('status')
    
    # Base query
    query = TrainingSession.query.filter_by(user_id=current_user.id)
    
    # Apply filters
    if status:
        query = query.filter_by(status=status)
    
    # Order by creation date, newest first
    sessions = query.order_by(TrainingSession.start_time.desc()).all()
    
    return render_template('sessions/list.html', sessions=sessions)

@app.route('/training/create', methods=['GET', 'POST'])
@login_required
def training_session_create():
    """Create a new training session."""
    hardware_configs = HardwareConfig.query.filter_by(user_id=current_user.id).all()
    training_configs = TrainingConfig.query.all()
    
    if not hardware_configs:
        flash('You need to create a hardware configuration first', 'warning')
        return redirect(url_for('hardware_create'))
    
    if not training_configs:
        flash('You need to create a training configuration first', 'warning')
        return redirect(url_for('training_config_create'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        hardware_config_id = request.form.get('hardware_config_id')
        training_config_id = request.form.get('training_config_id')
        
        # Create new training session
        session = TrainingSession(
            name=name,
            user_id=current_user.id,
            hardware_config_id=hardware_config_id,
            training_config_id=training_config_id,
            status='pending'
        )
        
        db.session.add(session)
        db.session.commit()
        
        flash(f'Training session "{name}" created successfully', 'success')
        return redirect(url_for('training_sessions'))
    
    return render_template(
        'sessions/create.html',
        hardware_configs=hardware_configs,
        training_configs=training_configs
    )

@app.route('/training/<int:session_id>', methods=['GET'])
@login_required
def training_session_detail(session_id):
    """View training session details."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Check ownership
    if session.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to view this session', 'danger')
        return redirect(url_for('training_sessions'))
    
    # Get hardware and training configs
    hardware_config = HardwareConfig.query.get(session.hardware_config_id)
    training_config = TrainingConfig.query.get(session.training_config_id)
    
    # Get metrics snapshots
    metrics = TrainingMetrics.query.filter_by(
        training_session_id=session_id
    ).order_by(TrainingMetrics.iterations_completed).all()
    
    # Get recent logs
    logs = TrainingLog.query.filter_by(
        training_session_id=session_id
    ).order_by(TrainingLog.timestamp.desc()).limit(100).all()
    
    return render_template(
        'sessions/detail.html',
        session=session,
        hardware_config=hardware_config,
        training_config=training_config,
        metrics=metrics,
        logs=logs
    )

@app.route('/training/<int:session_id>/start', methods=['POST'])
@login_required
def training_session_start(session_id):
    """Start a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Check ownership
    if session.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to start this session', 'danger')
        return redirect(url_for('training_sessions'))
    
    if session.status != 'pending':
        flash('Only pending sessions can be started', 'warning')
        return redirect(url_for('training_session_detail', session_id=session_id))
    
    # Get related configs
    training_config = TrainingConfig.query.get(session.training_config_id)
    hardware_config = HardwareConfig.query.get(session.hardware_config_id)
    
    # Build command to start training
    command = ['python', 'cloud_trainer.py', '--mode', 'train']
    
    # Add training configuration parameters
    command.extend(['--num_episodes', str(training_config.num_episodes)])
    command.extend(['--num_iterations', str(100)])  # Default to 100 iterations
    command.extend(['--save_interval', str(training_config.save_interval)])
    command.extend(['--eval_interval', str(training_config.eval_interval)])
    command.extend(['--game_config', str(training_config.game_type)])
    command.extend(['--stack_size', str(training_config.stack_size)])
    
    # Add hardware configuration parameters
    command.extend(['--num_workers', str(hardware_config.num_cpus)])
    
    # Add CFR parameters if enabled
    if training_config.use_cfr:
        command.append('--use_cfr')
        command.extend(['--cfr_alternation_freq', str(training_config.cfr_alternation_freq)])
        command.extend(['--cfr_iters_per_step', str(training_config.cfr_iters_per_step)])
        
        if training_config.use_advantage_weighted:
            command.append('--use_advantage_weighted')
        
        if training_config.use_immediate_cfr:
            command.append('--use_immediate_cfr')
        
        command.extend(['--advantage_weight', str(training_config.advantage_weight)])
    
    # Add verbose flag
    command.append('--verbose')
    
    # Set unique checkpoint directory
    checkpoint_dir = f'./poker/checkpoints/{session_id}'
    os.makedirs(checkpoint_dir, exist_ok=True)
    command.extend(['--checkpoint_dir', checkpoint_dir])
    session.checkpoint_path = checkpoint_dir
    
    # Update session status
    session.status = 'running'
    
    # Create initial log entry
    log = TrainingLog(
        training_session_id=session_id,
        level='INFO',
        message=f'Starting training session with command: {" ".join(command)}'
    )
    db.session.add(log)
    db.session.commit()
    
    # TODO: In production, should start this asynchronously
    # For demo purposes, we'll just show the command
    flash(f'Started training with command: {" ".join(command)}', 'success')
    
    return redirect(url_for('training_session_detail', session_id=session_id))

@app.route('/training/<int:session_id>/stop', methods=['POST'])
@login_required
def training_session_stop(session_id):
    """Stop a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Check ownership
    if session.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to stop this session', 'danger')
        return redirect(url_for('training_sessions'))
    
    if session.status != 'running':
        flash('Only running sessions can be stopped', 'warning')
        return redirect(url_for('training_session_detail', session_id=session_id))
    
    # In a real system, you would need to stop the actual training process
    # For demo purposes, we'll just update the status
    session.status = 'completed'
    session.end_time = datetime.utcnow()
    
    # Create log entry
    log = TrainingLog(
        training_session_id=session_id,
        level='INFO',
        message='Training session stopped by user'
    )
    db.session.add(log)
    db.session.commit()
    
    flash('Training session stopped successfully', 'success')
    return redirect(url_for('training_session_detail', session_id=session_id))

@app.route('/training/<int:session_id>/delete', methods=['POST'])
@login_required
def training_session_delete(session_id):
    """Delete a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Check ownership
    if session.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to delete this session', 'danger')
        return redirect(url_for('training_sessions'))
    
    if session.status == 'running':
        flash('Cannot delete running session. Please stop it first.', 'danger')
        return redirect(url_for('training_session_detail', session_id=session_id))
    
    # Delete related metrics and logs
    TrainingMetrics.query.filter_by(training_session_id=session_id).delete()
    TrainingLog.query.filter_by(training_session_id=session_id).delete()
    TrainingAction.query.filter_by(training_session_id=session_id).delete()
    
    db.session.delete(session)
    db.session.commit()
    
    flash('Training session deleted successfully', 'success')
    return redirect(url_for('training_sessions'))

###############################
# API Routes
###############################

@app.route('/api/metrics/<int:session_id>', methods=['GET'])
@login_required
def api_get_metrics(session_id):
    """Get metrics for a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Check ownership
    if session.user_id != current_user.id and not current_user.is_admin:
        return jsonify({'error': 'Permission denied'}), 403
    
    return jsonify(session.get_metrics())

@app.route('/api/metrics/<int:session_id>', methods=['POST'])
def api_update_metrics(session_id):
    """Update metrics for a training session (called by training script)."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # In production, would need proper authentication
    # For demo, allow any updates
    
    data = request.json
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    # Update session metrics
    session.update_metrics(data)
    
    # Create a metrics record if iteration is provided
    if 'iteration' in data:
        metrics = TrainingMetrics(
            training_session_id=session_id,
            iterations_completed=data['iteration'],
            win_rate=data.get('win_rate'),
            exploitability=data.get('exploitability'),
            avg_reward=data.get('reward'),
            total_loss=data.get('loss'),
            episodes_completed=data.get('episodes_completed')
        )
        db.session.add(metrics)
    
    db.session.commit()
    
    return jsonify({'success': True})

@app.route('/api/logs/<int:session_id>', methods=['POST'])
def api_add_log(session_id):
    """Add a log entry for a training session (called by training script)."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # In production, would need proper authentication
    # For demo, allow any updates
    
    data = request.json
    if not data or 'message' not in data:
        return jsonify({'error': 'No message provided'}), 400
    
    log = TrainingLog(
        training_session_id=session_id,
        level=data.get('level', 'INFO'),
        message=data['message']
    )
    
    db.session.add(log)
    db.session.commit()
    
    return jsonify({'success': True})

###############################
# System Settings Routes
###############################

@app.route('/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def system_settings():
    """Manage system settings."""
    if request.method == 'POST':
        # Process form data to update settings
        for key, value in request.form.items():
            if key.startswith('setting_'):
                setting_key = key.replace('setting_', '')
                setting = SystemSetting.query.filter_by(key=setting_key).first()
                
                if setting:
                    setting.value = value
                else:
                    # Create new setting
                    setting = SystemSetting(key=setting_key, value=value)
                    db.session.add(setting)
        
        db.session.commit()
        flash('System settings updated successfully', 'success')
        return redirect(url_for('system_settings'))
    
    # Get all settings
    settings = SystemSetting.query.all()
    
    # Group settings by category
    general_settings = []
    training_settings = []
    monitoring_settings = []
    
    for setting in settings:
        if setting.key.startswith('general_'):
            general_settings.append(setting)
        elif setting.key.startswith('training_'):
            training_settings.append(setting)
        elif setting.key.startswith('monitoring_'):
            monitoring_settings.append(setting)
    
    return render_template(
        'settings/index.html',
        general_settings=general_settings,
        training_settings=training_settings,
        monitoring_settings=monitoring_settings
    )

###############################
# Monitor Routes 
###############################

@app.route('/monitor', methods=['GET'])
@login_required
def monitoring_dashboard():
    """Show the monitoring dashboard."""
    active_sessions = TrainingSession.query.filter(
        TrainingSession.status == 'running'
    ).all()
    
    return render_template('monitor/dashboard.html', active_sessions=active_sessions)

@app.route('/monitor/<int:session_id>', methods=['GET'])
@login_required
def session_monitor(session_id):
    """Monitor a specific training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Check ownership
    if session.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to monitor this session', 'danger')
        return redirect(url_for('monitoring_dashboard'))
    
    return render_template('monitor/session.html', session=session)

###############################
# Main
###############################

def create_admin_user():
    """Create an admin user if no users exist."""
    if User.query.count() == 0:
        admin = User(
            username='admin',
            email='admin@pokerai.local',
            password=generate_password_hash('admin'),  # Change this in production!
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
        logger.info('Created default admin user')

def create_default_configs():
    """Create default configurations if none exist."""
    # Default training config
    if TrainingConfig.query.count() == 0:
        default_config = TrainingConfig(
            name='Default PSRO-CFR Config',
            game_type='6max_nlh',
            num_players=6,
            batch_size=64,
            learning_rate=0.0001,
            num_episodes=1000,
            stack_size=100,
            use_cfr=True,
            cfr_alternation_freq=2,
            cfr_iters_per_step=5,
            use_advantage_weighted=True,
            use_immediate_cfr=True,
            advantage_weight=0.1,
            save_interval=5,
            eval_interval=10
        )
        db.session.add(default_config)
        db.session.commit()
        logger.info('Created default training configuration')

if __name__ == '__main__':
    with app.app_context():
        # Create database tables
        try:
            db.create_all()
            create_admin_user()
            create_default_configs()
            logger.info('Database initialized successfully')
        except Exception as e:
            logger.error(f'Error initializing database: {e}')
        
    app.run(host='0.0.0.0', port=5001, debug=True)