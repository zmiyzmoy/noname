# Poker AI System - Transfer and Migration Guide

This consolidated guide explains how to download, transfer, and migrate your Poker AI system between servers.

## Table of Contents
- [Downloading from Replit](#downloading-from-replit)
- [Server Transfer Toolkit](#server-transfer-toolkit)
- [Manual Transfer Method](#manual-transfer-method)
- [Configuration After Transfer](#configuration-after-transfer)
- [Troubleshooting](#troubleshooting)

## Downloading from Replit

### Method 1: Using Replit's "Download as Zip" Feature

The easiest way to download all project files from Replit is to use the built-in "Download as Zip" feature:

1. In the Replit interface, locate the three dots menu (...) in the top-right corner of the Files panel
2. Click on the menu and select "Download as Zip"
3. Save the zip file to your computer
4. Upload the zip file to your server using SCP, SFTP, or another file transfer method
5. Extract the files on your server:
   ```bash
   unzip poker_ai_system.zip -d ~/poker_ai
   ```

### Method 2: Manual Download of Core Files

If the download zip feature doesn't work or you prefer to download only the essential files, refer to the list in CORE_FILES.md for the critical files you need to transfer.

## Server Transfer Toolkit

The Server Transfer Toolkit provides a streamlined process for transferring your Poker AI system to a new server.

### Overview

The Server Transfer Toolkit handles:

1. Creating a deployment package with all necessary files
2. Configuring your target server
3. Transferring files to the target server
4. Deploying the system on the target server

### Requirements

#### Source Server
- Poker AI system installed and working
- Access to terminal/command line
- Internet connection

#### Target Server
- Python 3.8 or higher
- PostgreSQL database
- SSH access
- Sufficient disk space (at least 1GB)

### Using the Web Interface

1. Access the main web interface at http://your_server:5010/
2. Navigate to the "Server Transfer" page in the menu
3. Follow the on-screen instructions:
   - Click "Create Package" to generate a deployment package
   - Download the package using the provided link
   - Follow the instructions for transferring to your new server

### Using the Command Line

#### Step 1: Create a deployment package

```bash
python server_transfer_toolkit.py pack
```

This will create a file named `poker_ai_system_YYYYMMDDHHMMSS.tar.gz` in the current directory.

#### Step 2: Transfer the package to your new server

Use SCP or another file transfer method:

```bash
scp poker_ai_system_YYYYMMDDHHMMSS.tar.gz username@new_server_ip:~/
```

#### Step 3: Extract and configure on the new server

On the new server:

```bash
# Extract the files
mkdir -p ~/poker_ai
tar -xzf poker_ai_system_YYYYMMDDHHMMSS.tar.gz -C ~/poker_ai
cd ~/poker_ai

# Run the setup script
./setup.sh
```

## Manual Transfer Method

If you prefer to manually transfer files or the automated tools aren't working:

### Step 1: Identify Essential Files

The core files needed for the system to function are:
- Python source files (*.py)
- Templates directory
- Static directory
- Requirements file (requirements.txt)
- Configuration files (*.json)
- Deployment scripts (*.sh)

### Step 2: Create a Manual Package

```bash
tar -czf manual_poker_ai.tar.gz --exclude="*.log" --exclude="__pycache__" --exclude="venv" --exclude=".git" .
```

### Step 3: Transfer and Extract

Transfer the package to your new server and extract it:

```bash
scp manual_poker_ai.tar.gz username@new_server_ip:~/
ssh username@new_server_ip
mkdir -p ~/poker_ai
tar -xzf manual_poker_ai.tar.gz -C ~/poker_ai
cd ~/poker_ai
```

### Step 4: Set Up Environment

Follow the steps in [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) to set up your environment, database, and services.

## Configuration After Transfer

After transferring to your server, you'll need to modify these key configuration settings:

### 1. Database URL

Update any database connection strings to match your server's PostgreSQL setup:

```bash
export DATABASE_URL="postgresql://yourusername:yourpassword@localhost/yourdbname"
```

Add this to your `.bashrc` or `.profile` for persistence:

```bash
echo 'export DATABASE_URL="postgresql://yourusername:yourpassword@localhost/yourdbname"' >> ~/.bashrc
source ~/.bashrc
```

### 2. Port Bindings

Make sure to bind to 0.0.0.0 instead of localhost to make services accessible from other machines:

```python
# In main.py and other server files
app.run(host="0.0.0.0", port=5010)
```

### 3. Server IP

Update any hardcoded URLs to use your server's IP address or domain name.

### 4. Security Settings

1. Make sure to change the default admin password (pokeradmin/pokerpwd123) immediately after setup:
   ```bash
   python create_new_admin.py
   ```

2. Set secure passwords for your database

3. Consider setting up a firewall to restrict access to the necessary ports only:
   ```bash
   sudo ufw allow ssh
   sudo ufw allow 80/tcp
   sudo ufw allow 5010/tcp
   sudo ufw enable
   ```

## Troubleshooting

### Package Creation Issues

If you encounter issues creating the deployment package:

```bash
# Check disk space
df -h

# Try creating a smaller package with only essential files
python server_transfer_toolkit.py pack --minimal
```

### Transfer Issues

If you have problems transferring files:

```bash
# Check connectivity
ping new_server_ip

# Try alternative transfer method
rsync -avz --progress poker_ai_system_YYYYMMDDHHMMSS.tar.gz username@new_server_ip:~/
```

### Deployment Issues

If you encounter issues deploying on the new server:

1. Check the logs:
   ```bash
   cat deployment.log
   ```

2. Try manual installation steps:
   ```bash
   pip install -r requirements.txt
   python create_new_admin.py
   python main.py
   ```

3. Verify database connection:
   ```bash
   python -c "import psycopg2; conn=psycopg2.connect('$DATABASE_URL'); print('Connection successful')"
   ```

### Testing After Deployment

After deploying, test the system by:

1. Running the test script:
   ```bash
   python test_all_components.py
   ```

2. Starting the onboarding wizard:
   ```bash
   python run_onboarding_wizard.py --web --port 5060
   ```

3. Verifying the main application works:
   ```bash
   python main.py
   ```

## Database Migration

To migrate your database data between servers:

### Export data from source server:
```bash
pg_dump -U postgres -d poker_ai > poker_ai_data.sql
```

### Import data to target server:
```bash
psql -U postgres -d poker_ai < poker_ai_data.sql
```

## Model Checkpoints Transfer

To transfer trained model checkpoints:

1. Identify checkpoint files:
   ```bash
   find . -name "*.pt" -o -name "*.checkpoint"
   ```

2. Create a separate archive for checkpoints:
   ```bash
   tar -czf model_checkpoints.tar.gz checkpoints/
   ```

3. Transfer and extract on the target server:
   ```bash
   scp model_checkpoints.tar.gz username@new_server_ip:~/poker_ai/
   ssh username@new_server_ip "cd ~/poker_ai && tar -xzf model_checkpoints.tar.gz"
   ```