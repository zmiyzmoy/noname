# Poker AI with PSRO

A reinforcement learning system for training poker AI using Policy Space Response Oracles (PSRO) with PyTorch and OpenSpiel. This AI model can learn No-Limit Texas Hold'em strategies through self-play.

## Documentation Overview

This project now has consolidated documentation for easier navigation. Please refer to these guides:

- [Deployment Guide](DEPLOYMENT_GUIDE.md) - Complete instructions for installing and setting up the system
- [Transfer Guide](TRANSFER_GUIDE.md) - Instructions for downloading and transferring the system between servers
- [Command Reference](COMMAND_REFERENCE.md) - Comprehensive list of commands for all system operations
- [System Guide](SYSTEM_GUIDE.md) - Details of system architecture, core files, and functions
- [Testing Guide](TESTING_GUIDE.md) - How to test the system and interpret results
- [Documentation Guide](DOCUMENTATION_GUIDE.md) - Overview of all documentation in this project

## Features

- **PSRO Algorithm Implementation**: Policy Space Response Oracles for discovering effective poker strategies
- **Neural Network Architecture**: Deep neural networks for strategy and regret modeling
- **Cloud Optimized**: Scripts for training on Google Cloud A100 GPUs with spot instance support
- **Checkpointing**: Built-in checkpointing for graceful recovery from spot instance preemption
- **JSON Interface**: Interface for using the trained model via JSON input/output
- **Enhanced Opponent Modeling**: Track opponent tendencies like VPIP, PFR, and street-specific aggression
- **Advanced Analytics**: 
  - Comprehensive metrics tracking and visualization tools
  - Animated learning curves with milestone markers
  - Position-based win rate analysis
  - Learning plateau detection
- **CFR+ Integration**:
  - Hybrid PSRO-CFR learning algorithm combining deep learning with tabular methods
  - Advantage-weighted regret updates for faster convergence
  - Immediate counterfactual regret calculation for more stable learning
  - Neural network mapping to abstract information states
  - Adaptive strategy refinement through subgame solving
- **Web Monitoring Interface**:
  - Real-time training progress visualization in your browser
  - Live metrics tracking with charts and graphs
  - No complex port forwarding required
  - Automatic template generation for easy customization
- **Admin Dashboard**:
  - User authentication and multi-user support
  - Hardware monitoring and resource allocation
  - Training configuration management
  - Session history and metrics storage

## Quick Start

### Option 1: Web-Based Onboarding Wizard (Recommended)

For new users, the easiest way to get started is with the onboarding wizard:

```bash
python run_onboarding_wizard.py --web --port 5060
```

Then open your browser to http://localhost:5060 and follow the guided setup process.

### Option 2: Automatic Deployment Script

```bash
# Make the script executable
chmod +x deploy_poker_ai.sh

# Install dependencies and set up the system
sudo ./deploy_poker_ai.sh install

# Start the system
sudo ./deploy_poker_ai.sh start
```

### Option 3: Manual Setup

1. Install required Python packages:
   ```bash
   pip install -r requirements.txt
   ```

2. Set up the database:
   ```bash
   export DATABASE_URL="postgresql://username:password@localhost/poker_ai"
   ```

3. Create an admin user:
   ```bash
   python create_new_admin.py
   ```

4. Start the main Flask application:
   ```bash
   python main.py
   ```

## Web Interfaces

Once installed, you can access these web interfaces:

- **Main Dashboard**: http://localhost:5010/ - Consolidated interface with access to all features
- **Training Dashboard**: http://localhost:5003/ - Web-based training menu
- **Monitoring Dashboard**: http://localhost:5000/ - Real-time training monitoring
- **Admin Dashboard**: http://localhost:5002/ - Advanced administration interface

## Basic Commands

```bash
# Start basic training
python poker_rl.py --mode train --num_episodes 100 --num_iterations 10

# Run self-play demonstration
python poker_rl.py --mode selfplay --num_episodes 5 --verbose

# Evaluate against opponents
python poker_rl.py --mode eval --num_episodes 50 --eval_opponents random,tight_aggressive
```

See [COMMAND_REFERENCE.md](COMMAND_REFERENCE.md) for a complete list of commands.

## System Architecture

The poker AI system consists of several integrated components:

1. **Core AI Engine**: Deep reinforcement learning implementation using Policy Space Response Oracles (PSRO)
2. **Training Infrastructure**: Distributed training with Ray parallelism
3. **Web Interfaces**: Multiple Flask-based dashboards for control and monitoring
4. **Database Layer**: PostgreSQL database for configuration and results storage
5. **Visualization Tools**: TensorBoard integration for metrics visualization

See [SYSTEM_GUIDE.md](SYSTEM_GUIDE.md) for more details about the system architecture.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- OpenSpiel team for the game environment
- PyTorch team for the deep learning framework
- The poker AI research community