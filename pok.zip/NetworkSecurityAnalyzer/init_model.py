import os
import logging
import torch
import torch.optim as optim
from models import Config, RegretNet, StrategyNet, StateProcessor
from environment import TabularPolicy
import pyspiel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('init_model.log'),
        logging.StreamHandler()
    ]
)

def main():
    """Initialize and save a basic model for the PSRO algorithm."""
    # Initialize configuration without parsing arguments which might time out
    config = Config()
    config.NUM_EPISODES = 1  # Minimize work
    config.GAME_NAME = "kuhn_poker()"  # Use simple game for initialization
    
    # Override paths to avoid disturbing production models
    config.MODEL_PATH = "./poker/models/psro_model_new.pt"
    
    # Create directories
    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)
    
    # Use a fixed state size to avoid loading large state processor
    STATE_SIZE = 77  # Known size from logs
    
    # Initialize device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device: {device}")
    
    # Load game (simple game to avoid timeout)
    game = pyspiel.load_game(config.GAME_NAME)
    num_actions = 4  # Fixed for poker
    logging.info(f"Using {num_actions} distinct actions")
    
    # Initialize models directly with known state size
    regret_net = RegretNet(STATE_SIZE, num_actions).to(device)
    strategy_net = StrategyNet(STATE_SIZE, num_actions).to(device)
    
    # Initialize optimizers
    regret_optimizer = optim.Adam(regret_net.parameters(), lr=config.LEARNING_RATE)
    strategy_optimizer = optim.Adam(strategy_net.parameters(), lr=config.LEARNING_RATE)
    
    # Save models
    checkpoint = {
        'epoch': 0,
        'regret_net_state_dict': regret_net.state_dict(),
        'strategy_net_state_dict': strategy_net.state_dict(),
        'regret_optimizer_state_dict': regret_optimizer.state_dict(),
        'strategy_optimizer_state_dict': strategy_optimizer.state_dict(),
        'strategy_pool': [TabularPolicy(game).serialize()],
        'meta_strategies': [1.0]
    }
    
    # Save to checkpoint files
    torch.save(checkpoint, config.MODEL_PATH)
    torch.save(checkpoint, config.MODEL_PATH + ".final")
    torch.save(checkpoint, config.MODEL_PATH + ".best")
    
    # Also save to original paths to support old code
    torch.save(checkpoint, "./poker/models/psro_model.pt")
    torch.save(checkpoint, "./poker/models/psro_model.pt.final")
    torch.save(checkpoint, "./poker/models/psro_model.pt.best")
    
    logging.info(f"Initial models saved successfully")
    
    return True

if __name__ == "__main__":
    main()