#!/bin/bash
# This script will create a base64-encoded version of the package that can be copied and pasted

echo "Creating base64 encoded chunks of the Poker AI system..."
rm -f chunks_*.txt 2>/dev/null

# Create 1MB (approx.) sized chunks of base64 content
split -b 1M <(base64 poker_ai_system_slim.tar.gz) chunks_

# Count the total chunks
TOTAL_CHUNKS=$(ls chunks_* | wc -l)

for i in chunks_*; do
  echo "# CHUNK: $i ($(du -h $i | cut -f1))"
  echo ""
  cat $i
  echo ""
  echo ""
done

echo "# INSTRUCTIONS: Copy all the chunks above and save them to a file on your A100 server."
echo "# Then run this command on your A100 server to decode and extract:"
echo ""
echo 'cat chunks_file.txt | grep -v "^#" | base64 -d > poker_ai_system_slim.tar.gz'
echo 'tar -xzf poker_ai_system_slim.tar.gz'
echo 'cd poker_ai_system_slim'
echo 'pip install -r requirements.txt'
echo 'python main.py'