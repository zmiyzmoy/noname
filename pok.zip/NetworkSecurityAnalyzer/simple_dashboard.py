import os
import logging
from datetime import datetime

from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.declarative import declarative_base
from flask_migrate import Migrate

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('admin_dashboard.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Configure the SQLAlchemy part of the app
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/postgres')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'poker-ai-dashboard-secret-key')

# Initialize database
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Define models
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<User {self.username}>'

class SystemSetting(db.Model):
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, 
                         onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'

# Routes
@app.route('/')
def index():
    """Dashboard home page."""
    return jsonify({
        'status': 'success',
        'message': 'Admin Dashboard API is running'
    })

@app.route('/api/users')
def list_users():
    """List all users."""
    users = User.query.all()
    return jsonify({
        'users': [{'id': user.id, 'username': user.username, 'email': user.email, 'is_admin': user.is_admin} 
                 for user in users]
    })

@app.route('/api/settings')
def list_settings():
    """List all settings."""
    settings = SystemSetting.query.all()
    return jsonify({
        'settings': [{'id': setting.id, 'key': setting.key, 'value': setting.value} 
                    for setting in settings]
    })

@app.route('/api/settings/add/<key>/<value>')
def add_setting(key, value):
    """Add a system setting."""
    setting = SystemSetting.query.filter_by(key=key).first()
    
    if setting:
        setting.value = value
        message = f"Updated setting '{key}'"
    else:
        setting = SystemSetting(key=key, value=value, description=f"Added via API at {datetime.utcnow()}")
        db.session.add(setting)
        message = f"Added new setting '{key}'"
    
    db.session.commit()
    return jsonify({
        'status': 'success',
        'message': message,
        'setting': {'id': setting.id, 'key': setting.key, 'value': setting.value}
    })

def create_admin_user():
    """Create an admin user if no users exist."""
    if User.query.count() == 0:
        admin = User(
            username='admin',
            email='admin@pokerai.local',
            password='admin',  # Change this in production!
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
        logger.info('Created default admin user')

if __name__ == '__main__':
    with app.app_context():
        # Create database tables
        try:
            db.create_all()
            create_admin_user()
            logger.info('Database initialized successfully')
        except Exception as e:
            logger.error(f'Error initializing database: {e}')
        
    app.run(host='0.0.0.0', port=5002, debug=True)