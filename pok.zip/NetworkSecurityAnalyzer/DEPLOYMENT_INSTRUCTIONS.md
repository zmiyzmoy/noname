# Poker AI System Deployment Instructions

This document provides step-by-step instructions for deploying the Poker AI system to your server.

## Prerequisites

Your server should have:
- Python 3.10 or later
- PostgreSQL database
- Git (for cloning the repository)
- Basic Linux command-line knowledge

## Step 1: Prepare Your Server

1. Update your package lists:
   ```
   sudo apt update
   sudo apt upgrade -y
   ```

2. Install required system dependencies:
   ```
   sudo apt install -y python3-pip python3-dev libpq-dev postgresql postgresql-contrib nginx
   sudo apt install -y build-essential cmake
   ```

3. Create a directory for the project:
   ```
   mkdir -p ~/poker_ai
   cd ~/poker_ai
   ```

## Step 2: Clone or Upload the Code

### Option 1: Clone from Git (if you have a repository)
```
git clone [your-repository-url] .
```

### Option 2: Manual Upload
1. Download the files from your Replit project
2. Upload them to your server using SCP, SFTP, or another file transfer method:
   ```
   scp -r /path/to/local/poker_ai user@your-server:~/poker_ai
   ```

## Step 3: Set Up Python Environment

1. Create a virtual environment:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```

2. Install Python dependencies:
   ```
   pip install -r requirements.txt
   ```

   If no requirements.txt exists, install the packages manually:
   ```
   pip install torch>=2.0.0 numpy>=1.20.0 matplotlib>=3.5.0 flask>=2.0.0 flask-login>=0.6.0 flask-sqlalchemy>=3.0.0 flask-migrate>=3.0.0 gunicorn>=20.1.0 dash>=2.0.0 dash-bootstrap-components>=1.0.0 psycopg2-binary>=2.9.0 scikit-learn>=1.0.0 scipy>=1.7.0 tensorboard>=2.8.0 plotly>=5.0.0 open-spiel>=1.0.0 ray>=2.0.0 tqdm>=4.60.0 werkzeug>=2.0.0 joblib>=1.0.0 psutil>=5.9.0 pynvml>=11.0.0 requests>=2.27.0 imageio>=2.15.0
   ```

## Step 4: Set Up the Database

1. Log in to PostgreSQL:
   ```
   sudo -u postgres psql
   ```

2. Create a database and user:
   ```sql
   CREATE DATABASE poker_ai;
   CREATE USER pokeradmin WITH PASSWORD 'your_secure_password';
   ALTER ROLE pokeradmin SET client_encoding TO 'utf8';
   ALTER ROLE pokeradmin SET default_transaction_isolation TO 'read committed';
   ALTER ROLE pokeradmin SET timezone TO 'UTC';
   GRANT ALL PRIVILEGES ON DATABASE poker_ai TO pokeradmin;
   \q
   ```

3. Set the database URL as an environment variable:
   ```
   export DATABASE_URL="postgresql://pokeradmin:your_secure_password@localhost/poker_ai"
   ```

   For persistence, add to your .bashrc or create an environment file:
   ```
   echo 'export DATABASE_URL="postgresql://pokeradmin:your_secure_password@localhost/poker_ai"' >> ~/.bashrc
   ```

## Step 5: Initialize the Database

1. Run the database initialization script:
   ```
   python create_new_admin.py
   ```

## Step 6: Run the Onboarding Wizard

1. Start the onboarding wizard to complete the setup:
   ```
   python run_onboarding_wizard.py --web --port 5060
   ```

2. Open your browser and navigate to `http://your-server-ip:5060` to complete the setup.

## Step 7: Deploy for Production

### Using Screen or tmux
For a simple deployment, you can use screen or tmux:

```
# Install screen if not already installed
sudo apt install -y screen

# Create a new screen session
screen -S poker_ai

# Run the consolidated app
python main.py

# Detach from screen with Ctrl+A, then D
```

### Using Systemd for Service Management
For a more robust setup:

1. Create a systemd service file:
   ```
   sudo nano /etc/systemd/system/poker-ai.service
   ```

2. Add the following content:
   ```
   [Unit]
   Description=Poker AI System
   After=network.target

   [Service]
   User=your_username
   Group=your_group
   WorkingDirectory=/home/your_username/poker_ai
   Environment="PATH=/home/your_username/poker_ai/venv/bin"
   Environment="DATABASE_URL=postgresql://pokeradmin:your_secure_password@localhost/poker_ai"
   ExecStart=/home/your_username/poker_ai/venv/bin/python main.py

   [Install]
   WantedBy=multi-user.target
   ```

3. Enable and start the service:
   ```
   sudo systemctl enable poker-ai
   sudo systemctl start poker-ai
   ```

### Using Nginx as a Reverse Proxy
To expose your application through standard ports:

1. Create an Nginx configuration file:
   ```
   sudo nano /etc/nginx/sites-available/poker-ai
   ```

2. Add the following configuration:
   ```
   server {
       listen 80;
       server_name your_domain_or_ip;

       location / {
           proxy_pass http://localhost:5010;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```

3. Enable the site and restart Nginx:
   ```
   sudo ln -s /etc/nginx/sites-available/poker-ai /etc/nginx/sites-enabled
   sudo nginx -t
   sudo systemctl restart nginx
   ```

## Step 8: Access Your Application

1. Open your browser and navigate to either:
   - `http://your-server-ip:5010` (direct access)
   - `http://your-server-ip` or `http://your-domain` (if using Nginx)

2. Log in with the admin credentials created during setup.

## Troubleshooting

- **PostgreSQL connection issues**: Make sure the DATABASE_URL environment variable is set correctly.
- **Missing dependencies**: Check the requirements.txt file and ensure all dependencies are installed.
- **Port already in use**: Change the port numbers in the configuration files.
- **Permission errors**: Ensure your user has the necessary permissions to run the application.

For detailed logs, check:
- `poker_rl.log` - For training logs
- `flask_app.log` - For web interface logs
- `monitoring.log` - For monitoring service logs
- `web_onboarding_wizard.log` - For onboarding wizard logs

## Backup Strategy

Regularly backup your database and model files:

```
# Database backup
pg_dump -U pokeradmin poker_ai > poker_ai_backup_$(date +"%Y%m%d").sql

# Files backup
tar -czf poker_ai_files_backup_$(date +"%Y%m%d").tar.gz /path/to/poker_ai
```

## Security Considerations

1. **Firewall**: Restrict access to the necessary ports only.
2. **HTTPS**: Consider setting up HTTPS with Let's Encrypt for production.
3. **Authentication**: Change the default admin password immediately.
4. **Database**: Use a strong password and restrict database access.