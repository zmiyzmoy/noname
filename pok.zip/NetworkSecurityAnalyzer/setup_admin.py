import os
import sys
import logging
import json
from datetime import datetime
from werkzeug.security import generate_password_hash
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Configure the SQLAlchemy part of the app
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/postgres')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'poker-ai-dashboard-secret-key'

# Initialize database
db = SQLAlchemy(app)

# Define models
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    hardware_configs = db.relationship('HardwareConfig', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<User {self.username}>'

class HardwareConfig(db.Model):
    """Hardware configuration for training sessions."""
    __tablename__ = 'hardware_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    num_cpus = db.Column(db.Integer, default=8)
    num_gpus = db.Column(db.Integer, default=1)
    gpu_memory = db.Column(db.Integer, default=8)
    cpu_memory = db.Column(db.Integer, default=16)
    gpu_type = db.Column(db.String(50), default='default')
    use_cuda = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<HardwareConfig {self.name}>'

class TrainingConfig(db.Model):
    """Training configuration for AI models."""
    __tablename__ = 'training_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    game_type = db.Column(db.String(50), default='nl_holdem')
    num_players = db.Column(db.Integer, default=6)
    batch_size = db.Column(db.Integer, default=64)
    learning_rate = db.Column(db.Float, default=0.0001)
    num_episodes = db.Column(db.Integer, default=1000)
    stack_size = db.Column(db.Integer, default=100)
    use_cfr = db.Column(db.Boolean, default=True)
    cfr_alternation_freq = db.Column(db.Integer, default=2)
    cfr_iters_per_step = db.Column(db.Integer, default=5)
    use_advantage_weighted = db.Column(db.Boolean, default=True)
    use_immediate_cfr = db.Column(db.Boolean, default=True)
    advantage_weight = db.Column(db.Float, default=0.1)
    save_interval = db.Column(db.Integer, default=5)
    eval_interval = db.Column(db.Integer, default=10)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<TrainingConfig {self.name}>'

class TrainingSession(db.Model):
    """Training session record."""
    __tablename__ = 'training_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    hardware_config_id = db.Column(db.Integer, db.ForeignKey('hardware_configs.id'))
    training_config_id = db.Column(db.Integer, db.ForeignKey('training_configs.id'))
    status = db.Column(db.String(20), default='pending')  # pending, running, completed, failed
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    total_episodes = db.Column(db.Integer, default=0)
    win_rate = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    hardware_config = db.relationship('HardwareConfig')
    training_config = db.relationship('TrainingConfig')
    training_metrics = db.relationship('TrainingMetrics', backref='training_session', lazy=True)
    
    def __repr__(self):
        return f'<TrainingSession {self.name}>'

class TrainingMetrics(db.Model):
    """Metrics collected during training."""
    __tablename__ = 'training_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('training_sessions.id'))
    episode = db.Column(db.Integer)
    win_rate = db.Column(db.Float)
    loss = db.Column(db.Float)
    exploration_rate = db.Column(db.Float)
    avg_reward = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<TrainingMetrics session={self.session_id} episode={self.episode}>'

class SystemSetting(db.Model):
    """System-wide settings."""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'

class HardwareMetrics(db.Model):
    """Hardware metrics for system monitoring."""
    __tablename__ = 'hardware_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    session_id = db.Column(db.Integer, db.ForeignKey('training_sessions.id'), nullable=True)
    
    # CPU metrics
    cpu_usage = db.Column(db.Float, default=0.0)  # Percentage (0-100)
    cpu_temperature = db.Column(db.Float, nullable=True)  # Celsius
    
    # Memory metrics
    memory_total = db.Column(db.Float, default=0.0)  # GB
    memory_used = db.Column(db.Float, default=0.0)  # GB
    memory_utilization = db.Column(db.Float, default=0.0)  # Percentage (0-100)
    
    # GPU metrics
    gpu_count = db.Column(db.Integer, default=0)
    gpu_utilization = db.Column(db.Float, default=0.0)  # Average utilization across GPUs (0-100)
    gpu_memory_total = db.Column(db.Float, default=0.0)  # Total memory across all GPUs (GB)
    gpu_memory_used = db.Column(db.Float, default=0.0)  # Used memory across all GPUs (GB)
    gpu_temperature = db.Column(db.Float, nullable=True)  # Average temperature across GPUs (Celsius)
    
    # Disk metrics
    disk_total = db.Column(db.Float, default=0.0)  # GB
    disk_used = db.Column(db.Float, default=0.0)  # GB
    disk_utilization = db.Column(db.Float, default=0.0)  # Percentage (0-100)
    
    # Raw metrics JSON for detailed analysis
    raw_metrics = db.Column(db.JSON, nullable=True)
    
    # Optimization recommendations
    recommendations = db.Column(db.JSON, nullable=True)
    
    # Reference to training session if applicable
    training_session = db.relationship('TrainingSession', backref='hardware_metrics_list', lazy=True)
    
    def __repr__(self):
        return f'<HardwareMetrics id={self.id} timestamp={self.timestamp}>'

class TrainingLog(db.Model):
    """Training logs for debugging and analysis."""
    __tablename__ = 'training_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('training_sessions.id'))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    level = db.Column(db.String(10), default='INFO')  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    message = db.Column(db.Text)
    
    # Reference to training session
    training_session = db.relationship('TrainingSession', backref='logs', lazy=True)
    
    def __repr__(self):
        return f'<TrainingLog session={self.session_id} level={self.level}>'

class TrainingAction(db.Model):
    """Actions taken during training, such as parameter updates, checkpoint savings, etc."""
    __tablename__ = 'training_actions'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('training_sessions.id'))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    action_type = db.Column(db.String(50))  # checkpoint, parameter_update, model_reset, etc.
    description = db.Column(db.Text)
    action_data = db.Column(db.JSON, nullable=True)  # Additional action-specific data
    
    # Reference to training session
    training_session = db.relationship('TrainingSession', backref='actions', lazy=True)
    
    def __repr__(self):
        return f'<TrainingAction session={self.session_id} type={self.action_type}>'

def setup_database():
    """Set up the database and create admin user."""
    with app.app_context():
        # Create tables
        try:
            db.create_all()
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Error creating database tables: {str(e)}")
            return False
        
        # Check if admin user exists
        if User.query.filter_by(username='admin').first():
            logger.info("Admin user already exists")
        else:
            # Create admin user
            try:
                admin_user = User(
                    username='admin',
                    email='admin@pokerai.local',
                    password=generate_password_hash('admin'),
                    is_admin=True
                )
                db.session.add(admin_user)
                db.session.commit()
                logger.info("Admin user created successfully")
            except Exception as e:
                logger.error(f"Error creating admin user: {str(e)}")
                return False
        
        return True

if __name__ == '__main__':
    if setup_database():
        logger.info("Database setup completed successfully")
        sys.exit(0)
    else:
        logger.error("Database setup failed")
        sys.exit(1)