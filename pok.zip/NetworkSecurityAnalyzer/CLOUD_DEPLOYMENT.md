# Deploying Poker AI System to Google Cloud with A100 GPU Support

This guide provides step-by-step instructions for deploying the Poker AI system to Google Cloud Platform (GCP) using Docker.

## Prerequisites

1. Google Cloud Platform account with billing enabled
2. Google Cloud SDK installed and configured on your local machine
3. Docker installed on your local machine
4. Access to an A100 GPU instance on GCP (or other GPU instance)

## Deployment Steps

### 1. Build the Docker Image Locally

```bash
# From the project root directory
docker build -t poker-ai-system:latest .
```

### 2. Configure Google Cloud Container Registry

```bash
# Configure Docker to use Google Cloud credentials
gcloud auth configure-docker

# Create a project if you don't have one
gcloud projects create [YOUR_PROJECT_ID] --name="Poker AI"

# Set the project as current
gcloud config set project [YOUR_PROJECT_ID]
```

### 3. Tag and Push the Docker Image

```bash
# Tag the image for GCR
docker tag poker-ai-system:latest gcr.io/[YOUR_PROJECT_ID]/poker-ai-system:latest

# Push to Google Container Registry
docker push gcr.io/[YOUR_PROJECT_ID]/poker-ai-system:latest
```

### 4. Create an A100 GPU Instance

```bash
# Create a VM with an A100 GPU (adjust machine type as needed)
gcloud compute instances create poker-ai-server \
    --machine-type=a2-highgpu-1g \
    --accelerator=type=nvidia-tesla-a100,count=1 \
    --boot-disk-size=100GB \
    --image-family=ubuntu-2004-lts \
    --image-project=ubuntu-os-cloud \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --metadata="install-nvidia-driver=True" \
    --zone=[YOUR_PREFERRED_ZONE]
```

### 5. SSH into the VM and Install Docker

```bash
# SSH into the VM
gcloud compute ssh poker-ai-server

# Install Docker on the VM
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Log out and log back in for group changes to take effect
exit
gcloud compute ssh poker-ai-server
```

### 6. Install NVIDIA Container Toolkit

```bash
# Set up the NVIDIA Container Toolkit
distribution=$(. /etc/os-release;echo $ID$VERSION_ID) \
      && curl -s -L https://nvidia.github.io/libnvidia-container/gpgkey | sudo apt-key add - \
      && curl -s -L https://nvidia.github.io/libnvidia-container/$distribution/libnvidia-container.list | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo systemctl restart docker
```

### 7. Pull and Run the Docker Image

```bash
# Pull the container from Google Container Registry
docker pull gcr.io/[YOUR_PROJECT_ID]/poker-ai-system:latest

# Run the container with GPU passthrough
docker run --gpus all -d \
  --name poker-ai \
  -p 5010:5010 \
  -v poker_models:/app/models \
  -v poker_runs:/app/runs \
  -v poker_logs:/app/logs \
  -v poker_cfr_results:/app/cfr_results \
  gcr.io/[YOUR_PROJECT_ID]/poker-ai-system:latest
```

### 8. Access the Web Interface

Create a firewall rule to allow access to port 5010:

```bash
gcloud compute firewall-rules create allow-poker-ai \
  --allow tcp:5010 \
  --target-tags=http-server \
  --description="Allow access to Poker AI web interface"

# Add the http-server tag to your VM
gcloud compute instances add-tags poker-ai-server --tags=http-server
```

Access the web interface by navigating to:
```
http://[VM_EXTERNAL_IP]:5010
```

## Alternative Deployment: Direct SSH Transfer

If you prefer not to use Docker, you can use the built-in server transfer tool:

```bash
# From your local machine
python server_transfer_toolkit.py --target-server [VM_EXTERNAL_IP] --target-user [USERNAME]

# SSH into the server to finish setup
gcloud compute ssh poker-ai-server

# On the server
cd poker-ai-system
bash ./deploy_poker_ai.sh
```

## Monitoring

To monitor the running container:

```bash
# View logs
docker logs -f poker-ai

# Check GPU utilization
nvidia-smi

# Enter the container if needed
docker exec -it poker-ai bash
```

## Backup and Maintenance

- Models, logs, and other data are stored in Docker volumes for persistence
- Use `docker cp` to extract files from the volumes if needed
- For full backup, consider setting up Cloud Storage buckets for periodic backups