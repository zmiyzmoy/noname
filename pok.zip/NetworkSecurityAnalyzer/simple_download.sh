#!/bin/bash

# Very simple direct downloader
echo "==== Poker AI System Simple Downloader ===="
echo "Starting download of project files..."

# Create directory and navigate to it
mkdir -p poker_download
cd poker_download

# Download the main archive directly 
echo "Downloading archive file..."
curl -L "https://77b2eb61-43f1-42a2-a5c5-6c4ce33fc5a3-00-250d4ddm7qp7e.worf.replit.dev/download" -o poker_ai_system.tar.gz

# Check if download was successful
if [ ! -f poker_ai_system.tar.gz ]; then
    echo "Error: Failed to download the system archive."
    exit 1
fi

# Extract the files
echo "Extracting files..."
tar -xzf poker_ai_system.tar.gz

if [ $? -eq 0 ]; then
    echo "✓ Success! Files extracted."
    echo
    echo "You can now use the Poker AI system:"
    echo "1. cd into the extracted directory"
    echo "2. Run: pip install -r requirements.txt"
    echo "3. Start the system: python main.py"
else
    echo "× Error: Failed to extract the archive."
    exit 1
fi