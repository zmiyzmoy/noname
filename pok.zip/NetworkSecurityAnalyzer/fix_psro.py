#!/usr/bin/env python3
import re
import sys

def fix_probability_normalization(filename):
    with open(filename, 'r') as f:
        content = f.read()
    
    # Pattern to match the problematic code
    pattern = r"normalized_probs = \[p / probs_sum for p in probs\]\s+action = np\.random\.choice\(actions, p=normalized_probs\)"
    
    # Replacement with better code that ensures proper normalization
    replacement = """# Convert to numpy array for better numeric stability
                        normalized_probs = np.array([float(p) / float(probs_sum) for p in probs])
                        
                        # Double-check normalization was successful
                        if abs(np.sum(normalized_probs) - 1.0) > 1e-10:
                            logging.warning(f"Probabilities don't sum to 1 after normalization: {np.sum(normalized_probs)}")
                            # Force normalization as a final fix
                            normalized_probs = normalized_probs / np.sum(normalized_probs)
                            
                        action = np.random.choice(actions, p=normalized_probs)"""
    
    # Apply the fix
    fixed_content = re.sub(pattern, replacement, content)
    
    # Write the fixed content back
    with open(filename, 'w') as f:
        f.write(fixed_content)
    
    print(f"Fixed {filename}")

if __name__ == "__main__":
    fix_probability_normalization("psro.py")
