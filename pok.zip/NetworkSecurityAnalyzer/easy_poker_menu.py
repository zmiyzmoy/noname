#!/usr/bin/env python3
"""
Interactive menu for running Poker AI training with various configurations.
This script provides an easy-to-use menu interface to configure and run training.
"""

import os
import sys
import subprocess
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PokerAIMenu:
    def __init__(self):
        # Default configuration
        self.config = {
            'mode': 'selfplay',
            'num_episodes': 100,
            'num_iterations': 10,
            'batch_size': 64,
            'learning_rate': 0.001,
            'use_mixed_precision': True,
            'eval_opponents': 'random,tight_passive,tight_aggressive,loose_passive,loose_aggressive',
            'checkpoint': 'latest',
            'num_workers': 4,
            'verbose': True,
            'enable_dynamic_adjustment': False
        }
        
        # Menu options
        self.menu_options = {
            '1': self.set_training_mode,
            '2': self.set_num_episodes,
            '3': self.set_num_iterations,
            '4': self.set_batch_size,
            '5': self.set_learning_rate,
            '6': self.toggle_mixed_precision,
            '7': self.set_eval_opponents,
            '8': self.set_checkpoint,
            '9': self.set_num_workers,
            '10': self.toggle_verbose,
            '11': self.toggle_dynamic_adjustment,
            'r': self.run_training,
            'q': self.quit
        }
    
    def display_menu(self):
        """Display the main menu."""
        print("\n" + "="*50)
        print(" "*15 + "POKER AI TRAINING MENU")
        print("="*50)
        print(f"Current Configuration:")
        print(f"  Mode: {self.config['mode']}")
        print(f"  Number of Episodes: {self.config['num_episodes']}")
        print(f"  Training Iterations: {self.config['num_iterations']}")
        print(f"  Batch Size: {self.config['batch_size']}")
        print(f"  Learning Rate: {self.config['learning_rate']}")
        print(f"  Mixed Precision: {'Enabled' if self.config['use_mixed_precision'] else 'Disabled'}")
        print(f"  Evaluation Opponents: {self.config['eval_opponents']}")
        print(f"  Checkpoint: {self.config['checkpoint']}")
        print(f"  Number of Workers: {self.config['num_workers']}")
        print(f"  Verbose Output: {'Enabled' if self.config['verbose'] else 'Disabled'}")
        print(f"  Dynamic Parameter Adjustment: {'Enabled' if self.config['enable_dynamic_adjustment'] else 'Disabled'}")
        print("-"*50)
        print("Options:")
        print("  1. Change Training Mode")
        print("  2. Set Number of Episodes")
        print("  3. Set Training Iterations")
        print("  4. Set Batch Size")
        print("  5. Set Learning Rate")
        print("  6. Toggle Mixed Precision")
        print("  7. Set Evaluation Opponents")
        print("  8. Set Checkpoint")
        print("  9. Set Number of Workers")
        print("  10. Toggle Verbose Output")
        print("  11. Toggle Dynamic Parameter Adjustment")
        print("-"*50)
        print("  r. Run Training")
        print("  q. Quit")
        print("="*50)
    
    def run(self):
        """Run the main menu loop."""
        while True:
            self.display_menu()
            choice = input("Enter your choice: ").lower()
            
            if choice in self.menu_options:
                self.menu_options[choice]()
            else:
                print("Invalid choice. Please try again.")
    
    def set_training_mode(self):
        """Set the training mode."""
        print("\nTraining Modes:")
        print("  1. Selfplay - Run self-play with opponent modeling")
        print("  2. Train - Run PSRO training")
        print("  3. Eval - Evaluate against different opponents")
        
        choice = input("Select mode (1-3): ")
        
        mode_map = {
            '1': 'selfplay',
            '2': 'train',
            '3': 'eval'
        }
        
        if choice in mode_map:
            self.config['mode'] = mode_map[choice]
            print(f"Mode set to: {self.config['mode']}")
        else:
            print("Invalid choice. Mode not changed.")
    
    def set_num_episodes(self):
        """Set the number of episodes."""
        try:
            num = int(input("\nEnter number of episodes/hands (10-1000): "))
            if 10 <= num <= 1000:
                self.config['num_episodes'] = num
                print(f"Number of episodes set to: {num}")
            else:
                print("Value out of range. Not changed.")
        except ValueError:
            print("Invalid input. Not changed.")
    
    def set_num_iterations(self):
        """Set the number of training iterations."""
        try:
            num = int(input("\nEnter number of training iterations (1-100): "))
            if 1 <= num <= 100:
                self.config['num_iterations'] = num
                print(f"Number of iterations set to: {num}")
            else:
                print("Value out of range. Not changed.")
        except ValueError:
            print("Invalid input. Not changed.")
    
    def set_batch_size(self):
        """Set the batch size."""
        try:
            size = int(input("\nEnter batch size (16, 32, 64, 128, 256): "))
            if size in [16, 32, 64, 128, 256]:
                self.config['batch_size'] = size
                print(f"Batch size set to: {size}")
            else:
                print("Invalid batch size. Not changed.")
        except ValueError:
            print("Invalid input. Not changed.")
    
    def set_learning_rate(self):
        """Set the learning rate."""
        try:
            rate = float(input("\nEnter learning rate (0.0001-0.01): "))
            if 0.0001 <= rate <= 0.01:
                self.config['learning_rate'] = rate
                print(f"Learning rate set to: {rate}")
            else:
                print("Value out of range. Not changed.")
        except ValueError:
            print("Invalid input. Not changed.")
    
    def toggle_mixed_precision(self):
        """Toggle mixed precision training."""
        self.config['use_mixed_precision'] = not self.config['use_mixed_precision']
        status = "Enabled" if self.config['use_mixed_precision'] else "Disabled"
        print(f"\nMixed precision training: {status}")
    
    def set_eval_opponents(self):
        """Set the evaluation opponents."""
        print("\nAvailable opponent types:")
        print("  1. Random")
        print("  2. MCCFR")
        print("  3. Tight Passive")
        print("  4. Tight Aggressive")
        print("  5. Loose Passive")
        print("  6. Loose Aggressive")
        print("  7. Maniac")
        print("  8. Rock")
        print("  9. Calling Station")
        print("  10. Nit")
        print("  11. All Types")
        
        choice = input("Select opponents (comma-separated numbers, e.g., '1,3,4'): ")
        
        opponent_map = {
            '1': 'random',
            '2': 'mccfr',
            '3': 'tight_passive',
            '4': 'tight_aggressive',
            '5': 'loose_passive',
            '6': 'loose_aggressive',
            '7': 'maniac',
            '8': 'rock',
            '9': 'calling_station',
            '10': 'nit'
        }
        
        if choice == '11':
            self.config['eval_opponents'] = ','.join(opponent_map.values())
            print(f"All opponent types selected.")
        else:
            try:
                selected = [opponent_map[num.strip()] for num in choice.split(',') if num.strip() in opponent_map]
                if selected:
                    self.config['eval_opponents'] = ','.join(selected)
                    print(f"Evaluation opponents set to: {self.config['eval_opponents']}")
                else:
                    print("No valid opponents selected. Not changed.")
            except:
                print("Invalid input. Not changed.")
    
    def set_checkpoint(self):
        """Set the checkpoint to load."""
        print("\nCheckpoint options:")
        print("  1. latest - Load the latest checkpoint")
        print("  2. final - Load the final checkpoint")
        print("  3. Custom tag")
        
        choice = input("Select checkpoint option (1-3): ")
        
        if choice == '1':
            self.config['checkpoint'] = 'latest'
        elif choice == '2':
            self.config['checkpoint'] = 'final'
        elif choice == '3':
            tag = input("Enter custom checkpoint tag: ")
            if tag:
                self.config['checkpoint'] = tag
            else:
                print("Invalid tag. Not changed.")
        else:
            print("Invalid choice. Not changed.")
    
    def set_num_workers(self):
        """Set the number of workers."""
        try:
            num = int(input("\nEnter number of parallel workers (1-16): "))
            if 1 <= num <= 16:
                self.config['num_workers'] = num
                print(f"Number of workers set to: {num}")
            else:
                print("Value out of range. Not changed.")
        except ValueError:
            print("Invalid input. Not changed.")
    
    def toggle_verbose(self):
        """Toggle verbose output."""
        self.config['verbose'] = not self.config['verbose']
        status = "Enabled" if self.config['verbose'] else "Disabled"
        print(f"\nVerbose output: {status}")
    
    def toggle_dynamic_adjustment(self):
        """Toggle dynamic parameter adjustment."""
        self.config['enable_dynamic_adjustment'] = not self.config['enable_dynamic_adjustment']
        status = "Enabled" if self.config['enable_dynamic_adjustment'] else "Disabled"
        print(f"\nDynamic parameter adjustment: {status}")
        
        if self.config['enable_dynamic_adjustment']:
            print("\nWhen enabled, the system will periodically check system resources")
            print("and suggest optimal batch size and worker count adjustments")
            print("based on your hardware utilization.")
            print("\nYou can accept/reject each suggestion or disable further checks")
            print("during training by entering 'd' when prompted.")
    
    def generate_command(self):
        """Generate the command to run the poker_rl.py script with the current configuration."""
        cmd = ["python", "poker_rl.py"]
        
        # Add all arguments
        for arg_name, arg_value in self.config.items():
            if arg_value is True:
                cmd.append(f"--{arg_name}")
            elif arg_value is not False and arg_value is not None:
                cmd.append(f"--{arg_name}")
                cmd.append(str(arg_value))
        
        return cmd
    
    def run_training(self):
        """Run the poker training with the current configuration."""
        # Print configuration
        print("\n=== Running Poker AI Training ===")
        for arg_name, arg_value in self.config.items():
            print(f"{arg_name}: {arg_value}")
        print("===============================")
        
        # Generate command
        cmd = self.generate_command()
        cmd_str = " ".join(cmd)
        print(f"Running command: {cmd_str}")
        
        # Confirm execution
        confirm = input("Do you want to proceed? (y/n): ").lower()
        if confirm != 'y':
            print("Training canceled.")
            return
        
        # Execute command
        try:
            # Use subprocess.run to run the command and capture output
            result = subprocess.run(cmd, check=True, text=True)
            print("Training completed successfully")
        except subprocess.CalledProcessError as e:
            print(f"Error running training: {e}")
        except KeyboardInterrupt:
            print("Training interrupted by user")
    
    def quit(self):
        """Exit the program."""
        print("\nExiting Poker AI Training Menu.")
        sys.exit(0)

def main():
    menu = PokerAIMenu()
    try:
        menu.run()
    except KeyboardInterrupt:
        print("\nProgram interrupted. Exiting.")
        sys.exit(0)

if __name__ == "__main__":
    main()