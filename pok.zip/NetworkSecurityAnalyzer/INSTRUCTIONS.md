
# Poker AI Project Instructions

This document provides detailed instructions for using the Poker AI training system. Follow these steps in order to get started.

## Project Overview

This is a reinforcement learning system for training poker AI using Policy Space Response Oracles (PSRO) with PyTorch and OpenSpiel. The system can learn No-Limit Texas Hold'em strategies through self-play.

## File Structure and Purpose

### Core Files:

1. `poker_rl.py`
   - Main entry point for running training and evaluation
   - Usage: `python poker_rl.py --mode [train/eval/selfplay] --num_episodes [number] --verbose`
   - Modes:
     - train: Full training mode
     - eval: Evaluate trained model
     - selfplay: Watch AI play against itself

2. `models.py`
   - Contains neural network architecture definitions
   - Includes RegretNet, StrategyNet, and card embedding models
   - No direct usage - imported by other files

3. `environment.py`
   - Poker environment wrapper for OpenSpiel
   - Handles game state management
   - No direct usage - imported by other files

4. `psro.py`
   - Implementation of the PSRO algorithm
   - Handles strategy computation and updates
   - No direct usage - imported by other files

### Training Files:

5. `train.py`
   - Secondary training script with additional options
   - Usage: `python train.py --base_dir ./poker --num_iterations 20 --num_workers 8`

6. `cloud_trainer.py`
   - Optimized training script for cloud/GPU usage
   - Usage: `python cloud_trainer.py --mode train --num_episodes 1000 --verbose`

7. `cloud_spot_runner.py`
   - Script for managing training on cloud instances
   - Handles checkpointing and recovery
   - Used automatically by cloud_trainer.py

### Utility Files:

8. `config.py`
   - Configuration settings for the entire project
   - Edit this to modify hyperparameters
   - No direct usage - imported by other files

9. `utils.py`
   - Helper functions used throughout the project
   - No direct usage - imported by other files

10. `state_processor.py`
    - Handles processing of game states
    - No direct usage - imported by other files

### Analysis Tools:

11. `poker_json_analyzer.py`
    - Analyzes specific poker hand scenarios
    - Usage: `python poker_json_analyzer.py --input hand.json --output analysis.json`

12. `analyze_training.py`
    - Generates training progress reports
    - Usage: `python analyze_training.py --metrics_file ./poker/logs/metrics.json`

13. `visualize_learning.py`
    - Creates visualizations of training progress
    - Usage: `python visualize_learning.py --log_dir ./poker/logs`

## Getting Started

### Step 1: Initial Setup

1. First, ensure all dependencies are installed:
```bash
pip install torch numpy ray open-spiel joblib scikit-learn matplotlib tqdm
```

2. Initialize the model:
```bash
python init_model.py
```

### Step 2: Basic Training

1. For a quick test run:
```bash
python poker_rl.py --mode selfplay --num_episodes 5 --verbose
```

2. For actual training:
```bash
python cloud_trainer.py --mode train --num_episodes 1000 --verbose
```

### Step 3: Monitoring Progress

1. Check training logs in `poker/logs/`
2. Generate training report:
```bash
python analyze_training.py --metrics_file ./poker/logs/metrics.json
```

3. Visualize learning progress:
```bash
python visualize_learning.py --log_dir ./poker/logs
```

### Step 4: Analyzing Specific Hands

1. Create a JSON file with your hand scenario (see `sample_hand.json` for format)
2. Run analysis:
```bash
python poker_json_analyzer.py --input your_hand.json --output analysis.json
```

## Directory Structure

- `poker/models/`: Stores trained models and checkpoints
- `poker/logs/`: Contains training logs and metrics
- `poker/analysis/`: Stores analysis results and visualizations

## Common Issues and Solutions

1. **Out of Memory Errors**
   - Reduce batch size in config.py
   - Reduce number of workers

2. **Slow Training**
   - Increase batch size if memory allows
   - Increase number of workers if CPU cores available

3. **Poor Performance**
   - Increase number of training episodes
   - Adjust learning rate in config.py
   - Check training logs for anomalies

## Advanced Usage

### Custom Training Scenarios

Edit `config.py` to modify:
- Number of players
- Stack sizes
- Blind structure
- Neural network architecture

### Analyzing Training Progress

Use `analyze_training.py` to:
- Track win rates
- Monitor exploitability
- View learning curves
- Identify learning plateaus

### Production Deployment

For production use:
1. Complete full training (100K+ episodes)
2. Use `poker_json_inference.py` for real-time decisions
3. Monitor performance with analysis tools

## Support Files

- `sample_hand.json`: Example hand format
- `sample_usage.py`: Example usage of analyzers
- `poker_input_template.json`: Template for hand input

## Maintenance

- Regular checkpoints are saved in `poker/models/`
- Logs are rotated automatically
- Analysis results are timestamped

## Best Practices

1. Always start with small test runs
2. Monitor training metrics regularly
3. Save checkpoints frequently
4. Validate model performance before deployment

## Contact & Support

For issues or questions:
1. Check the logs in `poker/logs/`
2. Review error messages
3. Check configuration in `config.py`

Remember to check the README.md for additional information and updates.
