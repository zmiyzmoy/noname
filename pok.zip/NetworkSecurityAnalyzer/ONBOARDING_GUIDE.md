# Quick Start Onboarding Wizard Guide

## Introduction

The Poker AI Quick Start Onboarding Wizard is designed to help new users get started with the system quickly and easily. It provides a guided step-by-step process to set up and configure the system, install dependencies, and run initial training sessions.

## Accessing the Wizard

There are two ways to access the onboarding wizard:

1. **Standalone Mode**: Run the wizard independently on port 5060
   ```bash
   python web_onboarding_wizard.py --port 5060
   ```

2. **Integrated Mode**: Access through the main application at http://localhost:5010
   * When you first access the main application, if no previous configuration is detected, you'll be automatically redirected to the onboarding wizard.
   * You can also start the wizard manually from the main application using the "Start Onboarding" button.

## Onboarding Steps

The wizard guides you through the following steps:

1. **Welcome**: Introduction to the system and overview of the onboarding process.
2. **System Check**: Verifies that your system meets the minimum requirements.
3. **Dependencies**: Installs required Python libraries and system dependencies.
4. **Database Setup**: Configures the PostgreSQL database connection.
5. **Create Admin User**: Sets up the initial admin user for the system.
6. **Start Services**: Launches the required services for the system.
7. **Quick Training**: Runs a short training session to verify everything is working.
8. **Finish**: Completes the onboarding process and redirects you to the main application.

## Command Line Launcher

For convenience, you can use the command line launcher to start the wizard:

```bash
python run_onboarding_wizard.py --web --port 5060
```

This will automatically detect your environment and launch the web-based wizard at the specified port.

## Skipping Onboarding

If you're an experienced user or just want to skip the onboarding process, you can use the "Skip Onboarding" link on the welcome page. This will create a configuration file indicating that onboarding has been completed and redirect you to the main application.

## Testing

To verify that the onboarding wizard is working correctly, you can run the test script:

```bash
python test_onboarding_wizard.py --run
```

This will test:
- The consolidated Flask app
- The onboarding wizard
- The skip onboarding functionality

## Troubleshooting

If you encounter any issues with the onboarding wizard:

1. Check the logs in `web_onboarding_wizard.log` for detailed error messages.
2. Ensure all required ports are available (5010 for the main app, 5060 for the wizard).
3. Verify that you have the necessary permissions to install packages and create database tables.
4. Make sure the PostgreSQL database is running and accessible.

## Configuration

The wizard creates a configuration file `onboarding_wizard_state.json` that tracks the progress of the onboarding process. If you need to restart the onboarding process, you can delete this file.

## Integration

The onboarding wizard is integrated with the main application through the `main.py` file. It uses Flask blueprints to provide a seamless experience between the main application and the wizard.