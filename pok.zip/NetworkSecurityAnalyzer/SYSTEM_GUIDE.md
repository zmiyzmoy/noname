# Poker AI System - Comprehensive System Guide

This guide provides detailed information about the system architecture, core files, and functions of the Poker AI system, including monitoring and visualization using TensorBoard.

## Table of Contents
- [System Architecture](#system-architecture)
- [Core Files](#core-files)
- [Directory Structure](#directory-structure)
- [Setting Up TensorBoard](#setting-up-tensorboard)
- [Training Functions](#training-functions)
- [Evaluation Functions](#evaluation-functions)
- [Web Interfaces](#web-interfaces)
- [Database Structure](#database-structure)
- [System Management](#system-management)
- [Troubleshooting](#troubleshooting)

## System Architecture

The Poker AI system consists of several integrated components:

1. **Core AI Engine**: Deep reinforcement learning implementation using Policy Space Response Oracles (PSRO)
2. **Training Infrastructure**: Distributed training with Ray parallelism
3. **Web Interfaces**: Multiple Flask-based dashboards for control and monitoring
4. **Database Layer**: PostgreSQL database for configuration and results storage
5. **Visualization Tools**: TensorBoard integration for metrics visualization

## Core Files

These are the essential files of the Poker AI system:

### Core System Files
- `main.py` - Main Flask application entry point
- `models.py` - Neural network models and database models
- `psro.py` - Policy Space Response Oracle implementation
- `poker_rl.py` - Main RL training script
- `environment.py` - Environment interface
- `buffer.py` - Experience replay buffer
- `state_processor.py` - State processing utilities
- `config.py` - Configuration settings
- `utils.py` - Utility functions

### Training & Optimization Files
- `cloud_trainer.py` - Distributed training script
- `parameter_adjuster.py` - Auto-tuning for training parameters
- `adaptation_manager.py` - Strategy adaptation management
- `opponent_modeling.py` - Opponent modeling system
- `tensorboard_logger.py` - Training visualization logger
- `fix_openspiel_player_id.py` - OpenSpiel error fix utility

### Web Interfaces
- `admin_dashboard.py` - Admin dashboard
- `advanced_dashboard.py` - Advanced monitoring dashboard
- `web_poker_menu.py` - Web-based training menu
- `monitoring_web.py` - Training monitoring interface
- `easy_poker_menu.py` - Simplified CLI menu

### Onboarding & Setup
- `onboarding_wizard.py` - CLI onboarding wizard
- `web_onboarding_wizard.py` - Web onboarding wizard
- `run_onboarding_wizard.py` - Wizard launcher
- `create_new_admin.py` - Admin user creation script

### Deployment Files
- `deploy_poker_ai.sh` - Deployment script
- `server_transfer_toolkit.py` - Server transfer utilities

### Testing Scripts
- `test_onboarding_wizard.py` - Onboarding wizard tests
- `test_all_components.py` - Component testing script
- `test_openspiel_stability.py` - OpenSpiel stability tests

## Directory Structure

When setting up or transferring the system, maintain this directory structure:
```
poker_ai/
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── templates/
├── logs/ (create empty directory)
├── runs/ (create empty directory)
├── cfr_results/ (create empty directory)
└── (all python files and scripts)
```

The logs, runs, and cfr_results directories will be created by the system if they don't exist, but it's good practice to create them explicitly.

## Setting Up TensorBoard

TensorBoard is a visualization tool that allows you to monitor your training progress in real-time with charts and graphs.

### Installing TensorBoard

TensorBoard is included in the requirements.txt file and will be installed automatically when you run the deployment script. If you need to install it manually:

```bash
pip install tensorboard
```

### Starting TensorBoard

To start TensorBoard:

```bash
# Make sure you're in your project directory
tensorboard --logdir=runs --host 0.0.0.0 --port 6006
```

This will start TensorBoard on port 6006. You can access it by opening a web browser and navigating to `http://your_server_ip:6006`.

### Key Metrics in TensorBoard

The Poker AI system logs these key metrics to TensorBoard:

1. **Loss Values** - Training and validation loss
2. **Win Rates** - Performance against different opponents
3. **Exploration Rate** - Current exploration rate (epsilon)
4. **Learning Rate** - Current learning rate
5. **Gradient Norms** - L2 norms of gradients
6. **Hardware Utilization** - CPU, RAM, and GPU usage if available

### Custom Logging

You can add custom metrics to TensorBoard by modifying the `tensorboard_logger.py` file:

```python
def log_custom_metric(self, name, value, step):
    self.writer.add_scalar(name, value, step)
```

## Training Functions

The system provides several training functions through the `poker_rl.py` script:

### Basic Training

```bash
python poker_rl.py --mode train --num_episodes 1000 --num_iterations 10
```

Key parameters:
- `--mode`: Training mode (train, selfplay, eval, tournament)
- `--num_episodes`: Number of episodes per iteration
- `--num_iterations`: Number of PSRO iterations
- `--verbose`: Enable detailed logging
- `--checkpoint`: Load from a checkpoint file

### Distributed Training

For larger training jobs, use the distributed training script:

```bash
python cloud_trainer.py --mode train --num_episodes 10000 --num_workers 4
```

Key parameters:
- `--num_workers`: Number of Ray workers
- `--batch_size`: Batch size for training
- `--checkpoint_interval`: How often to save checkpoints
- `--use_gpu`: Enable GPU acceleration if available

### Parameter Optimization

The system can automatically optimize training parameters:

```bash
python parameter_adjuster.py --auto
```

This will analyze your hardware and set optimal values for:
- Batch size
- Number of workers
- Learning rate
- Memory allocation

## Evaluation Functions

Evaluate your trained models with these functions:

### Against Built-in Opponents

```bash
python poker_rl.py --mode eval --num_episodes 500 --eval_opponents random,tight_aggressive,loose_passive
```

### Tournament Mode

```bash
python poker_rl.py --mode tournament --num_iterations 5
```

### Interactive Play

```bash
python poker_rl.py --mode interactive
```

## Web Interfaces

The system provides several web interfaces:

### Main Dashboard (Port 5010)

```bash
python main.py
```

Features:
- Access to all system functionalities
- Server transfer tools
- Documentation access

### Training Dashboard (Port 5003)

```bash
python web_poker_menu.py
```

Features:
- Start/stop training
- Configure training parameters
- View training progress

### Monitoring Dashboard (Port 5000)

```bash
python monitoring_web.py
```

Features:
- Real-time performance metrics
- System resource usage
- Training statistics

### Admin Dashboard (Port 5002)

```bash
python advanced_dashboard.py
```

Features:
- User management
- Database administration
- Advanced system configuration

## Database Structure

The system uses a PostgreSQL database with these main tables:

### Users Table
Stores user accounts for the admin dashboard:
- `id`: Primary key
- `username`: Username
- `password_hash`: Hashed password
- `email`: User email
- `is_admin`: Admin status flag

### Hardware Configs Table
Stores hardware configuration settings:
- `id`: Primary key
- `name`: Configuration name
- `cpu_cores`: Number of CPU cores
- `ram_gb`: RAM in gigabytes
- `gpu_type`: GPU model (if any)
- `gpu_memory`: GPU memory (if any)

### Training Configs Table
Stores training configuration profiles:
- `id`: Primary key
- `name`: Configuration name
- `batch_size`: Batch size
- `learning_rate`: Learning rate
- `num_workers`: Number of workers
- `use_gpu`: GPU usage flag

### Training Sessions Table
Stores training session records:
- `id`: Primary key
- `start_time`: Session start time
- `end_time`: Session end time
- `config_id`: Foreign key to training_configs
- `hardware_id`: Foreign key to hardware_configs
- `status`: Session status

### Metrics Table
Stores training metrics data:
- `id`: Primary key
- `session_id`: Foreign key to training_sessions
- `timestamp`: Measurement timestamp
- `metric_name`: Name of the metric
- `metric_value`: Value of the metric

## System Management

### Creating a Requirements File

If you don't already have a requirements.txt file, you can create one with:

```bash
pip freeze > requirements.txt
```

Or manually create one with these essential packages:

```
torch>=2.0.0
numpy>=1.20.0
matplotlib>=3.5.0
flask>=2.0.0
flask-login>=0.6.0
flask-sqlalchemy>=3.0.0
gunicorn>=20.1.0
dash>=2.0.0
dash-bootstrap-components>=1.0.0
psycopg2-binary>=2.9.0
scikit-learn>=1.0.0
scipy>=1.7.0
tensorboard>=2.8.0
plotly>=5.0.0
open-spiel>=1.0.0
ray>=2.0.0
tqdm>=4.60.0
werkzeug>=2.0.0
```

### Service Management

If you've set up the system as a service, you can manage it with:

```bash
# Start the service
sudo systemctl start poker-ai

# Stop the service
sudo systemctl stop poker-ai

# Restart the service
sudo systemctl restart poker-ai

# Check service status
sudo systemctl status poker-ai
```

### Backup and Restore

Back up your trained models and database:

```bash
# Backup models
tar -czf models_backup.tar.gz cfr_results/ runs/

# Backup database
pg_dump -U postgres poker_ai > poker_ai_db_backup.sql

# Restore database
psql -U postgres -d poker_ai < poker_ai_db_backup.sql
```

## Troubleshooting

### Common TensorBoard Issues

1. **Can't connect to TensorBoard**
   - Ensure it's running on 0.0.0.0, not localhost
   - Check firewall settings
   - Verify the port is open

2. **No metrics showing**
   - Ensure the `runs` directory exists
   - Verify training is logging metrics
   - Check disk space

3. **TensorBoard crashes**
   - Try clearing the runs directory
   - Restart with `--samples_per_plugin=images=100` to limit memory usage

### Training Issues

1. **OpenSpiel Errors**
   - Check for "player_id=-4" errors
   - Use the fix_openspiel_player_id.py utility
   - Try reducing the number of players or episodes

2. **Ray Worker Failures**
   - Check available CPU and memory
   - Reduce the number of workers
   - Try running without Ray: `--use_ray False`

3. **CUDA Out of Memory**
   - Reduce batch size
   - Use gradient accumulation
   - Consider switching to CPU training for larger models

### Database Issues

1. **Connection Failures**
   - Verify PostgreSQL is running
   - Check the DATABASE_URL environment variable
   - Ensure the user has proper permissions

2. **Slow Queries**
   - Add indices to frequently queried fields
   - Consider running VACUUM ANALYZE
   - Check for long-running transactions

### Web Interface Issues

1. **Interface Not Loading**
   - Check if the Flask app is running
   - Verify port availability
   - Check for JavaScript console errors

2. **Missing Data in Dashboards**
   - Verify database connection
   - Check permissions on log files
   - Ensure metrics are being collected

3. **Authentication Issues**
   - Reset admin password with create_new_admin.py
   - Check Flask-Login configuration
   - Verify session cookie settings