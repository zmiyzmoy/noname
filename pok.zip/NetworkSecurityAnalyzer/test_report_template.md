# Poker AI Functional Tests Report

Generated: {{generation_date}}

## Summary

- Total Tests: {{total_tests}}
- Successful Tests: {{successful_tests}}
- Failed Tests: {{failed_tests}}

## Overall Assessment

{{overall_assessment}}

## Core Features Status

| Feature | Status | Notes |
|---------|--------|-------|
| Selfplay Mode | {{selfplay_status}} | {{selfplay_notes}} |
| Evaluation Mode | {{eval_status}} | {{eval_notes}} |
| Training Mode | {{train_status}} | {{train_notes}} |
| Dynamic Parameter Adjustment | {{dynamic_params_status}} | {{dynamic_params_notes}} |
| Opponent Modeling | {{opponent_modeling_status}} | {{opponent_modeling_notes}} |

## Detailed Test Results

{{detailed_results}}

## Recommendations

{{recommendations}}