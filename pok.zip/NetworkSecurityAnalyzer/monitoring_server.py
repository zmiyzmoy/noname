
#!/usr/bin/env python3
from flask import jsonify
import json
import os
import time
import logging
from threading import Lock
import sys

# Import our enhanced web monitoring module
from monitoring_web import app, update_training_data, training_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('monitoring.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Global data storage
data_lock = Lock()
latest_metrics = {}
win_rates = []
exploitability = []

@app.route('/legacy_metrics')
def get_metrics():
    """Legacy API endpoint for compatibility."""
    with data_lock:
        response = {
            'latest_metrics': latest_metrics,
            'win_rates': win_rates,
            'exploitability': exploitability
        }
        return jsonify(response)

def update_metrics(metrics_data):
    """
    Update metrics data and also update the training data for the web interface.
    
    Args:
        metrics_data: Dictionary with training metrics
    """
    # Convert numpy types to Python standard types to avoid JSON serialization issues
    def convert_to_serializable(obj):
        import numpy as np
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, (list, tuple)):
            return [convert_to_serializable(item) for item in obj]
        elif isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        else:
            return obj
    
    # Convert all metrics to serializable types
    metrics_data = convert_to_serializable(metrics_data)
    
    with data_lock:
        global latest_metrics, win_rates, exploitability
        latest_metrics = metrics_data
        
        # Update win rates if available
        if 'win_rate' in metrics_data:
            win_rates.append(metrics_data['win_rate'])
        
        # Update exploitability if available
        if 'exploitability' in metrics_data:
            exploitability.append(metrics_data['exploitability'])
    
    # Convert to format for web interface
    web_data = {
        'status': 'training',
        'last_update': time.time()
    }
    
    # Copy relevant metrics for web interface
    if 'iteration' in metrics_data:
        web_data['iteration'] = metrics_data['iteration']
    
    if 'reward' in metrics_data:
        web_data['reward'] = metrics_data['reward']
    
    if 'loss' in metrics_data:
        web_data['loss'] = metrics_data['loss']
    
    if 'win_rate' in metrics_data:
        web_data['win_rate'] = metrics_data['win_rate']
    
    if 'exploitability' in metrics_data:
        web_data['exploitability'] = metrics_data['exploitability']
    
    if 'episodes_completed' in metrics_data:
        web_data['episodes_completed'] = metrics_data['episodes_completed']
    else:
        # Try to infer from other metrics
        if 'total_episodes' in metrics_data:
            web_data['episodes_completed'] = metrics_data['total_episodes']
        elif 'episode' in metrics_data:
            web_data['episodes_completed'] = metrics_data['episode']
    
    if 'action' in metrics_data:
        web_data['action'] = f"Player {metrics_data.get('player_id', 'N/A')}: {metrics_data['action']}"
    
    # Update the web interface data
    update_training_data(web_data)
    logger.info(f"Updated metrics: {metrics_data}")

def run_server():
    """Run the monitoring server."""
    app.run(host='0.0.0.0', port=5000, debug=False)

if __name__ == '__main__':
    run_server()
