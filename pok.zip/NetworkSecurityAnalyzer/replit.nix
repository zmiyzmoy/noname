{pkgs}: {
  deps = [
    pkgs.zip
    pkgs.postgresql
    pkgs.xsimd
    pkgs.libxcrypt
    pkgs.libGL
    pkgs.tk
    pkgs.tcl
    pkgs.qhull
    pkgs.pkg-config
    pkgs.gtk3
    pkgs.gobject-introspection
    pkgs.ghostscript
    pkgs.freetype
    pkgs.ffmpeg-full
    pkgs.cairo
    pkgs.py-spy
    pkgs.glibcLocales
  ];
}
