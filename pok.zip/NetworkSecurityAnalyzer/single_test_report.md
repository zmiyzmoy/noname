# Poker AI Functional Tests Report

Generated: 2025-04-22 16:58:19

## Summary

- Total Tests: 1
- Successful Tests: 1
- Failed Tests: 0

## Overall Assessment

✅ All tests passed successfully

## Detailed Test Results

### Test Case 1: Selfplay Mode Test

- **Command**: `python poker_rl.py --mode selfplay --num_episodes 1 --verbose`
- **Exit Code**: 0 (Success)
- **Duration**: 3.86 seconds
- **Success Pattern Found**: Yes

#### Key Log Messages

```
2025-04-22 16:58:18,408 - INFO - Using device: cpu
2025-04-22 16:58:18,410 - INFO - CardEmbedding initialized
2025-04-22 16:58:18,411 - INFO - Loaded buckets from ./poker/models/kmeans.joblib
2025-04-22 16:58:18,411 - INFO - StateProcessor initialized, state_size=77
2025-04-22 16:58:18,411 - INFO - Initializing standard PSRO solver for selfplay...
2025-04-22 16:58:18,415 - INFO - RegretNet initialized with input_size=77, num_actions=4
2025-04-22 16:58:18,418 - INFO - StrategyNet initialized with input_size=77, num_actions=4
2025-04-22 16:58:19,206 - INFO - Loaded checkpoint with tag: final (checksum verified)
2025-04-22 16:58:19,207 - INFO - Poker Environment initialized with game: universal_poker(betting=nolimit,numPlayers=6,numRounds=4,blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,stack=100 100 100 100 100 100,numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)
2025-04-22 16:58:19,208 - INFO - Opponent model loaded from ./poker/models/opponent_models.json
2025-04-22 16:58:19,208 - INFO - OpponentModel initialized
2025-04-22 16:58:19,208 - INFO - AdaptationManager initialized
2025-04-22 16:58:19,208 - INFO - Starting selfplay demonstration with opponent modeling...
2025-04-22 16:58:19,328 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:58:19,329 - WARNING - Error in adaptive action selection: 0
2025-04-22 16:58:19,333 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:58:19,337 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:58:19,340 - WARNING - Error in action selection, using fallback: 'int' object has no attribute 'get'
2025-04-22 16:58:19,343 - INFO - Episode 1 complete
2025-04-22 16:58:19,343 - INFO -   Final returns: [243.0, -100.0, -32.0, -100.0, -5.0, -6.0]
2025-04-22 16:58:19,344 - INFO -   Actions: [(0, 2, 'exploitative', 4.0, 3.0835821628570557), (0, 2), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 1, 'exploitative', 0.0, 0.5275802612304688), (3, 3, 'exploration', 0.0, 0.0), (4, 0, 'exploration', 0.0, 0.0), (5, 0, 'exploration', 0.0, 0.0), (0, 1, 'exploration', 0.0, 0.0), (1, 1, 'exploitative', 0.0, 0.15245169401168823), (2, 0, 'exploration', 0.0, 0.0)]
2025-04-22 16:58:19,346 - INFO - Opponent model saved to ./poker/models/opponent_models.json
2025-04-22 16:58:19,346 - INFO - Opponent models saved to ./poker/models/opponent_models.json
2025-04-22 16:58:19,347 - INFO - Selfplay demonstration with opponent modeling complete
```

#### Standard Error

```
/home/runner/workspace/psro.py:43: FutureWarning: `torch.cuda.amp.GradScaler(args...)` is deprecated. Please use `torch.amp.GradScaler('cuda', args...)` instead.
  self.scaler = GradScaler('cuda') if torch.cuda.is_available() else GradScaler()
/home/runner/workspace/.pythonlibs/lib/python3.11/site-packages/torch/amp/grad_scaler.py:132: UserWarning: torch.cuda.amp.GradScaler is enabled, but CUDA is not available.  Disabling.
  warnings.warn(
```

---

