#!/usr/bin/env python3
import os
import logging
import numpy as np
import torch
from typing import List, Dict, Any, Tuple, Optional, Union

from dynamic_sizing import DynamicBetSizing

# Helper function to safely convert numpy integers to Python integers
def safe_int_convert(value: Union[int, np.integer, Any]) -> int:
    """
    Safely convert numpy integer types to Python integers.
    
    Args:
        value: A value that might be a numpy integer
        
    Returns:
        Python int version of the value
    """
    # Handle numpy integer types (np.int32, np.int64, etc.)
    if isinstance(value, (np.integer, np.int32, np.int64)):
        return int(value)
    # Handle Python integer
    elif isinstance(value, int):
        return value
    # Handle list/tuple/dict containing a single value
    elif isinstance(value, (list, tuple)) and len(value) == 1:
        return safe_int_convert(value[0])
    # Handle string that might contain an integer
    elif isinstance(value, str):
        try:
            return int(value)
        except (ValueError, TypeError):
            logging.warning(f"Could not convert string {value} to int, using 0")
            return 0
    # Handle other types
    else:
        # Try to convert, but return 0 if it fails
        try:
            return int(value)
        except (TypeError, ValueError):
            logging.debug(f"Could not convert value of type {type(value)} to int, using 0")
            return 0

class PokerActionSelector:
    """
    Integrates AI decision-making with dynamic bet sizing.
    This class determines optimal actions and bet sizes based on neural network outputs
    and the dynamic bet sizing system.
    """
    
    def __init__(self, game, solver, state_processor, config=None):
        """
        Initialize the action selector.
        
        Args:
            game: OpenSpiel game instance
            solver: PSROSolver instance with trained models
            state_processor: StateProcessor for game state processing
            config: Configuration object
        """
        self.game = game
        self.solver = solver
        self.state_processor = state_processor
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize logger
        self.logger = logging.getLogger('PokerActionSelector')
        
    def select_action(self, 
                     state, 
                     player_id: int, 
                     stack_sizes: List[float],
                     pot_size: float,
                     board: List[str] = None,
                     hole_cards: List[str] = None,
                     position_name: str = None,
                     opponent_stats: Optional[Dict] = None,
                     temperature: float = 1.0,
                     is_competitive: bool = False,
                     exploration_rate: float = 0.0,
                     detailed_output: bool = False,
                     action_probs: Optional[Dict[int, float]] = None) -> Dict:
        """
        Select an action using the trained model with dynamic bet sizing.
        
        Args:
            state: OpenSpiel game state
            player_id: Current player's ID
            stack_sizes: Stack sizes for all players
            pot_size: Current pot size
            board: Board cards in human-readable format ['Ah', 'Kd', etc.]
            hole_cards: Player's hole cards
            position_name: Position name (BTN, SB, BB, etc.)
            opponent_stats: Dictionary of opponent statistics
            temperature: Temperature for action selection randomness
            is_competitive: Whether to use competitive (vs. exploitative) mode
            exploration_rate: Rate of exploration (0-1)
            detailed_output: Whether to return detailed info about decision
            action_probs: Optional dictionary mapping action indices to probabilities, 
                         used to override the model's strategy (e.g., from adaptation)
            
        Returns:
            Dictionary with selected action, amount, and additional info
        """
        # Get legal actions
        legal_actions = state.legal_actions()
        if not legal_actions:
            return {'action': None, 'amount': 0, 'ev': 0}
        
        # Process state for model input
        processed_state = self.state_processor.process([state], [player_id])
        state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
        
        # Get current round index
        round_idx = 0  # Default to preflop
        if hasattr(state, 'round'):
            if callable(getattr(state, 'round')):
                round_idx = state.round()
            else:
                round_idx = getattr(state, 'round')
        else:
            # Estimate round from board cards if state doesn't provide it
            if board:
                if len(board) <= 0:
                    round_idx = 0  # Preflop
                elif len(board) <= 3:
                    round_idx = 1  # Flop
                elif len(board) <= 4:
                    round_idx = 2  # Turn
                else:
                    round_idx = 3  # River
        
        # Random exploration
        if np.random.random() < exploration_rate:
            action = np.random.choice(legal_actions)
            return {'action': action, 'amount': 0, 'ev': 0, 'method': 'exploration'}
        
        # Run model inference
        with torch.no_grad():
            # Get expected values from regret network
            ev_values = self.solver.regret_net(state_tensor)[0].cpu().numpy()
            
            # Get action probabilities from strategy network or use provided ones
            if action_probs is not None:
                # Convert the dictionary format to numpy array
                model_probs = np.zeros(len(ev_values))
                
                # Handle different action_probs types safely
                if isinstance(action_probs, dict):
                    # Process dictionary format of action probabilities
                    for action_id, prob in action_probs.items():
                        # Convert action_id to Python int if needed
                        action_id = safe_int_convert(action_id)
                        if action_id < len(model_probs):
                            model_probs[action_id] = float(prob)
                elif isinstance(action_probs, (list, np.ndarray)):
                    # Handle array-like action_probs
                    for i, prob in enumerate(action_probs):
                        if i < len(model_probs):
                            model_probs[i] = float(prob)
                elif isinstance(action_probs, (int, np.integer, np.int32, np.int64)):
                    # Handle case where action_probs is a single integer action
                    action_id = safe_int_convert(action_probs)
                    if 0 <= action_id < len(model_probs):
                        # Create a one-hot distribution for this action
                        model_probs[action_id] = 1.0
                    logging.info(f"Converted integer action_probs {action_probs} to one-hot distribution")
                action_probs = model_probs
            else:
                # Use default action probabilities from the model
                action_probs = self.solver.strategy_net(state_tensor)[0].cpu().numpy()
        
        # If in competitive mode, use strategy network output
        if is_competitive:
            # Apply temperature and mask illegal actions
            masked_probs = np.ones_like(action_probs) * float('-inf')
            masked_probs[legal_actions] = action_probs[legal_actions]
            
            # Apply softmax with temperature
            exp_probs = np.exp(masked_probs / temperature)
            action_probs = exp_probs / np.sum(exp_probs)
            
            # Sample action according to probabilities
            action = np.random.choice(len(action_probs), p=action_probs)
            # Convert numpy int to Python int
            action = safe_int_convert(action)
            
            return {
                'action': action,
                'amount': 0,  # Will be set by game engine
                'ev': ev_values[action],
                'method': 'competitive'
            }
        
        # For exploitative play, use regret network with dynamic sizing
        else:
            # Check if we have enough info for dynamic sizing
            if None not in [stack_sizes, pot_size, hole_cards, board]:
                # Determine if this is a raise response
                is_raise = self._is_facing_raise(state)
                
                # Get dynamic bet sizing options
                bet_sizer = DynamicBetSizing(stack_sizes, self.config)
                bet_options = bet_sizer.calculate_bet_options(
                    state, 
                    pot_size,
                    player_id,
                    position_name or "MP",  # Default to middle position if unknown
                    board or [],
                    hole_cards,
                    opponent_stats,
                    round_idx=round_idx,
                    is_raise=is_raise
                )
                
                # Map actions to their expected values
                action_to_ev = {action: ev_values[action] for action in legal_actions}
                
                # Choose best action considering dynamic bet sizes
                best_action, best_amount, best_ev = self._select_best_action_with_sizing(
                    action_to_ev, bet_options, state
                )
                
                if detailed_output:
                    return {
                        'action': best_action,
                        'amount': best_amount,
                        'ev': best_ev,
                        'method': 'exploitative',
                        'all_evs': action_to_ev,
                        'bet_options': bet_options
                    }
                else:
                    return {
                        'action': best_action,
                        'amount': best_amount,
                        'ev': best_ev,
                        'method': 'exploitative'
                    }
            
            # If missing info for dynamic sizing, fall back to simple EV-based selection
            else:
                # Mask illegal actions with -inf values
                masked_values = np.ones_like(ev_values) * float('-inf')
                masked_values[legal_actions] = ev_values[legal_actions]
                
                # Select action with highest expected value
                action = np.argmax(masked_values)
                # Convert numpy int to Python int
                action = safe_int_convert(action)
                
                return {
                    'action': action,
                    'amount': 0,  # Will be set by game engine
                    'ev': ev_values[action],
                    'method': 'ev_based'
                }
    
    def _is_facing_raise(self, state) -> bool:
        """Determine if the player is facing a raise/bet."""
        # This is a simplified implementation
        # In a real system, you would parse the game history
        
        # For OpenSpiel, we can check if any bets are in the pot
        if hasattr(state, 'pot'):
            return state.pot() > 0
        
        # For universal poker specifically
        if hasattr(state, 'contribution'):
            contributions = state.contribution()
            return any(c > 0 for c in contributions)
            
        return False
    
    def _select_best_action_with_sizing(self, action_to_ev, bet_options, state) -> Tuple[int, float, float]:
        """
        Select the best action considering dynamic bet sizing options.
        
        Args:
            action_to_ev: Dict mapping action IDs to expected values
            bet_options: Dict of bet sizing options from DynamicBetSizing
            state: Current game state
            
        Returns:
            Tuple of (action_id, amount, expected_value)
        """
        # Ensure action_to_ev is a dictionary
        if not isinstance(action_to_ev, dict):
            logging.warning(f"action_to_ev is not a dictionary: {type(action_to_ev)}")
            # Create a simple fallback dictionary with legal actions
            fallback_ev = {}
            for action in state.legal_actions():
                fallback_ev[safe_int_convert(action)] = 0.0  # Assign neutral expected value
            action_to_ev = fallback_ev
        
        # Ensure bet_options is a dictionary
        if not isinstance(bet_options, dict):
            logging.warning(f"bet_options is not a dictionary: {type(bet_options)}")
            # Create a simple fallback dictionary
            bet_options = {
                'fold': 0.0,
                'call': 0.0,
                'raise_min': 2.0,  # Minimal raise
                'raise_max': 10.0  # Maximum raise
            }
        
        # Map fold, call, and raise actions
        fold_action = self._get_fold_action(state)
        call_action = self._get_call_action(state)
        raise_actions = self._get_raise_actions(state)
        
        # Convert any numpy integers to Python integers in the action_to_ev dictionary
        # This ensures we don't have compatibility issues with dictionary keys
        converted_action_to_ev = {}
        for action, ev in action_to_ev.items():
            # Convert action key to Python int if it's a numpy integer
            action_key = safe_int_convert(action)
            converted_action_to_ev[action_key] = float(ev) if ev is not None else 0.0
            
        # Use the converted dictionary from now on
        action_to_ev = converted_action_to_ev
        
        # Initialize with worst possible value
        best_action = fold_action
        best_amount = 0
        best_ev = float('-inf')
        
        # Evaluate fold
        if fold_action in action_to_ev:
            fold_ev = action_to_ev[fold_action]
            if fold_ev > best_ev:
                best_ev = fold_ev
                best_action = fold_action
                best_amount = 0
        
        # Evaluate call
        if call_action in action_to_ev:
            call_ev = action_to_ev[call_action]
            if call_ev > best_ev:
                best_ev = call_ev
                best_action = call_action
                # Handle different bet_options types safely
                if isinstance(bet_options, dict) and 'call' in bet_options:
                    try:
                        best_amount = float(bet_options['call'])
                    except (ValueError, TypeError):
                        logging.warning(f"Could not convert bet_options['call'] with value {bet_options['call']} to float")
                        best_amount = 0.0
                else:
                    best_amount = 0.0
        
        # Evaluate different raise sizes
        if raise_actions:
            # For each raise action, evaluate with different sizing options
            for raise_action in raise_actions:
                raise_ev = action_to_ev[raise_action]
                
                # Skip if this action has terrible EV
                if raise_ev < best_ev - 0.5:
                    continue
                
                # Get bet options that are reasonable for this action
                # (excluding fold and call options)
                raise_options = {}
                if isinstance(bet_options, dict):
                    try:
                        # Filter out fold and call options, ensure we only have valid numeric values
                        for k, v in bet_options.items():
                            if k != 'fold' and k != 'call':
                                try:
                                    amount_value = float(v)
                                    if amount_value > 0:
                                        raise_options[k] = amount_value
                                except (ValueError, TypeError):
                                    logging.debug(f"Skipping non-numeric bet option {k}: {v}")
                    except Exception as e:
                        logging.warning(f"Error processing bet_options: {e}")
                
                # If we have raise options, find the best one
                if raise_options:
                    # Choose optimal sizing based on EV
                    for option_name, amount in raise_options.items():
                        try:
                            # Ensure raise_ev is a number
                            if not isinstance(raise_ev, (int, float)):
                                if hasattr(raise_ev, 'item'):
                                    # Handle numpy scalar
                                    raise_ev = float(raise_ev.item())
                                elif hasattr(raise_ev, '__float__'):
                                    # Try converting to float
                                    raise_ev = float(raise_ev)
                                else:
                                    # Use a default value if conversion not possible
                                    raise_ev = 0.0
                                    logging.warning(f"Could not convert raise_ev of type {type(raise_ev)} to float")
                            
                            # Convert amount to float
                            try:
                                amount_float = float(amount)
                            except (ValueError, TypeError):
                                logging.warning(f"Invalid amount {amount} for option {option_name}, skipping")
                                continue
                                
                            # Safety check for division
                            if amount_float <= 0:
                                size_factor = 1.0
                            else:
                                size_factor = 1.0 + (amount_float / 100.0)  # Small adjustment factor
                                
                            # Calculate adjusted EV with type safety
                            adjusted_ev = raise_ev / size_factor
                            
                            if adjusted_ev > best_ev:
                                best_ev = raise_ev  # Store original EV
                                best_action = raise_action
                                best_amount = amount_float
                        except (ValueError, TypeError, ZeroDivisionError) as e:
                            logging.warning(f"Error calculating adjusted EV for option {option_name}: {e}")
        
        return best_action, best_amount, best_ev
    
    def _get_fold_action(self, state) -> int:
        """Get the action ID for folding."""
        # In most poker variants, fold is action 0
        return 0
    
    def _get_call_action(self, state) -> int:
        """Get the action ID for calling."""
        # In most poker variants, call/check is action 1
        return 1
    
    def _get_raise_actions(self, state) -> List[int]:
        """Get the action IDs for raising."""
        # In most poker variants, raise options start at action 2
        legal_actions = state.legal_actions()
        return [a for a in legal_actions if a >= 2]

# Test function
def test_action_selector():
    """Test the action selector functionality."""
    from environment import PokerEnvironment
    from psro import PSROSolver
    from models import StateProcessor, Config
    import pyspiel
    
    # Mock configuration
    config = Config()
    
    # Create game
    game = pyspiel.load_game(config.GAME_NAME)
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize mock solver
    solver = PSROSolver(config, state_processor)
    
    # Load models if available
    model_loaded = solver.load_checkpoints()
    if not model_loaded:
        logging.warning("No models found, using untrained networks")
    
    # Create environment
    env = PokerEnvironment(config.GAME_NAME, config.NUM_PLAYERS)
    
    # Create action selector
    action_selector = PokerActionSelector(game, solver, state_processor, config)
    
    # Reset environment
    state = env.reset()
    
    # Sample scenario data
    stack_sizes = [100, 100, 100, 100, 100, 100]
    pot_size = 3.5
    board = []
    hole_cards = ["Ah", "Ks"]
    position_name = "BTN"
    player_id = 0
    
    # Select action
    result = action_selector.select_action(
        state,
        player_id,
        stack_sizes,
        pot_size,
        board,
        hole_cards,
        position_name,
        detailed_output=True
    )
    
    print("Selected action:", result)
    
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_action_selector()