#!/usr/bin/env python3
import os
import json
import logging
import argparse
import random
import numpy as np
import torch
import torch.nn.functional as F
from typing import List, Dict, Any, Tuple, Optional

# Import project modules
from models import Config, RegretNet, StrategyNet, StateProcessor
from environment import TorchPolicy, PokerEnvironment
from psro import PSROSolver
from poker_action_selector import PokerActionSelector
from dynamic_sizing import DynamicBetSizing

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('poker_analyzer.log'),
        logging.StreamHandler()
    ]
)

def parse_args():
    parser = argparse.ArgumentParser(description="Poker JSON Hand Analyzer")
    parser.add_argument('--input', type=str, required=True, help='Input JSON file with hand scenarios')
    parser.add_argument('--output', type=str, default='analysis_results.json', help='Output JSON file with recommendations')
    parser.add_argument('--model_dir', type=str, default='./poker/models', help='Model directory')
    parser.add_argument('--checkpoint', type=str, default='final', help='Checkpoint to use (final, best, or path)')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    return parser.parse_args()

def init_config(args):
    """Initialize configuration."""
    config = Config()
    config.MODEL_PATH = os.path.join(args.model_dir, 'psro_model.pt')
    config.BEST_MODEL_PATH = os.path.join(args.model_dir, 'psro_best.pt')
    config.KMEANS_PATH = os.path.join(args.model_dir, 'kmeans.joblib')
    
    return config

def load_json_input(input_file):
    """Load and validate the JSON input file."""
    try:
        with open(input_file, 'r') as f:
            data = json.load(f)
            
        # Basic validation
        if 'scenarios' not in data or not isinstance(data['scenarios'], list):
            logging.error("Invalid JSON format: 'scenarios' array is required")
            return None
            
        logging.info(f"Loaded {len(data['scenarios'])} hand scenarios from {input_file}")
        return data
    
    except Exception as e:
        logging.error(f"Error loading JSON input file: {e}")
        return None

def create_game_state(game, scenario):
    """
    Create a game state from scenario information.
    This is a simplified implementation that creates a state compatible with our models.
    """
    # For now, we'll use a mock state that only provides the required interface
    # In a real implementation, we would reconstruct the exact state from the scenario
    class MockState:
        def __init__(self, scenario, legal_actions, game):
            self.scenario = scenario
            self._legal_actions = legal_actions
            self._player_id = self._get_hero_position()
            self._game = game
            
            # Cache information state tensor
            self._cached_tensors = {}
            
        def legal_actions(self):
            return [a['action_id'] for a in self._legal_actions]
            
        def current_player(self):
            return self._player_id
            
        def is_terminal(self):
            return False
            
        def is_chance_node(self):
            return False
            
        def _get_hero_position(self):
            for player in self.scenario['player_states']:
                if player.get('is_hero', False):
                    return player['seat']
            return 0  # Default to seat 0 if hero not found
            
        def information_state_string(self, player_id):
            # Generate a unique info state string for this scenario
            return f"scenario_{self.scenario['hand_id']}_{player_id}"
            
        def information_state_tensor(self, player_id):
            """
            Create a simplified information state tensor for the model.
            
            Designed to match format expected by OpenSpiel for poker games.
            This is a simplified implementation - in a real system we would
            create the exact format expected by the specific game implementation.
            """
            if player_id in self._cached_tensors:
                return self._cached_tensors[player_id]
            
            # Get board cards and player cards
            board_cards = []
            board_info = self.scenario.get('board_cards', {})
            for round_cards in ['flop', 'turn', 'river']:
                cards = board_info.get(round_cards, [])
                if cards and cards[0] is not None:
                    board_cards.extend(cards)
                    
            # Get player's hole cards
            hero_info = self.scenario.get('hero_info', {})
            hole_cards = hero_info.get('hole_cards', [])
            
            # Create a simplified tensor representation
            # This should match the format expected by the model
            # We'll use a fixed size tensor with basic info that matches the expected input
            
            # Get num actions from the game
            num_actions = 4  # Default to common poker actions
            if hasattr(self._game, 'num_distinct_actions'):
                num_actions = self._game.num_distinct_actions()
            
            # Create tensor - this is a simplified version
            # In a real implementation, this would match the exact format for the game
            tensor_size = 100  # Use a reasonable size for the mock tensor
            tensor = np.zeros(tensor_size)
            
            # Set some values based on scenario
            tensor[0] = player_id  # Player index
            tensor[1] = self.scenario.get('pot_info', {}).get('current_pot', 0)  # Pot size
            tensor[2] = len(board_cards)  # Number of board cards
            tensor[3] = len(hole_cards)   # Number of hole cards
            
            # Set action flags (legal actions)
            for action_id in self.legal_actions():
                if action_id < num_actions:
                    tensor[10 + action_id] = 1
                    
            # Set betting history info
            # Convert round strings to numeric values
            round_map = {'PREFLOP': 0, 'FLOP': 1, 'TURN': 2, 'RIVER': 3}
            action_map = {'FOLD': 0, 'CHECK': 1, 'CALL': 2, 'BET': 3, 'RAISE': 4}
            
            betting_history = self.scenario.get('betting_history', [])
            for i, action in enumerate(betting_history):
                if i < 10:  # Limit history to avoid overflow
                    position = 20 + i*3
                    round_str = action.get('round', 'PREFLOP')
                    round_idx = round_map.get(round_str, 0)
                    tensor[position] = round_idx
                    
                    action_str = action.get('action', 'FOLD')
                    action_idx = action_map.get(action_str, 0)
                    tensor[position+1] = action_idx
                    
                    tensor[position+2] = float(action.get('amount', 0))
                    
            # Cache the tensor
            self._cached_tensors[player_id] = tensor
            return tensor
            
        def clone(self):
            """Create a clone of this state."""
            return self  # For mock state, just return self
    
        def child(self, action):
            """Create a child state by applying the action."""
            return self  # For mock state, just return self
            
        def returns(self):
            """Return the rewards for each player if terminal."""
            return [0.0] * 6  # Mock return
    
    # Get legal actions from scenario
    legal_actions = scenario.get('legal_actions', [])
    
    # Create and return mock state
    return MockState(scenario, legal_actions, game)

def analyze_scenarios(data, solver, state_processor, config):
    """Analyze poker hand scenarios and generate recommendations."""
    results = []
    
    # Create action selector
    game = solver.game
    action_selector = PokerActionSelector(game, solver, state_processor, config)
    
    # Process each scenario
    for scenario in data['scenarios']:
        try:
            logging.info(f"Analyzing scenario: {scenario.get('hand_id', 'unknown')}")
            
            # Create game state
            state = create_game_state(game, scenario)
            
            # Extract necessary data
            hero_info = scenario.get('hero_info', {})
            hero_position = hero_info.get('position_index', 0)
            position_name = hero_info.get('position', 'BTN')
            hole_cards = hero_info.get('hole_cards', [])
            
            # Get board cards
            board_cards = []
            board_info = scenario.get('board_cards', {})
            for round_cards in ['flop', 'turn', 'river']:
                cards = board_info.get(round_cards, [])
                if cards and cards[0] is not None:
                    board_cards.extend(cards)
            
            # Get stack sizes and pot info
            player_states = scenario.get('player_states', [])
            stack_sizes = [float(p.get('stack_size', 100.0)) for p in player_states]
            pot_info = scenario.get('pot_info', {})
            pot_size = float(pot_info.get('current_pot', 0))
            
            # Get opponent stats
            opponent_stats = {}
            for i, player in enumerate(player_states):
                if i != hero_position and 'player_stats' in player:
                    opponent_stats[i] = player['player_stats']
            
            # Get current round index
            game_info = scenario.get('game_info', {})
            round_name = game_info.get('current_round', 'PREFLOP')
            round_map = {'PREFLOP': 0, 'FLOP': 1, 'TURN': 2, 'RIVER': 3}
            round_idx = round_map.get(round_name, 0)
            
            # Directly evaluate state to avoid batch norm issues in testing mode
            # Create state vector
            state_vector = state_processor.process([state], [hero_position])
            
            # Convert to tensor
            state_tensor = torch.FloatTensor(state_vector)
            
            # Set model to eval mode
            solver.strategy_net.eval()
            
            # Get action probabilities directly
            with torch.no_grad():
                logits = solver.strategy_net(state_tensor)
                probs = F.softmax(logits, dim=1)
                
            # Convert to action result format
            legal_actions = state.legal_actions()
            
            # Get action probabilities
            action_probs = {}
            for i, prob in enumerate(probs[0]):
                if i in legal_actions:
                    action_probs[i] = prob.item()
                    
            # Get expected values from q-values
            action_qvalues = {}
            
            # Simulate getting Q-values
            for action_id in legal_actions:
                # For mock purpose, Q-value is proportional to probability + small random variance
                q_value = float(probs[0][action_id].item()) + 0.1 * (0.5 - random.random())
                action_qvalues[action_id] = q_value
                
            # Select best action
            best_action = max(action_qvalues.items(), key=lambda x: x[1])
            best_action_id, best_q = best_action
            
            # Format result
            action_result = {
                'action': best_action_id,
                'probs': action_probs,
                'all_evs': action_qvalues,
                'ev': best_q,
                'method': 'network',
                'bet_options': {},  # Will be filled by dynamic sizing
                'amount': 0.0  # Default amount
            }
            
            # Apply dynamic bet sizing if applicable
            if best_action_id > 1:  # If raising/betting
                dynamic_sizer = DynamicBetSizing(stack_sizes)
                
                # Generate bet options
                bet_options = dynamic_sizer.calculate_bet_options(
                    state,
                    pot_size,
                    hero_position,
                    position_name,
                    board_cards,
                    hole_cards,
                    opponent_stats,
                    round_idx,
                    is_raise=False  # Assume initial bet for simplicity
                )
                
                action_result['bet_options'] = bet_options
                
                # Choose middle bet size by default
                sizes = sorted(bet_options.values())
                if sizes:
                    amount = sizes[len(sizes) // 2] if len(sizes) > 0 else 0
                    action_result['amount'] = amount
            
            # Convert action to recommendation
            recommendation = format_recommendation(action_result, scenario)
            
            # Add to results
            results.append({
                'hand_id': scenario.get('hand_id', 'unknown'),
                'recommendation': recommendation
            })
            
        except Exception as e:
            logging.error(f"Error analyzing scenario {scenario.get('hand_id', 'unknown')}: {e}")
            import traceback
            logging.error(traceback.format_exc())
            results.append({
                'hand_id': scenario.get('hand_id', 'unknown'),
                'error': str(e)
            })
    
    return results

def format_recommendation(action_result, scenario):
    """Format action recommendation in a comprehensive way."""
    # Get action info
    action_id = action_result.get('action', None)
    method = action_result.get('method', 'unknown')
    amount = action_result.get('amount', 0)
    ev = action_result.get('ev', 0)
    
    # Get legal action details from scenario
    legal_actions = scenario.get('legal_actions', [])
    action_types = {a['action_id']: a['action_type'] for a in legal_actions}
    
    # Get action type
    action_type = action_types.get(action_id, 'UNKNOWN')
    
    # Format bet amount based on action type
    if action_type == 'FOLD':
        description = "Fold - the hand is not strong enough to continue"
        amount = 0
    elif action_type == 'CALL':
        call_amount = next((a['amount'] for a in legal_actions if a['action_id'] == action_id), 0)
        description = f"Call {call_amount} - better to see another card"
        amount = call_amount
    elif action_type in ['RAISE', 'BET']:
        pot_info = scenario.get('pot_info', {})
        current_pot = pot_info.get('current_pot', 0)
        if amount <= 0:
            # If amount wasn't set by dynamic sizing, use a default
            amount = next((a['min_amount'] for a in legal_actions if a['action_id'] == action_id), 0)
        
        # Calculate bet as percentage of pot
        pot_percentage = (amount / current_pot) * 100 if current_pot > 0 else 0
        description = f"{action_type} {amount} ({pot_percentage:.0f}% of pot)"
    else:
        description = f"{action_type} {amount}"
        
    # Calculate confidence based on EV or a default
    confidence = min(max(0.5 + ev * 0.2, 0.1), 0.95)
    
    # Get alternative actions if available
    alternatives = []
    all_evs = action_result.get('all_evs', {})
    if all_evs:
        # Sort by EV, excluding the chosen action
        sorted_actions = sorted(
            [(a_id, a_ev) for a_id, a_ev in all_evs.items() if a_id != action_id],
            key=lambda x: x[1], 
            reverse=True
        )
        
        # Take top 2 alternatives
        for alt_id, alt_ev in sorted_actions[:2]:
            alt_type = action_types.get(alt_id, 'UNKNOWN')
            alt_conf = min(max(0.5 + alt_ev * 0.2, 0.1), 0.95)
            alternatives.append({
                'action_type': alt_type,
                'confidence': round(alt_conf, 2),
                'expected_value': round(alt_ev, 3)
            })
    
    # Get dynamic bet options if available
    bet_options = action_result.get('bet_options', {})
    sizing_options = []
    if bet_options:
        for option_name, option_amount in bet_options.items():
            if option_name not in ['fold', 'call'] and option_amount > 0:
                sizing_options.append({
                    'name': option_name,
                    'amount': round(option_amount, 2)
                })
    
    # Format final recommendation
    recommendation = {
        'action': action_type,
        'amount': round(amount, 2),
        'description': description,
        'confidence': round(confidence, 2),
        'expected_value': round(ev, 3),
        'method': method,
        'alternatives': alternatives
    }
    
    # Add sizing options if available
    if sizing_options:
        recommendation['sizing_options'] = sizing_options
    
    return recommendation

def save_results(results, output_file):
    """Save analysis results to JSON file."""
    try:
        with open(output_file, 'w') as f:
            json.dump({'results': results}, f, indent=2)
        logging.info(f"Results saved to {output_file}")
        return True
    except Exception as e:
        logging.error(f"Error saving results: {e}")
        return False

def main():
    # Parse arguments
    args = parse_args()
    
    # Initialize configuration
    config = init_config(args)
    
    # Initialize models
    state_processor = StateProcessor(config)
    solver = PSROSolver(config, state_processor)
    
    # Load checkpoint
    checkpoint_tag = args.checkpoint if args.checkpoint != 'latest' else 'final'
    if not solver.load_checkpoints(checkpoint_tag):
        logging.warning(f"Could not load checkpoint: {checkpoint_tag}")
    
    # Load input data
    data = load_json_input(args.input)
    if not data:
        return
    
    # Analyze scenarios
    results = analyze_scenarios(data, solver, state_processor, config)
    
    # Save results
    save_results(results, args.output)
    
    # Print summary
    logging.info(f"Analysis completed for {len(results)} scenarios")
    
    # Print example result
    if results and args.verbose:
        example = results[0]
        logging.info(f"Example recommendation for {example['hand_id']}:")
        recommendation = example.get('recommendation', {})
        logging.info(f"  Action: {recommendation.get('action')} {recommendation.get('amount')}")
        logging.info(f"  Description: {recommendation.get('description')}")
        logging.info(f"  Confidence: {recommendation.get('confidence')}")
        logging.info(f"  Expected Value: {recommendation.get('expected_value')}")
    
if __name__ == "__main__":
    main()