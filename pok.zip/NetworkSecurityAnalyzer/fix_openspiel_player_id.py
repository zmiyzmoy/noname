#!/usr/bin/env python3
"""
OpenSpiel Player ID=-4 Fix Module

This module provides a fix for the OpenSpiel universal_poker implementation
where player ID=-4 is incorrectly returned for certain terminal states.

The fix works by catching and handling the player ID=-4 case by marking
those states as terminal states, which is what they should be according to our testing.
"""

import logging
from typing import Optional, Any, Dict, List, Union, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class OpenSpielPlayerIdFix:
    """
    Provides fixes for the player ID=-4 issue in OpenSpiel.
    
    This class can be used as a wrapper or directly via its static methods
    to handle cases where OpenSpiel returns player ID=-4 incorrectly.
    """
    
    @staticmethod
    def is_valid_player_id(player_id: int) -> bool:
        """
        Check if a player ID is valid.
        
        Args:
            player_id: The player ID to check
            
        Returns:
            True if valid, False otherwise
        """
        # In OpenSpiel, player IDs are non-negative for regular players
        # Player ID = -1 is reserved for chance nodes
        # Player ID = -2 is valid for simultaneous move games (not used in poker)
        # Player ID = -3 is valid for mean field games (not used in poker)
        # Player ID = -4 is invalid and indicates an error
        return player_id >= 0 or player_id == -1 or player_id == -2 or player_id == -3
    
    @staticmethod
    def get_fixed_player_id(player_id: int, state: Any = None) -> int:
        """
        Fix player ID if invalid.
        
        Args:
            player_id: Original player ID
            state: Game state (if available)
            
        Returns:
            Fixed player ID
        """
        if player_id == -4:
            logger.warning("Detected invalid player ID=-4, fixing it")
            
            # If we have a state object, check if it should be terminal
            if state and hasattr(state, 'is_terminal'):
                if state.is_terminal():
                    logger.info("State with player ID=-4 is actually terminal")
                    # Keep -4 to indicate terminal state, caller should handle it
                    return -4
                
                # Check if this is after the last chance node at a hand end
                if hasattr(state, 'history') and state.history():
                    history = state.history()
                    # If last action was a chance action, this is likely a terminal state
                    # in poker that OpenSpiel misidentifies
                    if len(history) > 0 and history[-1] >= 0:  # Chance actions are typically positive indices
                        logger.info("State with player ID=-4 after chance action is likely terminal")
                        # Return -4 to indicate special handling needed
                        return -4
            
            # If we have no information, assume it's a terminal state (safer option)
            logger.warning("Assuming player ID=-4 indicates terminal state")
            return -4
            
        return player_id
    
    @staticmethod
    def fix_state_player(state: Any) -> Tuple[int, bool]:
        """
        Check and fix the current player in a state.
        
        Args:
            state: Game state
            
        Returns:
            Tuple of (fixed_player_id, is_terminal_override)
        """
        if not hasattr(state, 'current_player'):
            return -1, False
            
        player_id = state.current_player()
        fixed_player_id = OpenSpielPlayerIdFix.get_fixed_player_id(player_id, state)
        
        # If player ID is still -4 after fixing, we need to mark this as terminal
        is_terminal_override = fixed_player_id == -4
        
        # For caller convenience, return a valid player ID even when terminal
        # This avoids crashes in code expecting valid player IDs
        if is_terminal_override:
            # Return 0 as a safe player ID when we know it's terminal
            # Caller should check is_terminal_override first
            return 0, True
            
        return fixed_player_id, False
        
    @staticmethod
    def is_terminal_or_error(state: Any) -> bool:
        """
        Check if a state is terminal or has an error.
        
        Args:
            state: Game state
            
        Returns:
            True if terminal or error state, False otherwise
        """
        if not hasattr(state, 'current_player') or not hasattr(state, 'is_terminal'):
            return False
            
        # First check if the state says it's terminal
        if state.is_terminal():
            return True
            
        # Then check for player ID=-4 which indicates terminal or error
        player_id = state.current_player()
        if player_id == -4:
            return True
            
        return False

# Example usage in the main code:
def example_usage():
    """Example of how to use the OpenSpielPlayerIdFix class."""
    # Assume 'state' is an OpenSpiel state object
    # state = game.new_initial_state()
    # 
    # while not state.is_terminal():
    #     player = state.current_player()
    #     
    #     # Fix player ID issues
    #     fixed_player, is_terminal_override = OpenSpielPlayerIdFix.fix_state_player(state)
    #     
    #     # If we detected a terminal state via player ID=-4, break out
    #     if is_terminal_override:
    #         logger.info("Breaking out of game loop due to terminal state detection")
    #         break
    #         
    #     # Use the fixed player ID for decision making
    #     if fixed_player >= 0:  # Regular player
    #         # Regular player action
    #         action = choose_action(state)
    #         state.apply_action(action)
    #     elif fixed_player == -1:  # Chance player
    #         # Chance action
    #         action = sample_chance_action(state)
    #         state.apply_action(action)
    
    pass

if __name__ == "__main__":
    logger.info("OpenSpiel Player ID Fix module - Import this module to use the fixes")