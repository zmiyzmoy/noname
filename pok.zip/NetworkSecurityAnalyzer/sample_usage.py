#!/usr/bin/env python3
"""
Sample script to demonstrate how to use the Poker JSON analyzer.
This script creates a sample hand scenario, saves it to a JSON file,
and then analyzes it using the analyzer.
"""

import json
import subprocess
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
)

def create_sample_hand():
    """Create a sample hand scenario."""
    
    sample_hand = {
        "version": "1.0",
        "scenarios": [
            {
                "hand_id": "SAMPLE_001",
                "description": "Late position decision with pocket pairs",
                
                "game_info": {
                    "game_type": "NL_HOLDEM",
                    "table_type": "6MAX",
                    "blinds": {
                        "small_blind": 1.0,
                        "big_blind": 2.0
                    },
                    "ante": 0.0,
                    "current_round": "FLOP",
                    "num_players": 6
                },
                
                "hero_info": {
                    "position": "BTN",
                    "position_index": 3,
                    "hole_cards": ["Qs", "Qd"],
                    "stack_size": 90.0,
                    "vpip": 24.5,
                    "pfr": 18.2,
                    "three_bet": 6.8,
                    "aggression_factor": 2.1,
                    "hands_played": 450
                },
                
                "board_cards": {
                    "flop": ["8h", "Ts", "2c"],
                    "turn": None,
                    "river": None
                },
                
                "pot_info": {
                    "current_pot": 12.5,
                    "current_bet": 4.5,
                    "to_call": 4.5,
                    "min_raise": 9.0
                },
                
                "player_states": [
                    {
                        "seat": 0,
                        "position": "SB",
                        "stack_size": 98.0,
                        "has_folded": True,
                        "last_action": {
                            "action_type": "FOLD",
                            "amount": 0.0,
                            "round": "FLOP"
                        },
                        "player_stats": {
                            "vpip": 22.0,
                            "pfr": 15.0,
                            "three_bet": 5.3,
                            "fold_to_three_bet": 65.0,
                            "fold_to_cbet": 58.0,
                            "aggression_factor": 1.8,
                            "hands_played": 350
                        }
                    },
                    {
                        "seat": 1,
                        "position": "BB",
                        "stack_size": 98.0,
                        "has_folded": False,
                        "last_action": {
                            "action_type": "BET",
                            "amount": 4.5,
                            "round": "FLOP"
                        },
                        "player_stats": {
                            "vpip": 28.5,
                            "pfr": 17.2,
                            "three_bet": 7.0,
                            "fold_to_three_bet": 55.0,
                            "fold_to_cbet": 45.0,
                            "aggression_factor": 2.6,
                            "hands_played": 420
                        }
                    },
                    {
                        "seat": 2,
                        "position": "UTG",
                        "stack_size": 100.0,
                        "has_folded": True,
                        "last_action": {
                            "action_type": "FOLD",
                            "amount": 0.0,
                            "round": "PREFLOP"
                        },
                        "player_stats": {
                            "vpip": 18.0,
                            "pfr": 14.0,
                            "three_bet": 4.0,
                            "fold_to_three_bet": 70.0,
                            "fold_to_cbet": 62.0,
                            "aggression_factor": 1.5,
                            "hands_played": 380
                        }
                    },
                    {
                        "seat": 3,
                        "position": "BTN",
                        "stack_size": 90.0,
                        "is_hero": True,
                        "has_folded": False,
                        "last_action": {
                            "action_type": "CALL",
                            "amount": 2.0,
                            "round": "PREFLOP"
                        }
                    },
                    {
                        "seat": 4,
                        "position": "CO",
                        "stack_size": 105.0,
                        "has_folded": True,
                        "last_action": {
                            "action_type": "FOLD",
                            "amount": 0.0,
                            "round": "PREFLOP"
                        },
                        "player_stats": {
                            "vpip": 25.0,
                            "pfr": 20.0,
                            "three_bet": 8.0,
                            "fold_to_three_bet": 58.0,
                            "fold_to_cbet": 52.0,
                            "aggression_factor": 2.4,
                            "hands_played": 400
                        }
                    },
                    {
                        "seat": 5,
                        "position": "MP",
                        "stack_size": 94.0,
                        "has_folded": False,
                        "last_action": {
                            "action_type": "CALL",
                            "amount": 3.0,
                            "round": "PREFLOP"
                        },
                        "player_stats": {
                            "vpip": 32.0,
                            "pfr": 16.0,
                            "three_bet": 4.5,
                            "fold_to_three_bet": 60.0,
                            "fold_to_cbet": 40.0,
                            "aggression_factor": 1.2,
                            "hands_played": 320
                        }
                    }
                ],
                
                "betting_history": [
                    {"round": "PREFLOP", "position": "UTG", "action": "FOLD", "amount": 0.0},
                    {"round": "PREFLOP", "position": "MP", "action": "RAISE", "amount": 3.0},
                    {"round": "PREFLOP", "position": "CO", "action": "FOLD", "amount": 0.0},
                    {"round": "PREFLOP", "position": "BTN", "action": "CALL", "amount": 3.0, "is_hero": True},
                    {"round": "PREFLOP", "position": "SB", "action": "FOLD", "amount": 0.0},
                    {"round": "PREFLOP", "position": "BB", "action": "CALL", "amount": 2.0},
                    {"round": "FLOP", "position": "BB", "action": "BET", "amount": 4.5},
                    {"round": "FLOP", "position": "MP", "action": "CALL", "amount": 4.5}
                ],
                
                "legal_actions": [
                    {"action_id": 0, "action_type": "FOLD", "amount": 0.0},
                    {"action_id": 1, "action_type": "CALL", "amount": 4.5},
                    {"action_id": 2, "action_type": "RAISE", "min_amount": 9.0, "max_amount": 90.0}
                ],
                
                "hand_evaluation": {
                    "hand_type": "OVERPAIR",
                    "made_hand": "PAIR",
                    "hand_strength": 0.75,
                    "equity_vs_range": 0.68,
                    "expected_value": None
                }
            }
        ]
    }
    
    return sample_hand

def save_json_file(data, filename):
    """Save data to a JSON file."""
    try:
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
        logging.info(f"Saved sample hand to {filename}")
        return True
    except Exception as e:
        logging.error(f"Error saving JSON file: {e}")
        return False

def analyze_hand(input_file, output_file):
    """Run the analyzer on the input file."""
    try:
        cmd = ["python", "poker_json_analyzer.py", 
               "--input", input_file, 
               "--output", output_file,
               "--verbose"]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            logging.info("Analysis completed successfully")
            logging.info(result.stdout)
        else:
            logging.error(f"Analysis failed with error code {result.returncode}")
            logging.error(result.stderr)
            
    except Exception as e:
        logging.error(f"Error running analyzer: {e}")

def display_results(filename):
    """Display the analysis results."""
    try:
        with open(filename, 'r') as f:
            results = json.load(f)
            
        logging.info("Analysis results:")
        for scenario in results.get('results', []):
            hand_id = scenario.get('hand_id', 'unknown')
            recommendation = scenario.get('recommendation', {})
            
            if recommendation:
                action = recommendation.get('action')
                amount = recommendation.get('amount')
                desc = recommendation.get('description')
                conf = recommendation.get('confidence')
                ev = recommendation.get('expected_value')
                
                logging.info(f"Hand {hand_id}:")
                logging.info(f"  Recommended action: {action} {amount}")
                logging.info(f"  Description: {desc}")
                logging.info(f"  Confidence: {conf}")
                logging.info(f"  Expected value: {ev}")
                
                alternatives = recommendation.get('alternatives', [])
                if alternatives:
                    logging.info("  Alternative actions:")
                    for alt in alternatives:
                        alt_action = alt.get('action_type')
                        alt_conf = alt.get('confidence')
                        alt_ev = alt.get('expected_value')
                        logging.info(f"    {alt_action} (conf: {alt_conf}, EV: {alt_ev})")
            else:
                error = scenario.get('error')
                logging.error(f"Hand {hand_id} analysis failed: {error}")
                
    except Exception as e:
        logging.error(f"Error displaying results: {e}")

def main():
    """Main function."""
    input_file = "sample_hand.json"
    output_file = "sample_analysis.json"
    
    # Create and save sample hand
    sample_hand = create_sample_hand()
    if save_json_file(sample_hand, input_file):
        # Run analysis
        analyze_hand(input_file, output_file)
        # Display results
        display_results(output_file)

if __name__ == "__main__":
    main()