#!/usr/bin/env python3
"""
Simple CLI for running Poker AI training with various configurations.
This script provides an easy way to configure and run training without relying on the web interface.
"""

import os
import sys
import argparse
import subprocess
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Poker AI Training CLI")
    
    # Operation mode
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'selfplay'], default='selfplay',
                        help='Operation mode: train, eval, or selfplay')
    
    # Training parameters
    parser.add_argument('--num_episodes', type=int, default=100,
                        help='Number of episodes/hands to play')
    parser.add_argument('--num_iterations', type=int, default=10,
                        help='Number of training iterations for PSRO')
    parser.add_argument('--batch_size', type=int, default=64,
                        help='Batch size for neural network training')
    parser.add_argument('--learning_rate', type=float, default=0.001,
                        help='Learning rate for optimizer')
    parser.add_argument('--use_mixed_precision', action='store_true',
                        help='Use mixed precision training for better performance on GPUs')
    
    # Evaluation parameters
    parser.add_argument('--eval_opponents', type=str, 
                        default='random,tight_passive,tight_aggressive,loose_passive,loose_aggressive',
                        help='Comma-separated list of opponents for evaluation')
    parser.add_argument('--checkpoint', type=str, default='latest',
                        help='Checkpoint to load (e.g., "latest", "final", or specific tag)')
    
    # System parameters
    parser.add_argument('--num_workers', type=int, default=4,
                        help='Number of parallel workers for training')
    parser.add_argument('--verbose', action='store_true', default=True,
                        help='Enable verbose output')
    
    return parser.parse_args()

def generate_command(args):
    """Generate the command to run the poker_rl.py script with the specified arguments."""
    cmd = ["python", "poker_rl.py"]
    
    # Add all arguments
    for arg_name, arg_value in vars(args).items():
        if arg_value is True:
            cmd.append(f"--{arg_name}")
        elif arg_value is not False and arg_value is not None:
            cmd.append(f"--{arg_name}")
            cmd.append(str(arg_value))
    
    return cmd

def main():
    args = parse_args()
    
    # Print configuration
    logger.info("=== Poker AI Training Configuration ===")
    for arg_name, arg_value in vars(args).items():
        logger.info(f"{arg_name}: {arg_value}")
    logger.info("=======================================")
    
    # Generate command
    cmd = generate_command(args)
    cmd_str = " ".join(cmd)
    logger.info(f"Running command: {cmd_str}")
    
    # Execute command
    try:
        # Use subprocess.run to run the command and capture output
        result = subprocess.run(cmd, check=True, text=True)
        logger.info("Training completed successfully")
    except subprocess.CalledProcessError as e:
        logger.error(f"Error running training: {e}")
        return 1
    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())