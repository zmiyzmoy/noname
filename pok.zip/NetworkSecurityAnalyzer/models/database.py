"""
Database models for Poker AI Admin Dashboard and monitoring system.
"""

import json
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from flask_login import UserMixin

# Import the database instance
from models.db import db

# Base class for all models
Base = db.Model

class User(Base, UserMixin):
    """User model for authentication and authorization."""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password = Column(String(256), nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)
    
    hardware_configs = relationship('HardwareConfig', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<User {self.username}>'

class HardwareConfig(Base):
    """Hardware configuration for training sessions."""
    __tablename__ = 'hardware_configs'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'))
    num_cpus = Column(Integer, default=8)
    num_gpus = Column(Integer, default=1)
    gpu_memory = Column(Integer, default=8)
    cpu_memory = Column(Integer, default=16)
    gpu_type = Column(String(50), default='default')
    use_cuda = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<HardwareConfig {self.name}>'
        
# Removed duplicated SystemSettings class, using SystemSetting instead

class TrainingConfig(Base):
    """Training configuration for AI models."""
    __tablename__ = 'training_configs'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    game_type = Column(String(50), default='nl_holdem')
    num_players = Column(Integer, default=6)
    batch_size = Column(Integer, default=64)
    learning_rate = Column(Float, default=0.0001)
    num_episodes = Column(Integer, default=1000)
    stack_size = Column(Integer, default=100)
    use_cfr = Column(Boolean, default=True)
    cfr_alternation_freq = Column(Integer, default=2)
    cfr_iters_per_step = Column(Integer, default=5)
    use_advantage_weighted = Column(Boolean, default=True)
    use_immediate_cfr = Column(Boolean, default=True)
    advantage_weight = Column(Float, default=0.1)
    save_interval = Column(Integer, default=5)
    eval_interval = Column(Integer, default=10)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<TrainingConfig {self.name}>'

class TrainingSession(Base):
    """Training session record."""
    __tablename__ = 'training_sessions'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    hardware_config_id = Column(Integer, ForeignKey('hardware_configs.id'))
    training_config_id = Column(Integer, ForeignKey('training_configs.id'))
    status = Column(String(20), default='pending')  # pending, running, completed, failed
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    total_episodes = Column(Integer, default=0)
    win_rate = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    hardware_config = relationship('HardwareConfig')
    training_config = relationship('TrainingConfig')
    training_metrics = relationship('TrainingMetrics', backref='training_session', lazy=True)
    
    def __repr__(self):
        return f'<TrainingSession {self.name}>'

class TrainingMetrics(Base):
    """Metrics collected during training."""
    __tablename__ = 'training_metrics'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey('training_sessions.id'))
    episode = Column(Integer)
    win_rate = Column(Float)
    loss = Column(Float)
    exploration_rate = Column(Float)
    avg_reward = Column(Float)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<TrainingMetrics session={self.session_id} episode={self.episode}>'

class SystemSetting(Base):
    """System-wide settings."""
    __tablename__ = 'system_settings'
    
    id = Column(Integer, primary_key=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(Text)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'
    
    @classmethod
    def get_value(cls, db, key, default=None):
        """Get a setting value by key."""
        setting = db.session.query(cls).filter_by(key=key).first()
        if setting is None:
            return default
        
        # Try to parse as JSON if it looks like one
        if setting.value and (setting.value.startswith('{') or setting.value.startswith('[')):
            try:
                return json.loads(setting.value)
            except:
                pass
                
        return setting.value
    
    @classmethod
    def set_value(cls, db, key, value, description=None):
        """Set a setting value by key."""
        # Convert JSON-serializable values to string
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        elif isinstance(value, bool):
            value = str(value).lower()
        elif value is not None:
            value = str(value)
            
        setting = db.session.query(cls).filter_by(key=key).first()
        if setting is None:
            setting = cls(key=key, value=value, description=description)
            db.session.add(setting)
        else:
            setting.value = value
            if description:
                setting.description = description
                
        db.session.commit()
        return setting

class HardwareMetrics(Base):
    """Hardware metrics for system monitoring."""
    __tablename__ = 'hardware_metrics'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    session_id = Column(Integer, ForeignKey('training_sessions.id'), nullable=True)
    
    # CPU metrics
    cpu_usage = Column(Float, default=0.0)  # Percentage (0-100)
    cpu_temperature = Column(Float, nullable=True)  # Celsius
    
    # Memory metrics
    memory_total = Column(Float, default=0.0)  # GB
    memory_used = Column(Float, default=0.0)  # GB
    memory_utilization = Column(Float, default=0.0)  # Percentage (0-100)
    
    # GPU metrics
    gpu_count = Column(Integer, default=0)
    gpu_utilization = Column(Float, default=0.0)  # Average utilization across GPUs (0-100)
    gpu_memory_total = Column(Float, default=0.0)  # Total memory across all GPUs (GB)
    gpu_memory_used = Column(Float, default=0.0)  # Used memory across all GPUs (GB)
    gpu_temperature = Column(Float, nullable=True)  # Average temperature across GPUs (Celsius)
    
    # Disk metrics
    disk_total = Column(Float, default=0.0)  # GB
    disk_used = Column(Float, default=0.0)  # GB
    disk_utilization = Column(Float, default=0.0)  # Percentage (0-100)
    
    # Raw metrics JSON for detailed analysis
    raw_metrics = Column(JSON, nullable=True)
    
    # Optimization recommendations
    recommendations = Column(JSON, nullable=True)
    
    # Reference to training session if applicable
    training_session = relationship('TrainingSession', backref='hardware_metrics', lazy=True)
    
    def __repr__(self):
        return f'<HardwareMetrics id={self.id} timestamp={self.timestamp}>'
    
    @classmethod
    def from_monitor_data(cls, metrics_data):
        """Create a HardwareMetrics instance from the hardware monitor data."""
        hw_metrics = cls()
        
        # Store the raw metrics for future analysis
        hw_metrics.raw_metrics = metrics_data
        
        # CPU metrics
        cpu_data = metrics_data.get('cpu', {})
        hw_metrics.cpu_usage = cpu_data.get('usage_percent', 0.0)
        
        # Memory metrics
        memory_data = metrics_data.get('memory', {})
        hw_metrics.memory_total = memory_data.get('total_gb', 0.0)
        hw_metrics.memory_used = memory_data.get('used_gb', 0.0)
        hw_metrics.memory_utilization = memory_data.get('usage_percent', 0.0) * 100  # Convert from 0-1 to 0-100
        
        # GPU metrics
        gpu_data = metrics_data.get('gpu', {})
        hw_metrics.gpu_count = gpu_data.get('count', 0)
        
        if hw_metrics.gpu_count > 0:
            devices = gpu_data.get('devices', [])
            total_util = 0
            total_mem = 0
            used_mem = 0
            
            for device in devices:
                total_util += device.get('utilization', 0)
                total_mem += device.get('total_memory_gb', 0)
                used_mem += device.get('used_memory_gb', 0)
            
            hw_metrics.gpu_utilization = (total_util / hw_metrics.gpu_count) * 100 if hw_metrics.gpu_count > 0 else 0
            hw_metrics.gpu_memory_total = total_mem
            hw_metrics.gpu_memory_used = used_mem
        
        # Disk metrics
        disk_data = metrics_data.get('disk', {})
        hw_metrics.disk_total = disk_data.get('total_gb', 0.0)
        hw_metrics.disk_used = disk_data.get('used_gb', 0.0)
        hw_metrics.disk_utilization = disk_data.get('usage_percent', 0.0) * 100  # Convert from 0-1 to 0-100
        
        return hw_metrics

class TrainingLog(Base):
    """Training logs for debugging and analysis."""
    __tablename__ = 'training_logs'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey('training_sessions.id'))
    timestamp = Column(DateTime, default=datetime.utcnow)
    level = Column(String(10), default='INFO')  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    message = Column(Text)
    
    # Reference to training session
    training_session = relationship('TrainingSession', backref='logs', lazy=True)
    
    def __repr__(self):
        return f'<TrainingLog session={self.session_id} level={self.level}>'

class TrainingAction(Base):
    """Actions taken during training, such as parameter updates, checkpoint savings, etc."""
    __tablename__ = 'training_actions'
    
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey('training_sessions.id'))
    timestamp = Column(DateTime, default=datetime.utcnow)
    action_type = Column(String(50))  # checkpoint, parameter_update, model_reset, etc.
    description = Column(Text)
    action_data = Column(JSON, nullable=True)  # Additional action-specific data (renamed from metadata)
    
    # Reference to training session
    training_session = relationship('TrainingSession', backref='actions', lazy=True)
    
    def __repr__(self):
        return f'<TrainingAction session={self.session_id} type={self.action_type}>'