"""
Database initialization for the Poker AI application.

This module sets up the SQLAlchemy database instance
that will be used throughout the application.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager

# Create extensions
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

def init_app(app):
    """Initialize database and related extensions with the Flask app."""
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    login_manager.login_view = 'admin.login'
    
    # Import models to register them with SQLAlchemy
    from models.database import User, HardwareConfig, TrainingConfig, TrainingSession
    from models.database import TrainingMetrics, TrainingLog, TrainingAction, SystemSetting, HardwareMetrics
    
    @login_manager.user_loader
    def load_user(user_id):
        """Load user by ID for Flask-Login."""
        return User.query.get(int(user_id))
    
    # Create tables if they don't exist
    with app.app_context():
        db.create_all()