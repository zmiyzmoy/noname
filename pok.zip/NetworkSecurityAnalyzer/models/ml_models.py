"""
Machine learning models for the Poker AI project.
This directly imports the necessary models from the original models.py file
to resolve import issues.
"""

import os
import sys
import importlib.util

# Define the path to the original models.py file
models_file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models.py'))

# Load the models.py file as a module
spec = importlib.util.spec_from_file_location("ml_models_original", models_file_path)
ml_models_original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ml_models_original)

# Import all classes from the loaded module
Config = ml_models_original.Config
RegretNet = ml_models_original.RegretNet
StrategyNet = ml_models_original.StrategyNet
StateProcessor = ml_models_original.StateProcessor
OpponentStats = ml_models_original.OpponentStats
RewardNormalizer = ml_models_original.RewardNormalizer
PrioritizedReplayBuffer = ml_models_original.PrioritizedReplayBuffer
CardEmbedding = ml_models_original.CardEmbedding

# Export these classes from the ml_models module
__all__ = [
    'Config', 
    'RegretNet', 
    'StrategyNet', 
    'StateProcessor', 
    'OpponentStats', 
    'RewardNormalizer', 
    'PrioritizedReplayBuffer',
    'CardEmbedding'
]