#!/usr/bin/env python3
"""
Web interface for the Poker AI training system.
This provides a simple, user-friendly web UI to configure and run training.
"""

import os
import sys
import json
import time
import random
import logging
import subprocess
import threading
import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, session

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)

# Global variables for storing training state
TRAINING_PROCESS = None
TRAINING_OUTPUT = []
TRAINING_RUNNING = False
TRAINING_ERROR = None
TRAINING_STATS = {'episodes_completed': 0, 'total_episodes': 0}
OUTPUT_LOCK = threading.Lock()

# Default configuration
DEFAULT_CONFIG = {
    'mode': 'selfplay',
    'num_episodes': 100,
    'num_iterations': 10,
    'batch_size': 64,
    'learning_rate': 0.001,
    'use_mixed_precision': True,
    'eval_opponents': 'random,tight_passive,tight_aggressive,loose_passive,loose_aggressive',
    'checkpoint': 'latest',
    'num_workers': 4,
    'verbose': True,
    'enable_dynamic_adjustment': False
}

# Available opponent types
OPPONENT_TYPES = [
    {'id': 'random', 'name': 'Random'},
    {'id': 'mccfr', 'name': 'MCCFR'},
    {'id': 'tight_passive', 'name': 'Tight Passive'},
    {'id': 'tight_aggressive', 'name': 'Tight Aggressive'},
    {'id': 'loose_passive', 'name': 'Loose Passive'},
    {'id': 'loose_aggressive', 'name': 'Loose Aggressive'},
    {'id': 'maniac', 'name': 'Maniac'},
    {'id': 'rock', 'name': 'Rock'},
    {'id': 'calling_station', 'name': 'Calling Station'},
    {'id': 'nit', 'name': 'Nit'}
]

# HTML templates
@app.route('/')
def index():
    """Render the main page."""
    # Get config from session or use default
    config = session.get('config', DEFAULT_CONFIG)
    
    # Store in session
    session['config'] = config
    
    # Get training status
    training_running = TRAINING_RUNNING
    
    # Prepare output for display
    with OUTPUT_LOCK:
        training_output = TRAINING_OUTPUT.copy()
    
    # Get selected opponents as a list
    selected_opponents = config['eval_opponents'].split(',')
    
    # Prepare data dictionary for template
    data = {
        'status': 'Running' if training_running else 'Idle',
        'last_update': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'episodes_completed': TRAINING_STATS.get('episodes_completed', 0),
        'reward_plot': None,  # Add plot data if available
        'loss_plot': None,    # Add plot data if available
        'recent_actions': training_output[-10:] if training_output else []
    }
    
    return render_template('index.html', 
                          data=data,
                          config=config,
                          opponent_types=OPPONENT_TYPES,
                          selected_opponents=selected_opponents,
                          training_running=training_running,
                          training_output=training_output,
                          training_error=TRAINING_ERROR)

@app.route('/update_config', methods=['POST'])
def update_config():
    """Update the configuration based on form submission."""
    # Get current config
    config = session.get('config', DEFAULT_CONFIG.copy())
    
    # Update with form data
    config['mode'] = request.form.get('mode', 'selfplay')
    config['num_episodes'] = int(request.form.get('num_episodes', 100))
    config['num_iterations'] = int(request.form.get('num_iterations', 10))
    config['batch_size'] = int(request.form.get('batch_size', 64))
    config['learning_rate'] = float(request.form.get('learning_rate', 0.001))
    config['use_mixed_precision'] = request.form.get('use_mixed_precision') == 'on'
    
    # Handle opponents (checkboxes)
    selected_opponents = request.form.getlist('opponents')
    if selected_opponents:
        config['eval_opponents'] = ','.join(selected_opponents)
    else:
        config['eval_opponents'] = 'random'
    
    config['checkpoint'] = request.form.get('checkpoint', 'latest')
    config['num_workers'] = int(request.form.get('num_workers', 4))
    config['verbose'] = request.form.get('verbose') == 'on'
    config['enable_dynamic_adjustment'] = request.form.get('enable_dynamic_adjustment') == 'on'
    
    # Store in session
    session['config'] = config
    
    return redirect(url_for('index'))

@app.route('/run_training', methods=['POST'])
def run_training():
    """Run the training with the current configuration."""
    global TRAINING_PROCESS, TRAINING_RUNNING, TRAINING_OUTPUT, TRAINING_ERROR
    
    # Check if training is already running
    if TRAINING_RUNNING:
        return jsonify({'status': 'error', 'message': 'Training is already running'})
    
    # Get configuration
    config = session.get('config', DEFAULT_CONFIG.copy())
    
    # Generate command
    cmd = ["python", "poker_rl.py"]
    
    # Add all arguments
    for arg_name, arg_value in config.items():
        if arg_value is True:
            cmd.append(f"--{arg_name}")
        elif arg_value is not False and arg_value is not None:
            cmd.append(f"--{arg_name}")
            cmd.append(str(arg_value))
    
    # Clear previous output
    with OUTPUT_LOCK:
        TRAINING_OUTPUT = []
        TRAINING_ERROR = None
    
    # Start training in a separate thread
    thread = threading.Thread(target=run_training_process, args=(cmd,))
    thread.daemon = True
    thread.start()
    
    return jsonify({'status': 'success', 'message': 'Training started'})

def run_training_process(cmd):
    """Run the training process and capture output."""
    global TRAINING_PROCESS, TRAINING_RUNNING, TRAINING_OUTPUT, TRAINING_ERROR
    
    cmd_str = " ".join(cmd)
    logger.info(f"Running command: {cmd_str}")
    
    try:
        # Mark as running
        TRAINING_RUNNING = True
        
        # Start process
        TRAINING_PROCESS = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        # Read output
        for line in TRAINING_PROCESS.stdout:
            with OUTPUT_LOCK:
                TRAINING_OUTPUT.append(line.strip())
            logger.info(line.strip())
        
        # Wait for process to complete
        TRAINING_PROCESS.wait()
        
        # Check return code
        if TRAINING_PROCESS.returncode != 0:
            with OUTPUT_LOCK:
                TRAINING_ERROR = f"Training failed with return code: {TRAINING_PROCESS.returncode}"
            logger.error(TRAINING_ERROR)
    
    except Exception as e:
        with OUTPUT_LOCK:
            TRAINING_ERROR = f"Error running training: {str(e)}"
        logger.error(TRAINING_ERROR)
    
    finally:
        # Mark as not running
        TRAINING_RUNNING = False
        TRAINING_PROCESS = None

@app.route('/training_status')
def training_status():
    """Get the current training status."""
    with OUTPUT_LOCK:
        output = TRAINING_OUTPUT.copy()
        error = TRAINING_ERROR
    
    return jsonify({
        'running': TRAINING_RUNNING,
        'output': output,
        'error': error
    })

@app.route('/stop_training', methods=['POST'])
def stop_training():
    """Stop the running training process."""
    global TRAINING_PROCESS, TRAINING_RUNNING
    
    if TRAINING_RUNNING and TRAINING_PROCESS:
        try:
            TRAINING_PROCESS.terminate()
            time.sleep(0.5)
            if TRAINING_PROCESS.poll() is None:
                TRAINING_PROCESS.kill()
            
            with OUTPUT_LOCK:
                TRAINING_OUTPUT.append("Training stopped by user")
            
            TRAINING_RUNNING = False
            TRAINING_PROCESS = None
            
            return jsonify({'status': 'success', 'message': 'Training stopped'})
        
        except Exception as e:
            return jsonify({'status': 'error', 'message': f'Error stopping training: {str(e)}'})
    
    return jsonify({'status': 'error', 'message': 'No training running'})

def create_templates():
    """Create the HTML templates for the web interface."""
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)
    
    # Create index.html
    index_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poker AI Training Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }
        .container {
            width: 95%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 15px 0;
            text-align: center;
            border-radius: 8px 8px 0 0;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .config-section, .training-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
        h2 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-top: 0;
        }
        form {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        select, input[type="number"], input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .checkbox-group {
            margin-top: 5px;
        }
        .checkbox-item {
            margin-bottom: 5px;
        }
        .button-group {
            grid-column: 1 / -1;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        button {
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.2s;
        }
        .save-btn {
            background-color: #3498db;
            color: white;
        }
        .save-btn:hover {
            background-color: #2980b9;
        }
        .run-btn {
            background-color: #2ecc71;
            color: white;
        }
        .run-btn:hover {
            background-color: #27ae60;
        }
        .stop-btn {
            background-color: #e74c3c;
            color: white;
        }
        .stop-btn:hover {
            background-color: #c0392b;
        }
        .disabled {
            background-color: #95a5a6;
            cursor: not-allowed;
        }
        .disabled:hover {
            background-color: #7f8c8d;
        }
        .output {
            background-color: #2c3e50;
            color: #ecf0f1;
            border-radius: 4px;
            padding: 15px;
            height: 400px;
            overflow-y: auto;
            font-family: monospace;
            white-space: pre-wrap;
            line-height: 1.5;
        }
        .output p {
            margin: 0;
            padding: 2px 0;
        }
        .error {
            color: #e74c3c;
            font-weight: bold;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-running {
            background-color: #2ecc71;
            color: white;
        }
        .badge-stopped {
            background-color: #e74c3c;
            color: white;
        }
        .full-width {
            grid-column: 1 / -1;
        }
        .tooltip {
            position: relative;
            display: inline-block;
            cursor: help;
            margin-left: 5px;
            color: #3498db;
            font-size: 14px;
        }
        .tooltip:hover::after {
            content: attr(title);
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            bottom: 100%;
            background-color: #34495e;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            white-space: nowrap;
            z-index: 10;
            font-weight: normal;
            font-size: 12px;
            width: 300px;
            white-space: normal;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Poker AI Training Dashboard</h1>
        </div>
        
        <div class="config-section">
            <h2>Training Configuration</h2>
            <form action="/update_config" method="post">
                <div class="form-group">
                    <label for="mode">Training Mode</label>
                    <select id="mode" name="mode">
                        <option value="selfplay" {% if config.mode == 'selfplay' %}selected{% endif %}>Selfplay</option>
                        <option value="train" {% if config.mode == 'train' %}selected{% endif %}>Train (PSRO)</option>
                        <option value="eval" {% if config.mode == 'eval' %}selected{% endif %}>Evaluate</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="num_episodes">Number of Episodes</label>
                    <input type="number" id="num_episodes" name="num_episodes" min="1" max="1000" value="{{ config.num_episodes }}">
                </div>
                
                <div class="form-group">
                    <label for="num_iterations">Training Iterations</label>
                    <input type="number" id="num_iterations" name="num_iterations" min="1" max="100" value="{{ config.num_iterations }}">
                </div>
                
                <div class="form-group">
                    <label for="batch_size">Batch Size</label>
                    <select id="batch_size" name="batch_size">
                        <option value="16" {% if config.batch_size == 16 %}selected{% endif %}>16</option>
                        <option value="32" {% if config.batch_size == 32 %}selected{% endif %}>32</option>
                        <option value="64" {% if config.batch_size == 64 %}selected{% endif %}>64</option>
                        <option value="128" {% if config.batch_size == 128 %}selected{% endif %}>128</option>
                        <option value="256" {% if config.batch_size == 256 %}selected{% endif %}>256</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="learning_rate">Learning Rate</label>
                    <select id="learning_rate" name="learning_rate">
                        <option value="0.0001" {% if config.learning_rate == 0.0001 %}selected{% endif %}>0.0001</option>
                        <option value="0.0005" {% if config.learning_rate == 0.0005 %}selected{% endif %}>0.0005</option>
                        <option value="0.001" {% if config.learning_rate == 0.001 %}selected{% endif %}>0.001</option>
                        <option value="0.005" {% if config.learning_rate == 0.005 %}selected{% endif %}>0.005</option>
                        <option value="0.01" {% if config.learning_rate == 0.01 %}selected{% endif %}>0.01</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="checkpoint">Checkpoint</label>
                    <select id="checkpoint" name="checkpoint">
                        <option value="latest" {% if config.checkpoint == 'latest' %}selected{% endif %}>Latest</option>
                        <option value="final" {% if config.checkpoint == 'final' %}selected{% endif %}>Final</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="num_workers">Number of Workers</label>
                    <input type="number" id="num_workers" name="num_workers" min="1" max="16" value="{{ config.num_workers }}">
                </div>
                
                <div class="form-group">
                    <label>Advanced Options</label>
                    <div class="checkbox-group">
                        <div class="checkbox-item">
                            <input type="checkbox" id="use_mixed_precision" name="use_mixed_precision" {% if config.use_mixed_precision %}checked{% endif %}>
                            <label for="use_mixed_precision">Use Mixed Precision</label>
                        </div>
                        <div class="checkbox-item">
                            <input type="checkbox" id="verbose" name="verbose" {% if config.verbose %}checked{% endif %}>
                            <label for="verbose">Verbose Output</label>
                        </div>
                        <div class="checkbox-item">
                            <input type="checkbox" id="enable_dynamic_adjustment" name="enable_dynamic_adjustment" {% if config.enable_dynamic_adjustment %}checked{% endif %}>
                            <label for="enable_dynamic_adjustment">Dynamic Parameter Adjustment</label>
                            <span class="tooltip" title="When enabled, the system will periodically check system resources and suggest optimal batch size and worker count adjustments based on your hardware utilization.">ⓘ</span>
                        </div>
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label>Evaluation Opponents</label>
                    <div class="checkbox-group">
                        {% for opponent in opponent_types %}
                        <div class="checkbox-item">
                            <input type="checkbox" id="opponent_{{ opponent.id }}" name="opponents" value="{{ opponent.id }}"
                                {% if opponent.id in selected_opponents %}checked{% endif %}>
                            <label for="opponent_{{ opponent.id }}">{{ opponent.name }}</label>
                        </div>
                        {% endfor %}
                    </div>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="save-btn">Save Configuration</button>
                </div>
            </form>
        </div>
        
        <div class="training-section">
            <h2>
                Training Control
                {% if training_running %}
                <span class="badge badge-running">Running</span>
                {% else %}
                <span class="badge badge-stopped">Stopped</span>
                {% endif %}
            </h2>
            
            <div class="button-group">
                <button id="runBtn" class="run-btn" {% if training_running %}disabled class="disabled"{% endif %}>
                    Start Training
                </button>
                <button id="stopBtn" class="stop-btn" {% if not training_running %}disabled class="disabled"{% endif %}>
                    Stop Training
                </button>
            </div>
            
            <div class="form-group" style="margin-top: 20px;">
                <label>Training Output</label>
                <div id="output" class="output">
                    {% for line in training_output %}
                    <p>{{ line }}</p>
                    {% endfor %}
                    {% if training_error %}
                    <p class="error">{{ training_error }}</p>
                    {% endif %}
                </div>
            </div>
        </div>
    </div>

    <script>
        // Function to update the training status
        function updateStatus() {
            fetch('/training_status')
                .then(response => response.json())
                .then(data => {
                    // Update the output
                    const outputDiv = document.getElementById('output');
                    outputDiv.innerHTML = '';
                    
                    data.output.forEach(line => {
                        const p = document.createElement('p');
                        p.textContent = line;
                        outputDiv.appendChild(p);
                    });
                    
                    if (data.error) {
                        const p = document.createElement('p');
                        p.textContent = data.error;
                        p.className = 'error';
                        outputDiv.appendChild(p);
                    }
                    
                    // Scroll to bottom
                    outputDiv.scrollTop = outputDiv.scrollHeight;
                    
                    // Update the buttons
                    const runBtn = document.getElementById('runBtn');
                    const stopBtn = document.getElementById('stopBtn');
                    
                    if (data.running) {
                        runBtn.disabled = true;
                        runBtn.classList.add('disabled');
                        stopBtn.disabled = false;
                        stopBtn.classList.remove('disabled');
                    } else {
                        runBtn.disabled = false;
                        runBtn.classList.remove('disabled');
                        stopBtn.disabled = true;
                        stopBtn.classList.add('disabled');
                    }
                })
                .catch(error => console.error('Error fetching status:', error));
        }
        
        // Start updating status
        let statusInterval = setInterval(updateStatus, 2000);
        
        // Handle run button
        document.getElementById('runBtn').addEventListener('click', function() {
            fetch('/run_training', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                
                // Update immediately
                updateStatus();
                
                // Increase update frequency during training
                clearInterval(statusInterval);
                statusInterval = setInterval(updateStatus, 1000);
            })
            .catch(error => console.error('Error starting training:', error));
        });
        
        // Handle stop button
        document.getElementById('stopBtn').addEventListener('click', function() {
            fetch('/stop_training', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                
                // Update immediately
                updateStatus();
                
                // Restore normal update frequency
                clearInterval(statusInterval);
                statusInterval = setInterval(updateStatus, 2000);
            })
            .catch(error => console.error('Error stopping training:', error));
        });
        
        // Initial update
        updateStatus();
    </script>
</body>
</html>
    """
    
    with open('templates/index.html', 'w') as f:
        f.write(index_html)
    
    logger.info("Created templates for web interface")

if __name__ == "__main__":
    # Create templates
    create_templates()
    
    # Run the flask app
    app.run(host='0.0.0.0', port=5003, debug=True)