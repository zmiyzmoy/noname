# Poker AI System - Comprehensive Deployment Guide

This consolidated guide explains how to deploy the Poker AI system on your server, from basic setup to advanced configuration.

## Table of Contents
- [System Requirements](#system-requirements)
- [Quick Setup (Onboarding Wizard)](#quick-setup-onboarding-wizard)
- [Automatic Deployment](#automatic-deployment)
- [Manual Deployment](#manual-deployment)
- [Database Configuration](#database-configuration)
- [Web Interface Setup](#web-interface-setup)
- [Creating Admin Accounts](#creating-admin-accounts)
- [Setting Up Services](#setting-up-services)
- [Troubleshooting](#troubleshooting)
- [Security Recommendations](#security-recommendations)

## System Requirements

- Linux server (Ubuntu 20.04 or newer recommended)
- At least 4GB RAM (8GB+ recommended for training)
- At least 20GB free disk space
- Python 3.10 or newer
- PostgreSQL database
- Sudo/root access for installation

## Quick Setup (Onboarding Wizard)

The onboarding wizard is designed to handle most of the setup process automatically, making deployment much simpler.

### Step 1: Download the Project 

Download all files from this Replit project using the "Download as Zip" feature:
- Click the three dots menu (...) in the Files panel
- Select "Download as Zip"
- Save the zip file to your computer

### Step 2: Transfer to Your Server

- Upload the zip file to your server using SCP, SFTP, or another file transfer method
- Extract the files:
  ```bash
  unzip poker_ai.zip -d ~/poker_ai
  cd ~/poker_ai
  ```

### Step 3: Install Python and PostgreSQL

Make sure Python 3.10+ and PostgreSQL are installed on your server:
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv postgresql postgresql-contrib
```

### Step 4: Run the Onboarding Wizard

Run the onboarding wizard to set up the system:
```bash
python3 run_onboarding_wizard.py --web --port 5060
```

Then access the web interface at http://your_server_ip:5060 in your browser and follow the instructions.

## Automatic Deployment

The easiest way to deploy the system is using the provided `deploy_poker_ai.sh` script.

### Step 1: Make the script executable
```bash
chmod +x deploy_poker_ai.sh
```

### Step 2: Install the system
```bash
sudo ./deploy_poker_ai.sh install
```

### Step 3: Start the system
```bash
sudo ./deploy_poker_ai.sh start
```

### Step 4: Verify the installation
```bash
sudo ./deploy_poker_ai.sh status
```

## Manual Deployment

If you prefer to set up the system manually, follow these detailed steps:

### Step 1: Prepare Your Server

1. Update your package lists:
   ```bash
   sudo apt update
   sudo apt upgrade -y
   ```

2. Install required system dependencies:
   ```bash
   sudo apt install -y python3-pip python3-dev libpq-dev postgresql postgresql-contrib nginx
   sudo apt install -y build-essential cmake
   ```

3. Create a directory for the project:
   ```bash
   mkdir -p ~/poker_ai
   cd ~/poker_ai
   ```

### Step 2: Set up a Python Virtual Environment

1. Create a virtual environment:
   ```bash
   python3 -m venv venv
   ```

2. Activate the virtual environment:
   ```bash
   source venv/bin/activate
   ```

### Step 3: Install Python Dependencies

1. Upgrade pip:
   ```bash
   pip install --upgrade pip
   ```

2. Install the required Python packages:
   ```bash
   pip install -r requirements.txt
   ```

3. If installation fails for some packages, try installing PyTorch first:
   ```bash
   pip install torch
   pip install -r requirements.txt
   ```

## Database Configuration

### Step 1: Set up PostgreSQL

1. Start the PostgreSQL service:
   ```bash
   sudo systemctl start postgresql
   sudo systemctl enable postgresql
   ```

2. Switch to the PostgreSQL user:
   ```bash
   sudo -i -u postgres
   ```

3. Create a database and user:
   ```bash
   createdb poker_ai
   createuser --interactive
   ```
   When prompted:
   - Enter name of role to add: `poker_ai_user`
   - Shall the new role be a superuser? `n`
   - Shall the new role be allowed to create databases? `y`
   - Shall the new role be allowed to create more new roles? `n`

4. Set a password for the new user:
   ```bash
   psql -c "ALTER USER poker_ai_user WITH ENCRYPTED PASSWORD 'your_secure_password';"
   ```

5. Grant privileges to the user:
   ```bash
   psql -c "GRANT ALL PRIVILEGES ON DATABASE poker_ai TO poker_ai_user;"
   ```

6. Exit the PostgreSQL user:
   ```bash
   exit
   ```

### Step 2: Configure Database Connection

1. Set the database URL environment variable:
   ```bash
   export DATABASE_URL="postgresql://poker_ai_user:your_secure_password@localhost:5432/poker_ai"
   ```

2. Add this to your .bashrc or .profile for persistence:
   ```bash
   echo 'export DATABASE_URL="postgresql://poker_ai_user:your_secure_password@localhost:5432/poker_ai"' >> ~/.bashrc
   source ~/.bashrc
   ```

3. Verify database connection:
   ```bash
   python -c "import psycopg2; conn=psycopg2.connect('postgresql://poker_ai_user:your_secure_password@localhost:5432/poker_ai'); print('Connection successful')"
   ```

## Web Interface Setup

### Step 1: Configure the Web Application

1. Set a secret key for Flask:
   ```bash
   export FLASK_SECRET_KEY="your_random_secure_key"
   echo 'export FLASK_SECRET_KEY="your_random_secure_key"' >> ~/.bashrc
   ```

2. Test the web interface:
   ```bash
   python main.py
   ```
   This should start the consolidated Flask app on port 5010.

### Step 2: Set Up Nginx (Optional for Production)

1. Install Nginx if not already installed:
   ```bash
   sudo apt install -y nginx
   ```

2. Create an Nginx configuration file:
   ```bash
   sudo nano /etc/nginx/sites-available/poker_ai
   ```
   
3. Add the following configuration:
   ```
   server {
       listen 80;
       server_name your_server_domain_or_ip;

       location / {
           proxy_pass http://127.0.0.1:5010;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```

4. Enable the site:
   ```bash
   sudo ln -s /etc/nginx/sites-available/poker_ai /etc/nginx/sites-enabled
   sudo nginx -t
   sudo systemctl restart nginx
   ```

## Creating Admin Accounts

Create an administrator account for the web interface:

```bash
python create_new_admin.py
```

Follow the prompts to set a username and password.

## Setting Up Services

### Using Systemd for Automatic Startup

1. Create a systemd service file:
   ```bash
   sudo nano /etc/systemd/system/poker-ai.service
   ```

2. Add the following content:
   ```
   [Unit]
   Description=Poker AI System
   After=network.target postgresql.service

   [Service]
   User=your_username
   WorkingDirectory=/home/your_username/poker_ai
   Environment="PATH=/home/your_username/poker_ai/venv/bin"
   Environment="DATABASE_URL=postgresql://poker_ai_user:your_secure_password@localhost:5432/poker_ai"
   Environment="FLASK_SECRET_KEY=your_random_secure_key"
   ExecStart=/home/your_username/poker_ai/venv/bin/python /home/your_username/poker_ai/main.py
   Restart=always
   RestartSec=10
   StandardOutput=syslog
   StandardError=syslog
   SyslogIdentifier=poker-ai

   [Install]
   WantedBy=multi-user.target
   ```

3. Replace `your_username` with your actual username, and update the paths and environment variables as needed.

4. Enable and start the service:
   ```bash
   sudo systemctl enable poker-ai
   sudo systemctl start poker-ai
   ```

5. Check the service status:
   ```bash
   sudo systemctl status poker-ai
   ```

## Troubleshooting

### Database Connection Issues

If you encounter database connection problems:

1. Verify PostgreSQL is running:
   ```bash
   sudo systemctl status postgresql
   ```

2. Check the database connection string:
   ```bash
   echo $DATABASE_URL
   ```

3. Make sure the user has proper permissions:
   ```bash
   sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE poker_ai TO poker_ai_user;"
   ```

### Python Package Installation Issues

If you have trouble installing required packages:

1. Make sure you have the build essentials:
   ```bash
   sudo apt install -y build-essential
   ```

2. Try installing packages one by one to identify problematic dependencies.

3. For OpenSpiel issues, try:
   ```bash
   pip install open-spiel --no-deps
   ```

### Web Interface Not Accessible

If the web interface isn't accessible:

1. Check if the Flask app is running:
   ```bash
   ps aux | grep python
   ```

2. Verify the port is open:
   ```bash
   sudo netstat -tuln | grep 5010
   ```

3. Check Nginx configuration (if using):
   ```bash
   sudo nginx -t
   ```

4. Check Flask app logs:
   ```bash
   tail -f flask_app.log
   ```

## Security Recommendations

1. Use a strong password for the PostgreSQL user.
2. Set a secure FLASK_SECRET_KEY.
3. Consider using HTTPS with Let's Encrypt if exposing to the internet.
4. Restrict server access using a firewall:
   ```bash
   sudo ufw allow ssh
   sudo ufw allow 80/tcp
   sudo ufw allow 5010/tcp
   sudo ufw enable
   ```
5. Regularly update your system:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

## Next Steps

After successfully deploying the system:

1. Go through the onboarding wizard if you haven't already:
   ```bash
   python web_onboarding_wizard.py --port 5060
   ```

2. Access the main web interface at http://your_server_ip:5010/

3. Follow the [COMMAND_REFERENCE.md](COMMAND_REFERENCE.md) for common operations and commands.

4. Read [TENSORBOARD_AND_FUNCTIONS_GUIDE.md](TENSORBOARD_AND_FUNCTIONS_GUIDE.md) for monitoring training.