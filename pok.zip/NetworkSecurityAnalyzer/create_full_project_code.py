#!/usr/bin/env python3
import os
import subprocess

def main():
    # Get all Python files in the project
    cmd = "find . -name '*.py' -type f -not -path '*/__pycache__/*' -not -path '*/.pythonlibs/*' -not -path '*/.cache/*' | sort"
    output = subprocess.check_output(cmd, shell=True).decode('utf-8')
    python_files = output.strip().split('\n')
    
    # Create the output file
    with open('full_project_code.txt', 'w') as outfile:
        for file_path in python_files:
            if os.path.isfile(file_path):
                try:
                    # Add file header
                    outfile.write(f"# START FILE: {file_path}\n\n")
                    
                    # Add file content
                    with open(file_path, 'r', encoding='utf-8') as infile:
                        content = infile.read()
                        outfile.write(content)
                    
                    # Add file footer and separator
                    outfile.write(f"\n\n# END FILE: {file_path}\n\n")
                except Exception as e:
                    outfile.write(f"# Error reading file {file_path}: {str(e)}\n\n")
    
    print(f"Created full_project_code.txt with {len(python_files)} Python files")

if __name__ == "__main__":
    main()