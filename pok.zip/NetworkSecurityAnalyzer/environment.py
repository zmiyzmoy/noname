import os
import logging
import numpy as np
import torch
import pyspiel
from typing import List, Dict, Tuple, Optional
from collections import deque
from open_spiel.python import policy as openspiel_policy

class PokerEnvironment:
    """Environment wrapper for Poker game using OpenSpiel."""
    
    def __init__(self, game_name: str, num_players: int, max_steps: int = 1000):
        self.game = pyspiel.load_game(game_name)
        self.num_players = num_players
        self.max_steps = max_steps
        self.step_counter = 0
        self.action_mapping = {a: i for i, a in enumerate(range(self.game.num_distinct_actions()))}
        self.reverse_action_mapping = {i: a for a, i in self.action_mapping.items()}
        logging.info(f"Poker Environment initialized with game: {game_name}")
        
    def reset(self):
        """Reset the environment to initial state."""
        self.state = self.game.new_initial_state()
        self.step_counter = 0
        self.history = []
        self.done = False
        
        # Handle chance node at the beginning
        while self.state.is_chance_node() and not self.state.is_terminal():
            outcomes = self.state.chance_outcomes()
            action_list, prob_list = zip(*outcomes)
            action = np.random.choice(action_list, p=prob_list)
            self.state.apply_action(action)
            
        return self.state

    def step(self, action):
        """Take an action in the environment."""
        if self.state.is_terminal():
            logging.warning("Attempting to step in a terminal state")
            return self.state, 0, True, {}
            
        self.history.append({
            'player': self.state.current_player(),
            'action': action,
            'info_state': self.state.information_state_string(self.state.current_player())
        })
        
        self.state.apply_action(action)
        self.step_counter += 1
        
        # Process chance nodes
        while self.state.is_chance_node() and not self.state.is_terminal():
            outcomes = self.state.chance_outcomes()
            action_list, prob_list = zip(*outcomes)
            action = np.random.choice(action_list, p=prob_list)
            self.state.apply_action(action)
        
        # Check if game is over
        self.done = self.state.is_terminal() or self.step_counter >= self.max_steps
        
        # Get rewards
        rewards = self.state.returns() if self.state.is_terminal() else [0] * self.num_players
        
        info = {
            'legal_actions': self.state.legal_actions() if not self.state.is_terminal() else [],
            'current_player': self.state.current_player() if not self.state.is_terminal() else -1,
            'history': self.history,
            'is_terminal': self.state.is_terminal()
        }
        
        return self.state, rewards, self.done, info
    
    def sample_action(self):
        """Sample a random legal action."""
        if self.state.is_terminal():
            return None
        return np.random.choice(self.state.legal_actions())
    
    def legal_actions_mask(self):
        """Get a binary mask of legal actions."""
        if self.state.is_terminal():
            return np.zeros(self.game.num_distinct_actions(), dtype=np.bool)
        
        mask = np.zeros(self.game.num_distinct_actions(), dtype=np.bool)
        mask[self.state.legal_actions()] = True
        return mask
    
    def get_current_player(self):
        """Get the current player index."""
        if self.state.is_terminal():
            return -1
        return self.state.current_player()
    
    def get_state(self):
        """Get the current state."""
        return self.state
    
    def get_info_state(self, player_id):
        """Get the information state for a specific player."""
        return self.state.information_state_string(player_id)
    
    def get_info_state_tensor(self, player_id):
        """Get the information state tensor for a specific player."""
        return self.state.information_state_tensor(player_id)

class TabularPolicy(openspiel_policy.Policy):
    """Tabular policy implementation for OpenSpiel."""
    
    def __init__(self, game, player_ids=None):
        super().__init__(game, player_ids)
        self.policy_table = {}
        self.default_policy = {}
    
    def action_probabilities(self, state, player_id=None):
        """Returns the policy for a specific state."""
        if state.is_terminal():
            return {}
        
        if state.is_chance_node():
            return {a: p for a, p in state.chance_outcomes()}
        
        info_state = state.information_state_string()
        legal_actions = state.legal_actions()
        
        if info_state in self.policy_table:
            probs = self.policy_table[info_state]
            # Filter to legal actions and normalize
            filtered_probs = {a: probs.get(a, 0) for a in legal_actions}
            if sum(filtered_probs.values()) > 0:
                # Normalize if there are positive probabilities
                norm = sum(filtered_probs.values())
                return {a: p/norm for a, p in filtered_probs.items()}
        
        # Default uniform policy
        num_legal = len(legal_actions)
        if num_legal > 0:
            return {a: 1.0 / num_legal for a in legal_actions}
        return {}
    
    def update(self, info_state, action_probs):
        """Update the policy for a given information state."""
        self.policy_table[info_state] = action_probs
    
    def get_policy_table(self):
        """Get the full policy table."""
        return self.policy_table
    
    def set_policy_table(self, table):
        """Set the policy table."""
        self.policy_table = table
        
    def clone(self):
        """Create a clone of this policy."""
        clone = TabularPolicy(self.game)
        clone.policy_table = dict(self.policy_table)
        return clone
    
    def serialize(self):
        """Serialize this policy to a string."""
        import json
        return json.dumps(self.policy_table)  # Use JSON instead of str()
    
    @classmethod
    def deserialize(cls, game, serialized):
        """Deserialize a policy from a string."""
        import json
        policy_obj = cls(game)
        policy_obj.policy_table = json.loads(serialized)  # Safe deserialization
        return policy_obj

class TorchPolicy(openspiel_policy.Policy):
    """Neural network policy implementation using PyTorch."""
    
    def __init__(self, game, model, state_processor, temperature=1.0, player_ids=None):
        super().__init__(game, player_ids)
        self.model = model
        self.state_processor = state_processor
        self.temperature = temperature
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.model.eval()
    
    def action_probabilities(self, state, player_id=None):
        """Returns action probabilities for a given state."""
        if state.is_terminal():
            return {}
        
        if state.is_chance_node():
            return {a: p for a, p in state.chance_outcomes()}
        
        current_player = state.current_player() if player_id is None else player_id
        legal_actions = state.legal_actions()
        
        if not legal_actions:
            return {}
        
        # Process state for neural network
        try:
            processed_state = self.state_processor.process([state], [current_player])
            state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
            
            with torch.no_grad():
                logits = self.model(state_tensor)[0].cpu().numpy()
            
            # Apply temperature and mask illegal actions
            temperature_logits = logits / max(self.temperature, 1e-6)  # Prevent division by zero
            
            # Create mask for illegal actions - safer large negative value
            mask = np.ones_like(temperature_logits) * float('-1e6')  # Avoid extreme values
            mask[legal_actions] = 0
            masked_logits = temperature_logits + mask
            
            # Calculate probabilities using softmax with improved numerical stability
            max_logit = np.max(masked_logits)
            if np.isinf(max_logit) or np.isnan(max_logit):
                # Fallback for numerical issues - equal distribution across legal actions
                probs_dict = {a: 1.0 / len(legal_actions) for a in legal_actions}
            else:
                # Stable softmax calculation
                exp_logits = np.exp(masked_logits - max_logit)
                probabilities = exp_logits / (np.sum(exp_logits) + 1e-10)  # Add small constant to prevent division by zero
                
                # Ensure the probability distribution sums to 1 (fix any numerical errors)
                probs_dict = {a: float(probabilities[a]) for a in legal_actions}
                
                # Clip very small values to prevent underflow
                probs_dict = {a: max(p, 1e-10) for a, p in probs_dict.items()}
                
                # Normalize again to ensure sum to 1
                total_prob = sum(probs_dict.values())
                probs_dict = {a: p / total_prob for a, p in probs_dict.items()}
            
            # If we only have one action, ensure 100% probability for that action
            if len(legal_actions) == 1:
                probs_dict = {legal_actions[0]: 1.0}
            
            return probs_dict
            
        except Exception as e:
            logging.warning(f"Exception in action_probabilities: {e}")
            # Safe fallback - uniform distribution
            return {a: 1.0 / len(legal_actions) for a in legal_actions}
    
    def update_model(self, new_model):
        """Update the underlying model."""
        self.model.load_state_dict(new_model.state_dict())
        self.model.eval()

class AdaptedTorchPolicy(TorchPolicy):
    """
    Neural network policy implementation that adapts its behavior based on opponent archetypes.
    Used for evaluating AI against different player types.
    """
    
    def __init__(self, game, model, state_processor, archetype=None, adaptation_manager=None, 
                temperature=1.0, player_ids=None):
        super().__init__(game, model, state_processor, temperature, player_ids)
        self.archetype = archetype
        self.adaptation_manager = adaptation_manager
        self.player_id = 999  # Default unique ID for this adapted policy
        logging.info(f"Created adapted policy for archetype: {archetype}")
        
    def action_probabilities(self, state, player_id=None):
        """Returns action probabilities adapted based on the chosen archetype."""
        if state.is_terminal():
            return {}
        
        if state.is_chance_node():
            return {a: p for a, p in state.chance_outcomes()}
        
        # Get base probabilities from the parent class
        base_probs = super().action_probabilities(state, player_id)
        
        if not base_probs or not self.archetype or not self.adaptation_manager:
            return base_probs
            
        try:
            current_player = state.current_player() if player_id is None else player_id
            
            # Determine street based on state
            street = 0  # Default to preflop
            if hasattr(state, 'round') and callable(getattr(state, 'round')):
                street = state.round()
            
            # Determine position (simplified)
            position = current_player % 6  # 0=BTN, 1=SB, 2=BB, etc.
            
            # Determine if this is preflop
            is_preflop = (street == 0)
            
            # Get adapted probabilities based on the archetype
            adapted_probs = self._adapt_probabilities(base_probs, is_preflop, position)
            
            # Return the adapted probabilities
            return adapted_probs
            
        except Exception as e:
            logging.warning(f"Exception in adapted action_probabilities: {e}")
            # Return the original probabilities if adaptation fails
            return base_probs
    
    def _adapt_probabilities(self, original_probs, is_preflop=False, position=0):
        """
        Adapt action probabilities based on the archetype.
        
        Args:
            original_probs: The original action probabilities
            is_preflop: Whether this is a preflop decision
            position: Table position (0-5)
            
        Returns:
            Adapted action probabilities
        """
        # If no adaptation needed, return original
        if not self.archetype:
            return original_probs
            
        # Convert original probs to a more usable format for adaptation
        action_probs = {int(a): float(p) for a, p in original_probs.items()}
        
        # Get actions by type (fold=0, call=1, raise=2+)
        fold_actions = [a for a in action_probs.keys() if a == 0]
        call_actions = [a for a in action_probs.keys() if a == 1]
        raise_actions = [a for a in action_probs.keys() if a >= 2]
        
        # Apply archetype-specific adaptations
        if self.archetype == 'tight_passive':
            # Increases fold frequency, decreases raise frequency
            self._adjust_probs(action_probs, fold_mult=1.3, raise_mult=0.7)
            
        elif self.archetype == 'tight_aggressive':
            # Increases fold for weak hands but increases raises when playing
            if is_preflop:
                self._adjust_probs(action_probs, fold_mult=1.2, raise_mult=1.3, call_mult=0.7)
            else:
                self._adjust_probs(action_probs, raise_mult=1.4, call_mult=0.8)
                
        elif self.archetype == 'loose_passive':
            # Decreases fold frequency, increases call frequency
            self._adjust_probs(action_probs, fold_mult=0.7, call_mult=1.4, raise_mult=0.6)
            
        elif self.archetype == 'loose_aggressive':
            # Decreases fold frequency, increases raise frequency
            self._adjust_probs(action_probs, fold_mult=0.7, call_mult=0.8, raise_mult=1.5)
            
        elif self.archetype == 'maniac':
            # Rarely folds, raises very frequently
            self._adjust_probs(action_probs, fold_mult=0.4, call_mult=0.6, raise_mult=2.0)
            
        elif self.archetype == 'rock':
            # Folds very frequently, only plays premium hands
            self._adjust_probs(action_probs, fold_mult=1.5, call_mult=0.8, raise_mult=0.7)
            
        elif self.archetype == 'calling_station':
            # Rarely folds to bets, calls very frequently
            self._adjust_probs(action_probs, fold_mult=0.5, call_mult=1.8, raise_mult=0.6)
            
        elif self.archetype == 'nit':
            # Extremely risk-averse, folds most hands
            self._adjust_probs(action_probs, fold_mult=1.7, call_mult=0.7, raise_mult=0.6)
        
        # Position-based adjustments
        if position in [0, 5]:  # BTN or CO positions
            # More aggressive in late position for most archetypes
            if self.archetype not in ['rock', 'nit']:
                self._adjust_probs(action_probs, fold_mult=0.9, raise_mult=1.1)
        elif position in [1, 2]:  # SB or BB
            # More defensive in blinds for most archetypes
            if self.archetype not in ['maniac', 'loose_aggressive']:
                self._adjust_probs(action_probs, fold_mult=1.1, call_mult=1.1, raise_mult=0.9)
        
        # Normalize to ensure probabilities sum to 1
        total = sum(action_probs.values())
        if total > 0:
            normalized_probs = {a: p/total for a, p in action_probs.items()}
            return normalized_probs
        
        # Fallback to original if something went wrong
        return original_probs
        
    def _adjust_probs(self, probs, fold_mult=1.0, call_mult=1.0, raise_mult=1.0):
        """
        Adjust probabilities for different action types.
        
        Args:
            probs: Dictionary of action->probability (modified in place)
            fold_mult: Multiplier for fold actions
            call_mult: Multiplier for call/check actions
            raise_mult: Multiplier for raise/bet actions
        """
        for action, prob in list(probs.items()):
            if action == 0:  # Fold
                probs[action] *= fold_mult
            elif action == 1:  # Call/Check
                probs[action] *= call_mult
            else:  # Raise/Bet
                probs[action] *= raise_mult
    
    def set_temperature(self, temperature):
        """Update the temperature parameter for exploration."""
        self.temperature = temperature
    
    def clone(self):
        """Create a clone of this policy."""
        return TorchPolicy(self.game, 
                          torch.jit.script(self.model) if not isinstance(self.model, torch.jit.ScriptModule) else self.model, 
                          self.state_processor, 
                          self.temperature,
                          self.player_ids)
