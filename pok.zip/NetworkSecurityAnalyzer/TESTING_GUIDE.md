# Poker AI System - Testing Guide

This consolidated guide explains how to test the Poker AI system, interpret test results, and troubleshoot common issues.

## Table of Contents
- [Testing Overview](#testing-overview)
- [Running Tests](#running-tests)
- [Interpreting Test Reports](#interpreting-test-reports)
- [Test Case Reference](#test-case-reference)
- [Common Issues and Solutions](#common-issues-and-solutions)
- [Adding Custom Tests](#adding-custom-tests)
- [Sample Test Reports](#sample-test-reports)
- [Test Report Templates](#test-report-templates)

## Testing Overview

The Poker AI system includes a comprehensive testing framework for verifying that all components work correctly. Testing is important before:

- Initial deployment
- After updates or modifications
- When transferring to a new server
- When encountering unexpected behavior

Each test is designed to verify a specific aspect of the system's functionality, from basic mode execution to complex parameter optimization and error handling.

## Running Tests

### Running All Tests

To run the full test suite:

```bash
python test_all_components.py --all
```

This will execute all test cases and generate a comprehensive report.

### Running Specific Tests

To test only specific components:

```bash
# Test the OpenSpiel error fix
python test_openspiel_stability.py

# Test the onboarding wizard
python test_onboarding_wizard.py

# Test a specific training mode (selfplay, train, eval)
python run_functional_tests.py --mode selfplay --num_episodes 1
```

### Automated Testing with Reports

For automated testing that generates a markdown report:

```bash
python run_functional_tests.py --report-path test_report.md
```

## Interpreting Test Reports

Test reports include:

1. **Summary**: Total tests, successful tests, and failed tests
2. **Overall Assessment**: High-level evaluation of system functionality
3. **Core Features Status**: Status of main system features
4. **Detailed Test Results**: Results for each individual test
5. **Recommendations**: Suggestions for addressing any issues

### Success Indicators

- ✅ **Success**: Test completed without errors, functionality confirmed
- ⚠️ **Warning**: Test completed but with minor issues or concerns
- ❌ **Failure**: Test failed, functionality not working as expected

## Test Case Reference

### Core Functionality Tests

1. **Selfplay Mode**
   - Command: `python poker_rl.py --mode selfplay --num_episodes 1 --verbose`
   - Verifies: Basic game mechanics, OpenSpiel integration, model loading

2. **Training Mode**
   - Command: `python poker_rl.py --mode train --num_episodes 5 --num_iterations 2 --verbose`
   - Verifies: Training pipeline, experience collection, learning updates

3. **Evaluation Mode**
   - Command: `python poker_rl.py --mode eval --num_episodes 5 --eval_opponents random,tight_aggressive --verbose`
   - Verifies: Opponent modeling, strategy evaluation, metrics calculation

### Component Tests

1. **OpenSpiel Stability**
   - Command: `python test_openspiel_stability.py`
   - Verifies: Fixes for known OpenSpiel issues (player_id=-4 errors)

2. **Parameter Adjuster**
   - Command: `python parameter_adjuster.py --check`
   - Verifies: Hardware detection, parameter optimization

3. **Server Transfer Toolkit**
   - Command: `python server_transfer_toolkit.py check`
   - Verifies: Package creation and validation functions

4. **Interface Tests**
   - Command: `python test_all_components.py --interfaces`
   - Verifies: All web interfaces start correctly and respond to requests

## Common Issues and Solutions

### OpenSpiel Player ID Errors

If you see errors like `player=-4` in terminal states:

1. Ensure the `fix_openspiel_player_id.py` is properly included
2. Check that terminal state detection is working in poker_rl.py
3. Consider reducing the number of players or game complexity

### Training Fails to Converge

If you see unstable or non-improving performance:

1. Check learning rate (try lower values like 0.0001)
2. Ensure batch size is appropriate (64-256 recommended)
3. Verify reward scaling in the PSRO implementation
4. Increase the number of episodes for better statistics

### Web Interface Issues

If web interfaces fail to load or display errors:

1. Check port conflicts (use `netstat -tuln` to verify ports are available)
2. Ensure Flask is properly installed
3. Verify templates directory structure
4. Check the log files in the logs/ directory

## Adding Custom Tests

You can add custom test cases to the test_all_components.py file:

```python
def test_custom_feature():
    """Test a custom feature."""
    # Test implementation
    success = True  # or False if the test fails
    return success, "Custom feature test"
```

Then add your test to the main function:

```python
if args.custom or args.all:
    run_test(test_custom_feature)
```

## Sample Test Reports

### Example 1: Successful Test Report

```markdown
# Poker AI Functional Tests Report

Generated: 2025-04-22 16:58:19

## Summary

- Total Tests: 1
- Successful Tests: 1
- Failed Tests: 0

## Overall Assessment

✅ All tests passed successfully

## Detailed Test Results

### Test Case 1: Selfplay Mode Test

- **Command**: `python poker_rl.py --mode selfplay --num_episodes 1 --verbose`
- **Exit Code**: 0 (Success)
- **Stdout**: Command completed successfully
- **Stderr**: No errors detected
- **Duration**: 2.45 seconds
- **Assessment**: ✅ Selfplay mode is functioning correctly

## Core Features Status

| Feature | Status | Notes |
|---------|--------|-------|
| Selfplay Mode | ✅ Passed | No issues detected |
```

### Example 2: Test Report with Issues

```markdown
# Poker AI Functional Tests Report

Generated: 2025-04-22 17:05:33

## Summary

- Total Tests: 3
- Successful Tests: 2
- Failed Tests: 1

## Overall Assessment

⚠️ Some tests failed. Attention needed for training mode.

## Detailed Test Results

### Test Case 1: Selfplay Mode Test

- **Command**: `python poker_rl.py --mode selfplay --num_episodes 1 --verbose`
- **Exit Code**: 0 (Success)
- **Assessment**: ✅ Selfplay mode is functioning correctly

### Test Case 2: Training Mode Test

- **Command**: `python poker_rl.py --mode train --num_episodes 5 --num_iterations 2 --verbose`
- **Exit Code**: 1 (Error)
- **Assessment**: ❌ Training mode encountered errors
- **Error Details**: "CUDA out of memory" error detected

### Test Case 3: Evaluation Mode Test

- **Command**: `python poker_rl.py --mode eval --num_episodes 5 --eval_opponents random --verbose`
- **Exit Code**: 0 (Success)
- **Assessment**: ✅ Evaluation mode is functioning correctly

## Core Features Status

| Feature | Status | Notes |
|---------|--------|-------|
| Selfplay Mode | ✅ Passed | No issues detected |
| Training Mode | ❌ Failed | CUDA memory issues |
| Evaluation Mode | ✅ Passed | No issues detected |
```

## Test Report Templates

The system includes customizable test report templates. The default template (test_report_template.md) includes:

```markdown
# Poker AI Functional Tests Report

Generated: {{generation_date}}

## Summary

- Total Tests: {{total_tests}}
- Successful Tests: {{successful_tests}}
- Failed Tests: {{failed_tests}}

## Overall Assessment

{{overall_assessment}}

## Core Features Status

| Feature | Status | Notes |
|---------|--------|-------|
| Selfplay Mode | {{selfplay_status}} | {{selfplay_notes}} |
| Evaluation Mode | {{eval_status}} | {{eval_notes}} |
| Training Mode | {{train_status}} | {{train_notes}} |
| Dynamic Parameter Adjustment | {{dynamic_params_status}} | {{dynamic_params_notes}} |
| Opponent Modeling | {{opponent_modeling_status}} | {{opponent_modeling_notes}} |

## Detailed Test Results

{{detailed_results}}

## Recommendations

{{recommendations}}
```

To use a custom template:

```bash
python run_functional_tests.py --template-path my_custom_template.md --report-path custom_report.md
```

## Continuous Testing

For production environments, consider setting up periodic automated testing:

```bash
# Add to your crontab
0 2 * * * cd /path/to/poker_ai && python run_functional_tests.py --report-path /var/log/poker_ai/daily_test_$(date +\%Y\%m\%d).md
```

This will run tests every night at 2 AM and save the reports with datestamped filenames.