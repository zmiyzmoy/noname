#!/usr/bin/env python3
import logging
import json
from dynamic_sizing import DynamicBetSizing

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def test_with_sample_hand():
    """Test dynamic bet sizing with a sample hand scenario."""
    logging.info("Testing dynamic bet sizing with sample hand...")
    
    # Load sample hand data
    try:
        with open('sample_hand.json', 'r') as f:
            sample_hands = json.load(f)
    except FileNotFoundError:
        logging.error("sample_hand.json not found")
        return
    
    if not sample_hands or not isinstance(sample_hands, list):
        logging.error("Invalid sample hand format")
        return
    
    # Process each hand
    for hand_idx, hand in enumerate(sample_hands):
        logging.info(f"\nProcessing hand #{hand_idx+1}: {hand['hand_id']}")
        
        # Extract data
        hole_cards = hand['hole_cards']
        board = hand['board']
        pot_size = hand['pot_size']
        stack_sizes = hand['stack_sizes']
        hero_position = hand['hero_position']
        position_name = hand['positions']['hero']
        current_round = hand['current_round']
        villains_stats = hand.get('villains_stats', {})
        
        # Determine round index
        round_map = {'preflop': 0, 'flop': 1, 'turn': 2, 'river': 3}
        round_idx = round_map.get(current_round, 0)
        
        # Initialize bet sizer
        bet_sizer = DynamicBetSizing(stack_sizes)
        
        # Calculate options
        # Test three scenarios: initial bet, raise, and 3-bet
        for scenario, is_raise in [
            ("Initial bet", False),
            ("Raise response", True),
        ]:
            logging.info(f"\nScenario: {scenario}")
            
            bet_options = bet_sizer.calculate_bet_options(
                None,  # No game state for this test
                pot_size,
                hero_position,
                position_name,
                board,
                hole_cards,
                villains_stats,
                round_idx=round_idx,
                is_raise=is_raise
            )
            
            # Display options
            for action, amount in sorted(bet_options.items(), key=lambda x: x[1]):
                if action != 'fold' and action != 'call':
                    logging.info(f"  {action}: {amount:.2f}")
            
            # Compare with hand's legal actions if available
            if 'legal_actions' in hand:
                logging.info("\nHand's legal actions:")
                for action in hand['legal_actions']:
                    logging.info(f"  {action['action_type']}: {action.get('amount', 0):.2f}")
                    
            logging.info("=" * 50)

def test_different_game_states():
    """Test dynamic bet sizing in various game states."""
    logging.info("\nTesting dynamic bet sizing in various game states...")
    
    test_cases = [
        {
            "name": "Preflop with strong hand",
            "stack_sizes": [100, 100, 100, 100, 100, 100],
            "pot_size": 3.5,
            "player_position": 3,
            "position_name": "CO",
            "board": [],
            "hole_cards": ["Ah", "As"],
            "round_idx": 0,
            "is_raise": False,
            "opponent_stats": {
                0: {"vpip": 20, "pfr": 15, "af": 2.0},
                1: {"vpip": 30, "pfr": 18, "af": 3.0},
                2: {"vpip": 25, "pfr": 20, "af": 2.5}
            }
        },
        {
            "name": "Flop with draw",
            "stack_sizes": [95, 90, 110, 100, 100, 100],
            "pot_size": 15.0,
            "player_position": 0,
            "position_name": "BB",
            "board": ["7h", "8h", "Th"],
            "hole_cards": ["9s", "Js"],
            "round_idx": 1,
            "is_raise": False,
            "opponent_stats": {
                1: {"vpip": 18, "pfr": 12, "af": 1.5},
                2: {"vpip": 35, "pfr": 25, "af": 4.0}
            }
        },
        {
            "name": "Turn with strong hand vs. loose opponents",
            "stack_sizes": [80, 75, 120, 95, 90, 110],
            "pot_size": 45.0,
            "player_position": 2,
            "position_name": "MP",
            "board": ["As", "Kc", "Qd", "Jh"],
            "hole_cards": ["Th", "9h"],
            "round_idx": 2,
            "is_raise": True,
            "opponent_stats": {
                0: {"vpip": 40, "pfr": 10, "af": 1.0},
                1: {"vpip": 45, "pfr": 12, "af": 0.8},
                3: {"vpip": 35, "pfr": 15, "af": 1.2}
            }
        },
        {
            "name": "River with polarized range vs. tight opponents",
            "stack_sizes": [50, 60, 40, 70, 55, 45],
            "pot_size": 100.0,
            "player_position": 4,
            "position_name": "BTN",
            "board": ["2c", "7s", "Td", "Kh", "Ac"],
            "hole_cards": ["Ad", "Kd"],
            "round_idx": 3,
            "is_raise": False,
            "opponent_stats": {
                0: {"vpip": 15, "pfr": 12, "af": 2.5},
                1: {"vpip": 18, "pfr": 14, "af": 2.2},
                2: {"vpip": 12, "pfr": 10, "af": 1.8}
            }
        }
    ]
    
    for test_case in test_cases:
        logging.info(f"\nTest case: {test_case['name']}")
        
        # Initialize bet sizer
        bet_sizer = DynamicBetSizing(test_case["stack_sizes"])
        
        # Calculate options
        bet_options = bet_sizer.calculate_bet_options(
            None,
            test_case["pot_size"],
            test_case["player_position"],
            test_case["position_name"],
            test_case["board"],
            test_case["hole_cards"],
            test_case["opponent_stats"],
            test_case["round_idx"],
            test_case["is_raise"]
        )
        
        # Display options
        for action, amount in sorted(bet_options.items(), key=lambda x: x[1]):
            if action != 'fold' and action != 'call':
                logging.info(f"  {action}: {amount:.2f}")
        
        logging.info("=" * 50)

if __name__ == "__main__":
    logging.info("Testing dynamic bet sizing functionality")
    
    # Test with sample hand
    test_with_sample_hand()
    
    # Test with different game states
    test_different_game_states()