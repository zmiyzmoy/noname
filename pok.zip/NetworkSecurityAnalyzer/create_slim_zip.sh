#!/bin/bash

echo "Creating ultra-slim version of the Poker AI System..."

# Create a temporary directory for the export
TEMP_DIR="poker_ai_slim_export"
mkdir -p "$TEMP_DIR"

# Helper function to copy files without certain patterns
copy_files() {
  local src="$1"
  local dest="$2"
  local exclude_pattern="$3"
  
  if [ -d "$src" ]; then
    mkdir -p "$dest"
    find "$src" -type f | grep -v "$exclude_pattern" | xargs -I{} cp "{}" "$dest/" 2>/dev/null || true
  elif [ -f "$src" ]; then
    cp "$src" "$dest/" 2>/dev/null || true
  fi
}

# Copy essential code files (avoid large binary files and caches)
echo "Copying Python files..."
mkdir -p "$TEMP_DIR"
find . -maxdepth 1 -name "*.py" -exec cp {} "$TEMP_DIR/" \;

echo "Copying folders..."
mkdir -p "$TEMP_DIR/blueprints"
find ./blueprints -name "*.py" | grep -v "__pycache__" | xargs -I{} cp {} "$TEMP_DIR/blueprints/" 2>/dev/null || true

mkdir -p "$TEMP_DIR/poker"
find ./poker -name "*.py" | grep -v "__pycache__" | xargs -I{} cp {} "$TEMP_DIR/poker/" 2>/dev/null || true

mkdir -p "$TEMP_DIR/templates"
cp -r ./templates/* "$TEMP_DIR/templates/" 2>/dev/null || true

mkdir -p "$TEMP_DIR/static"
find ./static -type f -not -path "*/chunks/*" | xargs -I{} cp --parents {} "$TEMP_DIR/" 2>/dev/null || true

mkdir -p "$TEMP_DIR/models"
find ./models -name "*.py" | grep -v "__pycache__" | xargs -I{} cp {} "$TEMP_DIR/models/" 2>/dev/null || true

mkdir -p "$TEMP_DIR/cfr_results"
find ./cfr_results -type f -not -name "*.pkl" | xargs -I{} cp {} "$TEMP_DIR/cfr_results/" 2>/dev/null || true

# Copy essential config files
echo "Copying configuration files..."
cp requirements.txt "$TEMP_DIR/" 2>/dev/null || echo "No requirements.txt found"
find . -maxdepth 1 -name "*.md" -exec cp {} "$TEMP_DIR/" \; 2>/dev/null || echo "No MD files found"
find . -maxdepth 1 -name "*.nix" -exec cp {} "$TEMP_DIR/" \; 2>/dev/null || echo "No nix files found"
cp pyproject.toml "$TEMP_DIR/" 2>/dev/null || echo "No pyproject.toml found"

# Create a setup script
cat > "$TEMP_DIR/setup.sh" << 'EOF'
#!/bin/bash
echo "Setting up Poker AI System..."
echo "Installing dependencies..."
pip install -r requirements.txt

echo "===== Setup Complete ====="
echo "To start the system, run:"
echo "  python main.py"
EOF

chmod +x "$TEMP_DIR/setup.sh"

# Create zip file
echo "Creating ZIP archive..."
cd "$TEMP_DIR" && zip -r ../poker_ai_system_slim.zip . && cd ..

# Clean up
echo "Cleaning up..."
rm -rf "$TEMP_DIR"

echo "Done! Created poker_ai_system_slim.zip"
echo "Size of the zip file:"
du -h poker_ai_system_slim.zip