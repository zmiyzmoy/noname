#!/usr/bin/env python3
"""
Test script for the Poker AI Onboarding Wizard.

This script tests various functionality of the onboarding wizard
to ensure it's working correctly.
"""

import os
import sys
import requests
import json
import time
import argparse
from pathlib import Path
import subprocess
import threading

def test_consolidated_app():
    """Test if the consolidated Flask app is running and responds correctly."""
    print("Testing consolidated Flask app...")
    try:
        response = requests.get("http://localhost:5010")
        if response.status_code == 200:
            print("✓ Consolidated Flask app is running.")
            # Check if onboarding is shown correctly when no state file exists
            if "onboarding.html" in response.text.lower():
                print("✓ Onboarding page shown correctly when no state file exists.")
            else:
                print("✗ Onboarding page not shown correctly.")
        else:
            print(f"✗ Consolidated Flask app returned status code {response.status_code}.")
    except requests.RequestException as e:
        print(f"✗ Error connecting to consolidated Flask app: {e}")

def test_onboarding_wizard():
    """Test if the onboarding wizard is running correctly."""
    print("\nTesting onboarding wizard...")
    try:
        response = requests.get("http://localhost:5060")
        if response.status_code == 200:
            print("✓ Onboarding wizard is running.")
            if "welcome" in response.text.lower():
                print("✓ Welcome page shown correctly.")
            else:
                print("✗ Welcome page not shown correctly.")
        else:
            print(f"✗ Onboarding wizard returned status code {response.status_code}.")
    except requests.RequestException as e:
        print(f"✗ Error connecting to onboarding wizard: {e}")

def test_skip_onboarding():
    """Test if skipping onboarding creates the state file correctly."""
    print("\nTesting skip onboarding functionality...")
    try:
        # First, remove any existing state file
        state_file = Path("onboarding_wizard_state.json")
        if state_file.exists():
            os.remove(state_file)
            print("✓ Removed existing state file.")
        
        # Test skip onboarding
        response = requests.get("http://localhost:5010/skip-onboarding")
        if response.status_code == 302:  # Should redirect
            print("✓ Skip onboarding endpoint works correctly.")
        else:
            print(f"✗ Skip onboarding endpoint returned status code {response.status_code}.")
        
        # Check if state file was created
        time.sleep(1)  # Wait for file to be created
        if state_file.exists():
            print("✓ State file created successfully.")
            
            # Parse state file
            with open(state_file, "r") as f:
                state = json.load(f)
            
            if "skipped" in state and state["skipped"] is True:
                print("✓ State file contains correct information.")
            else:
                print("✗ State file does not contain correct information.")
        else:
            print("✗ State file was not created.")
    except requests.RequestException as e:
        print(f"✗ Error testing skip onboarding: {e}")
    except Exception as e:
        print(f"✗ General error testing skip onboarding: {e}")

def run_tests():
    """Run all tests."""
    print("=" * 50)
    print("Poker AI Onboarding Wizard Tests")
    print("=" * 50)
    
    test_consolidated_app()
    test_onboarding_wizard()
    test_skip_onboarding()
    
    print("\n" + "=" * 50)
    print("Tests completed.")
    print("=" * 50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test the Poker AI Onboarding Wizard")
    parser.add_argument("--run", action="store_true", help="Run the tests")
    args = parser.parse_args()
    
    if args.run:
        run_tests()
    else:
        print("Use --run to execute the tests.")
        print("Example: python test_onboarding_wizard.py --run")