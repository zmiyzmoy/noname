# Storage Cleanup Guide for Poker AI System

Your project has grown significantly in size due to several types of files that are not essential for deployment. This guide explains what's taking up space and how to clean it up.

## Current Storage Usage

Total project size: **~4.0GB**

### Large Files & Directories

1. **System & Cache Directories (2.8+ GB):**
   - `.cache` - 1.5GB (internal Replit cache)
   - `.git` - 1.3GB (version history)
   - `.pythonlibs` - 95MB (installed Python packages)

2. **Archive Files (1+ GB):**
   - Multiple `poker_ai_system_*.tar.gz` files (~410MB each)
   - `export/poker_ai_system.tar.gz` (56MB)

3. **Model Files (~34MB):**
   - Multiple model checkpoints in `poker/models/` (~1.4MB each)

4. **Application Code:**
   - Core application code is actually quite small (~10-20MB)

## Cleaning Options

### Option 1: Use the Slim Export Script

We've updated the `prepare_for_cloud.sh` script to create a slim version that excludes unnecessary files:

```bash
chmod +x prepare_for_cloud.sh
./prepare_for_cloud.sh
```

This will:
- Temporarily move iteration checkpoint models to an archive folder
- Exclude system directories, caches, and existing archives
- Create a much smaller deployment package (~20-30MB)
- Restore your original files when done

### Option 2: Manual Cleanup (if you want to free up space in Replit)

You can safely delete these files to free up space:

```bash
# Remove existing archive files
rm -f poker_ai_system_*.tar.gz

# Remove export folder archives
rm -f export/*.tar.gz

# Clean up cached files (these will be recreated as needed)
rm -rf .cache/*
rm -rf __pycache__
find . -name "*.pyc" -delete

# Archive older model checkpoints (keeping only the latest ones)
mkdir -p poker/models/archive
mv poker/models/psro_model.pt.iteration_* poker/models/archive/
```

## What to Include When Deploying

For deployment, you only need:
- Core Python files
- Essential model files (final, best)
- Templates and static assets
- Requirements.txt

The "slim" export script will handle this for you automatically.

## Why the Project Size Increased

The large size is primarily due to:
1. Accumulated archives from previous deployments
2. Multiple copies of model checkpoints for each training iteration
3. System cache files that aren't needed for deployment

Using the slim export option will give you a much more manageable file size.