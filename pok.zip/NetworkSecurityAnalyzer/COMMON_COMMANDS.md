# Common Commands for Poker AI System

This document provides a quick reference of commonly used commands for the Poker AI system.

## Training Commands

### Basic Training

```bash
# Start basic training
python poker_rl.py --mode train --num_episodes 100 --num_iterations 10 --verbose
```

### Self-Play Mode

```bash
# Run self-play demonstration
python poker_rl.py --mode selfplay --num_episodes 5 --verbose
```

### Evaluation

```bash
# Evaluate against opponents
python poker_rl.py --mode eval --num_episodes 50 --eval_opponents random,tight_aggressive
```

## Web Interface Commands

### Starting Web Interfaces Individually

```bash
# Start consolidated Flask app
python main.py

# Start web poker dashboard
python web_poker_menu.py

# Start monitoring web
python monitoring_web.py
```

## TensorBoard Commands

```bash
# Start TensorBoard
tensorboard --logdir=runs --host 0.0.0.0 --port 6006
```

## Database Commands

```bash
# Create a new admin user
python create_new_admin.py

# Check database status
psql -U postgres -c "SELECT datname FROM pg_database WHERE datname='poker_ai'"

# Backup database
pg_dump -U postgres poker_ai > poker_ai_backup.sql
```

## Testing and Debugging

```bash
# Run all component tests
python test_all_components.py --all

# Test the OpenSpiel player ID=-4 fix
python test_openspiel_stability.py

# Run functional tests
python run_functional_tests.py
```

## System Management

```bash
# Install system using deployment script
sudo ./deploy_poker_ai.sh install

# Start all services
sudo ./deploy_poker_ai.sh start

# Run components manually
sudo ./deploy_poker_ai.sh manual
```

## Quick Setup

Here's a quick setup sequence to get everything running:

```bash
# 1. Install dependencies
sudo ./deploy_poker_ai.sh install

# 2. Start all services
sudo ./deploy_poker_ai.sh start

# 3. Run a test training session
python poker_rl.py --mode train --num_episodes 10 --num_iterations 5 --verbose

# 4. Start TensorBoard
tensorboard --logdir=runs --host 0.0.0.0 --port 6006
```

## Log File Locations

```bash
# Main Poker RL logs
cat poker_rl.log

# Web interface logs
cat logs/main_flask.log
cat logs/web_menu.log
cat logs/monitor_web.log

# TensorBoard logs
cat logs/tensorboard.log
```