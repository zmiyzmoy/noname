import os
import logging
import torch
from models import RegretNet, StrategyNet

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)

# Define paths
base_dir = "./poker/models"
model_path = os.path.join(base_dir, "psro_model.pt")

def main():
    """Initialize and save just the neural network models with the new architecture."""
    # Create directory if it doesn't exist
    os.makedirs(base_dir, exist_ok=True)
    
    # Initialize device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device: {device}")
    
    # Fixed parameters we know from the system
    state_size = 77  # From logs
    num_actions = 4  # Fixed for poker
    
    # Initialize models with the new architecture
    regret_net = RegretNet(state_size, num_actions).to(device)
    strategy_net = StrategyNet(state_size, num_actions).to(device)
    
    # Create minimal checkpoint with just the model state dicts
    checkpoint = {
        'regret_net_state_dict': regret_net.state_dict(),
        'strategy_net_state_dict': strategy_net.state_dict(),
    }
    
    # Save to checkpoint files
    torch.save(checkpoint, model_path)
    torch.save(checkpoint, model_path + ".final")
    torch.save(checkpoint, model_path + ".best")
    
    logging.info(f"Models saved to {model_path} and variants")
    
    return True

if __name__ == "__main__":
    main()