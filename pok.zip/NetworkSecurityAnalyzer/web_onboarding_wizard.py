#!/usr/bin/env python3
"""
Web-based Quick Start Onboarding Wizard for Poker AI System

This module provides a web-based guided onboarding experience for new users
to help them set up and start using the Poker AI system quickly.
"""

import os
import sys
import subprocess
import logging
import time
import json
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
import psutil
import webbrowser

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('web_onboarding_wizard.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)

# Wizard configuration
WIZARD_CONFIG = {
    "name": "Poker AI Quick Start Wizard",
    "version": "1.0.0",
    "steps": [
        {
            "id": "welcome",
            "title": "Welcome",
            "description": "Welcome to the Poker AI Onboarding Wizard. This wizard will help you set up your Poker AI system quickly.",
            "action": "display_welcome",
            "template": "wizard_welcome.html"
        },
        {
            "id": "system_check",
            "title": "System Check",
            "description": "Checking your system configuration...",
            "action": "check_system",
            "template": "wizard_system_check.html"
        },
        {
            "id": "dependencies",
            "title": "Dependencies",
            "description": "Installing required dependencies...",
            "action": "install_dependencies",
            "template": "wizard_dependencies.html"
        },
        {
            "id": "database",
            "title": "Database Setup",
            "description": "Setting up the database...",
            "action": "setup_database",
            "template": "wizard_database.html"
        },
        {
            "id": "create_admin",
            "title": "Create Admin User",
            "description": "Creating admin user...",
            "action": "create_admin_user",
            "template": "wizard_create_admin.html"
        },
        {
            "id": "start_services",
            "title": "Start Services",
            "description": "Starting necessary services...",
            "action": "start_services",
            "template": "wizard_start_services.html"
        },
        {
            "id": "quick_train",
            "title": "Quick Training",
            "description": "Running a quick training session...",
            "action": "run_quick_training",
            "template": "wizard_quick_train.html"
        },
        {
            "id": "open_dashboard",
            "title": "Open Dashboard",
            "description": "Opening the web dashboard...",
            "action": "open_dashboard",
            "template": "wizard_open_dashboard.html"
        },
        {
            "id": "finish",
            "title": "Finished",
            "description": "Setup completed successfully!",
            "action": "display_completion",
            "template": "wizard_finish.html"
        }
    ]
}

# Global state to track progress
wizard_state = {
    "current_step": 0,
    "steps_completed": [],
    "system_info": {},
    "config": {},
    "errors": [],
    "start_time": None,
    "completion_time": None,
    "logs": []
}

# Helper functions
def run_command(command, timeout=60):
    """Run a shell command and return its output."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, f"Command failed with exit code {e.returncode}: {e.stderr}"
    except subprocess.TimeoutExpired:
        return False, f"Command timed out after {timeout} seconds"
    except Exception as e:
        return False, f"Error running command: {str(e)}"

def log_message(message):
    """Log a message to both the logger and the wizard state."""
    logging.info(message)
    wizard_state["logs"].append({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": message
    })

# Create templates directory if it doesn't exist
os.makedirs("templates", exist_ok=True)

# Create templates
def create_template(template_name, content):
    """Create a template file if it doesn't exist."""
    template_path = os.path.join("templates", template_name)
    if not os.path.exists(template_path):
        with open(template_path, "w") as f:
            f.write(content)

# Create base template
create_template("wizard_base.html", """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config.name }} - {{ step.title }}</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .wizard-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .wizard-header {
            background-color: #3498db;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .wizard-header h1 {
            margin: 0;
        }
        .wizard-progress {
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        .progress-bar-container {
            height: 8px;
            width: 100%;
            background-color: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-bar {
            height: 100%;
            background-color: #3498db;
            transition: width 0.3s ease;
        }
        .step-indicators {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }
        .step-indicator {
            font-size: 12px;
            color: #6c757d;
        }
        .wizard-content {
            padding: 30px;
        }
        .wizard-footer {
            display: flex;
            justify-content: space-between;
            padding: 20px 30px;
            background-color: #f8f9fa;
            border-top: 1px solid #dee2e6;
        }
        .btn {
            display: inline-block;
            font-weight: 500;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
            border: 1px solid transparent;
            padding: 8px 16px;
            font-size: 16px;
            line-height: 1.5;
            border-radius: 4px;
            transition: all 0.15s ease-in-out;
            text-decoration: none;
        }
        .btn-primary {
            color: #fff;
            background-color: #3498db;
            border-color: #3498db;
        }
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        .btn-secondary {
            color: #fff;
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #5a6268;
        }
        .btn-disabled {
            color: #fff;
            background-color: #b3b3b3;
            border-color: #b3b3b3;
            cursor: not-allowed;
        }
        .card {
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        .card-header {
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
        }
        .card-body {
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        .form-control {
            display: block;
            width: 100%;
            padding: 8px 12px;
            font-size: 16px;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            border: 1px solid #ced4da;
            border-radius: 4px;
            transition: border-color 0.15s ease-in-out;
        }
        .form-control:focus {
            border-color: #3498db;
            outline: 0;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-warning {
            color: #856404;
            background-color: #fff3cd;
            border-color: #ffeeba;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
        .alert-info {
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }
        .code-block {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            font-family: monospace;
            white-space: pre-wrap;
            margin-bottom: 20px;
            overflow-x: auto;
        }
        .log-container {
            height: 300px;
            overflow-y: scroll;
            background-color: #272822;
            color: #f8f8f2;
            padding: 15px;
            font-family: monospace;
            font-size: 14px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .system-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .system-info-item {
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }
        .system-info-item strong {
            display: block;
            margin-bottom: 5px;
        }
        .flashes {
            list-style-type: none;
            padding: 0;
            margin-bottom: 20px;
        }
        .flashes li {
            padding: 10px 15px;
            margin-bottom: 10px;
            border-radius: 4px;
            background-color: #d4edda;
            color: #155724;
        }
        .flashes li.error {
            background-color: #f8d7da;
            color: #721c24;
        }
        @media (max-width: 768px) {
            .system-info {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="wizard-container">
        <div class="wizard-header">
            <h1>{{ config.name }} <small>v{{ config.version }}</small></h1>
            <p>{{ step.description }}</p>
        </div>
        
        <div class="wizard-progress">
            <div class="progress-bar-container">
                <div class="progress-bar" style="width: {{ progress }}%;"></div>
            </div>
            <div class="step-indicators">
                <span class="step-indicator">Step {{ current_step + 1 }} of {{ total_steps }}</span>
                <span class="step-indicator">{{ step.title }}</span>
            </div>
        </div>
        
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                <ul class="flashes">
                    {% for category, message in messages %}
                        <li{% if category != 'message' %} class="{{ category }}"{% endif %}>{{ message }}</li>
                    {% endfor %}
                </ul>
            {% endif %}
        {% endwith %}
        
        <div class="wizard-content">
            {% block content %}{% endblock %}
        </div>
        
        <div class="wizard-footer">
            {% if current_step > 0 %}
                <a href="{{ url_for('wizard_step', step_id=prev_step) }}" class="btn btn-secondary">Back</a>
            {% else %}
                <span></span>
            {% endif %}
            
            {% if next_step %}
                <a href="{{ url_for('wizard_step', step_id=next_step) }}" class="btn btn-primary">Next</a>
            {% else %}
                <form action="{{ url_for('wizard_step', step_id=step.id) }}" method="post">
                    <button type="submit" class="btn btn-primary">Finish</button>
                </form>
            {% endif %}
        </div>
    </div>
    
    {% block scripts %}{% endblock %}
</body>
</html>""")

# Create welcome template
create_template("wizard_welcome.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Welcome to the Poker AI Setup Wizard!</h2>

<p>This wizard will guide you through the setup process for the Poker AI system, helping you:</p>

<ul>
    <li>Check your system configuration</li>
    <li>Install all required dependencies</li>
    <li>Set up the database</li>
    <li>Create an admin user</li>
    <li>Start necessary services</li>
    <li>Run a quick training session</li>
    <li>Access the web dashboards</li>
</ul>

<div class="card">
    <div class="card-header">System Requirements</div>
    <div class="card-body">
        <ul>
            <li>Python 3.8 or newer</li>
            <li>PostgreSQL database</li>
            <li>At least 4GB RAM</li>
            <li>At least 20GB free disk space</li>
            <li>(Optional) NVIDIA GPU for faster training</li>
        </ul>
    </div>
</div>

<p>Click "Next" to begin the setup process.</p>
{% endblock %}""")

# Create system check template
create_template("wizard_system_check.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>System Check</h2>

<p>Let's check your system configuration to make sure it meets the requirements for the Poker AI system.</p>

<div class="system-info">
    {% for key, value in system_info.items() %}
    <div class="system-info-item">
        <strong>{{ key | replace('_', ' ') | title }}</strong>
        <span>{{ value }}</span>
    </div>
    {% endfor %}
</div>

{% if errors %}
<div class="alert alert-warning">
    <h4>Warnings</h4>
    <ul>
        {% for error in errors %}
        <li>{{ error }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

<div id="check-progress" class="alert alert-info">
    Running system checks... <span id="progress-text">0%</span>
</div>

<div class="card">
    <div class="card-header">Recommendations</div>
    <div class="card-body" id="recommendations">
        <p>Analyzing your system...</p>
    </div>
</div>

{% endblock %}

{% block scripts %}
<script>
    // Simulated progress updates
    let progress = 0;
    const progressElement = document.getElementById('progress-text');
    const checkProgressElement = document.getElementById('check-progress');
    const recommendationsElement = document.getElementById('recommendations');
    
    const updateProgress = () => {
        progress += 10;
        progressElement.textContent = progress + '%';
        
        if (progress >= 100) {
            clearInterval(progressInterval);
            checkProgressElement.className = 'alert alert-success';
            checkProgressElement.textContent = 'System check complete!';
            
            // Update recommendations based on system info
            let recommendations = '<ul>';
            {% if system_info.get('has_cuda', False) %}
                recommendations += '<li>Your system has a GPU. Training will be faster!</li>';
            {% else %}
                recommendations += '<li>No GPU detected. Training will use CPU only, which may be slower.</li>';
            {% endif %}
            
            {% if system_info.get('has_openspiel', False) %}
                recommendations += '<li>OpenSpiel is installed and ready to use.</li>';
            {% else %}
                recommendations += '<li>OpenSpiel needs to be installed.</li>';
            {% endif %}
            
            {% if system_info.get('has_database_config', False) %}
                recommendations += '<li>Database configuration detected.</li>';
            {% else %}
                recommendations += '<li>Database configuration needs to be set up.</li>';
            {% endif %}
            
            {% if system_info.get('in_venv', False) %}
                recommendations += '<li>Running in a virtual environment (recommended).</li>';
            {% else %}
                recommendations += '<li>Not running in a virtual environment. Consider using one for better dependency management.</li>';
            {% endif %}
            
            recommendations += '</ul>';
            recommendationsElement.innerHTML = recommendations;
        }
    };
    
    const progressInterval = setInterval(updateProgress, 500);
</script>
{% endblock %}""")

# Create dependencies template
create_template("wizard_dependencies.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Install Dependencies</h2>

<p>The Poker AI system requires several dependencies to function properly. Let's install them now.</p>

<div class="card">
    <div class="card-header">Python Dependencies</div>
    <div class="card-body">
        <div class="log-container" id="python-deps-log">
            {% for log in logs %}
            <div>{{ log.time }} - {{ log.message }}</div>
            {% endfor %}
        </div>
        
        <form action="{{ url_for('install_dependencies') }}" method="post">
            <button type="submit" class="btn btn-primary" id="install-button">Install Python Dependencies</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">System Dependencies</div>
    <div class="card-body">
        <p>The following system dependencies may be required:</p>
        <ul>
            <li>PostgreSQL database server</li>
            <li>CUDA drivers (for GPU acceleration)</li>
            <li>Build tools (for compiling certain packages)</li>
        </ul>
        
        <div class="alert alert-info">
            System dependencies may require sudo/administrator privileges to install.
        </div>
        
        <form action="{{ url_for('install_system_dependencies') }}" method="post">
            <button type="submit" class="btn btn-primary" id="install-system-button">Install System Dependencies</button>
        </form>
    </div>
</div>

{% if errors %}
<div class="alert alert-warning">
    <h4>Warnings</h4>
    <ul>
        {% for error in errors %}
        <li>{{ error }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

{% endblock %}

{% block scripts %}
<script>
    // Auto-scroll log to bottom
    const logContainer = document.getElementById('python-deps-log');
    logContainer.scrollTop = logContainer.scrollHeight;
</script>
{% endblock %}""")

# Create database template
create_template("wizard_database.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Database Setup</h2>

<p>The Poker AI system requires a PostgreSQL database to store training configuration, results, and user information.</p>

{% if database_configured %}
<div class="alert alert-success">
    <p>Database is already configured!</p>
    <p>Current connection: <code>{{ database_url_masked }}</code></p>
</div>

<form action="{{ url_for('reconfigure_database') }}" method="post">
    <button type="submit" class="btn btn-secondary">Reconfigure Database</button>
</form>
{% else %}
<div class="card">
    <div class="card-header">Database Configuration</div>
    <div class="card-body">
        <form action="{{ url_for('setup_database') }}" method="post">
            <div class="form-group">
                <label for="db_name">Database Name:</label>
                <input type="text" id="db_name" name="db_name" class="form-control" value="poker_ai" required>
            </div>
            
            <div class="form-group">
                <label for="db_user">Database User:</label>
                <input type="text" id="db_user" name="db_user" class="form-control" value="poker_user" required>
            </div>
            
            <div class="form-group">
                <label for="db_password">Database Password:</label>
                <input type="password" id="db_password" name="db_password" class="form-control" value="poker_password" required>
            </div>
            
            <div class="form-group">
                <label for="db_host">Database Host:</label>
                <input type="text" id="db_host" name="db_host" class="form-control" value="localhost" required>
            </div>
            
            <div class="form-group">
                <label for="db_port">Database Port:</label>
                <input type="number" id="db_port" name="db_port" class="form-control" value="5432" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Configure Database</button>
        </form>
    </div>
</div>
{% endif %}

<div class="card">
    <div class="card-header">Database Migration</div>
    <div class="card-body">
        <div class="log-container" id="migration-log">
            {% for log in migration_logs %}
            <div>{{ log.time }} - {{ log.message }}</div>
            {% endfor %}
        </div>
        
        <form action="{{ url_for('run_migrations') }}" method="post">
            <button type="submit" class="btn btn-primary" id="migration-button" {% if not database_configured %}disabled{% endif %}>Run Database Migrations</button>
        </form>
    </div>
</div>

{% if errors %}
<div class="alert alert-warning">
    <h4>Warnings</h4>
    <ul>
        {% for error in errors %}
        <li>{{ error }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

{% endblock %}

{% block scripts %}
<script>
    // Auto-scroll log to bottom
    const logContainer = document.getElementById('migration-log');
    if (logContainer) {
        logContainer.scrollTop = logContainer.scrollHeight;
    }
</script>
{% endblock %}""")

# Create admin user template
create_template("wizard_create_admin.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Create Admin User</h2>

<p>Let's create an administrator user for the Poker AI system. This user will have full access to the admin dashboard.</p>

<div class="card">
    <div class="card-header">Admin User Information</div>
    <div class="card-body">
        <form action="{{ url_for('create_admin_user') }}" method="post">
            <div class="form-group">
                <label for="admin_username">Username:</label>
                <input type="text" id="admin_username" name="admin_username" class="form-control" value="pokeradmin" required>
            </div>
            
            <div class="form-group">
                <label for="admin_password">Password:</label>
                <input type="password" id="admin_password" name="admin_password" class="form-control" value="pokerpwd123" required>
            </div>
            
            <div class="form-group">
                <label for="admin_email">Email:</label>
                <input type="email" id="admin_email" name="admin_email" class="form-control" value="admin@example.com" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Create Admin User</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">Status</div>
    <div class="card-body" id="status-container">
        {% if admin_created %}
            <div class="alert alert-success">Admin user created successfully!</div>
        {% else %}
            <div class="alert alert-info">No admin user has been created yet.</div>
        {% endif %}
    </div>
</div>

{% if errors %}
<div class="alert alert-warning">
    <h4>Warnings</h4>
    <ul>
        {% for error in errors %}
        <li>{{ error }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

{% endblock %}""")

# Create start services template
create_template("wizard_start_services.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Start Services</h2>

<p>Now we'll start the necessary services for the Poker AI system.</p>

<div class="card">
    <div class="card-header">System Services</div>
    <div class="card-body">
        <div class="log-container" id="services-log">
            {% for log in service_logs %}
            <div>{{ log.time }} - {{ log.message }}</div>
            {% endfor %}
        </div>
        
        <div class="alert alert-info">
            <p>The following services will be started:</p>
            <ul>
                <li>Main Flask Application (port 5010)</li>
                <li>Web Poker Dashboard (port 5003)</li>
                <li>Monitoring Web (port 5000)</li>
            </ul>
        </div>
        
        <form action="{{ url_for('start_services') }}" method="post">
            <button type="submit" class="btn btn-primary" id="start-button">Start Services</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">Service Status</div>
    <div class="card-body">
        <table class="table" id="service-status-table">
            <thead>
                <tr>
                    <th>Service</th>
                    <th>Port</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                {% for service in services %}
                <tr>
                    <td>{{ service.name }}</td>
                    <td>{{ service.port }}</td>
                    <td>
                        {% if service.running %}
                            <span style="color: green;">Running</span>
                        {% else %}
                            <span style="color: red;">Stopped</span>
                        {% endif %}
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        
        <form action="{{ url_for('check_services') }}" method="post">
            <button type="submit" class="btn btn-secondary" id="check-button">Check Service Status</button>
        </form>
    </div>
</div>

{% if errors %}
<div class="alert alert-warning">
    <h4>Warnings</h4>
    <ul>
        {% for error in errors %}
        <li>{{ error }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

{% endblock %}

{% block scripts %}
<script>
    // Auto-scroll log to bottom
    const logContainer = document.getElementById('services-log');
    if (logContainer) {
        logContainer.scrollTop = logContainer.scrollHeight;
    }
</script>
{% endblock %}""")

# Create quick train template
create_template("wizard_quick_train.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Quick Training</h2>

<p>Let's run a quick training session to verify that everything is set up correctly.</p>

<div class="card">
    <div class="card-header">Training Configuration</div>
    <div class="card-body">
        <form action="{{ url_for('run_quick_training') }}" method="post">
            <div class="form-group">
                <label for="num_episodes">Number of Episodes:</label>
                <input type="number" id="num_episodes" name="num_episodes" class="form-control" value="10" min="1" max="100" required>
                <small class="form-text text-muted">For this quick test, we recommend 10-20 episodes.</small>
            </div>
            
            <div class="form-group">
                <label for="num_iterations">Number of Iterations:</label>
                <input type="number" id="num_iterations" name="num_iterations" class="form-control" value="2" min="1" max="10" required>
                <small class="form-text text-muted">For this quick test, we recommend 1-3 iterations.</small>
            </div>
            
            <div class="form-check">
                <input type="checkbox" id="verbose" name="verbose" class="form-check-input" checked>
                <label for="verbose" class="form-check-label">Enable Verbose Output</label>
            </div>
            
            <button type="submit" class="btn btn-primary">Start Training</button>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header">Training Log</div>
    <div class="card-body">
        <div class="log-container" id="training-log">
            {% for log in training_logs %}
            <div>{{ log.time }} - {{ log.message }}</div>
            {% endfor %}
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">Training Status</div>
    <div class="card-body" id="training-status">
        {% if training_started %}
            {% if training_complete %}
                <div class="alert alert-success">Training completed successfully!</div>
            {% else %}
                <div class="alert alert-info">Training in progress...</div>
            {% endif %}
        {% else %}
            <div class="alert alert-info">No training has been started yet.</div>
        {% endif %}
    </div>
</div>

{% if errors %}
<div class="alert alert-warning">
    <h4>Warnings</h4>
    <ul>
        {% for error in errors %}
        <li>{{ error }}</li>
        {% endfor %}
    </ul>
</div>
{% endif %}

{% endblock %}

{% block scripts %}
<script>
    // Auto-scroll log to bottom
    const logContainer = document.getElementById('training-log');
    if (logContainer) {
        logContainer.scrollTop = logContainer.scrollHeight;
    }
</script>
{% endblock %}""")

# Create open dashboard template
create_template("wizard_open_dashboard.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Open Dashboard</h2>

<p>The Poker AI system provides several web interfaces for training, monitoring, and administration.</p>

<div class="card">
    <div class="card-header">Available Dashboards</div>
    <div class="card-body">
        <div class="alert alert-info">
            Click on a dashboard to open it in a new tab.
        </div>
        
        <table class="table">
            <thead>
                <tr>
                    <th>Dashboard</th>
                    <th>URL</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {% for dashboard in dashboards %}
                <tr>
                    <td>{{ dashboard.name }}</td>
                    <td><code>{{ dashboard.url }}</code></td>
                    <td>{{ dashboard.description }}</td>
                    <td>
                        <a href="{{ dashboard.url }}" target="_blank" class="btn btn-primary btn-sm">Open</a>
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">TensorBoard</div>
    <div class="card-body">
        <p>TensorBoard is a visualization tool that allows you to monitor your training progress in real-time.</p>
        
        <div class="alert alert-info">
            TensorBoard runs on port 6006 by default.
        </div>
        
        <form action="{{ url_for('start_tensorboard') }}" method="post">
            <button type="submit" class="btn btn-primary">Start TensorBoard</button>
        </form>
        
        {% if tensorboard_running %}
        <div class="alert alert-success" style="margin-top: 15px;">
            TensorBoard is running! <a href="http://localhost:6006" target="_blank">Open TensorBoard</a>
        </div>
        {% endif %}
    </div>
</div>

{% endblock %}""")

# Create finish template
create_template("wizard_finish.html", """{% extends "wizard_base.html" %}

{% block content %}
<h2>Setup Complete!</h2>

<div class="alert alert-success">
    <h4>Congratulations!</h4>
    <p>The Poker AI system has been successfully set up on your machine.</p>
</div>

<div class="card">
    <div class="card-header">Next Steps</div>
    <div class="card-body">
        <p>Here are some things you can do next:</p>
        
        <ul>
            <li>Access the web dashboards to train and monitor your Poker AI</li>
            <li>Read the documentation to learn more about the system</li>
            <li>Run a full training session to develop a strong Poker AI strategy</li>
            <li>Customize the system to suit your needs</li>
        </ul>
    </div>
</div>

<div class="card">
    <div class="card-header">Documentation</div>
    <div class="card-body">
        <p>The following documentation is available to help you use the Poker AI system:</p>
        
        <ul>
            <li><strong>README_DEPLOYMENT.md</strong> - Detailed deployment instructions</li>
            <li><strong>TENSORBOARD_AND_FUNCTIONS_GUIDE.md</strong> - Guide to using TensorBoard and other features</li>
            <li><strong>COMMON_COMMANDS.md</strong> - Quick reference for common commands</li>
        </ul>
    </div>
</div>

<div class="card">
    <div class="card-header">Setup Summary</div>
    <div class="card-body">
        <p><strong>Setup started:</strong> {{ start_time }}</p>
        <p><strong>Setup completed:</strong> {{ end_time }}</p>
        <p><strong>Duration:</strong> {{ duration }}</p>
        
        <p><strong>Steps completed:</strong></p>
        <ul>
            {% for step in completed_steps %}
            <li>{{ step }}</li>
            {% endfor %}
        </ul>
        
        {% if errors %}
        <div class="alert alert-warning">
            <h4>Warnings</h4>
            <p>The following issues were encountered during setup:</p>
            <ul>
                {% for error in errors %}
                <li>{{ error }}</li>
                {% endfor %}
            </ul>
        </div>
        {% endif %}
    </div>
</div>

<div class="card">
    <div class="card-header">Support</div>
    <div class="card-body">
        <p>If you encounter any issues or have questions about the Poker AI system, please refer to the documentation or contact support.</p>
    </div>
</div>

<form action="{{ url_for('finish_wizard') }}" method="post">
    <button type="submit" class="btn btn-primary">Exit Wizard</button>
</form>

{% endblock %}""")

# Create static directory if it doesn't exist
os.makedirs("static", exist_ok=True)

# Routes
@app.route('/')
def index():
    """Main landing page for the onboarding wizard."""
    return redirect(url_for('wizard_step', step_id='welcome'))

@app.route('/wizard/<step_id>', methods=['GET', 'POST'])
def wizard_step(step_id):
    """Handle a specific step in the wizard."""
    # Find the step
    step_index = None
    for i, step in enumerate(WIZARD_CONFIG['steps']):
        if step['id'] == step_id:
            step_index = i
            break
    
    if step_index is None:
        flash("Step not found", "error")
        return redirect(url_for('index'))
    
    # Update current step in wizard state
    wizard_state["current_step"] = step_index
    step = WIZARD_CONFIG['steps'][step_index]
    
    # Handle post requests for the final step
    if request.method == 'POST' and step_id == 'finish':
        return redirect(url_for('finish_wizard'))
    
    # Get previous and next steps
    prev_step = WIZARD_CONFIG['steps'][step_index - 1]['id'] if step_index > 0 else None
    next_step = WIZARD_CONFIG['steps'][step_index + 1]['id'] if step_index < len(WIZARD_CONFIG['steps']) - 1 else None
    
    # Calculate progress
    progress = (step_index / (len(WIZARD_CONFIG['steps']) - 1)) * 100
    
    # Render the template
    return render_template(
        step['template'],
        config=WIZARD_CONFIG,
        step=step,
        current_step=step_index,
        total_steps=len(WIZARD_CONFIG['steps']),
        progress=progress,
        prev_step=prev_step,
        next_step=next_step,
        wizard_state=wizard_state,
        system_info=wizard_state['system_info'],
        errors=wizard_state['errors'],
        logs=wizard_state['logs'],
        database_url_masked="***" if os.environ.get("DATABASE_URL") else None,
        database_configured=os.environ.get("DATABASE_URL") is not None,
        admin_created='create_admin' in wizard_state['steps_completed'],
        training_started='quick_train' in wizard_state['steps_completed'],
        training_complete='quick_train' in wizard_state['steps_completed'],
        training_logs=wizard_state.get('training_logs', []),
        service_logs=wizard_state.get('service_logs', []),
        migration_logs=wizard_state.get('migration_logs', []),
        start_time=wizard_state['start_time'].strftime("%Y-%m-%d %H:%M:%S") if wizard_state['start_time'] else None,
        end_time=wizard_state['completion_time'].strftime("%Y-%m-%d %H:%M:%S") if wizard_state['completion_time'] else None,
        duration=str(wizard_state['completion_time'] - wizard_state['start_time']).split('.')[0] if wizard_state['completion_time'] and wizard_state['start_time'] else None,
        completed_steps=[step['title'] for i, step in enumerate(WIZARD_CONFIG['steps']) if i < step_index],
        services=[
            {"name": "Main Flask App", "port": 5010, "running": False},
            {"name": "Web Poker Dashboard", "port": 5003, "running": False},
            {"name": "Monitoring Web", "port": 5000, "running": False},
        ],
        dashboards=[
            {"name": "Main Flask App", "url": "http://localhost:5010", "description": "Main application interface"},
            {"name": "Web Poker Dashboard", "url": "http://localhost:5003", "description": "Dashboard for poker training"},
            {"name": "Monitoring Web", "url": "http://localhost:5000", "description": "Monitoring dashboard"},
        ],
        tensorboard_running=False
    )

@app.route('/check_system', methods=['POST'])
def check_system():
    """Check system configuration."""
    log_message("Checking system configuration...")
    
    # Check Python version
    python_version = sys.version.split()[0]
    log_message(f"Python version: {python_version}")
    wizard_state["system_info"]["python_version"] = python_version
    
    # Check if running in virtual environment
    in_venv = sys.prefix != sys.base_prefix
    log_message(f"Virtual environment: {'Yes' if in_venv else 'No'}")
    wizard_state["system_info"]["in_venv"] = in_venv
    
    # Check for GPU
    try:
        import torch
        has_cuda = torch.cuda.is_available()
        cuda_version = torch.version.cuda if has_cuda else "N/A"
        log_message(f"CUDA available: {'Yes' if has_cuda else 'No'}")
        log_message(f"CUDA version: {cuda_version}")
        wizard_state["system_info"]["has_cuda"] = has_cuda
        wizard_state["system_info"]["cuda_version"] = cuda_version
        if has_cuda:
            device_name = torch.cuda.get_device_name(0)
            log_message(f"GPU device: {device_name}")
            wizard_state["system_info"]["gpu_device"] = device_name
    except ImportError:
        log_message("PyTorch not installed. GPU status unknown.")
        wizard_state["system_info"]["has_cuda"] = False
        wizard_state["system_info"]["cuda_version"] = "N/A"
    
    # Check for OpenSpiel
    try:
        import pyspiel
        log_message("OpenSpiel installed: Yes")
        wizard_state["system_info"]["has_openspiel"] = True
    except ImportError:
        log_message("OpenSpiel not installed.")
        wizard_state["system_info"]["has_openspiel"] = False
    
    # Check for database
    try:
        import psycopg2
        log_message("PostgreSQL driver installed: Yes")
        # Check if DATABASE_URL is set
        database_url = os.environ.get("DATABASE_URL")
        if database_url:
            log_message(f"Database URL configured: Yes")
            wizard_state["system_info"]["has_database_config"] = True
        else:
            log_message(f"Database URL configured: No")
            wizard_state["system_info"]["has_database_config"] = False
    except ImportError:
        log_message("PostgreSQL driver not installed.")
        wizard_state["system_info"]["has_database_config"] = False
    
    # Check disk space
    try:
        import psutil
        disk_usage = psutil.disk_usage('.')
        free_gb = disk_usage.free / (1024 * 1024 * 1024)
        log_message(f"Free disk space: {free_gb:.2f} GB")
        wizard_state["system_info"]["free_disk_gb"] = free_gb
    except ImportError:
        log_message("Could not check disk space (psutil not installed).")
    
    log_message("System check completed.")
    
    wizard_state["steps_completed"].append("system_check")
    
    flash("System check completed", "success")
    return redirect(url_for('wizard_step', step_id='system_check'))

@app.route('/install_dependencies', methods=['POST'])
def install_dependencies():
    """Install required dependencies."""
    log_message("Installing Python dependencies...")
    
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        log_message("Creating requirements.txt...")
        with open("requirements.txt", "w") as f:
            f.write("""dash
dash-bootstrap-components
flask
flask-login
flask-migrate
flask-sqlalchemy
gunicorn
imageio
joblib
matplotlib
numpy
open-spiel
plotly
psutil
psycopg2-binary
pynvml
ray
requests
scikit-learn
scipy
sqlalchemy
tensorboard
torch
tqdm
werkzeug
""")
    
    # Install requirements
    def install_deps_thread():
        success, output = run_command("pip install -r requirements.txt", timeout=300)
        if not success:
            log_message(f"Error installing dependencies: {output}")
            wizard_state["errors"].append(f"Failed to install dependencies: {output}")
        else:
            log_message("Python dependencies installed successfully.")
        wizard_state["steps_completed"].append("dependencies")
    
    # Start installation in a separate thread
    threading.Thread(target=install_deps_thread).start()
    
    flash("Started installing Python dependencies", "success")
    return redirect(url_for('wizard_step', step_id='dependencies'))

@app.route('/install_system_dependencies', methods=['POST'])
def install_system_dependencies():
    """Install system dependencies."""
    log_message("Installing system dependencies...")
    
    # Check for the deploy script
    def install_system_deps_thread():
        if os.path.exists("deploy_poker_ai.sh"):
            log_message("Using deployment script to install system dependencies...")
            success, output = run_command("bash deploy_poker_ai.sh install", timeout=300)
            if not success:
                log_message(f"Warning: Deployment script encountered issues: {output}")
                wizard_state["errors"].append(f"Deployment script issues: {output}")
            else:
                log_message("System dependencies installed with deployment script.")
        else:
            log_message("Deployment script not found. Installing system dependencies manually...")
            success, output = run_command("sudo apt-get update && sudo apt-get install -y build-essential python3-dev libopenmpi-dev postgresql postgresql-contrib", timeout=300)
            if not success:
                log_message(f"Error installing system dependencies: {output}")
                wizard_state["errors"].append(f"Failed to install system dependencies: {output}")
            else:
                log_message("System dependencies installed successfully.")
    
    # Start installation in a separate thread
    threading.Thread(target=install_system_deps_thread).start()
    
    flash("Started installing system dependencies", "success")
    return redirect(url_for('wizard_step', step_id='dependencies'))

@app.route('/setup_database', methods=['POST'])
def setup_database():
    """Set up the database."""
    if 'migration_logs' not in wizard_state:
        wizard_state['migration_logs'] = []
    
    log_message = lambda msg: wizard_state['migration_logs'].append({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": msg
    })
    
    log_message("Setting up database...")
    
    # Get database configuration from form
    db_name = request.form.get('db_name', 'poker_ai')
    db_user = request.form.get('db_user', 'poker_user')
    db_password = request.form.get('db_password', 'poker_password')
    db_host = request.form.get('db_host', 'localhost')
    db_port = request.form.get('db_port', '5432')
    
    # Construct database URL
    db_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
    
    # Set environment variable
    os.environ["DATABASE_URL"] = db_url
    
    log_message(f"Database URL configured: postgresql://{db_user}:***@{db_host}:{db_port}/{db_name}")
    
    # Create database and user
    def setup_db_thread():
        # Check if database already exists
        success, output = run_command(f"sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw {db_name} && echo 'exists' || echo 'not exists'")
        if success and "exists" in output:
            log_message(f"Database '{db_name}' already exists.")
        else:
            success, output = run_command(f"sudo -u postgres createdb {db_name}")
            if not success:
                log_message(f"Error creating database: {output}")
                wizard_state["errors"].append(f"Failed to create database: {output}")
                return
            
            log_message(f"Database '{db_name}' created successfully.")
            
            # Create user and grant privileges
            success, output = run_command(f"sudo -u postgres psql -c \"CREATE USER {db_user} WITH PASSWORD '{db_password}';\"")
            if not success:
                log_message(f"Error creating database user: {output}")
                wizard_state["errors"].append(f"Failed to create database user: {output}")
            else:
                log_message(f"Database user '{db_user}' created successfully.")
            
            success, output = run_command(f"sudo -u postgres psql -c \"GRANT ALL PRIVILEGES ON DATABASE {db_name} TO {db_user};\"")
            if not success:
                log_message(f"Error granting privileges: {output}")
                wizard_state["errors"].append(f"Failed to grant database privileges: {output}")
            else:
                log_message(f"Privileges granted to user '{db_user}'.")
        
        wizard_state["steps_completed"].append("database")
    
    # Start database setup in a separate thread
    threading.Thread(target=setup_db_thread).start()
    
    flash("Database configuration set up", "success")
    return redirect(url_for('wizard_step', step_id='database'))

@app.route('/reconfigure_database', methods=['POST'])
def reconfigure_database():
    """Reset database configuration."""
    if 'DATABASE_URL' in os.environ:
        del os.environ['DATABASE_URL']
    
    if 'database' in wizard_state['steps_completed']:
        wizard_state['steps_completed'].remove('database')
    
    flash("Database configuration reset", "success")
    return redirect(url_for('wizard_step', step_id='database'))

@app.route('/run_migrations', methods=['POST'])
def run_migrations():
    """Run database migrations."""
    if 'migration_logs' not in wizard_state:
        wizard_state['migration_logs'] = []
    
    log_message = lambda msg: wizard_state['migration_logs'].append({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": msg
    })
    
    log_message("Running database migrations...")
    
    # Check if DATABASE_URL is set
    if 'DATABASE_URL' not in os.environ:
        log_message("Error: DATABASE_URL not set. Please configure the database first.")
        flash("Database not configured", "error")
        return redirect(url_for('wizard_step', step_id='database'))
    
    # Run migrations
    def run_migrations_thread():
        if os.path.exists("main.py"):
            log_message("Running migrations using main.py...")
            success, output = run_command("python main.py db upgrade")
            if not success:
                log_message(f"Warning: Database migration issues: {output}")
                wizard_state["errors"].append(f"Database migration issues: {output}")
            else:
                log_message("Database migrations completed successfully.")
        else:
            log_message("main.py not found. Cannot run migrations.")
            wizard_state["errors"].append("Could not run migrations: main.py not found")
    
    # Start migrations in a separate thread
    threading.Thread(target=run_migrations_thread).start()
    
    flash("Started database migrations", "success")
    return redirect(url_for('wizard_step', step_id='database'))

@app.route('/create_admin_user', methods=['POST'])
def create_admin_user():
    """Create an admin user."""
    log_message("Creating admin user...")
    
    # Get admin user information from form
    admin_username = request.form.get('admin_username', 'pokeradmin')
    admin_password = request.form.get('admin_password', 'pokerpwd123')
    admin_email = request.form.get('admin_email', 'admin@example.com')
    
    # Create admin user
    def create_admin_thread():
        if os.path.exists("create_new_admin.py"):
            log_message(f"Creating admin user '{admin_username}'...")
            
            # Create a temporary file with admin credentials
            with open("admin_credentials.tmp", "w") as f:
                f.write(f"{admin_username}\n{admin_password}\n{admin_email}\n")
            
            # Run the create_new_admin.py script with input from the temporary file
            success, output = run_command("cat admin_credentials.tmp | python create_new_admin.py")
            
            # Remove the temporary file
            if os.path.exists("admin_credentials.tmp"):
                os.remove("admin_credentials.tmp")
            
            if not success:
                log_message(f"Error creating admin user: {output}")
                wizard_state["errors"].append(f"Failed to create admin user: {output}")
            else:
                log_message("Admin user created successfully.")
                wizard_state["steps_completed"].append("create_admin")
        else:
            log_message("create_new_admin.py script not found. Could not create admin user.")
            wizard_state["errors"].append("Could not create admin user: script not found")
    
    # Start admin user creation in a separate thread
    threading.Thread(target=create_admin_thread).start()
    
    flash("Started creating admin user", "success")
    return redirect(url_for('wizard_step', step_id='create_admin'))

@app.route('/start_services', methods=['POST'])
def start_services():
    """Start necessary services."""
    if 'service_logs' not in wizard_state:
        wizard_state['service_logs'] = []
    
    log_message = lambda msg: wizard_state['service_logs'].append({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": msg
    })
    
    log_message("Starting services...")
    
    # Create logs directory if it doesn't exist
    os.makedirs("logs", exist_ok=True)
    
    # Start services
    def start_services_thread():
        # Check for the deploy script
        if os.path.exists("deploy_poker_ai.sh"):
            log_message("Using deployment script to start services...")
            success, output = run_command("bash deploy_poker_ai.sh start")
            if not success:
                log_message(f"Warning: Deployment script encountered issues: {output}")
                wizard_state["errors"].append(f"Service start issues: {output}")
                
                # Try manual start as fallback
                log_message("Trying manual service start...")
                start_services_manually(log_message)
            else:
                log_message("Services started with deployment script.")
        else:
            # Start services manually
            start_services_manually(log_message)
        
        wizard_state["steps_completed"].append("start_services")
    
    # Start services in a separate thread
    threading.Thread(target=start_services_thread).start()
    
    flash("Started system services", "success")
    return redirect(url_for('wizard_step', step_id='start_services'))

def start_services_manually(log_func):
    """Start services manually as a fallback."""
    log_func("Starting services manually...")
    
    # Start main Flask app
    if os.path.exists("main.py"):
        log_func("Starting main Flask app...")
        subprocess.Popen(
            ["python", "main.py"],
            stdout=open("logs/main_flask.log", "a"),
            stderr=open("logs/main_flask_err.log", "a")
        )
    else:
        log_func("main.py not found. Could not start main Flask app.")
    
    # Start monitoring web
    if os.path.exists("monitoring_web.py"):
        log_func("Starting monitoring web...")
        subprocess.Popen(
            ["python", "monitoring_web.py"],
            stdout=open("logs/monitor_web.log", "a"),
            stderr=open("logs/monitor_web_err.log", "a")
        )
    else:
        log_func("monitoring_web.py not found. Could not start monitoring web.")
    
    # Start web poker menu
    if os.path.exists("web_poker_menu.py"):
        log_func("Starting web poker menu...")
        subprocess.Popen(
            ["python", "web_poker_menu.py"],
            stdout=open("logs/web_menu.log", "a"),
            stderr=open("logs/web_menu_err.log", "a")
        )
    else:
        log_func("web_poker_menu.py not found. Could not start web poker menu.")
    
    # Give services time to start
    log_func("Giving services time to start...")
    time.sleep(5)
    
    log_func("Services started.")

@app.route('/check_services', methods=['POST'])
def check_services():
    """Check service status."""
    if 'service_logs' not in wizard_state:
        wizard_state['service_logs'] = []
    
    log_message = lambda msg: wizard_state['service_logs'].append({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": msg
    })
    
    log_message("Checking service status...")
    
    services = [
        {"name": "Main Flask App", "port": 5010, "running": False},
        {"name": "Web Poker Dashboard", "port": 5003, "running": False},
        {"name": "Monitoring Web", "port": 5000, "running": False},
    ]
    
    # Check if each service is running
    import socket
    for service in services:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.connect(("localhost", service["port"]))
            s.close()
            service["running"] = True
            log_message(f"{service['name']} is running on port {service['port']}")
        except:
            log_message(f"{service['name']} is not running on port {service['port']}")
    
    # Store service status in session for the template
    session['services'] = services
    
    flash("Service status checked", "success")
    return redirect(url_for('wizard_step', step_id='start_services'))

@app.route('/run_quick_training', methods=['POST'])
def run_quick_training():
    """Run a quick training session."""
    if 'training_logs' not in wizard_state:
        wizard_state['training_logs'] = []
    
    log_message = lambda msg: wizard_state['training_logs'].append({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "message": msg
    })
    
    log_message("Starting quick training session...")
    
    # Get training configuration from form
    num_episodes = request.form.get('num_episodes', '10')
    num_iterations = request.form.get('num_iterations', '2')
    verbose = 'verbose' in request.form
    
    # Run training
    def run_training_thread():
        if os.path.exists("poker_rl.py"):
            log_message(f"Running training with {num_episodes} episodes and {num_iterations} iterations...")
            
            cmd = f"python poker_rl.py --mode train --num_episodes {num_episodes} --num_iterations {num_iterations}"
            if verbose:
                cmd += " --verbose"
            
            log_message(f"Command: {cmd}")
            success, output = run_command(cmd, timeout=300)
            
            if not success:
                log_message(f"Warning: Training encountered issues: {output}")
                wizard_state["errors"].append(f"Training issues: {output}")
                
                # Try a simpler training as fallback
                log_message("Trying a simpler self-play session...")
                success, output = run_command("python poker_rl.py --mode selfplay --num_episodes 2 --verbose", timeout=60)
                if not success:
                    log_message(f"Error with self-play: {output}")
                    wizard_state["errors"].append(f"Self-play issues: {output}")
                else:
                    log_message("Self-play session completed successfully.")
                    wizard_state["steps_completed"].append("quick_train")
            else:
                log_message("Training session completed successfully.")
                wizard_state["steps_completed"].append("quick_train")
        else:
            log_message("poker_rl.py script not found. Could not run training.")
            wizard_state["errors"].append("Could not run training: script not found")
    
    # Start training in a separate thread
    threading.Thread(target=run_training_thread).start()
    
    session['training_started'] = True
    flash("Started training session", "success")
    return redirect(url_for('wizard_step', step_id='quick_train'))

@app.route('/start_tensorboard', methods=['POST'])
def start_tensorboard():
    """Start TensorBoard."""
    # Check if TensorBoard is already running
    try:
        import psutil
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            if 'tensorboard' in ' '.join(proc.info['cmdline'] or []):
                flash("TensorBoard is already running", "success")
                session['tensorboard_running'] = True
                return redirect(url_for('wizard_step', step_id='open_dashboard'))
    except:
        pass
    
    # Start TensorBoard
    def start_tensorboard_thread():
        log_message("Starting TensorBoard...")
        
        # Create logs directory if it doesn't exist
        os.makedirs("logs", exist_ok=True)
        
        # Start TensorBoard
        subprocess.Popen(
            ["tensorboard", "--logdir=runs", "--host=0.0.0.0", "--port=6006"],
            stdout=open("logs/tensorboard.log", "a"),
            stderr=open("logs/tensorboard_err.log", "a")
        )
        
        # Wait for TensorBoard to start
        time.sleep(5)
        
        log_message("TensorBoard started.")
    
    # Start TensorBoard in a separate thread
    threading.Thread(target=start_tensorboard_thread).start()
    
    session['tensorboard_running'] = True
    flash("Started TensorBoard", "success")
    return redirect(url_for('wizard_step', step_id='open_dashboard'))

@app.route('/finish_wizard', methods=['POST'])
def finish_wizard():
    """Finish the wizard."""
    wizard_state["completion_time"] = datetime.now()
    
    # Save wizard state to a file
    with open("onboarding_wizard_state.json", "w") as f:
        # Convert datetime objects to strings
        state_copy = wizard_state.copy()
        if state_copy["start_time"]:
            state_copy["start_time"] = state_copy["start_time"].isoformat()
        if state_copy["completion_time"]:
            state_copy["completion_time"] = state_copy["completion_time"].isoformat()
        
        json.dump(state_copy, f, indent=2)
    
    wizard_state["steps_completed"].append("finish")
    
    flash("Wizard completed successfully!", "success")
    
    # Redirect to the main web interface
    return redirect("http://localhost:5010")

# Initialize wizard state before the first request
def init_wizard_state():
    """Initialize wizard state before the first request."""
    wizard_state["start_time"] = datetime.now()
    wizard_state["steps_completed"] = []
    wizard_state["system_info"] = {}
    wizard_state["config"] = {}
    wizard_state["errors"] = []
    wizard_state["logs"] = []

# Initialize wizard state when app starts
with app.app_context():
    init_wizard_state()

if __name__ == "__main__":
    # Create templates directory if it doesn't exist
    os.makedirs("templates", exist_ok=True)
    
    # Create logs directory if it doesn't exist
    os.makedirs("logs", exist_ok=True)
    
    # Parse command-line arguments
    import argparse
    parser = argparse.ArgumentParser(description="Poker AI Onboarding Wizard")
    parser.add_argument("--port", type=int, default=5020, help="Port to run the wizard on")
    args = parser.parse_args()
    
    # Start the Flask app
    port = args.port
    url = f"http://localhost:{port}"
    
    # Open the browser
    threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    
    # Start the app
    print(f"Starting Poker AI Quick Start Wizard at {url}")
    app.run(host="0.0.0.0", port=port, debug=True)