#!/usr/bin/env python3
"""
Parameter Adjustment Helper

This module provides functionality to monitor system resources and
propose optimal parameter adjustments for training configuration.
"""

import os
import logging
import psutil
import time
from typing import Dict, Any, Tuple, Optional, Union, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Conditional imports for GPU support, handle them safely
# Try to import torch but don't fail if not available
HAS_TORCH = False
try:
    import torch
    if hasattr(torch, 'cuda') and hasattr(torch.cuda, 'is_available'):
        HAS_TORCH = True
except (ImportError, Exception) as e:
    logger.debug(f"Torch import failed: {e}")

# Try to import pynvml but don't fail if not available
HAS_NVIDIA = False
try:
    import pynvml
    pynvml.nvmlInit()
    HAS_NVIDIA = True
except (ImportError, Exception) as e:
    logger.debug(f"PYNVML import failed: {e}")

def get_system_metrics() -> Dict[str, Any]:
    """
    Get current system resource metrics for CPU, memory and GPU.
    
    Returns:
        Dictionary containing system metrics
    """
    metrics = {}
    
    # Get CPU metrics
    try:
        cpu_percent = psutil.cpu_percent(interval=0.5)
        cpu_count = psutil.cpu_count()
        cpu_count_physical = psutil.cpu_count(logical=False) or 1
        
        metrics['cpu'] = {
            'usage_percent': cpu_percent,
            'total_cores': cpu_count,
            'physical_cores': cpu_count_physical
        }
    except Exception as e:
        logger.error(f"Error getting CPU metrics: {e}")
        metrics['cpu'] = {
            'usage_percent': 0,
            'total_cores': 0,
            'physical_cores': 0
        }
    
    # Get memory metrics
    try:
        mem = psutil.virtual_memory()
        metrics['memory'] = {
            'total_gb': mem.total / (1024 ** 3),
            'used_gb': mem.used / (1024 ** 3),
            'available_gb': mem.available / (1024 ** 3),
            'usage_percent': mem.percent
        }
    except Exception as e:
        logger.error(f"Error getting memory metrics: {e}")
        metrics['memory'] = {
            'total_gb': 0,
            'used_gb': 0,
            'available_gb': 0,
            'usage_percent': 0
        }
    
    # Get GPU metrics with defensive programming
    metrics['gpu'] = {
        'available': False,
        'count': 0,
        'devices': []
    }
    
    # Only check for CUDA if torch was successfully imported
    if HAS_TORCH:
        try:
            # Check if CUDA is available, using hasattr for safety
            if hasattr(torch, 'cuda') and hasattr(torch.cuda, 'is_available') and torch.cuda.is_available():
                metrics['gpu']['available'] = True
                
                # Get device count safely
                if hasattr(torch.cuda, 'device_count'):
                    metrics['gpu']['count'] = torch.cuda.device_count()
                
                # Only try NVIDIA specific queries if pynvml was successfully imported
                if HAS_NVIDIA:
                    try:
                        # Get NVIDIA device information
                        device_count = pynvml.nvmlDeviceGetCount()
                        devices = []
                        
                        for i in range(device_count):
                            try:
                                handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                                name = pynvml.nvmlDeviceGetName(handle)
                                # Safely handle name decoding
                                if isinstance(name, bytes):
                                    name = name.decode('utf-8', errors='replace')
                                mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                                util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                                
                                # Calculate memory metrics safely
                                total_memory_gb = mem_info.total / (1024 ** 3)
                                used_memory_gb = mem_info.used / (1024 ** 3)
                                free_memory_gb = (mem_info.total - mem_info.used) / (1024 ** 3)
                                memory_percent = (mem_info.used / mem_info.total) * 100 if mem_info.total > 0 else 0
                                
                                devices.append({
                                    'index': i,
                                    'name': name,
                                    'total_memory_gb': total_memory_gb,
                                    'used_memory_gb': used_memory_gb,
                                    'free_memory_gb': free_memory_gb,
                                    'memory_percent': memory_percent,
                                    'gpu_util_percent': util.gpu,
                                    'memory_util_percent': util.memory
                                })
                            except Exception as e:
                                logger.warning(f"Error getting info for GPU {i}: {e}")
                                # Add a placeholder device with limited info
                                devices.append({
                                    'index': i,
                                    'name': f"GPU {i}",
                                    'total_memory_gb': 0,
                                    'used_memory_gb': 0,
                                    'free_memory_gb': 0,
                                    'memory_percent': 0,
                                    'gpu_util_percent': 0,
                                    'memory_util_percent': 0
                                })
                        
                        if devices:
                            metrics['gpu']['devices'] = devices
                    except Exception as e:
                        logger.warning(f"Error getting detailed GPU metrics with pynvml: {e}")
        except Exception as e:
            logger.warning(f"Error checking GPU availability: {e}")
    
    return metrics

def calculate_optimal_batch_size(current_batch_size: int, metrics: Dict[str, Any], 
                                target_util_percent: float = 85) -> int:
    """
    Calculate optimal batch size based on current system metrics.
    
    Args:
        current_batch_size: Current batch size
        metrics: System metrics from get_system_metrics()
        target_util_percent: Target utilization percentage (0-100)
        
    Returns:
        Recommended batch size
    """
    # Default to current batch size if we can't make a recommendation
    new_batch_size = current_batch_size
    
    # If GPU is available, base recommendation on GPU metrics
    if metrics['gpu']['available'] and metrics['gpu']['count'] > 0:
        gpu_devices = metrics['gpu']['devices']
        if gpu_devices:
            # Calculate average memory utilization across all GPUs
            avg_mem_util = sum(d.get('memory_percent', 0) for d in gpu_devices) / len(gpu_devices)
            avg_gpu_util = sum(d.get('gpu_util_percent', 0) for d in gpu_devices) / len(gpu_devices)
            
            # If memory utilization is below target, increase batch size
            if avg_mem_util < target_util_percent:
                # Calculate adjustment factor based on how far we are from target
                adjustment_factor = target_util_percent / max(avg_mem_util, 10)  # Avoid division by very small numbers
                # Limit adjustment to reasonable range (0.8x to 2x)
                adjustment_factor = max(0.8, min(2.0, adjustment_factor))
                new_batch_size = max(1, int(current_batch_size * adjustment_factor))
            
            # If GPU utilization is below target but memory is high, consider decreasing batch size
            elif avg_gpu_util < 50 and avg_mem_util > 90:
                new_batch_size = max(1, int(current_batch_size * 0.8))
    
    # If no GPU or couldn't make GPU-based recommendation, use CPU/memory
    else:
        # If CPU utilization is low, consider increasing batch size
        cpu_percent = metrics['cpu']['usage_percent']
        mem_percent = metrics['memory']['usage_percent']
        
        if cpu_percent < target_util_percent and mem_percent < target_util_percent:
            # Calculate adjustment based on both CPU and memory headroom
            cpu_headroom = (target_util_percent - cpu_percent) / 100
            mem_headroom = (target_util_percent - mem_percent) / 100
            adjustment_factor = 1.0 + min(cpu_headroom, mem_headroom)
            # Limit adjustment to reasonable range (1x to 1.5x)
            adjustment_factor = min(1.5, adjustment_factor)
            new_batch_size = max(1, int(current_batch_size * adjustment_factor))
        
        # If memory utilization is high, consider decreasing batch size
        elif mem_percent > 90:
            new_batch_size = max(1, int(current_batch_size * 0.8))
    
    # Ensure batch size is a power of 2 for optimal performance
    power_of_2 = 2 ** max(1, int(new_batch_size).bit_length() - 1)
    if new_batch_size > power_of_2:
        power_of_2 *= 2
    
    if abs(power_of_2 - new_batch_size) / new_batch_size < 0.25:  # If within 25% of a power of 2
        new_batch_size = power_of_2
    
    return new_batch_size

def calculate_optimal_num_workers(current_num_workers: int, metrics: Dict[str, Any],
                                 target_util_percent: float = 60) -> int:
    """
    Calculate optimal number of workers based on both CPU and memory utilization.
    
    Args:
        current_num_workers: Current number of workers
        metrics: System metrics from get_system_metrics()
        target_util_percent: Target utilization percentage (default: 60%)
        
    Returns:
        Recommended number of workers
    """
    # Don't adjust if we have no metrics or current_num_workers is invalid
    if not metrics or not isinstance(current_num_workers, int) or current_num_workers < 1:
        return current_num_workers
    
    new_num_workers = current_num_workers
    
    # Get CPU info
    cpu_percent = metrics['cpu']['usage_percent']
    physical_cores = metrics['cpu']['physical_cores']
    total_cores = metrics['cpu']['total_cores']
    
    # Get memory info
    memory_percent = metrics['memory']['usage_percent']
    available_memory_gb = metrics['memory']['available_gb']
    total_memory_gb = metrics['memory']['total_gb']
    
    # Estimate memory per worker (1GB per worker is a safe starting point)
    estimated_memory_per_worker_gb = 1.5
    
    # Calculate max workers based on memory constraints
    # Reserve 20% of available memory for system and main process
    memory_limited_max_workers = int((available_memory_gb * 0.8) / estimated_memory_per_worker_gb)
    
    # Calculate max workers based on CPU constraints
    # Reserve 1 core for the main process, another for system
    cpu_limited_max_workers = max(1, physical_cores - 2)
    
    # Take the more conservative limit
    hard_max_workers = min(memory_limited_max_workers, cpu_limited_max_workers)
    
    # Leave some cores free for the main process
    available_cores = max(1, total_cores - 2)
    
    # For OpenSpiel, CPU bound tasks are often better with fewer workers
    # to avoid context switching overhead
    available_cores = min(available_cores, physical_cores)
    
    # Memory pressure takes precedence in adjustment decisions
    if memory_percent > 80:  # Critical memory pressure
        # Aggressively reduce workers
        new_num_workers = max(1, int(current_num_workers * 0.6))
        logger.info(f"High memory pressure ({memory_percent}%), reducing workers from {current_num_workers} to {new_num_workers}")
    
    # Then consider CPU utilization
    elif cpu_percent < target_util_percent and memory_percent < 70:
        # Only increase if we have memory headroom
        # Calculate adjustment based on CPU headroom, but be very conservative
        cpu_headroom = (target_util_percent - cpu_percent) / 100
        adjustment_factor = 1.0 + (cpu_headroom * 0.3)  # Very conservative adjustment
        
        # Limit adjustment to reasonable range (1x to 1.3x)
        adjustment_factor = min(1.3, adjustment_factor)
        
        # Calculate new worker count with hard max workers cap
        proposed_workers = min(hard_max_workers, int(current_num_workers * adjustment_factor))
        proposed_workers = min(proposed_workers, available_cores)
        
        # Use the new value only if it's different
        if proposed_workers > current_num_workers:
            new_num_workers = proposed_workers
            logger.info(f"Increasing workers from {current_num_workers} to {new_num_workers} (CPU: {cpu_percent}%, Memory: {memory_percent}%)")
    
    # If CPU utilization is high, decrease workers
    elif cpu_percent > 90:
        new_num_workers = max(1, int(current_num_workers * 0.8))
        logger.info(f"High CPU usage ({cpu_percent}%), reducing workers from {current_num_workers} to {new_num_workers}")
    
    # Ensure we don't exceed our hard max workers
    new_num_workers = min(new_num_workers, hard_max_workers)
    
    # For security, add a hard cap of workers based on server size
    # For small-medium servers (4-8 cores), limit to physical cores
    if physical_cores <= 8:
        new_num_workers = min(new_num_workers, physical_cores - 1)
    
    # OpenSpiel and Ray can consume a lot of memory, so be very conservative
    # Always cap num_workers to a safe maximum
    if total_memory_gb < 32:  # Small memory systems
        new_num_workers = min(new_num_workers, 2)  # Maximum 2 workers
    elif total_memory_gb < 64:  # Medium memory systems
        new_num_workers = min(new_num_workers, 4)  # Maximum 4 workers
    
    # For PSRO algorithm specifically, very conservative limits
    new_num_workers = min(new_num_workers, physical_cores)
    
    return new_num_workers

def propose_parameter_adjustments(config: Any, current_active_state: bool, non_interactive: bool = False) -> bool:
    """
    Analyze system resources and propose parameter adjustments to the user.
    
    Args:
        config: Configuration object containing current parameters
        current_active_state: Whether the adjustment helper is currently active
        non_interactive: If True, will apply recommendations automatically without prompting
        
    Returns:
        New active state (True to continue checks, False to disable)
    """
    # Try to use server_config_helper for hardware-specific configuration
    try:
        from server_config_helper import get_recommended_psro_config, get_server_specs
        
        # Get hardware-specific recommendations
        server_config = get_recommended_psro_config()
        server_specs = get_server_specs()
        
        # Log detected server specifications
        logger.info("Detected server specifications:")
        logger.info(f"CPU: {server_specs.get('cpu', {}).get('physical_cores', 'Unknown')} physical cores, {server_specs.get('cpu', {}).get('logical_cores', 'Unknown')} logical cores")
        logger.info(f"Memory: {server_specs.get('memory', {}).get('total_gb', 'Unknown'):.2f} GB")
        if server_specs.get('gpu', {}).get('available', False):
            gpu_names = [d.get('name', 'Unknown') for d in server_specs.get('gpu', {}).get('devices', [])]
            logger.info(f"GPUs: {', '.join(gpu_names)}")
        
        logger.info("Using hardware-optimized parameter recommendations from server_config_helper")
    except ImportError as e:
        server_config = None
        logger.warning(f"server_config_helper not available: {e}, using standard parameter adjustment")
    except Exception as e:
        server_config = None
        logger.warning(f"Error accessing server_config_helper: {e}, using standard parameter adjustment")
    # Define safe parameter ranges
    MIN_BATCH_SIZE = 16
    MAX_BATCH_SIZE = 512
    MIN_WORKERS = 1
    MAX_WORKERS = 32
    
    # Target utilization thresholds
    TARGET_CPU_UTIL = 85.0  # Target CPU utilization percentage
    TARGET_MEM_UTIL = 85.0  # Target memory utilization percentage
    TARGET_GPU_UTIL = 85.0  # Target GPU utilization percentage
    TARGET_GPU_MEM = 85.0   # Target GPU memory utilization percentage
    
    if not current_active_state:
        return False
    
    # Get current metrics
    metrics = get_system_metrics()
    
    # Get current values from config
    current_batch_size = getattr(config, 'BATCH_SIZE', 64)
    current_num_workers = getattr(config, 'NUM_WORKERS', 8)
    
    # Use server_config recommendations if available
    if server_config:
        # Check if we should update initial batch size from server recommendations
        if hasattr(config, 'BATCH_SIZE') and server_config['batch_size'] != current_batch_size:
            logger.info(f"Using recommended batch size {server_config['batch_size']} from server configuration")
            if non_interactive:
                # In non-interactive mode, directly apply the server recommendation
                config.BATCH_SIZE = server_config['batch_size']
                logger.info(f"Auto-applied recommended batch size: {server_config['batch_size']}")
            else:
                # In interactive mode, ask for confirmation
                user_input = input(f"Use recommended BATCH_SIZE of {server_config['batch_size']} instead of current {current_batch_size}? (y/n): ").lower()
                if user_input == 'y':
                    config.BATCH_SIZE = server_config['batch_size']
                    logger.info(f"Applied recommended batch size: {server_config['batch_size']}")
                    current_batch_size = server_config['batch_size']
        
        # Check if we should update initial worker count from server recommendations
        if hasattr(config, 'NUM_WORKERS') and server_config['num_workers'] != current_num_workers:
            logger.info(f"Using recommended worker count {server_config['num_workers']} from server configuration")
            if non_interactive:
                # In non-interactive mode, directly apply the server recommendation
                config.NUM_WORKERS = server_config['num_workers']
                logger.info(f"Auto-applied recommended worker count: {server_config['num_workers']}")
            else:
                # In interactive mode, ask for confirmation
                user_input = input(f"Use recommended NUM_WORKERS of {server_config['num_workers']} instead of current {current_num_workers}? (y/n): ").lower()
                if user_input == 'y':
                    config.NUM_WORKERS = server_config['num_workers']
                    logger.info(f"Applied recommended worker count: {server_config['num_workers']}")
                    current_num_workers = server_config['num_workers']
    
    # Calculate current resource utilization averages
    cpu_util = metrics['cpu']['usage_percent']
    mem_util = metrics['memory']['usage_percent']
    
    # GPU utilization (if available)
    gpu_util = 0.0
    gpu_mem_util = 0.0
    gpu_available = metrics['gpu']['available'] and len(metrics['gpu']['devices']) > 0
    
    if gpu_available:
        # Calculate average GPU utilization across all devices
        gpu_utils = [device.get('gpu_util_percent', 0) for device in metrics['gpu']['devices']]
        gpu_util = sum(gpu_utils) / len(gpu_utils) if gpu_utils else 0
        
        # Calculate average GPU memory utilization
        gpu_mem_utils = [device.get('memory_percent', 0) for device in metrics['gpu']['devices']]
        gpu_mem_util = sum(gpu_mem_utils) / len(gpu_mem_utils) if gpu_mem_utils else 0
    
    # Calculate optimal parameters based on current resource utilization
    proposed_batch_size = calculate_optimal_batch_size(current_batch_size, metrics, 
                                                     target_util_percent=TARGET_GPU_MEM if gpu_available else TARGET_MEM_UTIL)
    proposed_num_workers = calculate_optimal_num_workers(current_num_workers, metrics, 
                                                       target_util_percent=TARGET_CPU_UTIL)
    
    # Apply hard limits to ensure stability
    proposed_batch_size = max(MIN_BATCH_SIZE, min(MAX_BATCH_SIZE, proposed_batch_size))
    proposed_num_workers = max(MIN_WORKERS, min(MAX_WORKERS, proposed_num_workers))
    
    # Only propose changes if they're significantly different
    batch_size_change = abs(proposed_batch_size - current_batch_size) / current_batch_size
    workers_change = abs(proposed_num_workers - current_num_workers) / max(1, current_num_workers)
    
    # Display current resource usage
    logger.info("Current System Resource Utilization:")
    logger.info(f"CPU: {cpu_util:.1f}% of {metrics['cpu']['total_cores']} cores (Target: {TARGET_CPU_UTIL:.1f}%)")
    logger.info(f"Memory: {mem_util:.1f}% of {metrics['memory']['total_gb']:.1f} GB (Target: {TARGET_MEM_UTIL:.1f}%)")
    
    # More detailed GPU utilization information
    if gpu_available:
        for i, device in enumerate(metrics['gpu']['devices']):
            logger.info(f"GPU #{i} ({device['name']}): {device['gpu_util_percent']:.1f}% compute, "
                      f"{device['memory_percent']:.1f}% memory used "
                      f"({device['used_memory_gb']:.2f}/{device['total_memory_gb']:.2f} GB)")
        logger.info(f"Average GPU Utilization: {gpu_util:.1f}% (Target: {TARGET_GPU_UTIL:.1f}%)")
        logger.info(f"Average GPU Memory: {gpu_mem_util:.1f}% (Target: {TARGET_GPU_MEM:.1f}%)")
    else:
        logger.info("No GPU detected or CUDA not available. Using CPU only.")
    
    made_proposal = False
    changes_applied = []
    
    # Propose batch size change if significant
    if batch_size_change > 0.15:  # More than 15% change
        if non_interactive:
            # In non-interactive mode, automatically apply the change with a more conservative adjustment
            old_batch_size = current_batch_size
            
            # For non-interactive mode, make smaller adjustments to ensure stability
            if proposed_batch_size > current_batch_size:
                # When increasing, be more conservative
                adjustment_ratio = min(1.25, proposed_batch_size / current_batch_size)
                adjusted_batch_size = int(current_batch_size * adjustment_ratio)
                # Ensure it's still a power of 2 if close
                power_of_2 = 2 ** max(1, int(adjusted_batch_size).bit_length() - 1)
                if adjusted_batch_size > power_of_2 and adjusted_batch_size < power_of_2 * 1.2:
                    adjusted_batch_size = power_of_2
                elif adjusted_batch_size >= power_of_2 * 1.2:
                    adjusted_batch_size = power_of_2 * 2
            else:
                # When decreasing, can be more aggressive
                adjusted_batch_size = proposed_batch_size
            
            # Apply the final constraints
            adjusted_batch_size = max(MIN_BATCH_SIZE, min(MAX_BATCH_SIZE, adjusted_batch_size))
            
            # Only update if the change is significant enough
            if abs(adjusted_batch_size - current_batch_size) / current_batch_size > 0.1:
                config.BATCH_SIZE = adjusted_batch_size
                logger.info(f"Parameter Adjustment (Auto): BATCH_SIZE {old_batch_size} → {adjusted_batch_size}")
                changes_applied.append(f"BATCH_SIZE: {old_batch_size} → {adjusted_batch_size}")
                made_proposal = True
        else:
            # Interactive mode with user confirmation
            logger.info(f"Current batch size: {current_batch_size}")
            logger.info(f"Proposed batch size: {proposed_batch_size}")
            reason = ""
            if gpu_available and gpu_mem_util < TARGET_GPU_MEM - 10:
                reason = f" (GPU memory utilization {gpu_mem_util:.1f}% < target {TARGET_GPU_MEM:.1f}%)"
            elif gpu_available and gpu_mem_util > TARGET_GPU_MEM + 10:
                reason = f" (GPU memory utilization {gpu_mem_util:.1f}% > target {TARGET_GPU_MEM:.1f}%)"
            elif not gpu_available and mem_util < TARGET_MEM_UTIL - 10:
                reason = f" (Memory utilization {mem_util:.1f}% < target {TARGET_MEM_UTIL:.1f}%)"
            elif not gpu_available and mem_util > TARGET_MEM_UTIL + 10:
                reason = f" (Memory utilization {mem_util:.1f}% > target {TARGET_MEM_UTIL:.1f}%)"
            
            logger.info(f"Reason for adjustment:{reason}")
            user_input = input(f"Adjust BATCH_SIZE from {current_batch_size} to {proposed_batch_size}? (y/n/d to disable further checks): ").lower()
            
            if user_input == 'y':
                config.BATCH_SIZE = proposed_batch_size
                logger.info(f"Updated BATCH_SIZE to {proposed_batch_size}")
                changes_applied.append(f"BATCH_SIZE: {current_batch_size} → {proposed_batch_size}")
                made_proposal = True
            elif user_input == 'd':
                logger.info("User requested disabling further adjustment checks for this run.")
                return False
    
    # Propose worker count change if significant
    if workers_change > 0.15:  # More than 15% change
        if non_interactive:
            # For non-interactive mode, make smaller adjustments to ensure stability
            old_num_workers = current_num_workers
            
            if proposed_num_workers > current_num_workers:
                # When increasing workers, be conservative
                adjustment_step = min(2, proposed_num_workers - current_num_workers)
                adjusted_workers = current_num_workers + adjustment_step
            else:
                # When decreasing workers, can be more direct
                adjusted_workers = proposed_num_workers
            
            # Apply the final constraints
            adjusted_workers = max(MIN_WORKERS, min(MAX_WORKERS, adjusted_workers))
            
            # Only update if there's an actual change
            if adjusted_workers != current_num_workers:
                config.NUM_WORKERS = adjusted_workers
                logger.info(f"Parameter Adjustment (Auto): NUM_WORKERS {old_num_workers} → {adjusted_workers}")
                changes_applied.append(f"NUM_WORKERS: {old_num_workers} → {adjusted_workers}")
                made_proposal = True
        else:
            # Interactive mode with user confirmation
            logger.info(f"Current num_workers: {current_num_workers}")
            logger.info(f"Proposed num_workers: {proposed_num_workers}")
            reason = ""
            if cpu_util < TARGET_CPU_UTIL - 10:
                reason = f" (CPU utilization {cpu_util:.1f}% < target {TARGET_CPU_UTIL:.1f}%)"
            elif cpu_util > TARGET_CPU_UTIL + 10:
                reason = f" (CPU utilization {cpu_util:.1f}% > target {TARGET_CPU_UTIL:.1f}%)"
                
            logger.info(f"Reason for adjustment:{reason}")
            user_input = input(f"Adjust NUM_WORKERS from {current_num_workers} to {proposed_num_workers}? (y/n/d to disable further checks): ").lower()
            
            if user_input == 'y':
                config.NUM_WORKERS = proposed_num_workers
                logger.info(f"Updated NUM_WORKERS to {proposed_num_workers}")
                changes_applied.append(f"NUM_WORKERS: {current_num_workers} → {proposed_num_workers}")
                made_proposal = True
            elif user_input == 'd':
                logger.info("User requested disabling further adjustment checks for this run.")
                return False
    
    # Summary of changes
    if made_proposal:
        if non_interactive:
            logger.info("Parameter Adjustment Summary (Auto Mode):")
            for change in changes_applied:
                logger.info(f" - {change}")
        else:
            logger.info("Parameter Adjustment Summary:")
            for change in changes_applied:
                logger.info(f" - {change}")
    else:
        logger.info("Current parameters appear well-optimized for your system. No changes proposed.")
    
    return True

if __name__ == "__main__":
    # Basic testing
    class DummyConfig:
        BATCH_SIZE = 64
        NUM_WORKERS = 8
    
    config = DummyConfig()
    active = True
    
    print("=== Parameter Adjustment Helper Test ===")
    active = propose_parameter_adjustments(config, active)
    
    print(f"Final parameters: BATCH_SIZE={config.BATCH_SIZE}, NUM_WORKERS={config.NUM_WORKERS}")
    print(f"Adjustment helper active: {active}")