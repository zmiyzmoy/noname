#!/usr/bin/env python3
"""
Quick Start Onboarding Wizard Launcher

This script provides a simple way to start the onboarding wizard.
It will detect whether to use the command-line or web-based wizard
based on the environment and user preference.
"""

import os
import sys
import argparse
import subprocess
import webbrowser
import time
import platform

def check_web_interface_dependencies():
    """Check if the dependencies for the web interface are installed."""
    try:
        import flask
        return True
    except ImportError:
        return False

def start_command_line_wizard():
    """Start the command-line onboarding wizard."""
    print("Starting command-line onboarding wizard...")
    
    # Check if the onboarding wizard script exists
    if not os.path.exists("onboarding_wizard.py"):
        print("Error: onboarding_wizard.py not found.")
        return False
    
    # Start the onboarding wizard
    try:
        subprocess.run(["python", "onboarding_wizard.py"], check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error starting onboarding wizard: {e}")
        return False

def start_web_wizard(port=5020):
    """Start the web-based onboarding wizard."""
    print("Starting web-based onboarding wizard...")
    
    # Check if the web onboarding wizard script exists
    if not os.path.exists("web_onboarding_wizard.py"):
        print("Error: web_onboarding_wizard.py not found.")
        return False
    
    # Start the web onboarding wizard
    url = f"http://localhost:{port}"
    print(f"Opening {url} in your browser...")
    
    # Open the browser
    try:
        # Wait a moment to allow the server to start
        time.sleep(1.5)
        webbrowser.open(url)
    except Exception as e:
        print(f"Warning: Could not open browser automatically: {e}")
        print(f"Please open {url} in your browser.")
    
    # Start the web server
    try:
        subprocess.run(["python", "web_onboarding_wizard.py", "--port", str(port)], check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error starting web onboarding wizard: {e}")
        return False
    except KeyboardInterrupt:
        print("\nWeb onboarding wizard stopped.")
        return True

def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Start the Poker AI Onboarding Wizard")
    parser.add_argument("--web", action="store_true", help="Force using the web-based wizard")
    parser.add_argument("--cli", action="store_true", help="Force using the command-line wizard")
    parser.add_argument("--port", type=int, default=5020, help="Port to use for the web-based wizard")
    
    args = parser.parse_args()
    
    # Determine which wizard to use
    use_web = args.web
    use_cli = args.cli
    
    if not use_web and not use_cli:
        # Auto-detect the best option
        if check_web_interface_dependencies():
            use_web = True
        else:
            use_cli = True
    
    # Start the appropriate wizard
    if use_web:
        return start_web_wizard(args.port)
    else:
        return start_command_line_wizard()

if __name__ == "__main__":
    # Print welcome message
    print("\n" + "="*70)
    print(" Poker AI Quick Start Onboarding Wizard")
    print("="*70)
    print(" This wizard will help you set up and start using the Poker AI system.")
    print("-"*70)
    
    try:
        success = main()
        if success:
            print("\nWizard completed successfully.")
            sys.exit(0)
        else:
            print("\nWizard encountered errors.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\nWizard interrupted. Exiting...")
        sys.exit(130)  # Standard exit code for SIGINT