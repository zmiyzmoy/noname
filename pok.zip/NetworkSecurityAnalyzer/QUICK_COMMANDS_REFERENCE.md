# Poker AI System - Quick Commands Reference

This quick reference guide provides common commands for managing your Poker AI system after deployment.

## Web Interfaces

| Interface | URL | Description |
|-----------|-----|-------------|
| Main Dashboard | http://your-server:5010/ | Consolidated interface with access to all features |
| Monitoring Dashboard | http://your-server:5000/ | Real-time monitoring of training progress |
| Admin Dashboard | http://your-server:5002/ | Advanced administration interface |
| Web Poker Dashboard | http://your-server:5003/ | Web-based training menu |

## Starting and Stopping Services

### Using Systemd (if configured during deployment)

```bash
# Start the Poker AI service
sudo systemctl start poker-ai

# Stop the Poker AI service
sudo systemctl stop poker-ai

# Restart the Poker AI service
sudo systemctl restart poker-ai

# Check service status
sudo systemctl status poker-ai

# Enable service to start on boot
sudo systemctl enable poker-ai

# Disable service from starting on boot
sudo systemctl disable poker-ai

# View service logs
sudo journalctl -u poker-ai
```

### Manual Start/Stop

If not using systemd, you can start the services manually:

```bash
# Start main service (runs in foreground)
python main.py

# Start main service (runs in background)
nohup python main.py > main.log 2>&1 &

# Stop a background service
pkill -f "python main.py"
```

## Training Commands

### Command Line Training

```bash
# Start training with default parameters
python poker_rl.py

# Self-play training with 100 episodes
python poker_rl.py --mode selfplay --num_episodes 100

# Tournament evaluation
python poker_rl.py --mode tournament

# Interactive play
python poker_rl.py --mode interactive
```

### Parameter Adjustment

```bash
# Check current parameter settings
python parameter_adjuster.py --check

# Auto-adjust parameters based on hardware
python parameter_adjuster.py --auto

# Set batch size manually
python parameter_adjuster.py --set batch_size=128

# Set number of workers manually
python parameter_adjuster.py --set workers=4

# Disable dynamic parameter adjustment
python parameter_adjuster.py --disable
```

## Database Management

```bash
# Connect to PostgreSQL database
psql -U postgres -d poker_ai

# Create a database backup
pg_dump -U postgres poker_ai > poker_ai_backup.sql

# Restore from a backup
psql -U postgres -d poker_ai < poker_ai_backup.sql
```

## Log Management

```bash
# View application logs
tail -f main.log

# View Flask app logs
tail -f flask_app.log

# View training logs
tail -f poker_rl.log

# View monitoring logs
tail -f monitoring.log

# Clear log files
> main.log
> flask_app.log
```

## File Management

```bash
# List model checkpoints
ls -la checkpoints/

# Check disk usage
du -h --max-depth=1

# Monitor system resources
htop
```

## Backup and Recovery

```bash
# Create full system backup
tar -czf poker_ai_backup.tar.gz --exclude="*.log" --exclude="__pycache__" .

# Backup only essential files
python server_transfer_toolkit.py pack
```

## Troubleshooting

### Common Issues

#### Web Interface Not Loading
```bash
# Check if the server is running
ps aux | grep python

# Check port availability
netstat -tuln | grep 5010

# Restart the service
sudo systemctl restart poker-ai
```

#### Database Connection Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Verify connection parameters
cat main.py | grep DATABASE_URL

# Check database logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

#### Training Issues
```bash
# Check for error messages
tail -f poker_rl.log

# Verify hardware resources
htop

# Restart training with verbose output
python poker_rl.py --verbose
```

## Security

```bash
# Check for sensitive information in config files
grep -r "password" --include="*.py" --include="*.json" .

# Set proper file permissions
find . -type f -name "*.py" -exec chmod 644 {} \;
find . -type f -name "*.sh" -exec chmod 755 {} \;
```

## Environment Variables

Set these environment variables to configure the system:

```bash
# Database connection
export DATABASE_URL="postgresql://username:password@localhost:5432/poker_ai"

# Flask secret key
export FLASK_SECRET_KEY="your_secret_key"

# Development mode (set to "1" for development)
export DEVELOPMENT_MODE="0"
```

## Server Transfer

```bash
# Create a deployment package
python server_transfer_toolkit.py pack

# Configure new server
python server_transfer_toolkit.py config

# Transfer to new server
./transfer.sh
```

## Maintenance Tasks

```bash
# Clean up old logs (older than 7 days)
find . -name "*.log" -type f -mtime +7 -delete

# Clean up temporary files
find . -name "*.tmp" -type f -delete

# Update system dependencies
pip install -r requirements.txt --upgrade
```

## Monitoring

```bash
# Monitor CPU and memory usage
python hardware_monitor.py

# Generate training analytics
python analyze_training.py

# Show training dashboard on port 5000
python monitoring_web.py
```

## Onboarding Wizard

```bash
# Run onboarding wizard
python run_onboarding_wizard.py

# Run web-based wizard on port 5060
python web_onboarding_wizard.py --port 5060
```

## Need More Help?

Refer to the comprehensive documentation:

- README.md - General information
- DEPLOYMENT_INSTRUCTIONS.md - Deployment guide
- README_SERVER_TRANSFER.md - Server transfer guide
- TENSORBOARD_AND_FUNCTIONS_GUIDE.md - Advanced monitoring