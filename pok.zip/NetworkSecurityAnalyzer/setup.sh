#!/bin/bash
echo "Installing Poker AI System..."
echo "This script will install Python dependencies and initialize the database."

# Install dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Create necessary directories
mkdir -p models/
mkdir -p logs/
mkdir -p poker/logs/
mkdir -p poker/models/

# Initialize database
echo "Initializing database..."
python create_new_admin.py --username admin --password admin --email admin@example.com

echo "Installation complete! You can now run the system with:"
echo "python main.py"
