#!/usr/bin/env python3
"""
Server Configuration Helper

This module provides functions to detect server hardware specifications
and configure training parameters optimally.
"""

import os
import logging
import psutil
import time
from typing import Dict, Any, Tuple, Optional, Union, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Conditional imports for GPU detection, handle them safely
# Try to import torch but don't fail if not available
HAS_TORCH = False
try:
    import torch
    if hasattr(torch, 'cuda') and hasattr(torch.cuda, 'is_available'):
        HAS_TORCH = True
except (ImportError, Exception) as e:
    logger.debug(f"Torch import failed: {e}")

# Try to import pynvml but don't fail if not available
HAS_NVIDIA = False
try:
    import pynvml
    pynvml.nvmlInit()
    HAS_NVIDIA = True
except (ImportError, Exception) as e:
    logger.debug(f"PYNVML import failed: {e}")

def get_server_specs() -> Dict[str, Any]:
    """
    Detect server hardware specifications.
    
    Returns:
        Dict with CPU, memory, and GPU specifications
    """
    specs = {}
    
    # Get CPU info
    try:
        cpu_count = psutil.cpu_count()
        cpu_count_physical = psutil.cpu_count(logical=False) or 1
        
        specs['cpu'] = {
            'total_cores': cpu_count,
            'physical_cores': cpu_count_physical
        }
    except Exception as e:
        logger.error(f"Error getting CPU specs: {e}")
        specs['cpu'] = {
            'total_cores': 4,  # Default fallback
            'physical_cores': 2  # Default fallback
        }
    
    # Get memory info
    try:
        mem = psutil.virtual_memory()
        specs['memory'] = {
            'total_gb': mem.total / (1024 ** 3),
            'available_gb': mem.available / (1024 ** 3)
        }
    except Exception as e:
        logger.error(f"Error getting memory specs: {e}")
        specs['memory'] = {
            'total_gb': 8,  # Default fallback
            'available_gb': 4  # Default fallback
        }
    
    # Get GPU info with defensive programming
    specs['gpu'] = {
        'available': False,
        'count': 0,
        'devices': []
    }
    
    # Only check for CUDA if torch was successfully imported
    if HAS_TORCH:
        try:
            # Check if CUDA is available, using hasattr for safety
            if hasattr(torch, 'cuda') and hasattr(torch.cuda, 'is_available') and torch.cuda.is_available():
                specs['gpu']['available'] = True
                
                # Get device count safely
                if hasattr(torch.cuda, 'device_count'):
                    specs['gpu']['count'] = torch.cuda.device_count()
                
                # Only try NVIDIA specific queries if pynvml was successfully imported
                if HAS_NVIDIA:
                    try:
                        # Get NVIDIA device information
                        device_count = pynvml.nvmlDeviceGetCount()
                        devices = []
                        
                        for i in range(device_count):
                            try:
                                handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                                name = pynvml.nvmlDeviceGetName(handle)
                                # Safely handle name decoding
                                if isinstance(name, bytes):
                                    name = name.decode('utf-8', errors='replace')
                                mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                                
                                devices.append({
                                    'index': i,
                                    'name': name,
                                    'total_memory_gb': mem_info.total / (1024 ** 3)
                                })
                            except Exception as e:
                                logger.warning(f"Error getting info for GPU {i}: {e}")
                                # Add a placeholder device with limited info
                                devices.append({
                                    'index': i,
                                    'name': f"GPU {i}",
                                    'total_memory_gb': 0
                                })
                        
                        if devices:
                            specs['gpu']['devices'] = devices
                    except Exception as e:
                        logger.warning(f"Error getting detailed GPU specs with pynvml: {e}")
        except Exception as e:
            logger.warning(f"Error checking GPU availability: {e}")
    
    return specs

def get_recommended_psro_config() -> Dict[str, Any]:
    """
    Get recommended PSRO training configuration based on server specs.
    
    Returns:
        Dict with recommended training parameters
    """
    specs = get_server_specs()
    config = {}
    
    # Print server specs
    logger.info("Server Specifications:")
    logger.info(f"CPU: {specs['cpu']['physical_cores']} physical cores, {specs['cpu']['total_cores']} logical cores")
    logger.info(f"Memory: {specs['memory']['total_gb']:.2f} GB total, {specs['memory']['available_gb']:.2f} GB available")
    
    if specs['gpu']['available']:
        for device in specs['gpu']['devices']:
            logger.info(f"GPU {device['index']}: {device['name']} with {device['total_memory_gb']:.2f} GB memory")
    else:
        logger.info("No GPU detected, using CPU for training")
    
    # CPU-based configuration
    total_cores = specs['cpu']['total_cores']
    physical_cores = specs['cpu']['physical_cores']
    
    # Number of workers - ultra conservative to prevent OOM errors
    config['num_workers'] = 1  # Fixed at 1 worker only for extreme stability
    
    # Memory-based configuration
    total_memory_gb = specs['memory']['total_gb']
    available_memory_gb = specs['memory']['available_gb']
    
    # Calculate batch size based on available memory - ULTRA conservative
    # Use a higher estimate for memory per sample as a safety margin
    memory_per_sample_mb = 40  # Double the memory per sample for extreme safety
    
    # Use only 20% of available memory to leave plenty of headroom
    max_samples = int((available_memory_gb * 0.2 * 1024) / memory_per_sample_mb)  
    
    # Batch size should be a power of 2 for better performance
    # Starting with tiny batch size to be ultra-conservative
    batch_size = 1
    
    # Cap max batch size at 64 (significantly reduced from 128)
    while batch_size * 2 <= max_samples and batch_size * 2 <= 64:
        batch_size *= 2
    
    # ULTRA conservative batch size - minimum 8, maximum 64
    # This is far lower than previous settings (128 max) for extreme stability
    config['batch_size'] = max(8, min(batch_size, 64))
    
    logger.info(f"CRITICAL: Using ultra-conservative batch size {config['batch_size']} for memory stability")
    
    # Force CPU-only mode for ultimate stability
    config['use_gpu'] = False
    config['num_gpus'] = 0
    
    # Log the decision to force CPU-only mode
    logger.info("CRITICAL: Forcing CPU-only mode to prevent memory issues")
    
    # Ray-specific configuration to improve stability
    # For PSRO training with limited resources, we need to tune Ray parameters
    # to prevent GCS connection failures and memory issues
    
    # For Replit and other constrained environments, use extremely conservative settings
    config['ray_config'] = {
        # Always use local mode for stability
        'local_mode': True,
        # Disable dashboard completely
        'include_dashboard': False,
        'ignore_reinit_error': True,
        # Very limited memory allocation
        '_memory': min(int(available_memory_gb * 0.10 * 1e9), 2 * 1e9),  # Only 10% of memory, max 2GB
        '_redis_max_memory': int(0.005 * available_memory_gb * 1e9),  # Just 0.5% for Redis
        # Ultra-conservative system settings for OpenSpiel + Ray stability
        '_system_config': {
            "automatic_object_spilling_enabled": True,
            "object_spilling_threshold": 0.5,  # Spill at just 50% usage
            "object_timeout_milliseconds": 1000,
            "ping_gcs_rpc_server_max_retries": 1,
            "gcs_server_request_timeout_seconds": 1,
            "task_retry_delay_ms": 500,
            "raylet_startup_token_retries": 1,
            "max_direct_call_object_size": 500,  # Even smaller direct call objects
            "enable_timeline": False,
            "memory_monitor_refresh_ms": 100,  # More frequent memory monitoring
            "plasma_unlimited": False
        }
    }
    
    # For very large servers, can be somewhat less conservative
    if physical_cores >= 8 and available_memory_gb >= 64:
        config['ray_config']['local_mode'] = False  # Use distributed mode for large servers
        config['ray_config']['_memory'] = int(available_memory_gb * 0.25 * 1e9)  # 25% of memory
        config['ray_config']['_system_config']["object_timeout_milliseconds"] = 5000  # Longer timeout
    
    # For low memory systems, be extremely conservative
    if available_memory_gb < 8:
        config['ray_config']['local_mode'] = True  # Force local mode
        config['num_workers'] = min(2, config['num_workers'])  # Limit workers
        config['ray_config']['_memory'] = int(available_memory_gb * 0.1 * 1e9)  # Only 10% of memory
    
    # Print recommended configuration
    logger.info("Recommended PSRO Configuration:")
    logger.info(f"Number of Workers: {config['num_workers']}")
    logger.info(f"Batch Size: {config['batch_size']}")
    logger.info(f"Use GPU: {config['use_gpu']}")
    
    return config

if __name__ == "__main__":
    # When run directly, print server specs and recommended configuration
    specs = get_server_specs()
    config = get_recommended_psro_config()
    
    print("\nServer Specifications Summary:")
    print(f"CPU: {specs['cpu']['physical_cores']} physical cores, {specs['cpu']['total_cores']} logical cores")
    print(f"Memory: {specs['memory']['total_gb']:.2f} GB total, {specs['memory']['available_gb']:.2f} GB available")
    
    print("\nRecommended PSRO Configuration:")
    print(f"Number of Workers: {config['num_workers']}")
    print(f"Batch Size: {config['batch_size']}")
    print(f"Use GPU: {config['use_gpu']}")