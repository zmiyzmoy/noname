import os
import time
import logging
import numpy as np
import torch
import json
from typing import Dict, List, Optional, Tuple, Union, Any
from collections import defaultdict

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)

class OpponentModel:
    """
    A comprehensive opponent modeling system for poker AI.
    
    This class tracks, analyzes, and predicts opponent behaviors to help the AI
    adapt its strategy against different playing styles.
    """
    
    # Define opponent archetypes and their characteristic ranges
    OPPONENT_ARCHETYPES = {
        'tight_passive': {
            'vpip_range': (5, 20),
            'pfr_range': (3, 15),
            'af_range': (0.5, 1.8),
            'description': 'Plays few hands and rarely raises'
        },
        'tight_aggressive': {
            'vpip_range': (10, 25),
            'pfr_range': (8, 23),
            'af_range': (2.0, 4.5),
            'description': 'Plays few hands but plays them aggressively'
        },
        'loose_passive': {
            'vpip_range': (30, 60),
            'pfr_range': (5, 20),
            'af_range': (0.5, 2.0),
            'description': 'Plays many hands but calls frequently'
        },
        'loose_aggressive': {
            'vpip_range': (28, 60),
            'pfr_range': (22, 50),
            'af_range': (2.0, 5.0),
            'description': 'Plays many hands and plays them aggressively'
        },
        'maniac': {
            'vpip_range': (50, 100),
            'pfr_range': (40, 100),
            'af_range': (4.0, 10.0),
            'description': 'Extremely aggressive, plays most hands and raises frequently'
        },
        'rock': {
            'vpip_range': (5, 15),
            'pfr_range': (3, 10),
            'af_range': (1.0, 2.0),
            'description': 'Extremely tight, plays only premium hands'
        },
        'calling_station': {
            'vpip_range': (25, 60),
            'pfr_range': (5, 15),
            'af_range': (0.5, 1.2),
            'description': 'Calls frequently and rarely folds to bets'
        },
        'nit': {
            'vpip_range': (5, 12),
            'pfr_range': (4, 10),
            'af_range': (1.5, 3.0),
            'description': 'Plays very few hands, very risk-averse'
        }
    }
    
    # Street-specific tendencies categories
    STREET_CATEGORIES = {
        'preflop_raiser': {'pfr': 0.25},
        'flop_cbettor': {'cbet_flop': 0.65},
        'turn_barreler': {'barrel_turn': 0.45},
        'river_bluffer': {'bluff_river': 0.30},
        'check_raiser': {'check_raise_freq': 0.15},
        'float_bettor': {'float_bet_freq': 0.25},
        'three_bettor': {'three_bet': 0.10},
        'four_bettor': {'four_bet': 0.05}
    }
    
    # Special exploit categories
    EXPLOIT_CATEGORIES = {
        'folds_to_3bet': {'fold_to_3bet': 0.65},
        'folds_to_cbet': {'fold_to_cbet': 0.60},
        'calls_river_bluffs': {'call_river': 0.65},
        'overplays_draws': {'draw_aggression': 0.70},
        'passive_with_monsters': {'slow_play_freq': 0.60},
        'position_aware': {'positional_awareness': 0.70}
    }
    
    def __init__(self, model_file: str = None):
        """
        Initialize the opponent model.
        
        Args:
            model_file: Path to a previously saved model file (optional)
        """
        # Basic frequency-based stats for each opponent
        self.player_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip_count': 0,
            'pfr_count': 0,
            'aggression_actions': 0,
            'passive_actions': 0,
            'position_actions': {pos: {'count': 0, 'vpip': 0, 'pfr': 0} for pos in range(6)},
            'three_bet_opportunities': 0,
            'three_bet_count': 0,
            'cbet_opportunities': 0,
            'cbet_count': 0,
            'fold_to_3bet_opportunities': 0,
            'fold_to_3bet_count': 0,
            'fold_to_cbet_opportunities': 0,
            'fold_to_cbet_count': 0,
            'check_raise_opportunities': 0,
            'check_raise_count': 0,
            'street_actions': {street: {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0} 
                               for street in range(4)},  # 0=preflop, 1=flop, 2=turn, 3=river
            'board_texture_actions': {
                'draw_heavy': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'static': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'paired': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'high_card': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0}
            },
            'stack_depth_actions': {
                'short': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'medium': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'deep': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0}
            },
            'showdown_stats': {
                'went_to_showdown': 0,
                'won_at_showdown': 0,
                'bluff_caught': 0,
                'value_bet_paid': 0
            },
            'last_seen': time.time(),
            'hand_history': [],  # Store recent hand histories
            'archetypes': {},  # Store archetype classification with confidence scores
            'exploit_patterns': {},  # Store specific patterns that can be exploited
            'adaptation_history': []  # Track adaptations made against this opponent
        })
        
        # Dynamic adaptation weights for strategy adjustment
        self.adaptation_weights = {
            'base_strategy': 0.6,  # Weight for the base GTO-ish strategy
            'counter_strategy': 0.4,  # Weight for opponent-specific counter strategy
            'explore_rate': 0.1,  # Exploration rate to gather new information
            'adaptation_rate': 0.05  # Rate at which we adapt to new observations
        }
        
        # Counter-strategies for each archetype
        self.counter_strategies = {
            'tight_passive': {
                'steal_blinds': 1.3,  # Increase blind stealing frequency
                'bet_sizing': 0.8,    # Smaller bet sizing to get calls
                'bluff_frequency': 0.7 # Reduce bluffing
            },
            'tight_aggressive': {
                'call_3bets': 1.2,    # Call 3-bets more often
                'trap_frequency': 1.4, # Increase trapping
                'bluff_frequency': 0.6 # Reduce bluffing
            },
            'loose_passive': {
                'value_bet_thinner': 1.5, # Value bet thinner
                'bet_sizing': 1.2,       # Larger bet sizing
                'bluff_frequency': 0.5    # Reduce bluffing
            },
            'loose_aggressive': {
                'tighten_range': 1.3,    # Tighten opening ranges
                'trap_frequency': 1.5,    # Increase trapping
                'call_down_lighter': 1.3  # Call down lighter
            },
            'maniac': {
                'tighten_range': 1.5,    # Tighten opening ranges significantly
                'trap_frequency': 1.7,    # Increase trapping significantly
                'bluff_frequency': 0.3    # Reduce bluffing significantly
            },
            'rock': {
                'steal_blinds': 1.5,     # Increase blind stealing frequency significantly
                'bluff_frequency': 1.3,   # Increase bluffing
                'fold_to_aggression': 1.4 # Fold to their rare aggression
            },
            'calling_station': {
                'value_bet_thinner': 1.7, # Value bet much thinner
                'bet_sizing': 1.3,        # Larger bet sizing
                'bluff_frequency': 0.2     # Reduce bluffing significantly
            },
            'nit': {
                'steal_blinds': 1.6,      # Increase blind stealing frequency significantly
                'iso_raise': 1.4,         # Isolate them more
                'bluff_frequency': 1.4     # Increase bluffing
            }
        }
        
        # Neural network-based prediction models (placeholder for now)
        self.nn_models = {}
        
        # Load from file if provided
        if model_file and os.path.exists(model_file):
            self.load_model(model_file)
            
        logging.info("OpponentModel initialized")
    
    def update_opponent_stats(self, player_id: int, action_type: str, 
                             position: int = 0, street: int = 0, 
                             is_raise_opportunity: bool = False,
                             is_3bet_opportunity: bool = False, 
                             is_cbet_opportunity: bool = False,
                             is_check_raise_opportunity: bool = False,
                             stack_depth: str = 'medium',
                             board_texture: str = 'high_card',
                             went_to_showdown: bool = False,
                             won_at_showdown: bool = False,
                             was_bluffing: bool = False,
                             had_strong_hand: bool = False,
                             stack_to_pot: float = 0,
                             bet_sizing: float = 0) -> None:
        """
        Update opponent statistics based on observed actions.
        
        Args:
            player_id: Unique identifier for the player
            action_type: Type of action (bet, call, raise, fold, check)
            position: Table position (0-5, where 0 is SB, 1 is BB, etc.)
            street: Betting street (0=preflop, 1=flop, 2=turn, 3=river)
            is_raise_opportunity: Whether the player had an opportunity to raise
            is_3bet_opportunity: Whether this was a 3-bet opportunity
            is_cbet_opportunity: Whether this was a continuation bet opportunity
            is_check_raise_opportunity: Whether this was a check-raise opportunity
            stack_depth: Relative stack depth (short, medium, deep)
            board_texture: Texture of the board (draw_heavy, static, paired, high_card)
            went_to_showdown: Whether the hand went to showdown
            won_at_showdown: Whether the player won at showdown
            was_bluffing: Whether the player was bluffing (if known)
            had_strong_hand: Whether the player had a strong hand (if known)
            stack_to_pot: Stack-to-pot ratio
            bet_sizing: Bet size relative to pot (0.5 = half pot, 1.0 = pot-sized)
        """
        stats = self.player_stats[player_id]
        
        # Update basic stats
        stats['hands_played'] += 1
        stats['last_seen'] = time.time()
        
        # Update position stats
        stats['position_actions'][position]['count'] += 1
        
        # Update street-specific stats
        stats['street_actions'][street]['opportunity'] += 1
        stats['street_actions'][street][action_type.lower()] += 1
        
        # Update board texture stats
        stats['board_texture_actions'][board_texture]['opportunity'] += 1
        stats['board_texture_actions'][board_texture][action_type.lower()] += 1
        
        # Update stack depth stats
        stats['stack_depth_actions'][stack_depth]['opportunity'] += 1
        stats['stack_depth_actions'][stack_depth][action_type.lower()] += 1
        
        # Update VPIP (Voluntarily Put $ In Pot) - calls or raises preflop
        if street == 0 and (action_type.lower() == 'call' or action_type.lower() == 'raise'):
            stats['vpip_count'] += 1
            stats['position_actions'][position]['vpip'] += 1
        
        # Update PFR (Preflop Raise) - raises preflop
        if street == 0 and action_type.lower() == 'raise':
            stats['pfr_count'] += 1
            stats['position_actions'][position]['pfr'] += 1
        
        # Update aggression stats
        if action_type.lower() in ['bet', 'raise']:
            stats['aggression_actions'] += 1
        elif action_type.lower() in ['call', 'check']:
            stats['passive_actions'] += 1
        
        # Update 3-bet stats
        if is_3bet_opportunity:
            stats['three_bet_opportunities'] += 1
            if action_type.lower() == 'raise':
                stats['three_bet_count'] += 1
        
        # Update c-bet stats
        if is_cbet_opportunity:
            stats['cbet_opportunities'] += 1
            if action_type.lower() in ['bet', 'raise']:
                stats['cbet_count'] += 1
        
        # Update fold to 3-bet stats
        if is_3bet_opportunity and action_type.lower() == 'fold':
            stats['fold_to_3bet_opportunities'] += 1
            stats['fold_to_3bet_count'] += 1
        
        # Update fold to c-bet stats
        if is_cbet_opportunity and action_type.lower() == 'fold':
            stats['fold_to_cbet_opportunities'] += 1
            stats['fold_to_cbet_count'] += 1
        
        # Update check-raise stats
        if is_check_raise_opportunity:
            stats['check_raise_opportunities'] += 1
            if action_type.lower() == 'raise':
                stats['check_raise_count'] += 1
        
        # Update showdown stats
        if went_to_showdown:
            stats['showdown_stats']['went_to_showdown'] += 1
            if won_at_showdown:
                stats['showdown_stats']['won_at_showdown'] += 1
            if was_bluffing and not won_at_showdown:
                stats['showdown_stats']['bluff_caught'] += 1
            if had_strong_hand and won_at_showdown:
                stats['showdown_stats']['value_bet_paid'] += 1
        
        # Recalculate archetypes after sufficient data
        if stats['hands_played'] >= 20:
            self._classify_opponent(player_id)
    
    def get_opponent_stats(self, player_id: int) -> Dict[str, Any]:
        """
        Get comprehensive stats for a specific opponent.
        
        Args:
            player_id: Unique identifier for the player
            
        Returns:
            Dictionary containing opponent statistics
        """
        if player_id not in self.player_stats:
            return {}
        
        stats = self.player_stats[player_id]
        hands_played = max(1, stats['hands_played'])  # Avoid division by zero
        
        # Calculate derived statistics
        vpip = stats['vpip_count'] / hands_played
        pfr = stats['pfr_count'] / hands_played
        
        # Calculate aggression factor (AF)
        passive_actions = max(1, stats['passive_actions'])  # Avoid division by zero
        af = stats['aggression_actions'] / passive_actions
        
        # Calculate 3-bet percentage
        three_bet_opportunities = max(1, stats['three_bet_opportunities'])
        three_bet = stats['three_bet_count'] / three_bet_opportunities
        
        # Calculate c-bet percentage
        cbet_opportunities = max(1, stats['cbet_opportunities'])
        cbet = stats['cbet_count'] / cbet_opportunities
        
        # Calculate fold to 3-bet percentage
        fold_to_3bet_opportunities = max(1, stats['fold_to_3bet_opportunities'])
        fold_to_3bet = stats['fold_to_3bet_count'] / fold_to_3bet_opportunities
        
        # Calculate fold to c-bet percentage
        fold_to_cbet_opportunities = max(1, stats['fold_to_cbet_opportunities'])
        fold_to_cbet = stats['fold_to_cbet_count'] / fold_to_cbet_opportunities
        
        # Calculate check-raise frequency
        check_raise_opportunities = max(1, stats['check_raise_opportunities'])
        check_raise_freq = stats['check_raise_count'] / check_raise_opportunities
        
        # Calculate won at showdown percentage
        went_to_showdown = max(1, stats['showdown_stats']['went_to_showdown'])
        won_at_showdown = stats['showdown_stats']['won_at_showdown'] / went_to_showdown
        
        # Calculate street-specific tendencies
        street_tendencies = {}
        for street in range(4):
            # Ensure the street key exists
            if street not in stats['street_actions']:
                # Initialize this street if it doesn't exist
                stats['street_actions'][street] = {
                    'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 1
                }
            
            # Get opportunity count, ensuring it's at least 1 to avoid division by zero
            opp = max(1, stats['street_actions'][street]['opportunity'])
            
            # Calculate frequencies with safe division
            street_tendencies[f"street_{street}"] = {
                'bet_freq': stats['street_actions'][street]['bet'] / opp,
                'call_freq': stats['street_actions'][street]['call'] / opp,
                'raise_freq': stats['street_actions'][street]['raise'] / opp,
                'fold_freq': stats['street_actions'][street]['fold'] / opp,
                'check_freq': stats['street_actions'][street]['check'] / opp
            }
        
        # Calculate board texture tendencies
        texture_tendencies = {}
        for texture in ['draw_heavy', 'static', 'paired', 'high_card']:
            # Ensure the texture key exists with proper initialization
            if texture not in stats['board_texture_actions']:
                stats['board_texture_actions'][texture] = {
                    'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 1
                }
            
            # Get opportunity count with safe division
            opp = max(1, stats['board_texture_actions'][texture]['opportunity'])
            
            # Calculate frequencies
            texture_tendencies[texture] = {
                'bet_freq': stats['board_texture_actions'][texture]['bet'] / opp,
                'call_freq': stats['board_texture_actions'][texture]['call'] / opp,
                'raise_freq': stats['board_texture_actions'][texture]['raise'] / opp,
                'fold_freq': stats['board_texture_actions'][texture]['fold'] / opp,
                'check_freq': stats['board_texture_actions'][texture]['check'] / opp
            }
        
        # Calculate stack depth tendencies
        depth_tendencies = {}
        for depth in ['short', 'medium', 'deep']:
            # Ensure the depth key exists with proper initialization
            if depth not in stats['stack_depth_actions']:
                stats['stack_depth_actions'][depth] = {
                    'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 1
                }
                
            # Get opportunity count with safe division
            opp = max(1, stats['stack_depth_actions'][depth]['opportunity'])
            
            # Calculate frequencies
            depth_tendencies[depth] = {
                'bet_freq': stats['stack_depth_actions'][depth]['bet'] / opp,
                'call_freq': stats['stack_depth_actions'][depth]['call'] / opp,
                'raise_freq': stats['stack_depth_actions'][depth]['raise'] / opp,
                'fold_freq': stats['stack_depth_actions'][depth]['fold'] / opp,
                'check_freq': stats['stack_depth_actions'][depth]['check'] / opp
            }
        
        # Calculate position-specific tendencies
        position_tendencies = {}
        for pos in range(6):
            # Ensure the position key exists with proper initialization
            if pos not in stats['position_actions']:
                stats['position_actions'][pos] = {'count': 1, 'vpip': 0, 'pfr': 0}
                
            # Get count with safe division
            count = max(1, stats['position_actions'][pos]['count'])
            
            # Calculate frequencies
            position_tendencies[f"pos_{pos}"] = {
                'vpip': stats['position_actions'][pos]['vpip'] / count,
                'pfr': stats['position_actions'][pos]['pfr'] / count
            }
        
        # Return comprehensive stats
        return {
            'hands_played': hands_played,
            'vpip': vpip,
            'pfr': pfr,
            'af': af,
            'three_bet': three_bet,
            'cbet': cbet,
            'fold_to_3bet': fold_to_3bet,
            'fold_to_cbet': fold_to_cbet,
            'check_raise_freq': check_raise_freq,
            'won_at_showdown': won_at_showdown,
            'street_tendencies': street_tendencies,
            'texture_tendencies': texture_tendencies,
            'depth_tendencies': depth_tendencies,
            'position_tendencies': position_tendencies,
            'archetypes': stats.get('archetypes', {}),
            'exploit_patterns': stats.get('exploit_patterns', {})
        }
    
    def _classify_opponent(self, player_id: int) -> None:
        """
        Classify an opponent into different archetypes based on their stats.
        
        Args:
            player_id: Unique identifier for the player
        """
        if player_id not in self.player_stats:
            return
        
        stats = self.get_opponent_stats(player_id)
        if not stats or stats['hands_played'] < 20:
            return  # Not enough data for reliable classification
        
        # Calculate archetype fit and confidence for each archetype
        archetype_confidence = {}
        
        for archetype, criteria in self.OPPONENT_ARCHETYPES.items():
            # Check if vpip is within the archetype range
            vpip_min, vpip_max = criteria['vpip_range']
            vpip_fit = 0
            if vpip_min <= stats['vpip'] * 100 <= vpip_max:
                vpip_fit = 1 - abs((stats['vpip'] * 100 - (vpip_min + vpip_max) / 2)) / ((vpip_max - vpip_min) / 2)
            
            # Check if pfr is within the archetype range
            pfr_min, pfr_max = criteria['pfr_range']
            pfr_fit = 0
            if pfr_min <= stats['pfr'] * 100 <= pfr_max:
                pfr_fit = 1 - abs((stats['pfr'] * 100 - (pfr_min + pfr_max) / 2)) / ((pfr_max - pfr_min) / 2)
            
            # Check if af is within the archetype range
            af_min, af_max = criteria['af_range']
            af_fit = 0
            if af_min <= stats['af'] <= af_max:
                af_fit = 1 - abs((stats['af'] - (af_min + af_max) / 2)) / ((af_max - af_min) / 2)
            
            # Calculate overall confidence (weighted average)
            confidence = (0.4 * vpip_fit + 0.4 * pfr_fit + 0.2 * af_fit)
            if confidence > 0:
                archetype_confidence[archetype] = confidence
        
        # Identify strongest archetypes
        strongest_archetypes = sorted(archetype_confidence.items(), key=lambda x: x[1], reverse=True)
        
        # Store archetypes with confidence > 0.3
        archetypes = {archetype: conf for archetype, conf in strongest_archetypes if conf > 0.3}
        
        # Store archetype classification
        self.player_stats[player_id]['archetypes'] = archetypes
        
        # Identify exploit patterns
        self._identify_exploit_patterns(player_id, stats)
    
    def _identify_exploit_patterns(self, player_id: int, stats: Dict[str, Any]) -> None:
        """
        Identify specific patterns that can be exploited.
        
        Args:
            player_id: Unique identifier for the player
            stats: Calculated statistics for the player
        """
        exploit_patterns = {}
        
        # Check for each exploit category
        for category, criteria in self.EXPLOIT_CATEGORIES.items():
            for stat_name, threshold in criteria.items():
                if stat_name in stats and stats[stat_name] > threshold:
                    exploit_patterns[category] = stats[stat_name]
        
        # Check for street-specific patterns
        if 'street_tendencies' in stats:
            # Preflop patterns
            preflop = stats['street_tendencies'].get('street_0', {})
            if preflop.get('fold_freq', 0) > 0.7:
                exploit_patterns['preflop_overfolder'] = preflop['fold_freq']
            
            # Flop patterns
            flop = stats['street_tendencies'].get('street_1', {})
            if flop.get('bet_freq', 0) > 0.8:
                exploit_patterns['flop_overbettor'] = flop['bet_freq']
            if flop.get('check_freq', 0) > 0.8:
                exploit_patterns['flop_overchecker'] = flop['check_freq']
            
            # Turn patterns
            turn = stats['street_tendencies'].get('street_2', {})
            if turn.get('fold_freq', 0) > 0.6:
                exploit_patterns['turn_folder'] = turn['fold_freq']
            
            # River patterns
            river = stats['street_tendencies'].get('street_3', {})
            if river.get('call_freq', 0) > 0.7:
                exploit_patterns['river_calling_station'] = river['call_freq']
            if river.get('bet_freq', 0) > 0.7:
                exploit_patterns['river_bluffer'] = river['bet_freq']
        
        # Store exploit patterns
        self.player_stats[player_id]['exploit_patterns'] = exploit_patterns
    
    def get_counter_strategy(self, player_id: int) -> Dict[str, float]:
        """
        Get a counter-strategy for a specific opponent.
        
        Args:
            player_id: Unique identifier for the player
            
        Returns:
            Dictionary containing counter-strategy adjustments
        """
        if player_id not in self.player_stats:
            return {}
        
        stats = self.player_stats[player_id]
        archetypes = stats.get('archetypes', {})
        exploit_patterns = stats.get('exploit_patterns', {})
        
        # Initialize counter-strategy with default values
        counter_strategy = {
            'steal_blinds': 1.0,
            'bet_sizing': 1.0,
            'bluff_frequency': 1.0,
            'call_3bets': 1.0,
            'trap_frequency': 1.0,
            'value_bet_thinner': 1.0,
            'tighten_range': 1.0,
            'fold_to_aggression': 1.0,
            'iso_raise': 1.0,
            'call_down_lighter': 1.0
        }
        
        # Apply weighted archetype-based adjustments
        total_confidence = sum(archetypes.values())
        if total_confidence > 0:
            for archetype, confidence in archetypes.items():
                weight = confidence / total_confidence
                if archetype in self.counter_strategies:
                    for key, value in self.counter_strategies[archetype].items():
                        counter_strategy[key] = counter_strategy.get(key, 1.0) + (value - 1.0) * weight
        
        # Apply exploit pattern adjustments
        for pattern, value in exploit_patterns.items():
            # Fold to 3-bet exploits
            if pattern == 'folds_to_3bet':
                counter_strategy['bluff_frequency'] *= 1.2  # Increase bluffing
                counter_strategy['bet_sizing'] *= 0.9      # Smaller bets
            
            # Fold to c-bet exploits
            elif pattern == 'folds_to_cbet':
                counter_strategy['bluff_frequency'] *= 1.3  # Increase bluffing
                counter_strategy['bet_sizing'] *= 0.85     # Even smaller bets
            
            # River calling station exploits
            elif pattern == 'river_calling_station':
                counter_strategy['value_bet_thinner'] *= 1.4  # Value bet much thinner
                counter_strategy['bluff_frequency'] *= 0.5    # Reduce bluffing
            
            # Turn folder exploits
            elif pattern == 'turn_folder':
                counter_strategy['bluff_frequency'] *= 1.4  # Increase bluffing
            
            # Preflop overfolder exploits
            elif pattern == 'preflop_overfolder':
                counter_strategy['steal_blinds'] *= 1.5  # Increase blind stealing
                counter_strategy['iso_raise'] *= 1.3     # Increase isolation raising
        
        # Ensure all values are reasonable (between 0.5 and 2.0)
        for key in counter_strategy:
            counter_strategy[key] = max(0.5, min(2.0, counter_strategy[key]))
        
        return counter_strategy
    
    def adjust_action_probabilities(self, player_id: int, action_probs: Union[Dict[int, float], int, Any], 
                                   is_preflop: bool = False, is_bluff: bool = False, 
                                   is_value_bet: bool = False, position: int = 0) -> Dict[int, float]:
        """
        Adjust action probabilities based on opponent modeling.
        
        Args:
            player_id: Unique identifier for the opponent
            action_probs: Original action probabilities from the base strategy (can be a dict, int, or other)
            is_preflop: Whether this is a preflop decision
            is_bluff: Whether we're considering a bluff
            is_value_bet: Whether we're considering a value bet
            position: Table position (0-5)
            
        Returns:
            Adjusted action probabilities (always a dictionary)
        """
        try:
            # Handle case where action_probs is an integer (single action)
            if isinstance(action_probs, int):
                logging.warning(f"Converting single action {action_probs} to dictionary")
                # Convert single action to a dictionary with 100% probability for that action
                return {action_probs: 1.0}
                
            # Handle cases where action_probs is not a dictionary
            if not isinstance(action_probs, dict):
                logging.warning(f"Invalid action_probs type: {type(action_probs)}. Creating uniform distribution.")
                # Create a uniform distribution over standard actions
                return {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25}
                
            # Make sure all keys are integers
            validated_action_probs = {}
            for k, v in action_probs.items():
                try:
                    key = int(k)
                    validated_action_probs[key] = float(v)
                except (ValueError, TypeError):
                    logging.warning(f"Invalid action key/value: {k}/{v}")
                    continue
                    
            # If no valid actions found, create a uniform distribution
            if not validated_action_probs:
                logging.warning("No valid actions found in action_probs. Creating uniform distribution.")
                return {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25}
                
            # Get counter-strategy for this opponent
            counter_strategy = self.get_counter_strategy(player_id)
            if not counter_strategy:
                return validated_action_probs  # No adjustments if no counter-strategy
            
            # Get current adaptation weights
            base_weight = self.adaptation_weights['base_strategy']
            counter_weight = self.adaptation_weights['counter_strategy']
            
            # Deep copy of action probabilities to avoid modifying the original
            adjusted_probs = dict(validated_action_probs)
            
            # Apply adjustments based on counter-strategy
            for action, prob in validated_action_probs.items():
                # Adjust fold probability
                if action == 0:  # Fold
                    if is_bluff or is_value_bet:
                        continue  # Don't adjust fold probability for bluffs or value bets
                    if 'fold_to_aggression' in counter_strategy:
                        adjusted_probs[action] = prob * (base_weight + counter_weight * counter_strategy['fold_to_aggression'])
                
                # Adjust call probability
                elif action == 1:  # Call
                    if is_preflop and 'call_3bets' in counter_strategy:
                        adjusted_probs[action] = prob * (base_weight + counter_weight * counter_strategy['call_3bets'])
                    if not is_preflop and 'call_down_lighter' in counter_strategy:
                        adjusted_probs[action] = prob * (base_weight + counter_weight * counter_strategy['call_down_lighter'])
                
                # Adjust raise/bet probability
                elif action in [2, 3]:  # Raise or bet
                    if is_preflop and position in [0, 1] and 'steal_blinds' in counter_strategy:
                        adjusted_probs[action] = prob * (base_weight + counter_weight * counter_strategy['steal_blinds'])
                    if is_bluff and 'bluff_frequency' in counter_strategy:
                        adjusted_probs[action] = prob * (base_weight + counter_weight * counter_strategy['bluff_frequency'])
                    if is_value_bet and 'value_bet_thinner' in counter_strategy:
                        adjusted_probs[action] = prob * (base_weight + counter_weight * counter_strategy['value_bet_thinner'])
            
            # Normalize probabilities to sum to 1
            total_prob = sum(adjusted_probs.values())
            if total_prob > 0:
                return {a: p / total_prob for a, p in adjusted_probs.items()}
            else:
                # If normalization fails, return uniform distribution
                logging.warning("Normalization failed. Returning uniform distribution.")
                return {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25}
        
        except Exception as e:
            logging.warning(f"Error in adjust_action_probabilities: {e}")
            # On exception, return a safe fallback that's always a dictionary
            return {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25}
    
    def update_adaptation_weights(self, win_loss: float) -> None:
        """
        Update adaptation weights based on success or failure.
        
        Args:
            win_loss: Positive for win, negative for loss
        """
        # If we're winning, increase counter-strategy weight
        if win_loss > 0:
            self.adaptation_weights['counter_strategy'] = min(0.8, 
                self.adaptation_weights['counter_strategy'] + self.adaptation_weights['adaptation_rate'])
            self.adaptation_weights['base_strategy'] = 1.0 - self.adaptation_weights['counter_strategy']
        
        # If we're losing, shift back toward base strategy
        else:
            self.adaptation_weights['counter_strategy'] = max(0.2, 
                self.adaptation_weights['counter_strategy'] - self.adaptation_weights['adaptation_rate'])
            self.adaptation_weights['base_strategy'] = 1.0 - self.adaptation_weights['counter_strategy']
    
    def save_model(self, file_path: str) -> None:
        """
        Save the opponent model to a file.
        
        Args:
            file_path: Path to save the model to
        """
        data = {
            'player_stats': {k: dict(v) for k, v in self.player_stats.items()},
            'adaptation_weights': self.adaptation_weights
        }
        
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        logging.info(f"Opponent model saved to {file_path}")
    
    def load_model(self, file_path: str) -> None:
        """
        Load the opponent model from a file.
        
        Args:
            file_path: Path to load the model from
        """
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Convert to defaultdict and update
        self.player_stats = defaultdict(lambda: {
            'hands_played': 0,
            'vpip_count': 0,
            'pfr_count': 0,
            'aggression_actions': 0,
            'passive_actions': 0,
            'position_actions': {pos: {'count': 0, 'vpip': 0, 'pfr': 0} for pos in range(6)},
            'three_bet_opportunities': 0,
            'three_bet_count': 0,
            'cbet_opportunities': 0,
            'cbet_count': 0,
            'fold_to_3bet_opportunities': 0,
            'fold_to_3bet_count': 0,
            'fold_to_cbet_opportunities': 0,
            'fold_to_cbet_count': 0,
            'check_raise_opportunities': 0,
            'check_raise_count': 0,
            'street_actions': {street: {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0} 
                              for street in range(4)},
            'board_texture_actions': {
                'draw_heavy': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'static': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'paired': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'high_card': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0}
            },
            'stack_depth_actions': {
                'short': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'medium': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0},
                'deep': {'bet': 0, 'call': 0, 'raise': 0, 'fold': 0, 'check': 0, 'opportunity': 0}
            },
            'showdown_stats': {
                'went_to_showdown': 0,
                'won_at_showdown': 0,
                'bluff_caught': 0,
                'value_bet_paid': 0
            },
            'last_seen': time.time(),
            'hand_history': [],
            'archetypes': {},
            'exploit_patterns': {},
            'adaptation_history': []
        })
        
        # Update player stats
        for k, v in data['player_stats'].items():
            self.player_stats[int(k)].update(v)
        
        # Update adaptation weights
        if 'adaptation_weights' in data:
            self.adaptation_weights.update(data['adaptation_weights'])
        
        logging.info(f"Opponent model loaded from {file_path}")


# Function to analyze board texture
def analyze_board_texture(board_cards: List[str]) -> Dict[str, float]:
    """
    Analyze poker board texture to identify various characteristics.
    
    Args:
        board_cards: List of card strings in format like ['Ah', '2c', 'Td']
        
    Returns:
        Dictionary with various board texture metrics
    """
    if not board_cards:
        return {'draw_heavy': 0, 'static': 1, 'paired': 0, 'high_card': 1}
    
    # Parse cards
    ranks = [card[0] for card in board_cards]
    suits = [card[1] for card in board_cards]
    
    # Translate face cards to values
    rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    numeric_ranks = [rank_values.get(r, 0) for r in ranks]
    
    # Check for paired board
    rank_counts = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    
    paired = any(count >= 2 for count in rank_counts.values())
    trips = any(count >= 3 for count in rank_counts.values())
    
    # Check for flush draw
    suit_counts = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1
    
    flush_draw = any(count >= 3 for count in suit_counts.values())
    
    # Check for straight draw
    sorted_ranks = sorted(set(numeric_ranks))
    straight_draw = False
    
    for i in range(len(sorted_ranks) - 2):
        # Check for 3 consecutive cards
        if sorted_ranks[i + 2] - sorted_ranks[i] <= 4:
            straight_draw = True
            break
    
    # Check for high cards
    high_cards = sum(1 for r in numeric_ranks if r >= 10)
    high_card_heavy = high_cards >= 2
    
    # Check for connectedness
    connected_cards = 0
    for i in range(len(numeric_ranks)):
        for j in range(i + 1, len(numeric_ranks)):
            if abs(numeric_ranks[i] - numeric_ranks[j]) <= 3:
                connected_cards += 1
    
    connectedness = connected_cards / max(1, (len(numeric_ranks) * (len(numeric_ranks) - 1) / 2))
    
    # Determine if the board is draw-heavy
    draw_heavy = flush_draw or straight_draw
    
    # Determine if the board is static (not much likely to change)
    static = not draw_heavy and not paired
    
    # Calculate overall metrics
    return {
        'draw_heavy': float(draw_heavy),
        'static': float(static),
        'paired': float(paired),
        'trips': float(trips),
        'high_card': float(high_card_heavy),
        'connectedness': float(connectedness),
        'flush_draw': float(flush_draw),
        'straight_draw': float(straight_draw)
    }


def categorize_stack_depth(stack: float, big_blind: float = 2.0) -> str:
    """
    Categorize stack depth based on big blinds.
    
    Args:
        stack: Stack size
        big_blind: Big blind amount
    
    Returns:
        Stack depth category: 'short', 'medium', or 'deep'
    """
    bb_stacks = stack / big_blind
    
    if bb_stacks < 30:
        return 'short'
    elif bb_stacks < 70:
        return 'medium'
    else:
        return 'deep'


def analyze_hand_strength(hole_cards: List[str], board_cards: List[str]) -> Dict[str, float]:
    """
    Analyze hand strength relative to the board.
    This is a simplified version - in a real system you'd use a more sophisticated hand evaluator.
    
    Args:
        hole_cards: List of card strings like ['Ah', 'Kd']
        board_cards: List of card strings like ['Qh', '2c', 'Td']
    
    Returns:
        Dictionary with hand strength metrics
    """
    # Simplified hand strength calculation
    # In a real system, you'd compute equity against ranges
    
    # Parse cards
    hole_ranks = [card[0] for card in hole_cards]
    hole_suits = [card[1] for card in hole_cards]
    board_ranks = [card[0] for card in board_cards] if board_cards else []
    board_suits = [card[1] for card in board_cards] if board_cards else []
    
    # Translate face cards to values
    rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    hole_values = [rank_values.get(r, 0) for r in hole_ranks]
    board_values = [rank_values.get(r, 0) for r in board_ranks]
    
    # Check for pocket pair
    pocket_pair = hole_ranks[0] == hole_ranks[1]
    
    # Check for high cards
    high_cards = sum(1 for r in hole_values if r >= 10)
    
    # Check for pair with board
    paired_board = any(hr == br for hr in hole_ranks for br in board_ranks)
    
    # Check for flush draw
    suited = hole_suits[0] == hole_suits[1]
    flush_draw = False
    if suited and board_cards:
        suit_match = sum(1 for s in board_suits if s == hole_suits[0])
        flush_draw = suit_match >= 2
    
    # Check for straight draw
    straight_draw = False
    if board_cards:
        all_values = sorted(hole_values + board_values)
        for i in range(len(all_values) - 3):
            if all_values[i + 3] - all_values[i] <= 4:
                straight_draw = True
                break
    
    # Calculate simplified hand strength (0-1)
    strength = 0.0
    
    # Premium pocket pairs
    if pocket_pair:
        if hole_values[0] >= 10:  # TT+
            strength = 0.8
        elif hole_values[0] >= 7:  # 77-99
            strength = 0.6
        else:  # 22-66
            strength = 0.4
    
    # High card hands
    elif not board_cards:  # Preflop
        if 14 in hole_values:  # Has an Ace
            if 13 in hole_values:  # AK
                strength = 0.75
            elif 12 in hole_values:  # AQ
                strength = 0.7
            elif 11 in hole_values:  # AJ
                strength = 0.65
            elif 10 in hole_values:  # AT
                strength = 0.6
            else:  # Ax
                strength = 0.5
        elif 13 in hole_values:  # Has a King
            if 12 in hole_values:  # KQ
                strength = 0.65
            elif 11 in hole_values:  # KJ
                strength = 0.6
            else:  # Kx
                strength = 0.45
        elif high_cards == 2:  # Two high cards
            strength = 0.55
        elif high_cards == 1:  # One high card
            strength = 0.4
        else:  # No high cards
            strength = 0.3
    
    # Postflop strength
    else:
        if paired_board:
            strength = 0.7
        elif flush_draw:
            strength = 0.5
        elif straight_draw:
            strength = 0.45
        elif high_cards == 2:
            strength = 0.4
        else:
            strength = 0.3
    
    # Return hand analysis
    return {
        'strength': strength,
        'pocket_pair': float(pocket_pair),
        'high_cards': float(high_cards),
        'paired_board': float(paired_board),
        'flush_draw': float(flush_draw),
        'straight_draw': float(straight_draw)
    }


def test_opponent_model():
    """Test the opponent modeling functionality."""
    print("Testing OpponentModel...")
    
    # Create a new opponent model
    model = OpponentModel()
    
    # Add some sample data
    player_id = 42
    
    # Simulate a tight aggressive player
    for _ in range(50):
        # Most hands they fold preflop
        model.update_opponent_stats(
            player_id=player_id,
            action_type='fold',
            position=2,
            street=0,
            is_raise_opportunity=True,
            stack_depth='medium',
            board_texture='high_card'
        )
    
    # But when they play, they're aggressive
    for _ in range(15):
        model.update_opponent_stats(
            player_id=player_id,
            action_type='raise',
            position=3,
            street=0,
            is_raise_opportunity=True,
            stack_depth='medium',
            board_texture='high_card'
        )
        
        model.update_opponent_stats(
            player_id=player_id,
            action_type='bet',
            position=3,
            street=1,
            is_cbet_opportunity=True,
            stack_depth='medium',
            board_texture='high_card'
        )
    
    # Often folds to 3-bets
    for _ in range(10):
        model.update_opponent_stats(
            player_id=player_id,
            action_type='fold',
            position=3,
            street=0,
            is_3bet_opportunity=True,
            stack_depth='medium',
            board_texture='high_card'
        )
    
    # Get stats and classification
    stats = model.get_opponent_stats(player_id)
    print(f"Player stats: VPIP={stats['vpip']:.2f}, PFR={stats['pfr']:.2f}, AF={stats['af']:.2f}")
    print(f"Archetypes: {stats['archetypes']}")
    print(f"Exploit patterns: {stats['exploit_patterns']}")
    
    # Get counter strategy
    counter_strategy = model.get_counter_strategy(player_id)
    print(f"Counter strategy: {counter_strategy}")
    
    # Test action adjustment
    original_probs = {0: 0.2, 1: 0.3, 2: 0.5}  # fold, call, raise
    adjusted_probs = model.adjust_action_probabilities(
        player_id=player_id,
        action_probs=original_probs,
        is_preflop=True,
        is_bluff=False,
        position=2
    )
    print(f"Original action probs: {original_probs}")
    print(f"Adjusted action probs: {adjusted_probs}")
    
    # Test board texture analysis
    board = ['Ah', 'Kh', '2h']
    texture = analyze_board_texture(board)
    print(f"Board {board} texture: {texture}")
    
    # Test hand strength analysis
    hole_cards = ['As', 'Ks']
    hand_strength = analyze_hand_strength(hole_cards, board)
    print(f"Hand {hole_cards} on board {board} strength: {hand_strength}")
    
    return True


if __name__ == "__main__":
    test_opponent_model()