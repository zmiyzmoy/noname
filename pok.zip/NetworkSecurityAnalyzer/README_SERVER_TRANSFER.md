# Poker AI System - Server Transfer Toolkit

This guide explains how to use the Server Transfer Toolkit to easily migrate your Poker AI system from one server to another.

## Overview

The Server Transfer Toolkit provides a streamlined process for transferring your Poker AI system to a new server, including:

1. Creating a deployment package with all necessary files
2. Configuring your target server
3. Transferring files to the target server
4. Deploying the system on the target server

## Requirements

### Source Server
- Poker AI system installed and working
- Access to terminal/command line
- Internet connection

### Target Server
- Python 3.8 or higher
- PostgreSQL database
- SSH access
- Sufficient disk space (at least 1GB)

## Usage

### Web Interface

The easiest way to use the Server Transfer Toolkit is through the web interface:

1. Access your Poker AI system web interface
2. Navigate to "Server Transfer" in the menu
3. Follow the step-by-step guide:
   - Create deployment package
   - Configure target server
   - Transfer and deploy

### Command Line

You can also use the toolkit from the command line:

```bash
# Create a deployment package
python server_transfer_toolkit.py pack

# Create configuration for the target server
python server_transfer_toolkit.py config

# Deploy the system on the target server (run on target)
python server_transfer_toolkit.py deploy

# Run the complete process
python server_transfer_toolkit.py all
```

## Step-by-Step Guide

### 1. Create Deployment Package

This step creates a compressed archive (.tar.gz) containing all necessary files for your Poker AI system.

**Through Web Interface:**
1. Go to Server Transfer page
2. Click "Create Package" button
3. Wait for the process to complete

**Through Command Line:**
```bash
python server_transfer_toolkit.py pack
```

The package will be created in the current directory with a name like `poker_ai_system_20250422123456.tar.gz`.

### 2. Configure Target Server

This step creates configuration files for the target server.

**Through Web Interface:**
1. Go to Server Transfer page
2. Click "Configure Server" button
3. Follow the prompts in the terminal window

**Through Command Line:**
```bash
python server_transfer_toolkit.py config
```

You'll be asked for:
- Database configuration (name, user, password, host, port)
- Server configuration (hostname, SSH username, SSH key path, deployment path)
- Web server configuration (port, domain name)
- Deployment preferences (systemd, nginx, virtual environment)

This creates:
- `transfer_config.json` - Configuration file
- `deploy.sh` - Deployment script for the target server
- `transfer.sh` - Script to transfer files to the target server

### 3. Transfer and Deploy

**From Source Server:**
1. Run the transfer script:
   ```bash
   ./transfer.sh
   ```
   This will:
   - Copy the deployment package to the target server
   - Copy the deployment script to the target server
   - Run the deployment script on the target server

**On Target Server (if transferring manually):**
1. Copy the deployment package and `deploy.sh` to the target server
2. Run the deployment script:
   ```bash
   ./deploy.sh
   ```

## Troubleshooting

### Common Issues

#### Permission Denied when Running Scripts
```bash
chmod +x transfer.sh deploy.sh
```

#### SSH Connection Issues
- Check that you can connect to the target server using SSH
- Verify the SSH key path and permissions
- Ensure the SSH key is added to the SSH agent:
  ```bash
  ssh-add ~/.ssh/your_key
  ```

#### Database Connection Issues
- Check that PostgreSQL is installed on the target server
- Verify database credentials
- Ensure the database user has appropriate permissions

#### Web Server Not Accessible
- Check that the port is open in the firewall
- Verify nginx configuration (if using nginx)
- Check systemd service status:
  ```bash
  sudo systemctl status poker-ai
  ```

### Logs

- `transfer_toolkit.log` - Logs from the transfer toolkit
- `deploy.log` - Logs from the deployment script (on target server)

## Best Practices

1. **Backup First**: Always back up your database before transferring
2. **Test in Staging**: If possible, test the transfer process on a staging server
3. **Verify Deployment**: After deployment, verify all features are working
4. **Keep Transfer Scripts**: Save the transfer scripts for future use
5. **Document Configuration**: Document your server configuration for reference

## Technical Details

The Server Transfer Toolkit performs the following operations:

1. **Package Creation**:
   - Identifies essential files and directories
   - Excludes unnecessary files (logs, temporary files, etc.)
   - Creates a compressed archive (.tar.gz)

2. **Configuration**:
   - Collects information about the target server
   - Creates a JSON configuration file
   - Generates shell scripts for transfer and deployment

3. **Deployment**:
   - Sets up the deployment directory
   - Installs required dependencies
   - Configures database connection
   - Sets up systemd service (optional)
   - Configures nginx (optional)

## Examples

### Minimal Transfer Example

```bash
# On source server
python server_transfer_toolkit.py pack
# Creates poker_ai_system_20250422123456.tar.gz

python server_transfer_toolkit.py config
# Enter minimal information: target hostname, database info

./transfer.sh
# Transfers to target server and runs deploy.sh
```

### Complete Transfer with Custom Settings

```bash
# On source server
python server_transfer_toolkit.py all
# Follow prompts for all configuration options
# Use custom deployment path, systemd, nginx, etc.
```

## Support

For issues or questions, please refer to the main Poker AI documentation or contact the developer.