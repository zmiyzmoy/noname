#!/usr/bin/env python3
"""
OpenSpiel Stability Test - Player ID=-4 Issue

This script tests the OpenSpiel universal_poker implementation 
to identify instances of player=-4 errors and verify that our fixes
are working properly.
"""

import os
import sys
import logging
import time
import pyspiel
import numpy as np
from collections import defaultdict

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def setup_game():
    """Set up the poker game environment."""
    logger.info("Setting up poker game environment")
    
    # Use the exact same game string as in config.py
    game_string = "universal_poker(betting=nolimit,numPlayers=6,numRounds=4,blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,stack=100 100 100 100 100 100,numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    
    logger.info(f"Loading game with string: {game_string}")
    return pyspiel.load_game(game_string)

def run_games(num_games=100, verbose=True):
    """Run poker games and track player ID=-4 errors.
    
    Args:
        num_games: Number of games to play
        verbose: Whether to print detailed logs
        
    Returns:
        Statistics about player ID=-4 occurrences
    """
    game = setup_game()
    stats = {
        "total_games": num_games,
        "player_minus_4_count": 0,
        "total_steps": 0,
        "terminal_states": 0,
        "errors": [],
        "chance_followed_by_negatives": 0,
        "specific_patterns": defaultdict(int)
    }
    
    logger.info(f"Starting test with {num_games} games")
    
    for game_num in range(num_games):
        if verbose and game_num % 10 == 0:
            logger.info(f"Starting game {game_num}/{num_games}")
        
        # Initialize a new game
        state = game.new_initial_state()
        step_count = 0
        terminal_reached = False
        last_player_was_chance = False
        chance_sequence_length = 0
        
        try:
            # Run the game until terminal state or error
            while not state.is_terminal():
                step_count += 1
                stats["total_steps"] += 1
                
                # Check for player = -4 which indicates a possible error
                current_player = state.current_player()
                
                # Track if we have a sequence of chance nodes followed by a negative player
                if last_player_was_chance and current_player < 0 and current_player != -1:
                    stats["chance_followed_by_negatives"] += 1
                    stats["specific_patterns"][f"chance_seq_{chance_sequence_length}_then_{current_player}"] += 1
                    logger.warning(f"Game {game_num}, Step {step_count}: Detected {chance_sequence_length} chance actions followed by player={current_player}")
                
                # Reset chance tracking
                if current_player != -1:
                    last_player_was_chance = False
                    chance_sequence_length = 0
                
                if current_player < 0 and current_player != -1:  # -1 is the chance player
                    stats["player_minus_4_count"] += 1
                    logger.warning(f"Game {game_num}, Step {step_count}: Detected player={current_player}")
                    
                    # Log additional state information for debugging
                    logger.warning(f"State terminal status: {state.is_terminal()}")
                    logger.warning(f"Game history: {state.history()}")

                    # Try special case handling for player -4
                    if current_player == -4:
                        logger.info("ROOT CAUSE FIX: Marking state with negative player ID as terminal")
                        terminal_reached = True
                        stats["terminal_states"] += 1
                        break
                
                # Take a legal action (for testing) - choose randomly
                if current_player >= 0:  # Regular player
                    legal_actions = state.legal_actions()
                    if not legal_actions:
                        logger.error(f"No legal actions for player {current_player}!")
                        break
                    
                    # Choose random action
                    action = np.random.choice(legal_actions)
                    if verbose:
                        logger.debug(f"Player {current_player} taking action: {action}")
                    state.apply_action(action)
                else:  # Chance player
                    legal_actions = state.legal_actions()
                    if not legal_actions:
                        logger.error(f"No legal chance actions!")
                        break
                    
                    # Update chance tracking
                    last_player_was_chance = True
                    chance_sequence_length += 1
                    
                    # Choose random chance action
                    action = np.random.choice(legal_actions)
                    if verbose:
                        logger.debug(f"Taking chance action: {action}")
                    state.apply_action(action)
                
                # Special check immediately after applying a chance action
                # This is where player ID=-4 often appears
                if last_player_was_chance:
                    next_player = state.current_player()
                    if next_player < 0 and next_player != -1:
                        logger.warning(f"Game {game_num}, Step {step_count}: After chance action, detected player={next_player}")
                        logger.warning(f"State history: {state.history()}")
                        stats["player_minus_4_count"] += 1
                        
                        # Check for terminal state anyway
                        if state.is_terminal():
                            logger.info("State is actually terminal despite player=-4")
                            terminal_reached = True
                            stats["terminal_states"] += 1
                            break
                        
                        # Apply ROOT CAUSE FIX
                        if next_player == -4:
                            logger.info("ROOT CAUSE FIX: Marking state with player ID=-4 as terminal")
                            terminal_reached = True
                            stats["terminal_states"] += 1
                            break
            
            if state.is_terminal() and not terminal_reached:
                stats["terminal_states"] += 1
                if verbose:
                    logger.debug(f"Game {game_num} reached terminal state after {step_count} steps")
                    logger.debug(f"Returns: {state.returns()}")
                    
        except Exception as e:
            logger.error(f"Error in game {game_num}: {e}")
            stats["errors"].append((game_num, str(e)))
    
    return stats

def main():
    """Main test function."""
    num_games = 100
    if len(sys.argv) > 1:
        try:
            num_games = int(sys.argv[1])
        except ValueError:
            logger.error(f"Invalid number of games: {sys.argv[1]}")
    
    verbose = False
    if "--verbose" in sys.argv:
        verbose = True
    
    start_time = time.time()
    stats = run_games(num_games, verbose)
    end_time = time.time()
    
    # Display results
    logger.info(f"Test completed in {end_time - start_time:.2f} seconds")
    logger.info(f"Total games: {stats['total_games']}")
    logger.info(f"Total steps: {stats['total_steps']}")
    logger.info(f"Terminal states reached: {stats['terminal_states']}")
    logger.info(f"Player ID=-4 occurrences: {stats['player_minus_4_count']}")
    logger.info(f"Errors: {len(stats['errors'])}")
    
    if stats["player_minus_4_count"] > 0:
        percent = (stats["player_minus_4_count"] / stats["total_steps"]) * 100
        logger.info(f"Player ID=-4 frequency: {percent:.4f}% of steps")

if __name__ == "__main__":
    main()