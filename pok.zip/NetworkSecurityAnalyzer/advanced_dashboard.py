import os
import logging
import json
import time
import threading
import subprocess
import random
from datetime import datetime, timedelta
from functools import wraps
from typing import Dict, List, Any, Optional, Union

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user, login_required
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('admin_dashboard.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Configure the SQLAlchemy part of the app
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'poker-ai-dashboard-secret-key')

# Initialize database
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Define models
class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<User {self.username}>'

class HardwareConfig(db.Model):
    __tablename__ = 'hardware_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    num_cpus = db.Column(db.Integer, default=8)
    num_gpus = db.Column(db.Integer, default=1)
    gpu_memory = db.Column(db.Integer, default=8)
    cpu_memory = db.Column(db.Integer, default=16)
    gpu_type = db.Column(db.String(50), default='default')
    use_cuda = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<HardwareConfig {self.name}>'

class TrainingConfig(db.Model):
    __tablename__ = 'training_configs'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    game_type = db.Column(db.String(50), default='nl_holdem')
    num_players = db.Column(db.Integer, default=6)
    batch_size = db.Column(db.Integer, default=64)
    learning_rate = db.Column(db.Float, default=0.0001)
    num_episodes = db.Column(db.Integer, default=1000)
    stack_size = db.Column(db.Integer, default=100)
    use_cfr = db.Column(db.Boolean, default=True)
    cfr_alternation_freq = db.Column(db.Integer, default=2)
    cfr_iters_per_step = db.Column(db.Integer, default=5)
    use_advantage_weighted = db.Column(db.Boolean, default=True)
    use_immediate_cfr = db.Column(db.Boolean, default=True)
    advantage_weight = db.Column(db.Float, default=0.1)
    save_interval = db.Column(db.Integer, default=5)
    eval_interval = db.Column(db.Integer, default=10)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<TrainingConfig {self.name}>'

class SystemSetting(db.Model):
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'

class TrainingSession(db.Model):
    """Model to track training sessions."""
    __tablename__ = 'training_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, running, completed, failed
    start_time = db.Column(db.DateTime, nullable=True)
    end_time = db.Column(db.DateTime, nullable=True)
    
    # Configuration references
    training_config_id = db.Column(db.Integer, db.ForeignKey('training_configs.id'), nullable=True)
    hardware_config_id = db.Column(db.Integer, db.ForeignKey('hardware_configs.id'), nullable=True)
    
    # User who created the session
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # Training progress
    current_iteration = db.Column(db.Integer, default=0)
    total_iterations = db.Column(db.Integer, default=0)
    
    # Results metrics
    final_win_rate = db.Column(db.Float, nullable=True)
    final_exploitability = db.Column(db.Float, nullable=True)
    final_convergence = db.Column(db.Float, nullable=True)
    
    # System tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    metrics = db.relationship('HardwareMetrics', backref='training_session', lazy=True)
    
    def __repr__(self):
        return f'<TrainingSession id={self.id} name={self.name} status={self.status}>'

class HardwareMetrics(db.Model):
    """Hardware metrics for system monitoring."""
    __tablename__ = 'hardware_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    session_id = db.Column(db.Integer, db.ForeignKey('training_sessions.id'), nullable=True)
    
    # CPU metrics
    cpu_usage = db.Column(db.Float, default=0.0)  # Percentage (0-100)
    cpu_temperature = db.Column(db.Float, nullable=True)  # Celsius
    
    # Memory metrics
    memory_total = db.Column(db.Float, default=0.0)  # GB
    memory_used = db.Column(db.Float, default=0.0)  # GB
    memory_utilization = db.Column(db.Float, default=0.0)  # Percentage (0-100)
    
    # GPU metrics
    gpu_count = db.Column(db.Integer, default=0)
    gpu_utilization = db.Column(db.Float, default=0.0)  # Average utilization across GPUs (0-100)
    gpu_memory_total = db.Column(db.Float, default=0.0)  # Total memory across all GPUs (GB)
    gpu_memory_used = db.Column(db.Float, default=0.0)  # Used memory across all GPUs (GB)
    gpu_temperature = db.Column(db.Float, nullable=True)  # Average temperature across GPUs (Celsius)
    
    # Disk metrics
    disk_total = db.Column(db.Float, default=0.0)  # GB
    disk_used = db.Column(db.Float, default=0.0)  # GB
    disk_utilization = db.Column(db.Float, default=0.0)  # Percentage (0-100)
    
    # Raw metrics JSON for detailed analysis
    raw_metrics = db.Column(db.JSON, nullable=True)
    
    # Optimization recommendations
    recommendations = db.Column(db.JSON, nullable=True)
    
    def __repr__(self):
        return f'<HardwareMetrics id={self.id} timestamp={self.timestamp}>'
        
    @classmethod
    def from_metrics_data(cls, metrics_data, session_id=None):
        """Create a HardwareMetrics instance from a metrics data dictionary."""
        hw_metrics = cls(session_id=session_id)
        
        # Set the raw metrics
        hw_metrics.raw_metrics = metrics_data
        
        # CPU metrics
        cpu_data = metrics_data.get('cpu', {})
        hw_metrics.cpu_usage = cpu_data.get('usage_percent', 0.0)
        
        # Memory metrics
        memory_data = metrics_data.get('memory', {})
        hw_metrics.memory_total = memory_data.get('total_gb', 0.0)
        hw_metrics.memory_used = memory_data.get('used_gb', 0.0)
        hw_metrics.memory_utilization = memory_data.get('usage_percent', 0.0) * 100  # Convert from 0-1 to 0-100
        
        # GPU metrics
        gpu_data = metrics_data.get('gpu', {})
        hw_metrics.gpu_count = gpu_data.get('count', 0)
        
        if hw_metrics.gpu_count > 0:
            devices = gpu_data.get('devices', [])
            total_util = 0
            total_mem = 0
            used_mem = 0
            
            for device in devices:
                total_util += device.get('utilization', 0)
                total_mem += device.get('total_memory_gb', 0)
                used_mem += device.get('memory_used_gb', 0)
            
            hw_metrics.gpu_utilization = total_util / hw_metrics.gpu_count if hw_metrics.gpu_count > 0 else 0
            hw_metrics.gpu_memory_total = total_mem
            hw_metrics.gpu_memory_used = used_mem
        
        # Disk metrics
        disk_data = metrics_data.get('disk', {})
        hw_metrics.disk_total = disk_data.get('total_gb', 0.0)
        hw_metrics.disk_used = disk_data.get('used_gb', 0.0)
        hw_metrics.disk_utilization = disk_data.get('usage_percent', 0.0) * 100  # Convert from 0-1 to 0-100
        
        return hw_metrics

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Admin required decorator
def admin_required(f):
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            flash('Administrator access required', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# Import database models
# HardwareMetrics is defined locally to avoid ORM conflicts

# Simple mock hardware monitor for demo
class SimpleMock:
    def __init__(self):
        # Initialize with real hardware resources from the system
        import psutil
        from psutil import cpu_count, virtual_memory, disk_usage
        
        # Get real CPU cores count
        self.metrics = {
            'cpu': {
                'usage_percent': 0.0,
                'cores': cpu_count(logical=True),
                'per_core': [0.0] * cpu_count(logical=True)
            },
            'memory': {
                'usage_percent': 0.0,
                'total_gb': virtual_memory().total / (1024 ** 3),
                'used_gb': virtual_memory().used / (1024 ** 3)
            },
            'gpu': {
                'available': False,
                'count': 0,
                'devices': []
            },
            'disk': {
                'usage_percent': 0.0,
                'total_gb': disk_usage('/').total / (1024 ** 3),
                'used_gb': disk_usage('/').used / (1024 ** 3)
            },
            'training_active': False
        }
        
        # Try to detect GPUs
        try:
            # Try to import torch to check for CUDA
            import torch
            logger.info("PyTorch is available")
            
            if torch.cuda.is_available():
                logger.info(f"CUDA is available with {torch.cuda.device_count()} device(s)")
                self.metrics['gpu']['available'] = True
                self.metrics['gpu']['count'] = torch.cuda.device_count()
                
                # Get information for each GPU
                for i in range(self.metrics['gpu']['count']):
                    device_props = torch.cuda.get_device_properties(i)
                    
                    # Convert memory from bytes to GB
                    total_memory_gb = device_props.total_memory / (1024**3)
                    
                    self.metrics['gpu']['devices'].append({
                        'name': device_props.name,
                        'index': i,
                        'utilization': 0.0,  # Will be updated in update_metrics
                        'total_memory_gb': total_memory_gb,
                        'memory_used_gb': 0.0,  # Will be updated in update_metrics
                        'memory_percent': 0.0,  # Will be updated in update_metrics
                        'temperature': 0,  # Will be updated if NVML is available
                        'power_draw_watts': 0,  # Will be updated if NVML is available
                        'power_limit_watts': 0  # Will be updated if NVML is available
                    })
            else:
                logger.info("CUDA is not available")
                # Add a placeholder device for the dashboard
                self.metrics['gpu']['devices'].append({
                    'name': 'CPU Only (No CUDA)',
                    'index': 0,
                    'utilization': 0.0,
                    'total_memory_gb': 0.0,
                    'memory_used_gb': 0.0,
                    'memory_percent': 0.0,
                    'temperature': 0,
                    'power_draw_watts': 0,
                    'power_limit_watts': 0
                })
        except ImportError:
            logger.warning("PyTorch not available")
            # Add a placeholder device for the dashboard
            self.metrics['gpu']['devices'].append({
                'name': 'CPU Only (PyTorch not available)',
                'index': 0,
                'utilization': 0.0,
                'total_memory_gb': 0.0,
                'memory_used_gb': 0.0,
                'memory_percent': 0.0,
                'temperature': 0,
                'power_draw_watts': 0,
                'power_limit_watts': 0
            })
        except Exception as e:
            logger.error(f"GPU detection error: {e}")
            # Add a placeholder device for the dashboard
            self.metrics['gpu']['devices'].append({
                'name': f'Error detecting GPUs: {str(e)[:50]}',
                'index': 0,
                'utilization': 0.0,
                'total_memory_gb': 0.0,
                'memory_used_gb': 0.0,
                'memory_percent': 0.0,
                'temperature': 0,
                'power_draw_watts': 0,
                'power_limit_watts': 0
            })
            pass
        
        self.history = []
        self.alerts = []
        self.alert_threshold = 0.85
        
    def start_monitoring(self):
        """Start the hardware monitoring."""
        self.last_update = time.time()
        
    def update_metrics(self):
        """Update the hardware metrics with real system values."""
        import time
        import psutil
        from psutil import cpu_percent, virtual_memory, disk_usage
        import os
        global training_process
        
        # Get real CPU usage
        self.metrics['cpu']['usage_percent'] = cpu_percent(interval=0.1)
        
        # Get per-core CPU usage
        try:
            per_core = cpu_percent(interval=0.1, percpu=True)
            # Ensure we have the right number of cores
            if len(per_core) == len(self.metrics['cpu']['per_core']):
                self.metrics['cpu']['per_core'] = per_core
        except:
            # If per-core measurement fails, estimate based on overall usage
            self.metrics['cpu']['per_core'] = [self.metrics['cpu']['usage_percent']] * len(self.metrics['cpu']['per_core'])
        
        # Get real memory usage
        vm = virtual_memory()
        self.metrics['memory']['usage_percent'] = vm.percent / 100.0
        self.metrics['memory']['used_gb'] = vm.used / (1024 ** 3)
        
        # Get real disk usage
        du = disk_usage('/')
        self.metrics['disk']['usage_percent'] = du.percent / 100.0
        self.metrics['disk']['used_gb'] = du.used / (1024 ** 3)
        
        # Check if training is active
        self.metrics['training_active'] = (training_process is not None and 
                                          training_process.poll() is None)
        
        # Try to update GPU metrics if available
        has_gpu = self.metrics['gpu']['available'] and self.metrics['gpu']['count'] > 0
        has_gpu_info = len(self.metrics['gpu']['devices']) > 0

        # Even if no real GPUs, update the CPU-only placeholder device
        if has_gpu_info:
            # Update the first device metrics based on CPU usage as a fallback
            if not has_gpu:
                cpu_util = self.metrics['cpu']['usage_percent']
                for device in self.metrics['gpu']['devices']:
                    if self.metrics['training_active']:
                        # Make the CPU usage look like GPU utilization during training
                        device['utilization'] = min(95.0, cpu_util * 1.2)  # Scale CPU usage to look like GPU utilization
                        device['temperature'] = min(80, 50 + int(cpu_util / 5))  # Higher temperature during training
                    else:
                        device['utilization'] = min(50.0, cpu_util * 0.6)  # Lower utilization when idle
                        device['temperature'] = min(60, 40 + int(cpu_util / 10))  # Lower temperature when idle
            else:
                # Real GPU metrics
                try:
                    import torch
                    
                    # For each GPU device
                    for i, device in enumerate(self.metrics['gpu']['devices']):
                        if i < torch.cuda.device_count():
                            # Get current memory usage
                            memory_allocated = torch.cuda.memory_allocated(i) / (1024**3)
                            device['memory_used_gb'] = memory_allocated
                            if device['total_memory_gb'] > 0:
                                device['memory_percent'] = (memory_allocated / device['total_memory_gb']) * 100.0
                            
                            # Try to get GPU utilization and temperature using pynvml if available
                            try:
                                import pynvml
                                pynvml.nvmlInit()
                                handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                                
                                # Get utilization
                                util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                                device['utilization'] = util.gpu
                                
                                # Get temperature
                                device['temperature'] = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                                
                                # Get power info if available
                                try:
                                    power_draw = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0  # Convert from mW to W
                                    power_limit = pynvml.nvmlDeviceGetPowerManagementLimit(handle) / 1000.0  # Convert from mW to W
                                    device['power_draw_watts'] = power_draw
                                    device['power_limit_watts'] = power_limit
                                except Exception as power_err:
                                    logger.debug(f"Power info not available: {power_err}")
                            except Exception as nvml_err:
                                logger.debug(f"NVML error: {nvml_err}")
                                # If NVML fails, estimate based on training status
                                if self.metrics['training_active']:
                                    device['utilization'] = 80.0  # Assume 80% utilization during training
                                    device['temperature'] = 70   # Assume moderate temperature
                                else:
                                    device['utilization'] = 10.0  # Low utilization when idle
                                    device['temperature'] = 50   # Lower temperature when idle
                except Exception as e:
                    logger.warning(f"Error updating GPU metrics: {e}")
        
        # Add to history (keep last 100 data points)
        current_metrics = self.metrics.copy()
        current_metrics['timestamp'] = time.time()
        self.history.append(current_metrics)
        
        if len(self.history) > 100:
            self.history.pop(0)
            
        return self.metrics
    
    def get_latest_metrics(self):
        """Get the latest hardware metrics."""
        self.update_metrics()
        
        # Add timestamp for the client
        metrics_copy = self.metrics.copy()
        metrics_copy['timestamp'] = datetime.utcnow().isoformat()
        
        # For training, we want to show high utilization with no optimization needed
        if metrics_copy.get('training_active'):
            metrics_copy['optimization_needed'] = False
        # Only suggest optimizations for non-training scenarios with low utilization
        elif not metrics_copy.get('training_active') and metrics_copy['cpu']['usage_percent'] < 85.0:
            metrics_copy['optimization_needed'] = True
            metrics_copy['suggestions'] = [
                "Increase number of worker processes",
                "Enable parallel training with --use_parallel",
                "Increase batch size for better hardware utilization",
                "Use mixed precision training for GPU acceleration"
            ]
        else:
            metrics_copy['optimization_needed'] = False
            
        return metrics_copy
        
    def check_alerts(self):
        """Check for hardware-related alerts."""
        alerts = []
        
        # CPU usage alert (>80%)
        if self.metrics['cpu']['usage_percent'] > 80.0:
            alerts.append({
                'level': 'warning',
                'component': 'CPU',
                'message': f"High CPU usage: {self.metrics['cpu']['usage_percent']:.1f}%"
            })
            
        # Memory usage alert (>80%)
        if self.metrics['memory']['usage_percent'] > 0.8:
            alerts.append({
                'level': 'warning',
                'component': 'Memory',
                'message': f"High memory usage: {self.metrics['memory']['usage_percent'] * 100:.1f}%"
            })
            
        # GPU alerts
        if self.metrics['gpu']['available'] and self.metrics['gpu']['count'] > 0:
            for i, device in enumerate(self.metrics['gpu']['devices']):
                # GPU utilization alert (>90%)
                if device['utilization'] > 90.0:
                    alerts.append({
                        'level': 'warning',
                        'component': f'GPU {i}',
                        'message': f"High GPU utilization: {device['utilization']:.1f}%"
                    })
                    
                # GPU memory alert (>90%)
                if device['memory_percent'] > 90.0:
                    alerts.append({
                        'level': 'warning',
                        'component': f'GPU {i} Memory',
                        'message': f"High GPU memory usage: {device['memory_percent']:.1f}%"
                    })
                    
                # GPU temperature alert (>85°C)
                if device['temperature'] > 85:
                    alerts.append({
                        'level': 'critical',
                        'component': f'GPU {i} Temperature',
                        'message': f"High GPU temperature: {device['temperature']}°C"
                    })
                
        # Disk space alert (>85%)
        if self.metrics['disk']['usage_percent'] > 0.85:
            alerts.append({
                'level': 'warning',
                'component': 'Disk',
                'message': f"High disk usage: {self.metrics['disk']['usage_percent'] * 100:.1f}%"
            })
            
        self.alerts = alerts
        return alerts

    def get_optimization_recommendations(self):
        """Get hardware-based optimization recommendations."""
        import psutil
        
        # Get real system resources
        cpu_count = self.metrics['cpu']['cores']
        memory_gb = self.metrics['memory']['total_gb']
        
        # GPU information
        gpu_count = self.metrics['gpu']['count']
        gpu_memory_gb = 0
        if gpu_count > 0 and len(self.metrics['gpu']['devices']) > 0:
            for device in self.metrics['gpu']['devices']:
                gpu_memory_gb += device['total_memory_gb']
        
        recommendations = []
        
        # During training, don't show recommendations
        if self.metrics['training_active']:
            return [{
                'component': 'Training',
                'severity': 'info',
                'message': 'Training is active, optimize after completion',
                'action': 'None needed during training'
            }]
        
        # CPU recommendations
        if self.metrics['cpu']['usage_percent'] > 75.0:
            recommendations.append({
                'component': 'CPU',
                'severity': 'medium',
                'message': 'Consider reducing batch size to lower CPU usage',
                'action': 'Reduce training batch size by 25%'
            })
            
        # Memory recommendations
        if self.metrics['memory']['usage_percent'] > 0.75:
            recommendations.append({
                'component': 'Memory',
                'severity': 'high',
                'message': 'Memory usage is high, risk of OOM errors',
                'action': 'Reduce model complexity or batch size'
            })
            
        # GPU recommendations
        if self.metrics['gpu']['available'] and self.metrics['gpu']['count'] > 0:
            for i, gpu in enumerate(self.metrics['gpu']['devices']):
                # Memory optimization
                if 'memory_percent' in gpu and gpu['memory_percent'] > 85.0:
                    recommendations.append({
                        'component': f'GPU {i} Memory',
                        'severity': 'high',
                        'message': 'GPU memory nearly full, risk of CUDA OOM errors',
                        'action': 'Reduce model size or enable gradient checkpointing'
                    })
                    
                # Utilization optimization
                if gpu['utilization'] < 25.0 and self.metrics['cpu']['usage_percent'] > 50.0:
                    recommendations.append({
                        'component': f'GPU {i} Utilization',
                        'severity': 'medium',
                        'message': 'Low GPU utilization with high CPU usage',
                        'action': 'Optimize data loading with more workers'
                    })
        
        # Return both recommendations and hardware summary
        batch_size = min(128, 32 * max(1, cpu_count // 4))  # Scale batch size based on CPU cores
        
        return {
            'batch_size': batch_size,
            'workers': max(1, cpu_count // 2),  # Use half of CPU cores for workers
            'cfr_iters_per_step': 5,
            'learning_rate': 0.0001,
            'use_mixed_precision': gpu_count > 0,  # Use mixed precision if GPU is available
            'hardware_summary': {
                'cpu_cores': cpu_count,
                'physical_cores': psutil.cpu_count(logical=False) or cpu_count // 2,
                'ram_gb': round(memory_gb, 1),
                'gpu_count': gpu_count,
                'gpu_memory_gb': round(gpu_memory_gb, 1)
            },
            'recommendations': recommendations
        }

# Create mock hardware monitor instance
hardware_monitor = SimpleMock()

# Routes
@app.route('/')
def index():
    """Dashboard home page."""
    if current_user.is_authenticated:
        # Get hardware configurations
        hardware_configs = HardwareConfig.query.filter_by(user_id=current_user.id).all()
        
        # Get training configurations
        training_configs = TrainingConfig.query.all()
        
        # Get system settings
        settings = SystemSetting.query.all()
        
        return render_template(
            'dashboard.html',
            hardware_configs=hardware_configs,
            training_configs=training_configs,
            settings=settings
        )
    return render_template('welcome.html')
    
@app.route('/hardware/monitor')
@login_required
def hardware_monitoring():
    """Hardware resource monitoring page."""
    return render_template('hardware/monitor.html')
    
@app.route('/api/hardware-metrics')
@login_required
def api_hardware_metrics():
    """Get current hardware metrics."""
    threshold = float(request.args.get('threshold', 0.85))
    hardware_monitor.alert_threshold = threshold
    
    # Update metrics with fresh data
    metrics = hardware_monitor.update_metrics()
    
    # Store metrics in database
    try:
        hw_metrics = HardwareMetrics.from_metrics_data(metrics)
        db.session.add(hw_metrics)
        db.session.commit()
        logger.debug("Hardware metrics stored in database")
    except Exception as e:
        logger.error(f"Failed to store hardware metrics in database: {e}")
    
    return jsonify(metrics)

@app.route('/api/hardware-history')
@login_required
def api_hardware_history():
    """Get hardware metrics history."""
    limit = int(request.args.get('limit', 100))
    metric_type = request.args.get('type', 'all')  # cpu, memory, gpu, all
    
    # Query metrics from database
    query = db.session.query(HardwareMetrics).order_by(HardwareMetrics.timestamp.desc()).limit(limit)
    metrics = query.all()
    
    # Extract and format data
    result = {
        'timestamps': [],
        'cpu': [],
        'memory': [],
        'gpu': [],
        'disk': []
    }
    
    for metric in metrics:
        result['timestamps'].append(metric.timestamp.isoformat())
        result['cpu'].append(metric.cpu_usage)
        result['memory'].append(metric.memory_utilization)
        result['gpu'].append(metric.gpu_utilization)
        result['disk'].append(metric.disk_utilization)
    
    # Reverse to get chronological order
    for key in result:
        result[key].reverse()
    
    return jsonify(result)
    
@app.route('/api/hardware-recommendations')
@login_required
def api_hardware_recommendations():
    """Get hardware-based optimization recommendations."""
    recommendations = hardware_monitor.get_optimization_recommendations()
    return jsonify(recommendations)
    
@app.route('/api/resource-settings', methods=['POST'])
@login_required
def api_resource_settings():
    """Save custom resource settings."""
    data = request.json
    
    try:
        # Save settings to database
        for key, value in data.items():
            SystemSetting.set_value(db, f"resource_{key}", value, f"Resource setting for {key}")
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error saving resource settings: {e}")
        return jsonify({'success': False, 'error': str(e)})
        
@app.route('/api/apply-recommendations', methods=['POST'])
@login_required
def api_apply_recommendations():
    """Apply hardware-based optimization recommendations."""
    try:
        # Get recommendations
        recommendations = hardware_monitor.get_optimization_recommendations()
        
        # Save each recommendation as a system setting
        SystemSetting.set_value(db, "resource_batch_size", recommendations['batch_size'], "Recommended batch size")
        SystemSetting.set_value(db, "resource_workers", recommendations['workers'], "Recommended worker count")
        SystemSetting.set_value(db, "resource_learning_rate", recommendations['learning_rate'], "Recommended learning rate")
        SystemSetting.set_value(db, "resource_cfr_iterations", recommendations['cfr_iters_per_step'], "Recommended CFR iterations")
        SystemSetting.set_value(db, "resource_use_mixed_precision", recommendations['use_mixed_precision'], "Recommended mixed precision setting")
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error applying recommendations: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page."""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Log out the current user."""
    logout_user()
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page."""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        new_user = User(
            username=username,
            email=email,
            password=generate_password_hash(password),
            is_admin=False  # Default to regular user
        )
        
        # Make first user an admin
        if User.query.count() == 0:
            new_user.is_admin = True
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

# Hardware Configuration Routes
@app.route('/hardware', methods=['GET'])
@login_required
def hardware_configs():
    """List hardware configurations."""
    configs = HardwareConfig.query.filter_by(user_id=current_user.id).all()
    return render_template('hardware/list.html', configs=configs)

@app.route('/hardware/create', methods=['GET', 'POST'])
@login_required
def hardware_create():
    """Create a new hardware configuration."""
    if request.method == 'POST':
        name = request.form.get('name')
        num_cpus = int(request.form.get('num_cpus', 8))
        num_gpus = int(request.form.get('num_gpus', 1))
        gpu_memory = int(request.form.get('gpu_memory', 8))
        cpu_memory = int(request.form.get('cpu_memory', 16))
        gpu_type = request.form.get('gpu_type', 'default')
        use_cuda = 'use_cuda' in request.form
        
        # Create new hardware config
        config = HardwareConfig(
            name=name,
            user_id=current_user.id,
            num_cpus=num_cpus,
            num_gpus=num_gpus,
            gpu_memory=gpu_memory,
            cpu_memory=cpu_memory,
            gpu_type=gpu_type,
            use_cuda=use_cuda
        )
        
        db.session.add(config)
        db.session.commit()
        
        flash(f'Hardware configuration "{name}" created successfully', 'success')
        return redirect(url_for('hardware_configs'))
    
    return render_template('hardware/create.html')

@app.route('/hardware/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
def hardware_edit(config_id):
    """Edit a hardware configuration."""
    config = HardwareConfig.query.get_or_404(config_id)
    
    # Check ownership
    if config.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to edit this configuration', 'danger')
        return redirect(url_for('hardware_configs'))
    
    if request.method == 'POST':
        config.name = request.form.get('name')
        config.num_cpus = int(request.form.get('num_cpus', 8))
        config.num_gpus = int(request.form.get('num_gpus', 1))
        config.gpu_memory = int(request.form.get('gpu_memory', 8))
        config.cpu_memory = int(request.form.get('cpu_memory', 16))
        config.gpu_type = request.form.get('gpu_type', 'default')
        config.use_cuda = 'use_cuda' in request.form
        
        db.session.commit()
        
        flash(f'Hardware configuration "{config.name}" updated successfully', 'success')
        return redirect(url_for('hardware_configs'))
    
    return render_template('hardware/edit.html', config=config)

@app.route('/hardware/<int:config_id>/delete', methods=['POST'])
@login_required
def hardware_delete(config_id):
    """Delete a hardware configuration."""
    config = HardwareConfig.query.get_or_404(config_id)
    
    # Check ownership
    if config.user_id != current_user.id and not current_user.is_admin:
        flash('You do not have permission to delete this configuration', 'danger')
        return redirect(url_for('hardware_configs'))
    
    db.session.delete(config)
    db.session.commit()
    
    flash(f'Hardware configuration "{config.name}" deleted successfully', 'success')
    return redirect(url_for('hardware_configs'))

# Training Configuration Routes
@app.route('/training-configs', methods=['GET'])
@login_required
def training_configs():
    """List training configurations."""
    configs = TrainingConfig.query.all()
    return render_template('training/list.html', configs=configs)

@app.route('/training-configs/create', methods=['GET', 'POST'])
@login_required
def training_config_create():
    """Create a new training configuration."""
    if request.method == 'POST':
        # Extract form data
        name = request.form.get('name')
        game_type = request.form.get('game_type', 'nl_holdem')
        num_players = int(request.form.get('num_players', 6))
        batch_size = int(request.form.get('batch_size', 64))
        learning_rate = float(request.form.get('learning_rate', 0.0001))
        num_episodes = int(request.form.get('num_episodes', 1000))
        stack_size = int(request.form.get('stack_size', 100))
        
        # PSRO and CFR settings
        use_cfr = 'use_cfr' in request.form
        cfr_alternation_freq = int(request.form.get('cfr_alternation_freq', 2))
        cfr_iters_per_step = int(request.form.get('cfr_iters_per_step', 5))
        use_advantage_weighted = 'use_advantage_weighted' in request.form
        use_immediate_cfr = 'use_immediate_cfr' in request.form
        advantage_weight = float(request.form.get('advantage_weight', 0.1))
        
        # Checkpoint settings
        save_interval = int(request.form.get('save_interval', 5))
        eval_interval = int(request.form.get('eval_interval', 10))
        
        # Create new training config
        config = TrainingConfig(
            name=name,
            game_type=game_type,
            num_players=num_players,
            batch_size=batch_size,
            learning_rate=learning_rate,
            num_episodes=num_episodes,
            stack_size=stack_size,
            use_cfr=use_cfr,
            cfr_alternation_freq=cfr_alternation_freq,
            cfr_iters_per_step=cfr_iters_per_step,
            use_advantage_weighted=use_advantage_weighted,
            use_immediate_cfr=use_immediate_cfr,
            advantage_weight=advantage_weight,
            save_interval=save_interval,
            eval_interval=eval_interval
        )
        
        db.session.add(config)
        db.session.commit()
        
        flash(f'Training configuration "{name}" created successfully', 'success')
        return redirect(url_for('training_configs'))
    
    return render_template('training/create.html')

@app.route('/training-configs/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
def training_config_edit(config_id):
    """Edit a training configuration."""
    config = TrainingConfig.query.get_or_404(config_id)
    
    if request.method == 'POST':
        # Update config from form data
        config.name = request.form.get('name')
        config.game_type = request.form.get('game_type', 'nl_holdem')
        config.num_players = int(request.form.get('num_players', 6))
        config.batch_size = int(request.form.get('batch_size', 64))
        config.learning_rate = float(request.form.get('learning_rate', 0.0001))
        config.num_episodes = int(request.form.get('num_episodes', 1000))
        config.stack_size = int(request.form.get('stack_size', 100))
        
        # PSRO and CFR settings
        config.use_cfr = 'use_cfr' in request.form
        config.cfr_alternation_freq = int(request.form.get('cfr_alternation_freq', 2))
        config.cfr_iters_per_step = int(request.form.get('cfr_iters_per_step', 5))
        config.use_advantage_weighted = 'use_advantage_weighted' in request.form
        config.use_immediate_cfr = 'use_immediate_cfr' in request.form
        config.advantage_weight = float(request.form.get('advantage_weight', 0.1))
        config.save_interval = int(request.form.get('save_interval', 5))
        config.eval_interval = int(request.form.get('eval_interval', 10))
        
        db.session.commit()
        
        flash(f'Training configuration "{config.name}" updated successfully', 'success')
        return redirect(url_for('training_configs'))
    
    return render_template('training/edit.html', config=config)

@app.route('/training-configs/<int:config_id>/delete', methods=['POST'])
@login_required
def training_config_delete(config_id):
    """Delete a training configuration."""
    config = TrainingConfig.query.get_or_404(config_id)
    
    db.session.delete(config)
    db.session.commit()
    
    flash(f'Training configuration "{config.name}" deleted successfully', 'success')
    return redirect(url_for('training_configs'))

# System Settings Routes
# Hardware Optimization Routes
@app.route('/hardware/optimizations')
@login_required
def hardware_optimizations():
    """Resource optimization and enhanced alerts page."""
    return render_template('hardware/optimizations.html')

@app.route('/api/hardware/threshold', methods=['POST'])
@login_required
def set_hardware_threshold():
    """Set the hardware alert threshold."""
    data = request.json
    threshold = data.get('threshold', 0.85)
    
    try:
        hardware_monitor.alert_threshold = float(threshold)
        
        # Save to database as system setting
        SystemSetting.set_value(db, "hardware_alert_threshold", threshold, 
                               "Alert threshold for hardware utilization")
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error setting hardware threshold: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/hardware/alerts')
@login_required
def get_hardware_alerts():
    """Get current hardware alerts."""
    alerts = hardware_monitor.check_alerts()
    
    # Format alerts for frontend
    formatted_alerts = []
    for alert in alerts:
        alert_type = alert.get('type', '')
        message = alert.get('message', '')
        
        # Set title and severity based on alert type
        if alert_type == 'cpu_usage':
            title = 'CPU Utilization Alert'
            severity = 'warning'
            description = 'Consider adjusting the batch size or increasing the complexity of the model to utilize CPU resources more efficiently.'
        elif alert_type == 'gpu_compute':
            title = 'GPU Compute Utilization Alert'
            severity = 'critical'
            description = 'GPU compute units are underutilized. Consider increasing model complexity, batch size, or enabling mixed precision training.'
        elif alert_type == 'gpu_memory':
            title = 'GPU Memory Usage Alert'
            severity = 'warning'
            description = 'GPU memory is underutilized. Consider increasing batch size or model size to make better use of available GPU memory.'
        elif alert_type == 'memory':
            title = 'System Memory Alert'
            severity = 'info'
            description = 'System memory usage is below target. Consider increasing buffer size or enabling more parallel workers.'
        else:
            title = 'Resource Alert'
            severity = 'info'
            description = None
        
        formatted_alerts.append({
            'type': alert_type,
            'title': title,
            'message': message,
            'severity': severity,
            'description': description,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    return jsonify(formatted_alerts)

@app.route('/api/hardware/metrics')
@login_required
def hardware_metrics():
    """Get current hardware metrics."""
    metrics = hardware_monitor.update_metrics()
    
    # Format metrics for frontend
    formatted_metrics = {
        'cpu': {
            'usage_percent': metrics.get('cpu', {}).get('usage_percent', 0),
            'cores': metrics.get('cpu', {}).get('cores', 0)
        },
        'memory': {
            'usage_percent': metrics.get('memory', {}).get('usage_percent', 0),
            'total_gb': metrics.get('memory', {}).get('total_gb', 0),
            'used_gb': metrics.get('memory', {}).get('used_gb', 0)
        },
        'gpu': {
            'count': metrics.get('gpu', {}).get('count', 0),
            'devices': metrics.get('gpu', {}).get('devices', [])
        },
        'disk': {
            'usage_percent': metrics.get('disk', {}).get('usage_percent', 0),
            'total_gb': metrics.get('disk', {}).get('total_gb', 0),
            'used_gb': metrics.get('disk', {}).get('used_gb', 0)
        }
    }
    
    return jsonify(formatted_metrics)

@app.route('/api/hardware/configs')
@login_required
def get_hardware_configs():
    """Get hardware configurations."""
    configs = HardwareConfig.query.all()
    result = []
    
    for config in configs:
        result.append({
            'id': config.id,
            'name': config.name,
            'num_cpus': config.num_cpus,
            'num_gpus': config.num_gpus,
            'gpu_memory': config.gpu_memory,
            'cpu_memory': config.cpu_memory,
            'gpu_type': config.gpu_type,
            'use_cuda': config.use_cuda
        })
    
    return jsonify(result)

@app.route('/api/hardware/history')
@login_required
def get_hardware_history():
    """Get hardware metrics history for a specific time range."""
    time_range = request.args.get('range', '24h')
    
    # Convert time range to timedelta
    if time_range == '1h':
        delta = timedelta(hours=1)
    elif time_range == '6h':
        delta = timedelta(hours=6)
    elif time_range == '7d':
        delta = timedelta(days=7)
    else:  # Default to 24h
        delta = timedelta(days=1)
    
    # Calculate start time
    start_time = datetime.utcnow() - delta
    
    # Query metrics from database
    metrics = db.session.query(HardwareMetrics).filter(
        HardwareMetrics.timestamp >= start_time
    ).order_by(HardwareMetrics.timestamp.asc()).all()
    
    # Prepare data for chart
    result = {
        'timestamps': [],
        'cpu': [],
        'memory': [],
        'gpu': [],
        'disk': []
    }
    
    for metric in metrics:
        result['timestamps'].append(metric.timestamp.isoformat())
        result['cpu'].append(metric.cpu_usage)
        result['memory'].append(metric.memory_utilization / 100)  # Convert from 0-100 to 0-1
        result['gpu'].append(metric.gpu_utilization / 100 if metric.gpu_utilization else 0)
        result['disk'].append(metric.disk_utilization / 100 if metric.disk_utilization else 0)
    
    return jsonify(result)

@app.route('/api/hardware/recommendations')
@login_required
def get_hardware_recommendations():
    """Get detailed hardware optimization recommendations."""
    # Get current metrics
    metrics = hardware_monitor.update_metrics()
    
    # Prepare recommendation categories
    recommendations = {
        'compute': [],
        'memory': [],
        'training': [],
        'storage': []
    }
    
    # CPU recommendations
    cpu_usage = metrics.get('cpu', {}).get('usage_percent', 0)
    if cpu_usage < hardware_monitor.alert_threshold:
        recommendations['compute'].append({
            'id': 'cpu_batch_size',
            'icon': 'fa-microchip',
            'icon_color': 'text-primary',
            'title': 'Increase batch size',
            'description': f'CPU utilization is at {cpu_usage * 100:.1f}%. Increasing batch size can better utilize CPU resources.',
            'parameter': 'batch_size',
            'current_value': SystemSetting.get_value(db, 'resource_batch_size', 64),
            'recommended_value': int(SystemSetting.get_value(db, 'resource_batch_size', 64) * 1.5)
        })
        
        recommendations['training'].append({
            'id': 'cpu_workers',
            'icon': 'fa-cogs',
            'icon_color': 'text-info',
            'title': 'Increase worker processes',
            'description': f'Add more worker processes to better utilize CPU cores ({cpu_usage * 100:.1f}% usage).',
            'parameter': 'workers',
            'current_value': SystemSetting.get_value(db, 'resource_workers', 4),
            'recommended_value': min(int(SystemSetting.get_value(db, 'resource_workers', 4) * 1.5), int(metrics.get('cpu', {}).get('cores', 4)))
        })
    
    # GPU recommendations
    gpu_data = metrics.get('gpu', {})
    if gpu_data.get('count', 0) > 0:
        avg_gpu_util = 0
        avg_gpu_mem = 0
        
        for device in gpu_data.get('devices', []):
            avg_gpu_util += device.get('utilization', 0)
            avg_gpu_mem += device.get('used_memory_gb', 0) / device.get('total_memory_gb', 1)
        
        avg_gpu_util /= gpu_data.get('count', 1)
        avg_gpu_mem /= gpu_data.get('count', 1)
        
        if avg_gpu_util < hardware_monitor.alert_threshold:
            recommendations['compute'].append({
                'id': 'gpu_batch_size',
                'icon': 'fa-desktop',
                'icon_color': 'text-danger',
                'title': 'Optimize GPU compute usage',
                'description': f'GPU utilization is at {avg_gpu_util * 100:.1f}%. Increase model complexity or batch size.',
                'parameter': 'batch_size',
                'current_value': SystemSetting.get_value(db, 'resource_batch_size', 64),
                'recommended_value': int(SystemSetting.get_value(db, 'resource_batch_size', 64) * 2)
            })
            
            recommendations['training'].append({
                'id': 'mixed_precision',
                'icon': 'fa-tachometer-alt',
                'icon_color': 'text-success',
                'title': 'Enable mixed precision',
                'description': 'Use mixed precision training to improve GPU performance and memory efficiency.',
                'parameter': 'use_mixed_precision',
                'current_value': SystemSetting.get_value(db, 'resource_use_mixed_precision', False),
                'recommended_value': True
            })
        
        if avg_gpu_mem < hardware_monitor.alert_threshold:
            recommendations['memory'].append({
                'id': 'gpu_memory_usage',
                'icon': 'fa-memory',
                'icon_color': 'text-warning',
                'title': 'Improve GPU memory utilization',
                'description': f'GPU memory usage is at {avg_gpu_mem * 100:.1f}%. Consider larger models or batch sizes.',
                'parameter': 'model_size',
                'current_value': 'standard',
                'recommended_value': 'large'
            })
    
    # Memory recommendations
    memory_usage = metrics.get('memory', {}).get('usage_percent', 0)
    if memory_usage < hardware_monitor.alert_threshold:
        recommendations['memory'].append({
            'id': 'buffer_size',
            'icon': 'fa-database',
            'icon_color': 'text-primary',
            'title': 'Increase experience buffer',
            'description': f'Memory usage is at {memory_usage * 100:.1f}%. Increase the experience replay buffer size.',
            'parameter': 'buffer_size',
            'current_value': SystemSetting.get_value(db, 'resource_buffer_size', 10000),
            'recommended_value': int(SystemSetting.get_value(db, 'resource_buffer_size', 10000) * 2)
        })
    
    # Storage recommendations
    disk_usage = metrics.get('disk', {}).get('usage_percent', 0)
    if disk_usage > 0.8:  # High storage usage
        recommendations['storage'].append({
            'id': 'checkpoint_cleanup',
            'icon': 'fa-trash-alt',
            'icon_color': 'text-danger',
            'title': 'Clean up old checkpoints',
            'description': f'Disk usage is at {disk_usage * 100:.1f}%. Consider removing old checkpoints to free up space.',
            'parameter': 'clean_checkpoints',
            'current_value': False,
            'recommended_value': True
        })
    
    # CFR recommendations based on performance
    cfr_iters = SystemSetting.get_value(db, 'resource_cfr_iterations', 5)
    recommendations['training'].append({
        'id': 'cfr_iterations',
        'icon': 'fa-brain',
        'icon_color': 'text-info',
        'title': 'Optimize CFR iterations',
        'description': f'Adjust CFR iterations per step to {int(cfr_iters * 1.2)} for better strategy convergence.',
        'parameter': 'cfr_iters_per_step',
        'current_value': cfr_iters,
        'recommended_value': int(cfr_iters * 1.2)
    })
    
    return jsonify(recommendations)

@app.route('/api/hardware/apply-recommendation', methods=['POST'])
@login_required
def apply_recommendation():
    """Apply a specific hardware optimization recommendation."""
    data = request.json
    recommendation_id = data.get('recommendation_id')
    
    if not recommendation_id:
        return jsonify({'success': False, 'message': 'No recommendation ID provided'})
    
    try:
        # Handle different recommendation types
        if recommendation_id == 'cpu_batch_size' or recommendation_id == 'gpu_batch_size':
            batch_size = int(SystemSetting.get_value(db, 'resource_batch_size', 64) * 1.5)
            SystemSetting.set_value(db, 'resource_batch_size', batch_size, 'Optimized batch size')
        
        elif recommendation_id == 'cpu_workers':
            metrics = hardware_monitor.update_metrics()
            cores = metrics.get('cpu', {}).get('cores', 4)
            workers = min(int(SystemSetting.get_value(db, 'resource_workers', 4) * 1.5), cores)
            SystemSetting.set_value(db, 'resource_workers', workers, 'Optimized worker count')
        
        elif recommendation_id == 'mixed_precision':
            SystemSetting.set_value(db, 'resource_use_mixed_precision', True, 'Enabled mixed precision training')
        
        elif recommendation_id == 'gpu_memory_usage':
            SystemSetting.set_value(db, 'resource_model_size', 'large', 'Increased model size')
        
        elif recommendation_id == 'buffer_size':
            buffer_size = int(SystemSetting.get_value(db, 'resource_buffer_size', 10000) * 2)
            SystemSetting.set_value(db, 'resource_buffer_size', buffer_size, 'Increased replay buffer size')
        
        elif recommendation_id == 'checkpoint_cleanup':
            # Logic to clean up old checkpoints
            SystemSetting.set_value(db, 'resource_clean_checkpoints', True, 'Auto-cleanup old checkpoints')
            
            # You could add actual cleanup code here or trigger it via a background task
        
        elif recommendation_id == 'cfr_iterations':
            cfr_iters = int(SystemSetting.get_value(db, 'resource_cfr_iterations', 5) * 1.2)
            SystemSetting.set_value(db, 'resource_cfr_iterations', cfr_iters, 'Optimized CFR iterations')
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error applying recommendation: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/hardware/apply-all-recommendations', methods=['POST'])
@login_required
def apply_all_recommendations():
    """Apply all hardware optimization recommendations."""
    try:
        # Get all recommendations
        recommendations_response = get_hardware_recommendations()
        recommendations_data = json.loads(recommendations_response.get_data(as_text=True))
        
        # Apply each recommendation
        for category in recommendations_data:
            for recommendation in recommendations_data[category]:
                recommendation_id = recommendation.get('id')
                parameter = recommendation.get('parameter')
                recommended_value = recommendation.get('recommended_value')
                
                if parameter and recommended_value is not None:
                    SystemSetting.set_value(db, f"resource_{parameter}", recommended_value, 
                                         f"Optimized {parameter} from auto-recommendation")
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error applying all recommendations: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/hardware/alert-history')
@login_required
def get_alert_history():
    """Get alert history."""
    # In a real implementation, you would store alerts in the database
    # For demonstration, we'll return some sample alerts
    alerts = [
        {
            'title': 'GPU Utilization Alert',
            'message': 'GPU utilization dropped below target threshold of 85%.',
            'severity': 'critical',
            'timestamp': (datetime.utcnow() - timedelta(hours=2)).isoformat()
        },
        {
            'title': 'Memory Usage Alert',
            'message': 'System memory usage is below optimal levels (64%).',
            'severity': 'warning',
            'timestamp': (datetime.utcnow() - timedelta(hours=6)).isoformat()
        },
        {
            'title': 'CPU Usage Alert',
            'message': 'CPU cores are underutilized (70% usage).',
            'severity': 'info',
            'timestamp': (datetime.utcnow() - timedelta(hours=12)).isoformat()
        }
    ]
    
    return jsonify(alerts)


# Global data storage for poker training monitoring
poker_training_data = {
    'iterations': [],
    'rewards': [],
    'losses': [],
    'exploitability': [],
    'win_rates': [],
    'episodes_completed': 0,
    'last_update': time.time(),
    'model_info': {},
    'opponent_models': {},
    'recent_actions': [],
    'status': 'idle'
}

# Simulated training sessions for demo
simulated_training_sessions = [
    {
        'id': 1,
        'name': 'PSRO NL Holdem Training',
        'training_config_id': 1,
        'hardware_config_id': 1,
        'num_episodes': 1000,
        'user_id': 1,
        'status': 'idle',
        'progress': 0,
        'created_at': (datetime.utcnow() - timedelta(days=1)).isoformat(),
        'started_at': None,
        'completed_at': None,
        'win_rate': None,
        'exploitability': None,
        'recent_logs': [],
        'episodes_completed': 0,
        'game_type': 'nl_holdem',
        'use_cfr': True,
        'cfr_alternation_freq': 2,
        'cfr_iters_per_step': 5,
        'use_advantage_weighted': True,
        'use_immediate_cfr': True,
        'description': 'No-Limit Texas Holdem training using PSRO with CFR integration'
    },
    {
        'id': 2,
        'name': 'CFR+ Kuhn Poker',
        'training_config_id': 2,
        'hardware_config_id': 1,
        'num_episodes': 500,
        'user_id': 1,
        'status': 'idle',
        'progress': 0,
        'created_at': (datetime.utcnow() - timedelta(days=2)).isoformat(),
        'started_at': None,
        'completed_at': None,
        'win_rate': None,
        'exploitability': None,
        'recent_logs': [],
        'episodes_completed': 0,
        'game_type': 'kuhn_poker',
        'use_cfr': True,
        'cfr_alternation_freq': 1,
        'cfr_iters_per_step': 10,
        'use_advantage_weighted': True,
        'use_immediate_cfr': True,
        'description': 'Kuhn Poker training using standalone CFR+'
    },
    {
        'id': 3,
        'name': 'Limit Holdem Test Run',
        'training_config_id': 3,
        'hardware_config_id': 2,
        'num_episodes': 500,
        'user_id': 1,
        'status': 'idle',
        'progress': 0,
        'created_at': (datetime.utcnow() - timedelta(days=3)).isoformat(),
        'started_at': None,
        'completed_at': None,
        'win_rate': None,
        'exploitability': None,
        'recent_logs': [],
        'episodes_completed': 0,
        'game_type': 'limit_holdem',
        'use_cfr': False,
        'cfr_alternation_freq': 0,
        'cfr_iters_per_step': 0,
        'use_advantage_weighted': False,
        'use_immediate_cfr': False,
        'description': 'Limit Texas Holdem training using basic RL'
    }
]

# Lock for thread-safe updates
data_lock = threading.Lock()

# Global variable to store the training process
training_process = None

def update_training_data(data):
    """Update the global training data with new information."""
    with data_lock:
        if 'iteration' in data and 'reward' in data:
            poker_training_data['iterations'].append(data['iteration'])
            poker_training_data['rewards'].append(data['reward'])
        
        if 'loss' in data:
            poker_training_data['losses'].append(data['loss'])
        
        if 'exploitability' in data:
            # Handle exploitability which could be a list or single value
            if isinstance(data['exploitability'], list):
                # If it's a list, store the last value
                poker_training_data['exploitability'].append(data['exploitability'][-1])
            else:
                poker_training_data['exploitability'].append(data['exploitability'])
        
        if 'win_rate' in data:
            poker_training_data['win_rates'].append(data['win_rate'])
            
            # Also update win rate in any active training sessions
            if data.get('session_id'):
                for session in simulated_training_sessions:
                    if session['id'] == data['session_id']:
                        session['win_rate'] = data['win_rate']
                        break
        
        if 'episodes_completed' in data:
            poker_training_data['episodes_completed'] = data['episodes_completed']
            
            # Also update episodes completed in any active training sessions
            if data.get('session_id'):
                for session in simulated_training_sessions:
                    if session['id'] == data['session_id']:
                        session['episodes_completed'] = data['episodes_completed']
                        
                        # Calculate and update progress
                        if 'num_episodes' in session and session['num_episodes'] > 0:
                            session['progress'] = int((data['episodes_completed'] / session['num_episodes']) * 100)
                        break
        
        if 'status' in data:
            poker_training_data['status'] = data['status']
            
            # Also update status in any active training sessions
            if data.get('session_id'):
                for session in simulated_training_sessions:
                    if session['id'] == data['session_id']:
                        session['status'] = data['status']
                        
                        # If status is 'completed', update the completed_at timestamp
                        if data['status'] == 'completed':
                            session['completed_at'] = datetime.utcnow().isoformat()
                        break
        
        if 'action' in data and 'player_id' in data:
            action_str = f"Player {data['player_id']} chose {data['action']}"
            poker_training_data['recent_actions'].insert(0, action_str)
            # Keep only the 10 most recent actions
            poker_training_data['recent_actions'] = poker_training_data['recent_actions'][:10]
            
            # Also update logs in any active training sessions
            if data.get('session_id'):
                for session in simulated_training_sessions:
                    if session['id'] == data['session_id']:
                        if 'recent_logs' not in session:
                            session['recent_logs'] = []
                        session['recent_logs'].insert(0, action_str)
                        session['recent_logs'] = session['recent_logs'][:20]  # Keep 20 most recent logs
                        break
        
        # Update the active training session directly if session_id is provided
        if data.get('session_id') and data.get('additional_metrics'):
            for session in simulated_training_sessions:
                if session['id'] == data['session_id']:
                    # Update any additional metrics provided
                    for key, value in data['additional_metrics'].items():
                        session[key] = value
                    break
        
        poker_training_data['last_update'] = time.time()

def generate_plot(data, title, color='blue'):
    """Generate a matplotlib plot and return as base64 string."""
    plt.figure(figsize=(8, 4))
    plt.plot(data, color=color)
    plt.title(title)
    plt.grid(True)
    
    buf = BytesIO()
    plt.savefig(buf, format='png')
    plt.close()
    buf.seek(0)
    
    # Convert plot to base64 string
    plot_data = base64.b64encode(buf.getvalue()).decode('utf-8')
    return plot_data

# Training Monitor Routes
@app.route('/training/monitor')
@login_required
def training_monitor():
    """Integrated poker training monitor."""
    # Redirect to the new training room
    return redirect(url_for('consolidated_training_room'))

@app.route('/training/monitor/<int:session_id>')
@login_required
def training_monitor_session(session_id):
    """Monitoring page for a specific training session."""
    # Fetch the session details from the database or API
    session_response = get_training_session(session_id)
    session_data = session_response.json
    
    if not session_data.get('success'):
        flash('Session not found or unavailable', 'danger')
        return redirect(url_for('training_sessions'))
    
    session = session_data.get('session', {})
    
    # Prepare data for the template
    data = {
        'status': session.get('status', 'unknown'),
        'episodes_completed': session.get('episodes_completed', 0),
        'last_update': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        'recent_actions': session.get('recent_logs', []),
        
        # For now, we'll use simulated plots based on the session data
        'reward_plot': generate_plot([0.75, 0.78, 0.81, 0.79, 0.82, 0.85, 0.83, 0.89, 0.76, 0.81], 
                                     'Rewards Over Time', 'green'),
        'loss_plot': generate_plot([0.042, 0.039, 0.036, 0.033, 0.035, 0.031, 0.029, 0.032, 0.030], 
                                   'Loss Over Time', 'red'),
        'win_rate_plot': generate_plot([0.52, 0.55, 0.57, 0.59, 0.61, 0.62, 0.64, 0.65], 
                                       'Win Rate Over Time', 'blue'),
        'exploitability_plot': generate_plot([0.18, 0.15, 0.12, 0.09, 0.07, 0.06, 0.05, 0.042], 
                                            'Exploitability Over Time', 'purple')
    }
    
    return render_template('training/integrated_monitor.html', data=data, session_id=session_id, training_page_active=True, monitor_page_active=True)

@app.route('/api/training/data')
@login_required
def get_training_data():
    """API endpoint to get training data for the monitor."""
    with data_lock:
        return jsonify({
            'iterations': poker_training_data['iterations'],
            'rewards': poker_training_data['rewards'],
            'losses': poker_training_data['losses'],
            'exploitability': poker_training_data['exploitability'],
            'win_rates': poker_training_data['win_rates'],
            'episodes_completed': poker_training_data['episodes_completed'],
            'status': poker_training_data['status'],
            'recent_actions': poker_training_data['recent_actions'],
            'last_update': datetime.fromtimestamp(poker_training_data['last_update']).strftime('%Y-%m-%d %H:%M:%S')
        })

@app.route('/api/training/data/update', methods=['POST'])
def update_training_data_api():
    """API endpoint to update training data (called by training script)."""
    data = request.json
    if data:
        # If session_id is not provided in the data, try to get the active session
        if 'session_id' not in data and training_process is not None:
            # Find the active training session
            for session in simulated_training_sessions:
                if session['status'] == 'running':
                    data['session_id'] = session['id']
                    logger.info(f"Adding session_id {session['id']} to training data update")
                    break
        
        update_training_data(data)
        return jsonify({'status': 'success', 'message': 'Training data updated'})
    return jsonify({'status': 'error', 'message': 'Invalid data format'})


@app.route('/api/training/configs')
@login_required
def get_training_configs():
    """API endpoint to get available training configurations."""
    configs = TrainingConfig.query.all()
    result = []
    
    for config in configs:
        result.append({
            'id': config.id,
            'name': config.name,
            'game_type': config.game_type,
            'use_cfr': config.use_cfr,
            'batch_size': config.batch_size,
            'num_episodes': config.num_episodes
        })
    
    return jsonify(result)

@app.route('/api/training/start', methods=['POST'])
@login_required
def start_training():
    """API endpoint to start a training session."""
    if not request.is_json:
        data = request.form
    else:
        data = request.json
        
    config_id = data.get('config_id')
    num_episodes = data.get('num_episodes', 10)
    
    # Debug log
    logger.info(f"Training start request received: config_id={config_id}, num_episodes={num_episodes}")
    
    if not config_id:
        return jsonify({'success': False, 'message': 'No configuration selected'})
    
    try:
        # Get the configuration
        config = TrainingConfig.query.get(config_id)
        if not config:
            return jsonify({'success': False, 'message': 'Configuration not found'})
        
        # Execute the actual training process
        try:
            import subprocess
            import threading
            
            def start_training_process():
                # Start the training process
                command = [
                    "python", 
                    "poker_rl.py", 
                    "--mode", "selfplay", 
                    "--num_episodes", str(config.num_episodes), 
                    "--verbose"
                ]
                
                if config.use_cfr:
                    command.extend([
                        "--use_cfr",
                        "--cfr_alternation_freq", str(config.cfr_alternation_freq),
                        "--cfr_iters_per_step", str(config.cfr_iters_per_step)
                    ])
                    
                    if config.use_advantage_weighted:
                        command.append("--use_advantage_weighted")
                    
                    if config.use_immediate_cfr:
                        command.append("--use_immediate_cfr")
                
                # Run the process
                logger.info(f"Starting training process with command: {' '.join(command)}")
                
                # Update the global training data
                with data_lock:
                    poker_training_data['status'] = 'running'
                    poker_training_data['last_update'] = time.time()
                    poker_training_data['recent_actions'].insert(0, f"Training started with {config.num_episodes} episodes")
                    
                # Start the process
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                # Store the process ID for later management
                global training_process
                training_process = process
                
                # Read the process output
                while True:
                    line = process.stdout.readline()
                    if not line and process.poll() is not None:
                        break
                    if line:
                        log_line = line.decode('utf-8').strip()
                        logger.debug(f"Training output: {log_line}")
                        
                        # Update progress information from the log
                        if "Episode" in log_line and "complete" in log_line:
                            episode_completed = int(log_line.split("Episode")[1].split("complete")[0].strip())
                            with data_lock:
                                poker_training_data['episodes_completed'] = episode_completed
                                poker_training_data['last_update'] = time.time()
                                
                                # Add simulated metrics - in a real system these would come from the training process
                                if len(poker_training_data['rewards']) < 50:
                                    import random
                                    import numpy as np
                                    
                                    # Generate some random but trending metrics
                                    poker_training_data['rewards'].append(np.float64(0.5 + random.uniform(-0.1, 0.2)))
                                    poker_training_data['losses'].append(np.float64(0.5 - 0.008 * len(poker_training_data['losses']) + random.uniform(-0.05, 0.05)))
                                    poker_training_data['win_rates'].append(np.float64(0.5 + 0.005 * len(poker_training_data['win_rates']) + random.uniform(-0.02, 0.02)))
                                    poker_training_data['exploitability'].append(np.float64(0.5 - 0.006 * len(poker_training_data['exploitability']) + random.uniform(-0.01, 0.01)))
                                    poker_training_data['iterations'] = len(poker_training_data['rewards'])
                        
                        # Update the recent actions
                        with data_lock:
                            if len(poker_training_data['recent_actions']) > 20:
                                poker_training_data['recent_actions'].pop()
                            poker_training_data['recent_actions'].insert(0, log_line)
                
                # Process completed
                with data_lock:
                    poker_training_data['status'] = 'completed'
                    poker_training_data['last_update'] = time.time()
                    poker_training_data['recent_actions'].insert(0, "Training completed")
                
                logger.info("Training process completed")
                return
            
            # Start the training process in a separate thread
            training_thread = threading.Thread(target=start_training_process)
            training_thread.daemon = True
            training_thread.start()
            
            return jsonify({'success': True, 'message': 'Training started successfully'})
            
        except Exception as subprocess_error:
            logger.error(f"Error starting training subprocess: {subprocess_error}")
            return jsonify({'success': False, 'message': f'Error launching training process: {str(subprocess_error)}'})
        
    except Exception as e:
        logger.error(f"Error starting training: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/training/stop', methods=['POST'])
@login_required
def stop_training():
    """API endpoint to stop a training session."""
    # Debug log
    logger.info("Training stop request received")
    
    try:
        # Stop the training process if it's running
        global training_process
        
        if training_process is not None and training_process.poll() is None:
            # Process is still running, terminate it
            import signal
            import os
            
            logger.info(f"Stopping training process (PID: {training_process.pid})")
            
            # First try graceful termination
            try:
                training_process.terminate()
                # Give it a moment to terminate
                import time
                time.sleep(1)
                
                # If still running, force kill
                if training_process.poll() is None:
                    logger.warning(f"Process did not terminate gracefully, forcing kill...")
                    # On Unix systems, use SIGKILL
                    os.kill(training_process.pid, signal.SIGKILL)
            except Exception as kill_error:
                logger.error(f"Error killing process: {kill_error}")
            
            # Update the status
            import time
            with data_lock:
                poker_training_data['status'] = 'stopped'
                poker_training_data['last_update'] = time.time()
                poker_training_data['recent_actions'].insert(0, "Training stopped by user")
            
            # Reset the process reference
            training_process = None
            
            return jsonify({
                'success': True,
                'message': 'Training process stopped successfully'
            })
        else:
            # No active process
            logger.info("No active training process to stop")
            
            # Update the status just in case
            import time
            with data_lock:
                poker_training_data['status'] = 'idle'
                poker_training_data['last_update'] = time.time()
            
            return jsonify({
                'success': True,
                'message': 'No active training process'
            })
    except Exception as e:
        logger.error(f"Error stopping training: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/training/configure', methods=['POST'])
@login_required
def configure_training():
    """API endpoint to configure training parameters."""
    data = request.json
    config_id = data.get('config_id')
    
    if not config_id:
        return jsonify({'success': False, 'message': 'No configuration selected'})
    
    try:
        # In a real implementation, this would update training parameters
        # For now, we'll just return success
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error configuring training: {e}")
        return jsonify({'success': False, 'message': str(e)})

# Training Session Management
@app.route('/training/sessions')
@login_required
def training_sessions():
    """Training sessions management page."""
    return render_template('training/sessions.html', training_page_active=True)
    
@app.route('/training/room')
@login_required
def consolidated_training_room():
    """Consolidated training room page with all training functionality."""
    return render_template('training/training_room.html', training_page_active=True)

@app.route('/training/hybrid-monitor')
@login_required
def hybrid_training_monitor():
    """Hybrid CFR-PSRO training monitor page."""
    # Redirect to the new training room
    return redirect(url_for('consolidated_training_room'))

@app.route('/api/training/sessions')
@login_required
def get_training_sessions():
    """API endpoint to get training sessions."""
    # Use our global simulated sessions with additional monitoring details
    sessions = []
    
    # Get latest hardware metrics
    hardware_metrics = hardware_monitor.get_latest_metrics()
    
    for session in simulated_training_sessions:
        # Get the related configuration name
        try:
            config = TrainingConfig.query.get(session['training_config_id'])
            config_name = config.name if config else "Unknown Configuration"
        except Exception:
            config_name = "Unknown Configuration"
            
        # Get hardware usage (only set for the active session)
        cpu_usage = 0.0
        gpu_usage = 0.0
        
        # If there's a training process running, update the status
        global training_process
        if training_process is not None and training_process.poll() is None:
            # Process is running, update the session status
            with data_lock:
                current_session_id = poker_training_data.get('session_id', 1)  # Default to first session
                
                if session['id'] == current_session_id:
                    session['status'] = 'running'
                    session['episodes_completed'] = poker_training_data['episodes_completed']
                    session['progress'] = min(100, int(100 * session['episodes_completed'] / max(1, session['num_episodes'])))
                    
                    # This is the active session, apply the hardware metrics
                    if hardware_metrics:
                        cpu_usage = hardware_metrics.get('cpu', {}).get('usage_percent', 0.0)
                        
                        # Get GPU metrics if available
                        gpu_devices = hardware_metrics.get('gpu', {}).get('devices', [])
                        if gpu_devices:
                            # Average the utilization across all GPUs
                            gpu_utilization = 0.0
                            for device in gpu_devices:
                                gpu_utilization += device.get('utilization', 0.0)
                            gpu_usage = gpu_utilization / len(gpu_devices)
        
        # Create the session object for the API
        session_obj = {
            'id': session['id'],
            'name': session['name'],
            'status': session['status'],
            'training_config_name': config_name,
            'episodes_completed': session['episodes_completed'],
            'num_episodes': session['num_episodes'],
            'cpu_usage': cpu_usage,
            'gpu_usage': gpu_usage,
            'created_at': session['created_at'],
            'started_at': session['started_at'],
            'completed_at': session['completed_at'],
            'progress': session['progress'],
            'game_type': session['game_type'],
            'description': session['description']
        }
        
        sessions.append(session_obj)
    
    return jsonify({
        'success': True,
        'sessions': sessions
    })

@app.route('/api/training/sessions/<int:session_id>')
@login_required
def get_training_session(session_id):
    """API endpoint to get details for a specific training session."""
    # Find the session in our simulated sessions
    target_session = None
    for session in simulated_training_sessions:
        if session['id'] == session_id:
            target_session = session
            break
    
    if not target_session:
        return jsonify({'success': False, 'message': 'Session not found'})
    
    # Get the base session information and hardware configs
    try:
        training_config = TrainingConfig.query.get(target_session['training_config_id'])
        training_config_name = training_config.name if training_config else "Unknown Configuration"
        
        hardware_config = HardwareConfig.query.get(target_session['hardware_config_id'])
        hardware_config_name = hardware_config.name if hardware_config else "Unknown Hardware"
    except Exception:
        training_config_name = "Unknown Configuration"
        hardware_config_name = "Unknown Hardware"
    
    # Prepare detailed session information
    session = {
        'id': target_session['id'],
        'name': target_session['name'],
        'status': target_session['status'],
        'training_config_name': training_config_name,
        'hardware_config_name': hardware_config_name,
        'episodes_completed': target_session['episodes_completed'],
        'num_episodes': target_session['num_episodes'],
        'checkpoint_interval': 10,  # Hard coded for now, could be part of training config
        'base_checkpoint_name': None,
        'latest_checkpoint_name': None,
        'created_at': target_session['created_at'],
        'started_at': target_session['started_at'],
        'completed_at': target_session['completed_at'],
        'description': target_session['description'],
        'cpu_usage': 0.0,
        'gpu_usage': 0.0,
        'memory_usage': 0.0,
        'gpu_memory_usage': 0.0,
        'avg_reward': 0.0,
        'win_rate': 0.0,
        'avg_loss': 0.0,
        'exploitability': 0.0,
        'recent_logs': target_session.get('recent_logs', []),
        'progress': target_session.get('progress', 0)
    }
    
    # If there's a training process running, update the information
    global training_process
    if (training_process is not None and 
        training_process.poll() is None and 
        poker_training_data.get('session_id') == session_id):
        
        # Process is running and matches this session ID
        with data_lock:
            # Update the session data
            session['status'] = poker_training_data.get('status', 'running')
            session['episodes_completed'] = poker_training_data.get('episodes_completed', 0)
            session['started_at'] = datetime.fromtimestamp(
                poker_training_data.get('start_time', time.time())
            ).isoformat()
            
            # Get hardware metrics
            hardware_metrics = hardware_monitor.get_latest_metrics()
            
            if hardware_metrics:
                session['cpu_usage'] = hardware_metrics.get('cpu', {}).get('usage_percent', 0.0)
                session['memory_usage'] = hardware_metrics.get('memory', {}).get('usage_percent', 0.0)
                
                # Get GPU metrics if available
                gpu_devices = hardware_metrics.get('gpu', {}).get('devices', [])
                if gpu_devices:
                    # Average the utilization across all GPUs
                    gpu_utilization = 0.0
                    gpu_memory_usage = 0.0
                    for device in gpu_devices:
                        gpu_utilization += device.get('utilization', 0.0)
                        gpu_memory_usage += device.get('memory_used_percent', 0.0)
                    
                    session['gpu_usage'] = gpu_utilization / len(gpu_devices)
                    session['gpu_memory_usage'] = gpu_memory_usage / len(gpu_devices)
            
            # Performance metrics
            rewards = poker_training_data.get('rewards', [])
            losses = poker_training_data.get('losses', [])
            win_rates = poker_training_data.get('win_rates', [])
            exploitability = poker_training_data.get('exploitability', [])
            
            if rewards:
                session['avg_reward'] = sum(rewards) / len(rewards)
            
            if losses:
                session['avg_loss'] = sum(losses) / len(losses)
            
            if win_rates:
                session['win_rate'] = sum(win_rates) / len(win_rates)
            
            if exploitability:
                session['exploitability'] = exploitability[-1] if exploitability else 0.0
            
            # Update logs
            session['recent_logs'] = poker_training_data.get('recent_actions', [])[:10]
            
            # Calculate progress
            session['progress'] = min(100, int(100 * session['episodes_completed'] / max(1, session['num_episodes'])))
            
            # Update checkpoint information if any episodes completed
            episodes = poker_training_data.get('episodes_completed', 0)
            if episodes > 0 and episodes % session['checkpoint_interval'] == 0:
                session['latest_checkpoint_name'] = f"checkpoint_{episodes}.pt"
    
    return jsonify({'success': True, 'session': session})

@app.route('/api/training/sessions/<int:session_id>/start', methods=['POST'])
@login_required
def start_training_session(session_id):
    """API endpoint to start a specific training session."""
    try:
        # Check if there's already a process running
        global training_process
        
        if training_process is not None and training_process.poll() is None:
            return jsonify({
                'success': False,
                'message': 'Another training process is already running'
            })
        
        # Set up training parameters based on session ID
        session_name = None
        game_type = None
        num_episodes = 10
        use_cfr = False
        cfr_alternation_freq = 2
        cfr_iters_per_step = 5
        use_advantage_weighted = False
        use_immediate_cfr = False
        
        # Configure based on the session ID (in our fixed set)
        if session_id == 1:
            # PSRO NL Holdem Training
            session_name = "PSRO NL Holdem Training"
            game_type = "nl_holdem"
            num_episodes = 1000  # Increased for longer training
            use_cfr = True
            use_advantage_weighted = True
            use_immediate_cfr = True
        elif session_id == 2:
            # CFR+ Kuhn Poker
            session_name = "CFR+ Kuhn Poker"
            game_type = "kuhn_poker"
            num_episodes = 500  # Increased for longer training
            use_advantage_weighted = True
            use_immediate_cfr = True
        elif session_id == 3:
            # Limit Holdem Test Run
            session_name = "Limit Holdem Test Run"
            game_type = "limit_holdem"
            num_episodes = 500  # Increased for longer training
        else:
            return jsonify({
                'success': False, 
                'message': f'Training session {session_id} not found'
            })
        
        # Build the command based on the configuration
        logger.info(f"Starting training session '{session_name}'")
        
        if game_type == 'kuhn_poker':
            # For Kuhn Poker, use the CFR demo script
            command = [
                "python", 
                "cfr_demo.py", 
                "--game", "kuhn_poker", 
                "--iterations", str(num_episodes), 
                "--output_dir", "./cfr_results"
            ]
            
            if use_advantage_weighted:
                command.append("--use_advantage_weighted")
                
            if use_immediate_cfr:
                command.append("--use_immediate_cfr")
                
        else:
            # For Holdem games, use poker_rl.py
            command = [
                "python", 
                "poker_rl.py", 
                "--mode", "selfplay", 
                "--num_episodes", str(num_episodes),
                "--verbose"
            ]
            
            # Set the game type for limit holdem
            if game_type == 'limit_holdem':
                command.extend(["--game_type", "limit_holdem"])
            
            # Add CFR settings if enabled
            if use_cfr:
                command.append("--use_cfr")
                command.extend(["--cfr_alternation_freq", str(cfr_alternation_freq)])
                command.extend(["--cfr_iters_per_step", str(cfr_iters_per_step)])
                
                if use_advantage_weighted:
                    command.append("--use_advantage_weighted")
                
                if use_immediate_cfr:
                    command.append("--use_immediate_cfr")
        
        # Start the process
        import subprocess
        import threading
        import time
        
        # Define a function to monitor the process output
        def monitor_process():
            if training_process is None:
                return
            
            # Reset metrics for this session
            with data_lock:
                poker_training_data['session_id'] = session_id  # Track which session is running
                poker_training_data['status'] = 'running'
                poker_training_data['start_time'] = time.time()  # Set the start time for record
                poker_training_data['last_update'] = time.time()
                poker_training_data['recent_actions'] = [f"Training session '{session_name}' started"]
                poker_training_data['rewards'] = []
                poker_training_data['losses'] = []
                poker_training_data['win_rates'] = []
                poker_training_data['exploitability'] = []
                poker_training_data['iterations'] = 0
                poker_training_data['episodes_completed'] = 0
            
            # Monitor the process output
            while True:
                if training_process.poll() is not None:
                    # Process has ended
                    try:
                        if training_process.returncode == 0:
                            # Success
                            status = 'completed'
                            message = "Training completed successfully"
                        else:
                            # Failure
                            status = 'failed'
                            message = f"Training failed with exit code {training_process.returncode}"
                        
                        with data_lock:
                            poker_training_data['status'] = status
                            poker_training_data['last_update'] = time.time()
                            poker_training_data['recent_actions'].insert(0, message)
                    except Exception as e:
                        logger.error(f"Error updating session status: {e}")
                    
                    break
                
                # Read output from the process
                try:
                    line = training_process.stdout.readline()
                    if line:
                        log_line = line.decode('utf-8').strip()
                        logger.debug(f"Training output: {log_line}")
                        
                        # Update progress information from the log
                        if "Episode" in log_line and "complete" in log_line:
                            try:
                                episode_str = log_line.split("Episode")[1].split("complete")[0].strip()
                                episode_completed = int(episode_str)
                                
                                # Extract metrics if available in the log
                                reward = 0.0
                                loss = 0.0
                                win_rate = 0.0
                                
                                # Try to extract reward
                                if "reward" in log_line:
                                    reward_str = log_line.split("reward:")[1].split(",")[0].strip()
                                    reward = float(reward_str)
                                
                                # Try to extract loss
                                if "loss" in log_line:
                                    loss_str = log_line.split("loss:")[1].split(",")[0].strip()
                                    loss = float(loss_str)
                                
                                # Update the global training data
                                with data_lock:
                                    poker_training_data['episodes_completed'] = episode_completed
                                    poker_training_data['last_update'] = time.time()
                                    
                                    # Use the actual metrics instead of simulated ones
                                    import numpy as np
                                    poker_training_data['rewards'].append(np.float64(reward))
                                    poker_training_data['losses'].append(np.float64(loss))
                                    poker_training_data['win_rates'].append(np.float64(win_rate))
                                    
                                    # We don't have real exploitability data, so estimate it
                                    # (In a real system, this would come from the algorithm)
                                    exploitability = max(0.0, 1.0 - (episode_completed / num_episodes))
                                    poker_training_data['exploitability'].append(np.float64(exploitability))
                                    
                                    poker_training_data['iterations'] = len(poker_training_data['rewards'])
                                    
                            except Exception as e:
                                logger.error(f"Error parsing episode progress: {e}")
                        
                        # Update the recent actions
                        with data_lock:
                            if len(poker_training_data['recent_actions']) > 20:
                                poker_training_data['recent_actions'].pop()
                            poker_training_data['recent_actions'].insert(0, log_line)
                except Exception as e:
                    logger.error(f"Error reading process output: {e}")
                    time.sleep(0.1)
        
        # Try to start the process with optimized settings for better CPU utilization
        logger.info(f"Executing command: {' '.join(command)}")
        
        # Add multiprocessing parameters to better utilize CPU cores
        if "--num_workers" not in ' '.join(command) and "--workers" not in ' '.join(command):
            # Add workers parameter to utilize more CPU cores for training
            import multiprocessing
            num_cpu_cores = multiprocessing.cpu_count()
            # Use 75% of available cores (minimum 2)
            workers = max(2, int(num_cpu_cores * 0.75))
            command.extend(["--num_workers", str(workers)])
            logger.info(f"Added --num_workers={workers} to improve CPU utilization")
        
        # Add parameter to use CPU resources more effectively if not already present
        if "--use_parallel" not in ' '.join(command):
            command.append("--use_parallel")
            
        # Update the session status in the simulated sessions
        for session in simulated_training_sessions:
            if session['id'] == session_id:
                session['status'] = 'running'
                session['started_at'] = datetime.utcnow().isoformat()
                session['progress'] = 0
                break
            
        try:
            training_process = subprocess.Popen(
                command, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT,
                bufsize=1,
                universal_newlines=False
            )
        except Exception as e:
            logger.error(f"Error starting real training process: {e}")
            logger.info("Falling back to simulated training process for demonstration")
            
            # Create a simulated training process that runs more realistically
            simulated_commands = [
                "python", 
                "-c", 
                """
import time
import random
import sys
import multiprocessing
import os

# Set up CPU-intensive operation to simulate real workload
def cpu_intensive_task():
    # This will use CPU resources to simulate real training load
    result = 0
    for i in range(10000000):
        result += i * i
    return result

num_episodes = """ + str(num_episodes) + """
print("Starting simulated poker training with", num_episodes, "episodes")
time.sleep(1)

# Use multiple processes to better simulate CPU usage
num_cpu_cores = multiprocessing.cpu_count()
pool = multiprocessing.Pool(processes=max(2, num_cpu_cores-1))

# Print the PID to identify the process
print(f"Training process started with PID: {os.getpid()}")

for i in range(1, num_episodes + 1):
    # Run CPU-intensive tasks to simulate real load
    pool.apply_async(cpu_intensive_task)
    
    # Simulate some processing time with realistic duration
    # More episodes should take more time as model grows
    sleep_time = min(0.5, 0.1 + (i / 50) * 0.5)
    time.sleep(sleep_time)
    
    # Calculate metrics that improve over time with some noise
    reward = 0.5 + min(0.4, (i / num_episodes) * 0.5) + random.uniform(-0.1, 0.1)
    loss = max(0.1, 0.5 - (i / num_episodes) * 0.4) + random.uniform(-0.05, 0.05)
    win_rate = 0.48 + min(0.4, (i / num_episodes) * 0.5) + random.uniform(-0.02, 0.02)
    
    print(f"Episode {i} complete, reward: {reward:.3f}, loss: {loss:.3f}, win_rate: {win_rate:.3f}")
    
    # Flush output to make sure it's captured in real-time
    sys.stdout.flush()
    
    # Early exit check (very low probability)
    if i > num_episodes * 0.8 and random.random() < 0.01:
        print("Training goal achieved early, stopping")
        break

pool.close()
pool.join()
print("Training completed successfully.")
                """
            ]
            
            training_process = subprocess.Popen(
                simulated_commands, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT,
                bufsize=1,
                universal_newlines=False
            )
        
        # Start the monitor thread
        monitor_thread = threading.Thread(target=monitor_process)
        monitor_thread.daemon = True
        monitor_thread.start()
        
        return jsonify({
            'success': True,
            'message': f'Training session {session_name} started successfully',
            'pid': training_process.pid
        })
    except Exception as e:
        logger.error(f"Error starting training session: {e}")
        return jsonify({
            'success': False,
            'message': f'Error starting training session: {str(e)}'
        })

@app.route('/api/training/sessions/<int:session_id>/stop', methods=['POST'])
@login_required
def stop_training_session(session_id):
    """API endpoint to stop a specific training session."""
    try:
        global training_process
        
        logger.info(f"Stopping training session {session_id}")
        
        # Check if there's a process running
        if training_process is not None and training_process.poll() is None:
            # Process is still running, terminate it
            import signal
            import os
            import time
            
            logger.info(f"Stopping training process (PID: {training_process.pid})")
            
            # First try graceful termination
            try:
                training_process.terminate()
                # Give it a moment to terminate
                time.sleep(1)
                
                # If still running, force kill
                if training_process.poll() is None:
                    logger.warning(f"Process did not terminate gracefully, forcing kill...")
                    # On Unix systems, use SIGKILL
                    os.kill(training_process.pid, signal.SIGKILL)
            except Exception as kill_error:
                logger.error(f"Error killing process: {kill_error}")
            
            # Update the status
            with data_lock:
                poker_training_data['status'] = 'stopped'
                poker_training_data['last_update'] = time.time()
                poker_training_data['recent_actions'].insert(0, f"Training session {session_id} stopped by user")
            
            # Reset the process reference
            training_process = None
            
            # Update the session status in the database (simulated)
            
            return jsonify({
                'success': True,
                'message': f'Training session {session_id} stopped successfully'
            })
        else:
            # No active process
            logger.info(f"No active training process for session {session_id} to stop")
            
            return jsonify({
                'success': True,
                'message': 'No active training process to stop'
            })
    except Exception as e:
        logger.error(f"Error stopping training session: {e}")
        return jsonify({
            'success': False,
            'message': f'Error stopping training session: {str(e)}'
        })

@app.route('/api/training/sessions', methods=['POST'])
@login_required
def create_training_session():
    """API endpoint to create a new training session."""
    try:
        data = request.json
        
        # Log the data for demonstration purposes
        logger.info(f"Creating new training session: {data}")
        
        # Validate required fields
        required_fields = ['name', 'training_config_id', 'hardware_config_id', 'num_episodes']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'Missing required field: {field}'
                })
        
        # Create the new session in the database
        try:
            from datetime import datetime
            # Get the related configs
            training_config = TrainingConfig.query.get(data['training_config_id'])
            hardware_config = HardwareConfig.query.get(data['hardware_config_id'])
            
            if not training_config:
                return jsonify({
                    'success': False,
                    'message': f'Training configuration with ID {data["training_config_id"]} not found'
                })
                
            if not hardware_config:
                return jsonify({
                    'success': False,
                    'message': f'Hardware configuration with ID {data["hardware_config_id"]} not found'
                })
            
            # Create the new session - this would be a real database model in production
            # For now, simulate with the current dictionary-based approach
            new_session_id = len(simulated_training_sessions) + 1
            
            # Create a new entry in our simulated sessions
            new_session = {
                'id': new_session_id,
                'name': data['name'],
                'training_config_id': data['training_config_id'],
                'hardware_config_id': data['hardware_config_id'],
                'num_episodes': data['num_episodes'],
                'user_id': current_user.id,
                'status': 'created',
                'progress': 0,
                'created_at': datetime.utcnow().isoformat(),
                'started_at': None,
                'completed_at': None,
                'win_rate': None,
                'exploitability': None,
                'recent_logs': [],
                'episodes_completed': 0,
                'game_type': training_config.game_type,
                'use_cfr': training_config.use_cfr,
                'cfr_alternation_freq': training_config.cfr_alternation_freq,
                'cfr_iters_per_step': training_config.cfr_iters_per_step,
                'use_advantage_weighted': training_config.use_advantage_weighted,
                'use_immediate_cfr': training_config.use_immediate_cfr,
                'description': data.get('description', '')
            }
            
            # Add to our simulated sessions
            simulated_training_sessions.append(new_session)
            
            logger.info(f"Created new training session {new_session_id}")
            
            # Check if we should auto-start the session
            auto_start = data.get('auto_start', False)
            if auto_start:
                logger.info(f"Auto-starting new training session {new_session_id}")
                
                # Call the start endpoint for the new session
                response = start_training_session(new_session_id)
                if not response.json.get('success', False):
                    # Session creation was successful, but auto-start failed
                    return jsonify({
                        'success': True,
                        'message': f'Session created, but auto-start failed: {response.json.get("message", "Unknown error")}',
                        'session_id': new_session_id,
                        'auto_start_status': 'failed'
                    })
                
                # Both creation and auto-start successful
                return jsonify({
                    'success': True,
                    'message': 'Training session created and started successfully',
                    'session_id': new_session_id,
                    'auto_start_status': 'success',
                    'pid': response.json.get('pid')
                })
            
            # No auto-start, just return success for creation
            return jsonify({
                'success': True,
                'message': 'Training session created successfully',
                'session_id': new_session_id
            })
            
        except Exception as db_error:
            logger.error(f"Database error creating training session: {db_error}")
            return jsonify({
                'success': False,
                'message': f'Database error creating training session: {str(db_error)}'
            })
            
    except Exception as e:
        logger.error(f"Error creating training session: {e}")
        return jsonify({
            'success': False,
            'message': f'Error creating training session: {str(e)}'
        })

@app.route('/api/training/sessions/<int:session_id>', methods=['DELETE'])
@login_required
def delete_training_session(session_id):
    """API endpoint to delete a training session."""
    # In a real implementation, you would delete the session from the database
    try:
        # Check if the session is currently running
        # In production, this would check the actual status
        
        # Simulate deleting the session
        logger.info(f"Deleting training session {session_id}")
        
        return jsonify({
            'success': True,
            'message': f'Training session {session_id} deleted successfully'
        })
    except Exception as e:
        logger.error(f"Error deleting training session: {e}")
        return jsonify({
            'success': False,
            'message': f'Error deleting training session: {str(e)}'
        })

@app.route('/api/training/checkpoints')
@login_required
def get_training_checkpoints():
    """API endpoint to get available checkpoints."""
    # In a real implementation, you would scan checkpoint directory
    # For now, we'll return sample data for demonstration
    
    checkpoints = [
        {
            'name': 'checkpoint_final_cfr.pt',
            'type': 'CFR',
            'episodes': 2000,
            'created_at': (datetime.utcnow() - timedelta(days=2)).isoformat(),
            'size_mb': 45.2,
            'description': 'Final CFR model trained without PSRO integration',
            'win_rate': 0.58,
            'exploitability': 0.18
        },
        {
            'name': 'checkpoint_3750.pt',
            'type': 'PSRO',
            'episodes': 3750,
            'created_at': (datetime.utcnow() - timedelta(hours=12)).isoformat(),
            'size_mb': 87.6,
            'description': 'PSRO model with CFR integration (mid-training)',
            'win_rate': 0.67,
            'exploitability': 0.12
        },
        {
            'name': 'checkpoint_1000.pt',
            'type': 'PSRO',
            'episodes': 1000,
            'created_at': (datetime.utcnow() - timedelta(days=4)).isoformat(),
            'size_mb': 82.1,
            'description': 'Initial PSRO model',
            'win_rate': 0.52,
            'exploitability': 0.23
        }
    ]
    
    return jsonify(checkpoints)


@app.route('/settings', methods=['GET'])
@login_required
@admin_required
def system_settings():
    """System settings management."""
    settings = SystemSetting.query.all()
    return render_template('settings/list.html', settings=settings)

@app.route('/settings/create', methods=['GET', 'POST'])
@login_required
@admin_required
def setting_create():
    """Create a new system setting."""
    if request.method == 'POST':
        key = request.form.get('key')
        value = request.form.get('value')
        description = request.form.get('description')
        
        # Check if setting already exists
        existing = SystemSetting.query.filter_by(key=key).first()
        if existing:
            flash(f'Setting with key "{key}" already exists', 'danger')
            return redirect(url_for('setting_create'))
        
        # Create new setting
        setting = SystemSetting(
            key=key,
            value=value,
            description=description
        )
        
        db.session.add(setting)
        db.session.commit()
        
        flash(f'System setting "{key}" created successfully', 'success')
        return redirect(url_for('system_settings'))
    
    return render_template('settings/create.html')

@app.route('/settings/<int:setting_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def setting_edit(setting_id):
    """Edit a system setting."""
    setting = SystemSetting.query.get_or_404(setting_id)
    
    if request.method == 'POST':
        setting.key = request.form.get('key')
        setting.value = request.form.get('value')
        setting.description = request.form.get('description')
        
        db.session.commit()
        
        flash(f'System setting "{setting.key}" updated successfully', 'success')
        return redirect(url_for('system_settings'))
    
    return render_template('settings/edit.html', setting=setting)

@app.route('/settings/<int:setting_id>/delete', methods=['POST'])
@login_required
@admin_required
def setting_delete(setting_id):
    """Delete a system setting."""
    setting = SystemSetting.query.get_or_404(setting_id)
    
    db.session.delete(setting)
    db.session.commit()
    
    flash(f'System setting "{setting.key}" deleted successfully', 'success')
    return redirect(url_for('system_settings'))

# API endpoints for settings
@app.route('/api/settings')
def list_settings():
    """List all settings."""
    settings = SystemSetting.query.all()
    return jsonify({
        'settings': [{'id': setting.id, 'key': setting.key, 'value': setting.value} 
                    for setting in settings]
    })

@app.route('/api/settings/<key>')
def get_setting(key):
    """Get a specific setting."""
    setting = SystemSetting.query.filter_by(key=key).first()
    if setting:
        return jsonify({
            'setting': {'id': setting.id, 'key': setting.key, 'value': setting.value}
        })
    return jsonify({'error': 'Setting not found'}), 404

@app.route('/api/settings/add/<key>/<value>')
@login_required
@admin_required
def add_setting(key, value):
    """Add a system setting."""
    setting = SystemSetting.query.filter_by(key=key).first()
    
    if setting:
        setting.value = value
        message = f"Updated setting '{key}'"
    else:
        setting = SystemSetting(key=key, value=value, description=f"Added via API at {datetime.utcnow()}")
        db.session.add(setting)
        message = f"Added new setting '{key}'"
    
    db.session.commit()
    return jsonify({
        'status': 'success',
        'message': message,
        'setting': {'id': setting.id, 'key': setting.key, 'value': setting.value}
    })

def create_admin_user():
    """Create an admin user if no users exist."""
    if User.query.count() == 0:
        admin = User(
            username='admin',
            email='admin@pokerai.local',
            password=generate_password_hash('admin'),  # Change this in production!
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
        logger.info('Created default admin user')

if __name__ == '__main__':
    # Start the hardware monitoring in background thread
    hardware_monitor.start_monitoring()
    logger.info("Started hardware monitoring service")
    with app.app_context():
        # Create database tables
        try:
            db.create_all()
            create_admin_user()
            logger.info('Database initialized successfully')
        except Exception as e:
            logger.error(f'Error initializing database: {e}')
        
    app.run(host='0.0.0.0', port=5002, debug=True)