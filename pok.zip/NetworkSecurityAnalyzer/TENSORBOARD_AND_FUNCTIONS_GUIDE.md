# TensorBoard and Poker AI Functions Guide

This guide explains how to use TensorBoard for monitoring your Poker AI training and how to use all the main functions of the system.

## Table of Contents
1. [Setting Up TensorBoard](#setting-up-tensorboard)
2. [Training Functions](#training-functions)
3. [Evaluation Functions](#evaluation-functions)
4. [Web Interfaces](#web-interfaces)
5. [System Management](#system-management)
6. [Troubleshooting](#troubleshooting)

## Setting Up TensorBoard

TensorBoard is a visualization tool provided by TensorFlow that allows you to monitor your training progress in real-time with charts and graphs.

### Installing TensorBoard

TensorBoard is included in the requirements.txt file and will be installed automatically when you run the deployment script. If you need to install it manually:

```bash
pip install tensorboard
```

### Starting TensorBoard

To start TensorBoard:

```bash
# Make sure you're in your project directory
cd /path/to/poker_ai

# Activate your virtual environment
source venv/bin/activate

# Start TensorBoard
tensorboard --logdir=runs
```

This will start TensorBoard and make it available at http://localhost:6006 (by default).

### Making TensorBoard Available Remotely

If you want to access TensorBoard from outside your server:

```bash
# Start TensorBoard with specific host
tensorboard --logdir=runs --host 0.0.0.0 --port 6006
```

To add TensorBoard to your Nginx configuration for easy access:

1. Edit your Nginx configuration:
   ```bash
   sudo nano /etc/nginx/sites-available/poker_ai
   ```

2. Add the following location block:
   ```
   location /tensorboard/ {
       proxy_pass http://127.0.0.1:6006/;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection "upgrade";
   }
   ```

3. Reload Nginx:
   ```bash
   sudo nginx -t && sudo service nginx reload
   ```

### Setting Up TensorBoard as a Service

To run TensorBoard as a background service:

1. Create a supervisor configuration:
   ```bash
   sudo nano /etc/supervisor/conf.d/tensorboard.conf
   ```

2. Add the following content:
   ```
   [program:tensorboard]
   command=/path/to/venv/bin/tensorboard --logdir=/path/to/poker_ai/runs --host 0.0.0.0 --port 6006
   directory=/path/to/poker_ai
   user=your_username
   autostart=true
   autorestart=true
   stopasgroup=true
   killasgroup=true
   stdout_logfile=/path/to/poker_ai/logs/tensorboard.log
   stderr_logfile=/path/to/poker_ai/logs/tensorboard_err.log
   ```

3. Update supervisor:
   ```bash
   sudo supervisorctl reread
   sudo supervisorctl update
   sudo supervisorctl start tensorboard
   ```

### Reading TensorBoard Metrics

When you access TensorBoard, you'll see several tabs:

1. **Scalars**: Shows metrics like loss, win rate, reward over time
2. **Graphs**: Neural network architecture
3. **Distributions**: Weights distribution in your models
4. **Histograms**: Changes in weights over time

Key metrics to monitor:
- **training/regret_loss**: Should decrease over time
- **training/strategy_loss**: Should decrease over time
- **training/win_rate**: Should increase over time
- **system/cpu_usage**: Monitor system load
- **system/memory_usage**: Monitor memory usage

## Training Functions

The Poker AI system provides several training functions. Here's how to use them:

### Basic Training

```bash
# Train with default parameters
python poker_rl.py --mode train --num_episodes 100 --num_iterations 10

# Train with more episodes and iterations (longer training)
python poker_rl.py --mode train --num_episodes 500 --num_iterations 50

# Train with verbose logging (more details)
python poker_rl.py --mode train --num_episodes 100 --num_iterations 10 --verbose
```

### Advanced Training Options

```bash
# Train with custom batch size and learning rate
python poker_rl.py --mode train --num_episodes 100 --batch_size 128 --learning_rate 0.0005

# Train with dynamic parameter adjustment (auto-tunes batch size and workers)
python poker_rl.py --mode train --num_episodes 100 --enable_dynamic_adjustment

# Train with mixed precision (faster on compatible GPUs)
python poker_rl.py --mode train --num_episodes 100 --use_mixed_precision
```

### Parameter Adjustment

The system can automatically adjust training parameters based on your hardware:

```bash
# Run non-interactive training with dynamic parameter adjustment
python poker_rl.py --mode train --num_episodes 100 --enable_dynamic_adjustment --non_interactive
```

## Evaluation Functions

After training, you'll want to evaluate your AI:

### Self-Play Mode

```bash
# Run self-play demonstration with verbose output
python poker_rl.py --mode selfplay --num_episodes 10 --verbose
```

### Evaluation Against Different Opponents

```bash
# Evaluate against all built-in opponents
python poker_rl.py --mode eval --num_episodes 50 --eval_opponents random,mccfr,tight_passive,tight_aggressive,loose_passive,loose_aggressive,maniac,calling_station

# Evaluate against specific opponents
python poker_rl.py --mode eval --num_episodes 50 --eval_opponents tight_aggressive,loose_passive
```

## Web Interfaces

The system provides several web interfaces:

### Main Flask App

The main application provides a consolidated interface. Access it at:
```
http://your-server-ip:5010/
```

This interface lets you:
- View training status
- Start/stop training
- Access monitoring dashboard
- Configure system settings

### Web Poker Dashboard

The web poker dashboard provides a more focused interface for poker training:
```
http://your-server-ip:5003/
```

This interface lets you:
- Configure training parameters
- Start training sessions
- View training results
- Monitor model performance

### Monitoring Web

The monitoring web provides real-time system monitoring:
```
http://your-server-ip:5000/
```

This interface lets you:
- Monitor system resources (CPU, memory, GPU)
- View training metrics in real-time
- Check for errors or warnings
- See learning progress

## System Management

Managing the Poker AI system:

### Starting/Stopping Services

Using the deployment script:
```bash
# Start all services
sudo ./deploy_poker_ai.sh start

# Run components manually (for debugging)
sudo ./deploy_poker_ai.sh manual
```

Using Supervisor directly:
```bash
# View status of all services
sudo supervisorctl status

# Start a specific service
sudo supervisorctl start poker_ai_main

# Stop a specific service
sudo supervisorctl stop poker_ai_main

# Restart a specific service
sudo supervisorctl restart poker_ai_main
```

### Testing System Components

Use the test_all_components.py script to verify your system:

```bash
# Run all tests
python test_all_components.py --all

# Test specific components
python test_all_components.py --pytorch --openspiel --fix

# Save test results to a file
python test_all_components.py --all --output test_results.json
```

## Troubleshooting

### TensorBoard Not Showing Data

1. Check if log directory exists:
   ```bash
   ls -la runs/
   ```

2. Verify TensorBoard is running:
   ```bash
   ps aux | grep tensorboard
   ```

3. Check TensorBoard port is open:
   ```bash
   sudo netstat -tuln | grep 6006
   ```

4. Check TensorBoard logs:
   ```bash
   cat logs/tensorboard.log
   ```

### OpenSpiel Player ID=-4 Error

If you encounter the player ID=-4 error in your logs, the fix should be applied automatically. To verify:

1. Check the logs:
   ```bash
   grep "OpenSpiel fix" logs/poker_rl.log
   ```

2. Make sure `fix_openspiel_player_id.py` is being imported in `poker_rl.py`.

### Database Connection Issues

1. Check your database connection:
   ```bash
   echo $DATABASE_URL
   ```

2. Verify PostgreSQL is running:
   ```bash
   sudo systemctl status postgresql
   ```

3. Connect to PostgreSQL manually:
   ```bash
   psql -U poker_user -d poker_ai -h localhost
   ```

### Web Interface Not Loading

1. Check if the service is running:
   ```bash
   sudo supervisorctl status poker_ai_web_menu
   ```

2. Check logs for errors:
   ```bash
   cat logs/web_menu.log
   cat logs/web_menu_err.log
   ```

3. Verify the port is open:
   ```bash
   sudo netstat -tuln | grep 5003
   ```

4. Restart the service:
   ```bash
   sudo supervisorctl restart poker_ai_web_menu
   ```

## Advanced Function Reference

Here are some more advanced functions you might need:

### Creating a New Admin User

```bash
python create_new_admin.py
```

### Running Functional Tests

```bash
python run_functional_tests.py
```

### Visualizing Learning Progress

```bash
python visualize_learning.py
```

### Analyzing Training Results

```bash
python analyze_training.py
```

### Running a Tournament

```bash
python tournament_connector.py
```

### Dynamic Bet Sizing Testing

```bash
python test_dynamic_bets.py
```

## TensorBoard Custom Integration

The Poker AI system integrates TensorBoard in the PSROSolver class. Key points:

1. TensorBoard writer is initialized in `train_psro()` function:
   ```python
   log_dir = os.path.join('runs', 'poker_training', f'run_{int(time.time())}')
   writer = SummaryWriter(log_dir)
   ```

2. Metrics are logged throughout the training process:
   ```python
   writer.add_scalar('training/key', value, iteration)
   ```

3. System metrics are also logged:
   ```python
   writer.add_scalar('system/cpu_usage', psutil.cpu_percent(), iteration)
   ```

4. Model gradients are logged for debugging:
   ```python
   writer.add_histogram(f'gradients/{name}', param.grad, iteration)
   ```

To add your own custom metrics to TensorBoard, modify `train_psro()` function in `poker_rl.py`.