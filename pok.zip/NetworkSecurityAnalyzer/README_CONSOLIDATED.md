# Consolidated Poker AI System

## Overview

This is a consolidated, all-in-one application for the Poker AI training and management system. The application integrates all components into a single Flask app, removing the need to run multiple servers on different ports.

## Features

- **Unified Dashboard**: Main dashboard showing system status and key metrics
- **Monitoring**: Track training progress and system resources
- **Training Room**: Configure and run training sessions
- **Poker Menu**: Easy interface for poker-specific operations
- **Advanced Dashboard**: More detailed system management and configuration
- **Admin Panel**: User and system administration
- **Onboarding Wizard**: First-time setup guide
- **Server Transfer**: Tools for deploying to new servers

## Getting Started

1. Start the consolidated app using:
   ```
   python start_poker_ai.py
   ```

2. Access the application at: 
   ```
   http://localhost:5010/
   ```

## Port Configuration

The application runs on a single port: 5010

## Architecture

The application uses Flask blueprints to organize functionality:

- `/unified` - Unified Dashboard
- `/monitor` - Monitoring Interface
- `/training-room` - Training Management
- `/poker-menu` - Poker Specific Interface
- `/advanced` - Advanced Configuration
- `/admin` - Administrative Interface
- `/onboarding` - Setup Wizard

## How It Works

The consolidated architecture includes:

1. A single Flask application (`main.py`) that loads all blueprints
2. A centralized template structure organized by component
3. A shared static file directory
4. A unified database that all components access

## Legacy Application Support

To ensure backward compatibility with existing scripts that might expect the old port configuration, the system employs routing rules that map legacy URLs to the corresponding endpoints in the consolidated application.

## Stopping Previous Servers

If you previously ran multiple servers, use the included script to stop them:

```
python stop_other_servers.py
```

## Contributing

When adding new features, continue using the blueprint-based architecture to keep the codebase organized and maintainable.