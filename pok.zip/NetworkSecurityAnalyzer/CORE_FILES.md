# Core Files for Poker AI System

These are the essential files you need to transfer to your server for the Poker AI system to work correctly:

## Core System Files
- `main.py` - Main Flask application entry point
- `models.py` - Neural network models and database models
- `psro.py` - Policy Space Response Oracle implementation
- `poker_rl.py` - Main RL training script
- `environment.py` - Environment interface
- `buffer.py` - Experience replay buffer
- `state_processor.py` - State processing utilities
- `config.py` - Configuration settings
- `utils.py` - Utility functions

## Training & Optimization Files
- `cloud_trainer.py` - Distributed training script
- `parameter_adjuster.py` - Auto-tuning for training parameters
- `adaptation_manager.py` - Strategy adaptation management
- `opponent_modeling.py` - Opponent modeling system
- `tensorboard_logger.py` - Training visualization logger
- `fix_openspiel_player_id.py` - OpenSpiel error fix utility

## Web Interfaces
- `admin_dashboard.py` - Admin dashboard
- `advanced_dashboard.py` - Advanced monitoring dashboard
- `web_poker_menu.py` - Web-based training menu
- `monitoring_web.py` - Training monitoring interface
- `easy_poker_menu.py` - Simplified CLI menu

## Onboarding & Setup
- `onboarding_wizard.py` - CLI onboarding wizard
- `web_onboarding_wizard.py` - Web onboarding wizard
- `run_onboarding_wizard.py` - Wizard launcher
- `create_new_admin.py` - Admin user creation script

## Deployment Files
- `deploy_poker_ai.sh` - Deployment script
- `README_DEPLOYMENT.md` - Deployment instructions
- `ONBOARDING_GUIDE.md` - Onboarding guide
- `COMMON_COMMANDS.md` - Common command reference
- `TENSORBOARD_AND_FUNCTIONS_GUIDE.md` - TensorBoard guide

## Testing Scripts
- `test_onboarding_wizard.py` - Onboarding wizard tests
- `test_all_components.py` - Component testing script
- `test_openspiel_stability.py` - OpenSpiel stability tests

## Static Files & Templates
- `static/` - Directory containing CSS, JS, and images
- `templates/` - Directory containing HTML templates

## Creating a Requirements File

If you don't already have a requirements.txt file, you can create one with:

```bash
pip freeze > requirements.txt
```

Or manually create one with these essential packages:

```
torch>=2.0.0
numpy>=1.20.0
matplotlib>=3.5.0
flask>=2.0.0
flask-login>=0.6.0
flask-sqlalchemy>=3.0.0
gunicorn>=20.1.0
dash>=2.0.0
dash-bootstrap-components>=1.0.0
psycopg2-binary>=2.9.0
scikit-learn>=1.0.0
scipy>=1.7.0
tensorboard>=2.8.0
plotly>=5.0.0
open-spiel>=1.0.0
ray>=2.0.0
tqdm>=4.60.0
werkzeug>=2.0.0
```

## Database Structure

The system uses a PostgreSQL database with these main tables:
- `users` - User accounts for the admin dashboard
- `hardware_configs` - Hardware configuration settings
- `training_configs` - Training configuration profiles
- `training_sessions` - Training session records
- `metrics` - Training metrics data

## Directory Structure for Transfer

When transferring, maintain this directory structure:
```
poker_ai/
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── templates/
├── logs/ (create empty directory)
├── runs/ (create empty directory)
├── cfr_results/ (create empty directory)
└── (all python files and scripts)
```

The logs, runs, and cfr_results directories will be created by the system if they don't exist, but it's good practice to create them explicitly.