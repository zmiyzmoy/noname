# Poker AI Deployment Guide

This guide explains how to deploy the Poker AI system on your server.

## System Requirements

- Linux server (Ubuntu 20.04 or newer recommended)
- At least 4GB RAM
- At least 20GB free disk space
- Python 3.8 or newer
- PostgreSQL database
- Sudo/root access for installation

## Deployment Options

### Option 1: Automatic Deployment Script

The easiest way to deploy the system is using the provided `deploy_poker_ai.sh` script. 

1. First, make the script executable:
   ```bash
   chmod +x deploy_poker_ai.sh
   ```

2. Install the system:
   ```bash
   sudo ./deploy_poker_ai.sh install
   ```

3. Start the system:
   ```bash
   sudo ./deploy_poker_ai.sh start
   ```

4. Access the system through your web browser:
   - Main application: http://your-server-ip/
   - Web Dashboard: http://your-server-ip/dashboard/
   - Monitoring: http://your-server-ip/monitor/

### Option 2: Manual Deployment

If you prefer to deploy the system manually or the automatic script doesn't work for your environment, follow these steps:

1. Install system dependencies:
   ```bash
   sudo apt-get update
   sudo apt-get install -y build-essential python3 python3-pip python3-dev python3-venv git libopenmpi-dev supervisor nginx postgresql postgresql-contrib
   ```

2. Create and activate a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install Python dependencies:
   ```bash
   pip install --upgrade pip
   pip install dash dash-bootstrap-components flask flask-login flask-migrate flask-sqlalchemy gunicorn imageio joblib matplotlib numpy open-spiel plotly psutil psycopg2-binary pynvml ray requests scikit-learn scipy sqlalchemy tensorboard torch tqdm werkzeug
   ```

4. Set up PostgreSQL database:
   ```bash
   sudo -u postgres createdb poker_ai
   sudo -u postgres psql -c "CREATE USER poker_user WITH PASSWORD 'poker_password';"
   sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE poker_ai TO poker_user;"
   export DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"
   echo 'export DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"' >> ~/.bashrc
   ```

5. Run database migrations:
   ```bash
   python main.py db upgrade
   ```

6. Create an admin user:
   ```bash
   python create_new_admin.py
   ```

7. Start the system components:
   - Main Flask app: `python main.py`
   - Monitoring web: `python monitoring_web.py`
   - Web poker menu: `python web_poker_menu.py`

## Folder Structure Explanation

- `poker/` - Base directory for models and logs
- `models/` - Database models and ML models
- `templates/` - Web interface templates
- `static/` - Static assets for web interfaces
- `blueprints/` - Flask blueprints for modular design

## Running Training Sessions

To run a training session:

```bash
# Activate virtual environment
source venv/bin/activate

# Run training with default parameters
python poker_rl.py --mode train --num_episodes 100 --num_iterations 10 --verbose
```

## Troubleshooting

### Database Connection Issues

If you encounter database connection issues, check your DATABASE_URL environment variable:

```bash
echo $DATABASE_URL
```

Verify PostgreSQL is running:

```bash
sudo systemctl status postgresql
```

### Web Server Not Accessible

Check Nginx configuration:

```bash
sudo nginx -t
sudo systemctl status nginx
```

Check if the application services are running:

```bash
sudo supervisorctl status
```

### OpenSpiel Player ID=-4 Error

The system includes a custom fix for the OpenSpiel player ID=-4 bug. If you encounter this issue, verify that `fix_openspiel_player_id.py` is present and that `poker_rl.py` imports and uses it correctly.

## Advanced Configuration

### Customizing Database Connection

To use a different database configuration, modify the DATABASE_URL:

```bash
export DATABASE_URL="postgresql://username:password@hostname/database"
```

### Changing Port Numbers

If you need to change the default ports (5000, 5003, 5010), modify:

1. The Supervisor configuration files in `/etc/supervisor/conf.d/`
2. The Nginx configuration in `/etc/nginx/sites-available/poker_ai`

## Backup and Restore

### Backing Up the Database

```bash
pg_dump -U postgres poker_ai > poker_ai_backup.sql
```

### Backing Up Model Files

```bash
tar -czvf poker_models_backup.tar.gz ./poker/models/
```

### Restoring Database

```bash
psql -U postgres -d poker_ai < poker_ai_backup.sql
```

### Restoring Model Files

```bash
tar -xzvf poker_models_backup.tar.gz -C /path/to/destination
```

## Security Considerations

- Change the default database password in a production environment
- Set up proper firewall rules to restrict access to your server
- Consider setting up HTTPS using Let's Encrypt for secure connections