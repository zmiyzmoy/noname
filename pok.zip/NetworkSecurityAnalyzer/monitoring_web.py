#!/usr/bin/env python3
import os
import json
import time
import logging
import threading
from flask import Flask, render_template, jsonify, send_from_directory
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# Global data storage
training_data = {
    'iterations': [],
    'rewards': [],
    'losses': [],
    'exploitability': [],
    'win_rates': [],
    'episodes_completed': 0,
    'last_update': time.time(),
    'model_info': {},
    'opponent_models': {},
    'recent_actions': [],
    'status': 'idle'
}

# Lock for thread-safe updates
data_lock = threading.Lock()

def update_training_data(data):
    """Update the global training data with new information."""
    with data_lock:
        if 'iteration' in data and 'reward' in data:
            training_data['iterations'].append(data['iteration'])
            training_data['rewards'].append(data['reward'])
        
        if 'loss' in data:
            training_data['losses'].append(data['loss'])
        
        if 'exploitability' in data:
            training_data['exploitability'].append(data['exploitability'])
        
        if 'win_rate' in data:
            training_data['win_rates'].append(data['win_rate'])
        
        if 'episodes_completed' in data:
            training_data['episodes_completed'] = data['episodes_completed']
        
        if 'model_info' in data:
            training_data['model_info'] = data['model_info']
        
        if 'opponent_models' in data:
            training_data['opponent_models'] = data['opponent_models']
        
        if 'action' in data:
            if len(training_data['recent_actions']) >= 20:
                training_data['recent_actions'].pop(0)
            training_data['recent_actions'].append(data['action'])
        
        if 'status' in data:
            training_data['status'] = data['status']
        
        training_data['last_update'] = time.time()

def generate_reward_plot():
    """Generate a reward plot as a base64 encoded image."""
    if not training_data['iterations'] or not training_data['rewards']:
        return None
    
    plt.figure(figsize=(10, 6))
    plt.plot(training_data['iterations'], training_data['rewards'], 'b-')
    plt.title('Training Rewards')
    plt.xlabel('Iteration')
    plt.ylabel('Reward')
    plt.grid(True)
    
    # Save to a BytesIO object
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    plt.close()
    buffer.seek(0)
    
    # Convert to base64 for embedding in HTML
    img_base64 = base64.b64encode(buffer.getvalue()).decode()
    return img_base64

def generate_loss_plot():
    """Generate a loss plot as a base64 encoded image."""
    if not training_data['iterations'] or not training_data['losses']:
        return None
    
    plt.figure(figsize=(10, 6))
    plt.plot(training_data['iterations'], training_data['losses'], 'r-')
    plt.title('Training Losses')
    plt.xlabel('Iteration')
    plt.ylabel('Loss')
    plt.grid(True)
    
    # Save to a BytesIO object
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    plt.close()
    buffer.seek(0)
    
    # Convert to base64 for embedding in HTML
    img_base64 = base64.b64encode(buffer.getvalue()).decode()
    return img_base64

def load_opponent_models():
    """Load opponent models from file."""
    models_path = './poker/models/opponent_models.json'
    if os.path.exists(models_path):
        try:
            with open(models_path, 'r') as f:
                models = json.load(f)
                with data_lock:
                    training_data['opponent_models'] = models
                return models
        except Exception as e:
            logger.error(f"Error loading opponent models: {e}")
    return {}

@app.route('/')
def index():
    """Main monitoring page."""
    with data_lock:
        data = {
            'episodes_completed': training_data['episodes_completed'],
            'status': training_data['status'],
            'recent_actions': training_data['recent_actions'],
            'last_update': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(training_data['last_update'])),
            'reward_plot': generate_reward_plot(),
            'loss_plot': generate_loss_plot(),
        }
    return render_template('index.html', data=data)

@app.route('/api/training_data')
def get_training_data():
    """API endpoint to get current training data."""
    with data_lock:
        data = {
            'episodes_completed': training_data['episodes_completed'],
            'status': training_data['status'],
            'recent_actions': training_data['recent_actions'],
            'last_update': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(training_data['last_update'])),
        }
    return jsonify(data)

@app.route('/api/opponent_models')
def get_opponent_models():
    """API endpoint to get opponent models."""
    models = load_opponent_models()
    return jsonify(models)

@app.route('/static/<path:path>')
def send_static(path):
    """Serve static files."""
    return send_from_directory('static', path)

@app.route('/templates/<path:path>')
def send_template(path):
    """Serve template files."""
    return send_from_directory('templates', path)

def create_template_dirs():
    """Create necessary directories for templates and static files."""
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)

def create_default_templates():
    """Create default template files."""
    # Create main index.html template
    index_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Poker AI Training Monitor</title>
    <link rel="stylesheet" href="/static/css/style.css">
    <meta http-equiv="refresh" content="30">
</head>
<body>
    <div class="container">
        <header>
            <h1>Poker AI Training Monitor</h1>
            <p class="status">Status: <span id="status">{{ data.status }}</span></p>
            <p>Last Updated: <span id="last-update">{{ data.last_update }}</span></p>
        </header>
        
        <div class="stats-container">
            <div class="stat-card">
                <h2>Training Progress</h2>
                <div class="stat-value" id="episodes">{{ data.episodes_completed }}</div>
                <div class="stat-label">Episodes Completed</div>
            </div>
        </div>
        
        <div class="charts-container">
            {% if data.reward_plot %}
            <div class="chart-card">
                <h2>Rewards</h2>
                <img src="data:image/png;base64,{{ data.reward_plot }}" alt="Reward Plot">
            </div>
            {% endif %}
            
            {% if data.loss_plot %}
            <div class="chart-card">
                <h2>Losses</h2>
                <img src="data:image/png;base64,{{ data.loss_plot }}" alt="Loss Plot">
            </div>
            {% endif %}
        </div>
        
        <div class="recent-activity">
            <h2>Recent Actions</h2>
            <div class="action-list">
                {% for action in data.recent_actions %}
                <div class="action-item">{{ action }}</div>
                {% else %}
                <div class="action-item">No recent actions.</div>
                {% endfor %}
            </div>
        </div>
    </div>
    
    <script src="/static/js/monitor.js"></script>
</body>
</html>
    """
    
    # Create CSS
    css = """
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
    color: #333;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

header {
    background-color: #2c3e50;
    color: white;
    padding: 20px;
    border-radius: 5px;
    margin-bottom: 20px;
}

header h1 {
    margin: 0;
    font-size: 24px;
}

.status {
    margin-top: 10px;
    font-weight: bold;
}

.stats-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 20px;
}

.stat-card {
    background-color: white;
    border-radius: 5px;
    padding: 20px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    flex: 1;
    min-width: 200px;
    text-align: center;
}

.stat-value {
    font-size: 36px;
    font-weight: bold;
    margin: 10px 0;
    color: #3498db;
}

.charts-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 20px;
}

.chart-card {
    background-color: white;
    border-radius: 5px;
    padding: 20px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    flex: 1;
    min-width: 500px;
}

.chart-card img {
    width: 100%;
    height: auto;
}

.recent-activity {
    background-color: white;
    border-radius: 5px;
    padding: 20px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.action-list {
    margin-top: 10px;
}

.action-item {
    padding: 10px;
    border-bottom: 1px solid #eee;
}

.action-item:last-child {
    border-bottom: none;
}

@media (max-width: 768px) {
    .chart-card {
        min-width: 100%;
    }
}
    """
    
    # Create JavaScript
    js = """
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh data every 10 seconds
    setInterval(function() {
        fetch('/api/training_data')
            .then(response => response.json())
            .then(data => {
                document.getElementById('status').textContent = data.status;
                document.getElementById('last-update').textContent = data.last_update;
                document.getElementById('episodes').textContent = data.episodes_completed;
                
                // Update action list
                const actionList = document.querySelector('.action-list');
                actionList.innerHTML = '';
                
                if (data.recent_actions && data.recent_actions.length > 0) {
                    data.recent_actions.forEach(action => {
                        const actionItem = document.createElement('div');
                        actionItem.className = 'action-item';
                        actionItem.textContent = action;
                        actionList.appendChild(actionItem);
                    });
                } else {
                    const actionItem = document.createElement('div');
                    actionItem.className = 'action-item';
                    actionItem.textContent = 'No recent actions.';
                    actionList.appendChild(actionItem);
                }
            })
            .catch(error => console.error('Error:', error));
    }, 10000);
});
    """
    
    # Write all files
    with open('templates/index.html', 'w') as f:
        f.write(index_html)
    
    with open('static/css/style.css', 'w') as f:
        f.write(css)
    
    with open('static/js/monitor.js', 'w') as f:
        f.write(js)
    
    logger.info("Created default template files")

def run_server():
    """Run the Flask app with Gunicorn."""
    # Create necessary directories and templates
    create_template_dirs()
    create_default_templates()
    
    # For development
    app.run(host='0.0.0.0', port=5000, debug=True)

if __name__ == '__main__':
    run_server()