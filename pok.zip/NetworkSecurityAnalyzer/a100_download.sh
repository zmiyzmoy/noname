#!/bin/bash
# Script to download and reassemble Poker AI system on A100 server
# Copy and paste this entire script to your A100 server and run it

echo "=== Poker AI System Downloader ==="
echo "This script will download and set up the Poker AI system on your A100 server"
echo

# Create directory for downloads
mkdir -p poker_ai_download
cd poker_ai_download
echo "Created directory: $(pwd)"
echo

# Set the base URL for downloads
BASE_URL="https://77b2eb61-43f1-42a2-a5c5-6c4ce33fc5a3-00-250d4ddm7qp7e.worf.replit.dev/chunks"

# Check if curl is available
if ! command -v curl &> /dev/null; then
    echo "Error: curl is not installed. Please install curl first."
    exit 1
fi

# Download file chunks
echo "Downloading file chunks..."
for chunk in aa ab ac ad ae af ag ah ai aj ak al am an ao ap aq ar; do
    echo -n "Downloading chunk_$chunk... "
    curl -s -o chunk_$chunk "$BASE_URL/chunk_$chunk"
    
    if [ $? -eq 0 ] && [ -f chunk_$chunk ]; then
        size=$(du -h chunk_$chunk | cut -f1)
        echo "OK ($size)"
    else
        echo "FAILED"
        echo "Error downloading chunk_$chunk. Please try again."
        exit 1
    fi
done

echo
echo "All chunks downloaded successfully."
echo

# Reassemble the file
echo "Reassembling archive file..."
cat chunk_* > poker_ai_system.tar.gz

# Check the file size
size=$(du -h poker_ai_system.tar.gz | cut -f1)
echo "Reassembled archive size: $size"
echo

# Extract the archive
echo "Extracting files..."
tar -xzf poker_ai_system.tar.gz

if [ $? -eq 0 ]; then
    echo "✓ Extraction successful!"
    echo 
    echo "Setting up Poker AI System..."
    echo
    echo "Next steps:"
    echo "1. Install dependencies: pip install -r requirements.txt"
    echo "2. Run the application: python main.py"
else
    echo "✗ Extraction failed. The archive may be incomplete or corrupted."
    echo "Please try running the script again."
    exit 1
fi

echo
echo "=== Setup Complete ==="
echo "You can now run the Poker AI system with: python main.py"