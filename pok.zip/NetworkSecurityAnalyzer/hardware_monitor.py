"""
Hardware Resource Monitoring for Poker AI System

This module provides utilities for monitoring hardware resources (CPU, GPU, memory)
and making optimization recommendations based on available resources.
"""

import os
import sys
import json
import time
import logging
import threading
import psutil
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional, Union

# Conditional imports for GPU support
try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

try:
    import pynvml
    HAS_NVIDIA = True
except ImportError:
    HAS_NVIDIA = False

# Initialize NVML if available
if HAS_NVIDIA:
    try:
        pynvml.nvmlInit()
        NVML_INITIALIZED = True
    except Exception as e:
        logging.warning(f"Failed to initialize NVML: {e}")
        NVML_INITIALIZED = False
else:
    NVML_INITIALIZED = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('hardware_monitor.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class HardwareMonitor:
    """
    Monitors hardware resources (CPU, GPU, RAM) and provides
    optimization recommendations based on system specifications.
    """
    
    def __init__(self, storage_path: str = 'hardware_metrics.json', 
                alert_threshold: float = 0.85,
                polling_interval: int = 30,
                metrics_history_size: int = 1000):
        """
        Initialize the hardware monitor.
        
        Args:
            storage_path: Path to store metrics history
            alert_threshold: Utilization threshold for alerts (0.0-1.0)
            polling_interval: Seconds between metrics collection
            metrics_history_size: Maximum number of metrics to store
        """
        self.storage_path = storage_path
        self.alert_threshold = alert_threshold
        self.polling_interval = polling_interval
        self.metrics_history_size = metrics_history_size
        self.metrics_history = []
        self.last_metrics = None
        self.alerts = []
        self.monitor_thread = None
        self._stop_flag = threading.Event()
        
        # Load existing metrics if available
        self._load_metrics()
        
    def _load_metrics(self):
        """Load metrics history from file."""
        try:
            if os.path.exists(self.storage_path):
                with open(self.storage_path, 'r') as f:
                    data = json.load(f)
                    self.metrics_history = data.get('metrics', [])
                    if self.metrics_history:
                        self.last_metrics = self.metrics_history[-1]
        except Exception as e:
            logger.error(f"Failed to load metrics from {self.storage_path}: {e}")
            self.metrics_history = []
            self.last_metrics = None
    
    def _save_metrics(self):
        """Save metrics history to file."""
        try:
            with open(self.storage_path, 'w') as f:
                json.dump({'metrics': self.metrics_history}, f)
        except Exception as e:
            logger.error(f"Failed to save metrics to {self.storage_path}: {e}")
    
    def start_monitoring(self):
        """Start the background monitoring thread."""
        if self.monitor_thread and self.monitor_thread.is_alive():
            logger.warning("Monitoring thread already running")
            return
        
        self._stop_flag.clear()
        self.monitor_thread = threading.Thread(target=self._monitoring_loop)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        logger.info("Hardware monitoring started")
    
    def stop_monitoring(self):
        """Stop the background monitoring thread."""
        if not self.monitor_thread or not self.monitor_thread.is_alive():
            logger.warning("No monitoring thread running")
            return
        
        self._stop_flag.set()
        self.monitor_thread.join(timeout=5)
        logger.info("Hardware monitoring stopped")
    
    def _monitoring_loop(self):
        """Background monitoring loop."""
        while not self._stop_flag.is_set():
            try:
                self.update_metrics()
                time.sleep(self.polling_interval)
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)  # shorter interval on error
    
    def get_cpu_metrics(self) -> Dict[str, Any]:
        """Get CPU metrics."""
        try:
            cpu_percent = psutil.cpu_percent(interval=0.5)
            cpu_count = psutil.cpu_count()
            cpu_count_physical = psutil.cpu_count(logical=False) or 1
            
            # Get per-core utilization
            per_core = psutil.cpu_percent(interval=0.1, percpu=True)
            
            # Get CPU frequency
            freq = psutil.cpu_freq()
            if freq:
                current_freq = freq.current
                max_freq = freq.max if hasattr(freq, 'max') else None
            else:
                current_freq = None
                max_freq = None
            
            return {
                'usage_percent': cpu_percent,
                'core_count': cpu_count,
                'physical_core_count': cpu_count_physical,
                'per_core_usage': per_core,
                'current_freq_mhz': current_freq,
                'max_freq_mhz': max_freq
            }
        except Exception as e:
            logger.error(f"Error getting CPU metrics: {e}")
            return {
                'usage_percent': 0,
                'core_count': 0,
                'physical_core_count': 0,
                'per_core_usage': [],
                'current_freq_mhz': None,
                'max_freq_mhz': None
            }
    
    def get_memory_metrics(self) -> Dict[str, Any]:
        """Get memory (RAM) metrics."""
        try:
            mem = psutil.virtual_memory()
            return {
                'total': mem.total,
                'available': mem.available,
                'used': mem.used,
                'percent': mem.percent,
                'total_gb': mem.total / (1024 ** 3),
                'used_gb': mem.used / (1024 ** 3),
                'available_gb': mem.available / (1024 ** 3),
                'usage_percent': mem.percent / 100.0
            }
        except Exception as e:
            logger.error(f"Error getting memory metrics: {e}")
            return {
                'total': 0,
                'available': 0,
                'used': 0,
                'percent': 0,
                'total_gb': 0,
                'used_gb': 0,
                'available_gb': 0,
                'usage_percent': 0
            }
    
    def get_gpu_metrics(self) -> Dict[str, Any]:
        """Get GPU metrics if available."""
        # Default metrics
        default_metrics = {
            'available': False,
            'count': 0,
            'devices': []
        }

        try:
            # Check if CUDA is available via PyTorch
            if HAS_TORCH and torch.cuda.is_available():
                cuda_available = True
                cuda_device_count = torch.cuda.device_count()
                
                # If NVML is available, use it for detailed GPU metrics
                if NVML_INITIALIZED:
                    devices = []
                    device_count = pynvml.nvmlDeviceGetCount()
                    
                    for i in range(device_count):
                        try:
                            handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                            name = pynvml.nvmlDeviceGetName(handle).decode('utf-8')
                            mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                            total_mem = mem_info.total
                            used_mem = mem_info.used
                            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                            
                            devices.append({
                                'index': i,
                                'name': name,
                                'total_memory': total_mem,
                                'used_memory': used_mem,
                                'free_memory': total_mem - used_mem,
                                'total_memory_gb': total_mem / (1024 ** 3),
                                'used_memory_gb': used_mem / (1024 ** 3),
                                'free_memory_gb': (total_mem - used_mem) / (1024 ** 3),
                                'utilization': util.gpu / 100.0 if hasattr(util, 'gpu') else 0,
                                'memory_utilization': util.memory / 100.0 if hasattr(util, 'memory') else 0
                            })
                        except Exception as e:
                            logger.error(f"Error getting metrics for GPU {i}: {e}")
                            devices.append({
                                'index': i,
                                'error': str(e)
                            })
                    
                    return {
                        'available': True,
                        'count': device_count,
                        'devices': devices
                    }
                
                # Fallback to basic PyTorch info if NVML not available
                else:
                    devices = []
                    for i in range(cuda_device_count):
                        try:
                            name = torch.cuda.get_device_name(i)
                            # PyTorch doesn't provide memory usage by default, just report device info
                            devices.append({
                                'index': i,
                                'name': name,
                                'total_memory_gb': torch.cuda.get_device_properties(i).total_memory / (1024 ** 3),
                                'utilization': 0.5,  # Reasonable default when metrics aren't available
                                'memory_utilization': 0.5
                            })
                        except Exception as e:
                            logger.error(f"Error getting basic info for GPU {i}: {e}")
                            devices.append({
                                'index': i,
                                'error': str(e)
                            })
                    
                    return {
                        'available': True,
                        'count': cuda_device_count,
                        'devices': devices
                    }
        except Exception as e:
            logger.error(f"Error getting GPU metrics: {e}")
            return default_metrics
        
        return default_metrics
    
    def get_disk_metrics(self) -> Dict[str, Any]:
        """Get disk usage metrics."""
        try:
            usage = psutil.disk_usage('/')
            io_counters = psutil.disk_io_counters()
            
            return {
                'total_gb': usage.total / (1024 ** 3),
                'used_gb': usage.used / (1024 ** 3),
                'free_gb': usage.free / (1024 ** 3),
                'usage_percent': usage.percent / 100.0,
                'read_count': io_counters.read_count if io_counters else 0,
                'write_count': io_counters.write_count if io_counters else 0,
                'read_bytes': io_counters.read_bytes if io_counters else 0,
                'write_bytes': io_counters.write_bytes if io_counters else 0
            }
        except Exception as e:
            logger.error(f"Error getting disk metrics: {e}")
            return {
                'total_gb': 0,
                'used_gb': 0,
                'free_gb': 0,
                'usage_percent': 0,
                'read_count': 0,
                'write_count': 0,
                'read_bytes': 0,
                'write_bytes': 0
            }
    
    def get_process_metrics(self) -> Dict[str, Any]:
        """Get process metrics for the current Python process."""
        try:
            process = psutil.Process(os.getpid())
            mem_info = process.memory_info()
            
            return {
                'cpu_percent': process.cpu_percent(interval=0.1),
                'memory_rss_mb': mem_info.rss / (1024 * 1024),
                'memory_vms_mb': mem_info.vms / (1024 * 1024),
                'thread_count': process.num_threads(),
                'create_time': process.create_time()
            }
        except Exception as e:
            logger.error(f"Error getting process metrics: {e}")
            return {
                'cpu_percent': 0,
                'memory_rss_mb': 0,
                'memory_vms_mb': 0,
                'thread_count': 0,
                'create_time': 0
            }
    
    def check_alerts(self) -> List[Dict[str, str]]:
        """Check for resource alerts based on current metrics."""
        if not self.last_metrics:
            return []
        
        alerts = []
        
        # Check CPU usage
        cpu_usage = self.last_metrics.get('cpu', {}).get('usage_percent', 0)
        if cpu_usage < self.alert_threshold * 100:
            alerts.append({
                'type': 'cpu',
                'message': f'CPU usage ({cpu_usage:.1f}%) is below target ({self.alert_threshold * 100:.0f}%). '
                          f'Consider increasing batch size or number of workers.'
            })
        
        # Check GPU usage
        gpu_data = self.last_metrics.get('gpu', {})
        if gpu_data.get('available', False) and gpu_data.get('count', 0) > 0:
            total_utilization = 0
            total_memory_usage = 0
            gpu_count = 0
            
            for device in gpu_data.get('devices', []):
                if 'utilization' in device and 'memory_utilization' in device:
                    total_utilization += device['utilization']
                    total_memory_usage += device.get('used_memory_gb', 0) / device.get('total_memory_gb', 1)
                    gpu_count += 1
            
            if gpu_count > 0:
                avg_utilization = total_utilization / gpu_count
                avg_memory_usage = total_memory_usage / gpu_count
                
                if avg_utilization < self.alert_threshold:
                    alerts.append({
                        'type': 'gpu_compute',
                        'message': f'GPU compute utilization ({avg_utilization * 100:.1f}%) is below target '
                                  f'({self.alert_threshold * 100:.0f}%). Consider increasing model complexity or batch size.'
                    })
                
                if avg_memory_usage < self.alert_threshold:
                    alerts.append({
                        'type': 'gpu_memory',
                        'message': f'GPU memory usage ({avg_memory_usage * 100:.1f}%) is below target '
                                  f'({self.alert_threshold * 100:.0f}%). Consider increasing batch size or model size.'
                    })
        
        # Check memory usage
        memory_usage = self.last_metrics.get('memory', {}).get('usage_percent', 0)
        if memory_usage < self.alert_threshold:
            alerts.append({
                'type': 'memory',
                'message': f'Memory usage ({memory_usage * 100:.1f}%) is below target ({self.alert_threshold * 100:.0f}%). '
                          f'Consider increasing buffer sizes or parallelism.'
            })
        
        self.alerts = alerts
        return alerts
    
    def update_metrics(self) -> Dict[str, Any]:
        """Update and store current metrics."""
        current_time = datetime.now().isoformat()
        
        metrics = {
            'timestamp': current_time,
            'cpu': self.get_cpu_metrics(),
            'memory': self.get_memory_metrics(),
            'gpu': self.get_gpu_metrics(),
            'disk': self.get_disk_metrics(),
            'process': self.get_process_metrics()
        }
        
        # Store metrics
        self.last_metrics = metrics
        self.metrics_history.append(metrics)
        
        # Limit history size
        if len(self.metrics_history) > self.metrics_history_size:
            self.metrics_history = self.metrics_history[-self.metrics_history_size:]
        
        # Save to disk
        self._save_metrics()
        
        # Check for alerts
        alerts = self.check_alerts()
        
        # Add alerts to metrics
        metrics['alerts'] = alerts
        
        return metrics
    
    def get_optimization_recommendations(self) -> Dict[str, Any]:
        """
        Generate optimization recommendations based on hardware specifications.
        """
        # Get hardware specs
        specs = get_system_specs()
        gpu_info = self.get_gpu_metrics() if self.last_metrics is None else self.last_metrics.get('gpu', {})
        
        # Extract key hardware specs for recommendations
        cpu_cores = specs['cpu_cores']
        cpu_physical_cores = specs['physical_cores']
        ram_gb = specs['ram_gb']
        gpu_count = gpu_info.get('count', 0)
        gpu_memory_total = 0
        for device in gpu_info.get('devices', []):
            gpu_memory_total += device.get('total_memory_gb', 0)
        
        # Calculate optimal batch size based on GPU memory
        # Rule of thumb: 8GB GPU can handle batch size 64 for medium models
        if gpu_count > 0 and gpu_memory_total > 0:
            if gpu_memory_total < 6:  # <6GB VRAM
                batch_size = 32
            elif gpu_memory_total < 12:  # 6-12GB VRAM
                batch_size = 64
            elif gpu_memory_total < 24:  # 12-24GB VRAM
                batch_size = 128
            elif gpu_memory_total < 40:  # 24-40GB VRAM
                batch_size = 256
            else:  # 40GB+ VRAM (A100, H100, etc.)
                batch_size = 512
        else:
            # No GPU or unknown memory size, use CPU-based heuristic
            batch_size = min(max(32, cpu_physical_cores * 8), 128)
        
        # Calculate optimal number of workers based on CPU cores
        # Rule of thumb: Use physical cores minus 1 (reserve one for system)
        workers = max(1, min(cpu_physical_cores - 1, 12))
        
        # CFR iterations based on hardware specs
        if cpu_physical_cores >= 16 and ram_gb >= 64:
            cfr_iters = 10
        elif cpu_physical_cores >= 8 and ram_gb >= 32:
            cfr_iters = 7
        else:
            cfr_iters = 5
        
        # Learning rate based on batch size
        # Larger batch sizes generally need larger learning rates
        if batch_size <= 32:
            learning_rate = 0.00005
        elif batch_size <= 64:
            learning_rate = 0.0001
        elif batch_size <= 128:
            learning_rate = 0.0002
        elif batch_size <= 256:
            learning_rate = 0.0003
        else:
            learning_rate = 0.0005
        
        # Mixed precision recommendation
        # Only recommend for modern GPUs (compute capability 7.0+)
        use_mixed_precision = detect_cuda_status().get('supports_mixed_precision', False)
        
        return {
            'batch_size': batch_size,
            'workers': workers,
            'cfr_iters_per_step': cfr_iters,
            'learning_rate': learning_rate,
            'use_mixed_precision': use_mixed_precision,
            'hardware_summary': {
                'cpu_cores': cpu_cores,
                'physical_cores': cpu_physical_cores,
                'ram_gb': ram_gb,
                'gpu_count': gpu_count,
                'gpu_memory_gb': gpu_memory_total
            }
        }

def get_system_specs() -> Dict[str, Any]:
    """
    Get system hardware specifications.
    
    Returns:
        Dict containing CPU, RAM and GPU specs.
    """
    try:
        # CPU info
        cpu_cores = psutil.cpu_count()
        physical_cores = psutil.cpu_count(logical=False) or 1
        
        # Memory info
        mem = psutil.virtual_memory()
        ram_gb = mem.total / (1024 ** 3)
        
        # GPU info
        gpu_info = {
            'available': False,
            'count': 0,
            'devices': []
        }
        
        # Check for CUDA GPUs via PyTorch if available
        if HAS_TORCH and torch.cuda.is_available():
            gpu_info['available'] = True
            gpu_info['count'] = torch.cuda.device_count()
            
            for i in range(gpu_info['count']):
                device_props = torch.cuda.get_device_properties(i)
                gpu_info['devices'].append({
                    'name': device_props.name,
                    'total_memory_gb': device_props.total_memory / (1024 ** 3),
                    'compute_capability': f"{device_props.major}.{device_props.minor}"
                })
        
        # Network interfaces info
        net_io = psutil.net_io_counters()
        net_interfaces = psutil.net_if_addrs()
        
        return {
            'cpu_cores': cpu_cores,
            'physical_cores': physical_cores,
            'ram_gb': ram_gb,
            'gpu': gpu_info,
            'platform': sys.platform,
            'python_version': sys.version.split()[0],
            'network': {
                'bytes_sent': net_io.bytes_sent,
                'bytes_recv': net_io.bytes_recv,
                'interfaces': list(net_interfaces.keys())
            }
        }
    except Exception as e:
        logger.error(f"Error getting system specs: {e}")
        return {
            'cpu_cores': 0,
            'physical_cores': 0,
            'ram_gb': 0,
            'gpu': {'available': False, 'count': 0, 'devices': []},
            'error': str(e)
        }

def detect_cuda_status() -> Dict[str, Any]:
    """
    Detect CUDA availability and capabilities.
    
    Returns:
        Dict containing CUDA status information.
    """
    result = {
        'cuda_available': False,
        'cuda_version': None,
        'device_count': 0,
        'devices': [],
        'supports_mixed_precision': False
    }
    
    if not HAS_TORCH:
        return result
    
    try:
        result['cuda_available'] = torch.cuda.is_available()
        if not result['cuda_available']:
            return result
        
        result['cuda_version'] = torch.version.cuda
        result['device_count'] = torch.cuda.device_count()
        
        for i in range(result['device_count']):
            device_props = torch.cuda.get_device_properties(i)
            compute_capability = float(f"{device_props.major}.{device_props.minor}")
            
            result['devices'].append({
                'index': i,
                'name': device_props.name,
                'compute_capability': compute_capability,
                'total_memory_gb': device_props.total_memory / (1024 ** 3)
            })
            
            # Tensor cores available in compute capability 7.0+ (Volta and newer)
            # Required for effective mixed precision training
            if compute_capability >= 7.0:
                result['supports_mixed_precision'] = True
        
        return result
    except Exception as e:
        logger.error(f"Error detecting CUDA status: {e}")
        result['error'] = str(e)
        return result

if __name__ == "__main__":
    # Simple test of the hardware monitor
    monitor = HardwareMonitor()
    metrics = monitor.update_metrics()
    print(json.dumps(metrics, indent=2))
    
    print("\nSystem Specs:")
    specs = get_system_specs()
    print(json.dumps(specs, indent=2))
    
    print("\nCUDA Status:")
    cuda_status = detect_cuda_status()
    print(json.dumps(cuda_status, indent=2))
    
    print("\nOptimization Recommendations:")
    recommendations = monitor.get_optimization_recommendations()
    print(json.dumps(recommendations, indent=2))