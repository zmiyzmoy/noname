#!/usr/bin/env python3
"""
Quick Start Onboarding Wizard for Poker AI System

This module provides a guided onboarding experience for new users
to help them set up and start using the Poker AI system quickly.
"""

import os
import sys
import subprocess
import logging
import time
import json
from typing import Dict, Any, List, Optional, Tuple
import threading
import webbrowser
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('onboarding_wizard.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Wizard configuration
WIZARD_CONFIG = {
    "name": "Poker AI Quick Start Wizard",
    "version": "1.0.0",
    "steps": [
        {
            "id": "welcome",
            "title": "Welcome",
            "description": "Welcome to the Poker AI Onboarding Wizard. This wizard will help you set up your Poker AI system quickly.",
            "action": "display_welcome"
        },
        {
            "id": "system_check",
            "title": "System Check",
            "description": "Checking your system configuration...",
            "action": "check_system"
        },
        {
            "id": "dependencies",
            "title": "Dependencies",
            "description": "Installing required dependencies...",
            "action": "install_dependencies"
        },
        {
            "id": "database",
            "title": "Database Setup",
            "description": "Setting up the database...",
            "action": "setup_database"
        },
        {
            "id": "create_admin",
            "title": "Create Admin User",
            "description": "Creating admin user...",
            "action": "create_admin_user"
        },
        {
            "id": "start_services",
            "title": "Start Services",
            "description": "Starting necessary services...",
            "action": "start_services"
        },
        {
            "id": "quick_train",
            "title": "Quick Training",
            "description": "Running a quick training session...",
            "action": "run_quick_training"
        },
        {
            "id": "open_dashboard",
            "title": "Open Dashboard",
            "description": "Opening the web dashboard...",
            "action": "open_dashboard"
        },
        {
            "id": "finish",
            "title": "Finished",
            "description": "Setup completed successfully!",
            "action": "display_completion"
        }
    ]
}

# Global state to track progress
wizard_state = {
    "current_step": 0,
    "steps_completed": [],
    "system_info": {},
    "config": {},
    "errors": [],
    "start_time": None,
    "completion_time": None,
}

def clear_screen():
    """Clear the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """Print the wizard header."""
    clear_screen()
    print("\n" + "="*80)
    print(f" {WIZARD_CONFIG['name']} (v{WIZARD_CONFIG['version']})")
    print("="*80)
    print(" This wizard will help you set up and start using the Poker AI system.")
    print("-"*80)

def print_step_info(step: Dict[str, Any]):
    """Print information about the current step."""
    print(f"\n>> Step {wizard_state['current_step']+1}/{len(WIZARD_CONFIG['steps'])}: {step['title']}")
    print(f"   {step['description']}")
    print("-"*80)

def print_progress(percent: float, prefix: str = "", length: int = 50):
    """Print a progress bar."""
    filled_length = int(length * percent)
    bar = "█" * filled_length + "-" * (length - filled_length)
    print(f"\r{prefix} |{bar}| {percent*100:.1f}%", end="\r")
    if percent >= 1:
        print()

def run_command(command: str, timeout: int = 60) -> Tuple[bool, str]:
    """Run a shell command and return its output."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, f"Command failed with exit code {e.returncode}: {e.stderr}"
    except subprocess.TimeoutExpired:
        return False, f"Command timed out after {timeout} seconds"
    except Exception as e:
        return False, f"Error running command: {str(e)}"

def check_system():
    """Check system configuration."""
    print("\nChecking system configuration...")
    
    # Check Python version
    python_version = sys.version.split()[0]
    print(f"Python version: {python_version}")
    wizard_state["system_info"]["python_version"] = python_version
    
    # Check if running in virtual environment
    in_venv = sys.prefix != sys.base_prefix
    print(f"Virtual environment: {'Yes' if in_venv else 'No'}")
    wizard_state["system_info"]["in_venv"] = in_venv
    
    # Check for GPU
    try:
        import torch
        has_cuda = torch.cuda.is_available()
        cuda_version = torch.version.cuda if has_cuda else "N/A"
        print(f"CUDA available: {'Yes' if has_cuda else 'No'}")
        print(f"CUDA version: {cuda_version}")
        wizard_state["system_info"]["has_cuda"] = has_cuda
        wizard_state["system_info"]["cuda_version"] = cuda_version
        if has_cuda:
            device_name = torch.cuda.get_device_name(0)
            print(f"GPU device: {device_name}")
            wizard_state["system_info"]["gpu_device"] = device_name
    except ImportError:
        print("PyTorch not installed. GPU status unknown.")
        wizard_state["system_info"]["has_cuda"] = False
        wizard_state["system_info"]["cuda_version"] = "N/A"
    
    # Check for OpenSpiel
    try:
        import pyspiel
        print("OpenSpiel installed: Yes")
        wizard_state["system_info"]["has_openspiel"] = True
    except ImportError:
        print("OpenSpiel not installed.")
        wizard_state["system_info"]["has_openspiel"] = False
    
    # Check for database
    try:
        import psycopg2
        print("PostgreSQL driver installed: Yes")
        # Check if DATABASE_URL is set
        database_url = os.environ.get("DATABASE_URL")
        if database_url:
            print(f"Database URL configured: Yes")
            wizard_state["system_info"]["has_database_config"] = True
        else:
            print(f"Database URL configured: No")
            wizard_state["system_info"]["has_database_config"] = False
    except ImportError:
        print("PostgreSQL driver not installed.")
        wizard_state["system_info"]["has_database_config"] = False
    
    # Check disk space
    try:
        import psutil
        disk_usage = psutil.disk_usage('.')
        free_gb = disk_usage.free / (1024 * 1024 * 1024)
        print(f"Free disk space: {free_gb:.2f} GB")
        wizard_state["system_info"]["free_disk_gb"] = free_gb
    except ImportError:
        print("Could not check disk space (psutil not installed).")
    
    print("\nSystem check completed.")
    
    wizard_state["steps_completed"].append("system_check")
    input("\nPress Enter to continue...")
    return True

def install_dependencies():
    """Install required dependencies."""
    print("\nChecking and installing required dependencies...")
    
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        print("Creating requirements.txt...")
        with open("requirements.txt", "w") as f:
            f.write("""dash
dash-bootstrap-components
flask
flask-login
flask-migrate
flask-sqlalchemy
gunicorn
imageio
joblib
matplotlib
numpy
open-spiel
plotly
psutil
psycopg2-binary
pynvml
ray
requests
scikit-learn
scipy
sqlalchemy
tensorboard
torch
tqdm
werkzeug
""")
    
    # Install requirements
    print("Installing Python dependencies...")
    success, output = run_command("pip install -r requirements.txt", timeout=300)
    
    if not success:
        print(f"Error installing dependencies: {output}")
        wizard_state["errors"].append(f"Failed to install dependencies: {output}")
        input("\nThere were errors installing dependencies. Press Enter to continue anyway...")
    else:
        print("Python dependencies installed successfully.")
    
    # Check for system dependencies using the deploy script if available
    if os.path.exists("deploy_poker_ai.sh"):
        print("Checking system dependencies using deployment script...")
        success, output = run_command("bash deploy_poker_ai.sh install", timeout=300)
        if not success:
            print(f"Warning: Deployment script encountered issues: {output}")
            wizard_state["errors"].append(f"Deployment script issues: {output}")
        else:
            print("System dependencies checked with deployment script.")
    
    wizard_state["steps_completed"].append("dependencies")
    input("\nPress Enter to continue...")
    return True

def setup_database():
    """Set up the database."""
    print("\nSetting up the database...")
    
    # Check if DATABASE_URL is already set
    database_url = os.environ.get("DATABASE_URL")
    if database_url:
        print(f"Database URL already configured: {database_url.split('@')[1] if '@' in database_url else '***'}")
        use_existing = input("Use existing database configuration? (y/n): ").lower() == 'y'
        if use_existing:
            wizard_state["steps_completed"].append("database")
            return True
    
    # Check if PostgreSQL is installed
    success, output = run_command("which psql")
    if not success:
        print("PostgreSQL client not found. Installing...")
        success, output = run_command("sudo apt-get update && sudo apt-get install -y postgresql postgresql-contrib")
        if not success:
            print(f"Error installing PostgreSQL: {output}")
            wizard_state["errors"].append(f"Failed to install PostgreSQL: {output}")
            input("\nThere were errors installing PostgreSQL. Press Enter to continue anyway...")
            return False
    
    # Create PostgreSQL database
    db_name = input("Enter database name [poker_ai]: ") or "poker_ai"
    db_user = input("Enter database user [poker_user]: ") or "poker_user"
    db_password = input("Enter database password [poker_password]: ") or "poker_password"
    
    print(f"Creating database {db_name}...")
    
    # Check if database already exists
    success, output = run_command(f"sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw {db_name} && echo 'exists' || echo 'not exists'")
    if success and "exists" in output:
        print(f"Database '{db_name}' already exists.")
    else:
        success, output = run_command(f"sudo -u postgres createdb {db_name}")
        if not success:
            print(f"Error creating database: {output}")
            wizard_state["errors"].append(f"Failed to create database: {output}")
            input("\nThere were errors creating the database. Press Enter to continue anyway...")
            return False
        
        # Create user and grant privileges
        success, output = run_command(f"sudo -u postgres psql -c \"CREATE USER {db_user} WITH PASSWORD '{db_password}';\"")
        if not success:
            print(f"Error creating database user: {output}")
            wizard_state["errors"].append(f"Failed to create database user: {output}")
        
        success, output = run_command(f"sudo -u postgres psql -c \"GRANT ALL PRIVILEGES ON DATABASE {db_name} TO {db_user};\"")
        if not success:
            print(f"Error granting privileges: {output}")
            wizard_state["errors"].append(f"Failed to grant database privileges: {output}")
    
    # Set environment variable
    new_db_url = f"postgresql://{db_user}:{db_password}@localhost/{db_name}"
    os.environ["DATABASE_URL"] = new_db_url
    
    # Add to .bashrc for persistence
    print("Adding DATABASE_URL to .bashrc for persistence...")
    with open(os.path.expanduser("~/.bashrc"), "a") as f:
        f.write(f'\n# Added by Poker AI Onboarding Wizard\nexport DATABASE_URL="{new_db_url}"\n')
    
    print(f"Database URL configured: {new_db_url}")
    
    # Run migrations
    print("Running database migrations...")
    if os.path.exists("main.py"):
        success, output = run_command("python main.py db upgrade")
        if not success:
            print(f"Warning: Database migration issues: {output}")
            wizard_state["errors"].append(f"Database migration issues: {output}")
        else:
            print("Database migrations completed successfully.")
    
    wizard_state["steps_completed"].append("database")
    input("\nPress Enter to continue...")
    return True

def create_admin_user():
    """Create an admin user."""
    print("\nCreating admin user...")
    
    if os.path.exists("create_new_admin.py"):
        print("Using create_new_admin.py script...")
        admin_username = input("Enter admin username [pokeradmin]: ") or "pokeradmin"
        admin_password = input("Enter admin password [pokerpwd123]: ") or "pokerpwd123"
        admin_email = input("Enter admin email [admin@example.com]: ") or "admin@example.com"
        
        # Create a temporary file with admin credentials
        with open("admin_credentials.tmp", "w") as f:
            f.write(f"{admin_username}\n{admin_password}\n{admin_email}\n")
        
        # Run the create_new_admin.py script with input from the temporary file
        success, output = run_command("cat admin_credentials.tmp | python create_new_admin.py")
        
        # Remove the temporary file
        if os.path.exists("admin_credentials.tmp"):
            os.remove("admin_credentials.tmp")
        
        if not success:
            print(f"Error creating admin user: {output}")
            wizard_state["errors"].append(f"Failed to create admin user: {output}")
            input("\nThere were errors creating the admin user. Press Enter to continue anyway...")
            return False
        
        print("Admin user created successfully.")
    else:
        print("create_new_admin.py script not found. Skipping admin user creation.")
        wizard_state["errors"].append("Could not create admin user: script not found")
    
    wizard_state["steps_completed"].append("create_admin")
    input("\nPress Enter to continue...")
    return True

def start_services():
    """Start necessary services."""
    print("\nStarting necessary services...")
    
    # Check for the deploy script
    if os.path.exists("deploy_poker_ai.sh"):
        print("Using deployment script to start services...")
        success, output = run_command("bash deploy_poker_ai.sh start")
        if not success:
            print(f"Warning: Deployment script encountered issues: {output}")
            wizard_state["errors"].append(f"Service start issues: {output}")
            
            # Try manual start as fallback
            print("Trying manual service start...")
            start_services_manually()
        else:
            print("Services started with deployment script.")
    else:
        # Start services manually
        start_services_manually()
    
    wizard_state["steps_completed"].append("start_services")
    input("\nPress Enter to continue...")
    return True

def start_services_manually():
    """Start services manually as a fallback."""
    print("Starting services manually...")
    
    # Start processes in separate threads
    threads = []
    
    if os.path.exists("main.py"):
        print("Starting main Flask app...")
        thread = threading.Thread(target=lambda: subprocess.Popen(
            ["python", "main.py"],
            stdout=open("logs/main_flask.log", "a"),
            stderr=open("logs/main_flask_err.log", "a")
        ))
        thread.daemon = True
        thread.start()
        threads.append(thread)
    
    if os.path.exists("monitoring_web.py"):
        print("Starting monitoring web...")
        thread = threading.Thread(target=lambda: subprocess.Popen(
            ["python", "monitoring_web.py"],
            stdout=open("logs/monitor_web.log", "a"),
            stderr=open("logs/monitor_web_err.log", "a")
        ))
        thread.daemon = True
        thread.start()
        threads.append(thread)
    
    if os.path.exists("web_poker_menu.py"):
        print("Starting web poker menu...")
        thread = threading.Thread(target=lambda: subprocess.Popen(
            ["python", "web_poker_menu.py"],
            stdout=open("logs/web_menu.log", "a"),
            stderr=open("logs/web_menu_err.log", "a")
        ))
        thread.daemon = True
        thread.start()
        threads.append(thread)
    
    # Create logs directory if it doesn't exist
    os.makedirs("logs", exist_ok=True)
    
    # Give services time to start
    print("Waiting for services to start...")
    time.sleep(5)
    
    return True

def run_quick_training():
    """Run a quick training session."""
    print("\nRunning a quick training session...")
    
    if os.path.exists("poker_rl.py"):
        print("Starting a short training session to verify the system...")
        success, output = run_command("python poker_rl.py --mode train --num_episodes 10 --num_iterations 2 --verbose")
        if not success:
            print(f"Warning: Training encountered issues: {output}")
            wizard_state["errors"].append(f"Training issues: {output}")
            
            # Try a simpler training as fallback
            print("Trying a simpler self-play session...")
            success, output = run_command("python poker_rl.py --mode selfplay --num_episodes 2 --verbose")
            if not success:
                print(f"Error with self-play: {output}")
                wizard_state["errors"].append(f"Self-play issues: {output}")
                input("\nThere were errors with the training. Press Enter to continue anyway...")
                return False
            else:
                print("Self-play session completed successfully.")
        else:
            print("Training session completed successfully.")
    else:
        print("poker_rl.py script not found. Skipping training.")
        wizard_state["errors"].append("Could not run training: script not found")
    
    wizard_state["steps_completed"].append("quick_train")
    input("\nPress Enter to continue...")
    return True

def open_dashboard():
    """Open the web dashboard."""
    print("\nOpening web dashboard...")
    
    # Try to detect available web interfaces
    dashboards = []
    
    # Check default ports
    import socket
    def check_port(port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.connect(("localhost", port))
            s.close()
            return True
        except:
            return False
    
    if check_port(5010):
        dashboards.append(("Main Flask App", "http://localhost:5010"))
    if check_port(5003):
        dashboards.append(("Web Poker Dashboard", "http://localhost:5003"))
    if check_port(5000):
        dashboards.append(("Monitoring Web", "http://localhost:5000"))
    if check_port(5001):
        dashboards.append(("Admin Dashboard", "http://localhost:5001"))
    if check_port(5002):
        dashboards.append(("Advanced Admin Dashboard", "http://localhost:5002"))
    
    if not dashboards:
        print("No web interfaces detected. Services may not be running.")
        input("\nPress Enter to continue...")
        return False
    
    print("Available web interfaces:")
    for i, (name, url) in enumerate(dashboards):
        print(f"{i+1}. {name}: {url}")
    
    choice = input("\nEnter the number of the dashboard to open (or 'all' for all): ")
    
    try:
        if choice.lower() == 'all':
            for name, url in dashboards:
                print(f"Opening {name}...")
                webbrowser.open(url)
        else:
            idx = int(choice) - 1
            if 0 <= idx < len(dashboards):
                name, url = dashboards[idx]
                print(f"Opening {name}...")
                webbrowser.open(url)
            else:
                print("Invalid choice.")
    except ValueError:
        print("Invalid choice.")
    
    wizard_state["steps_completed"].append("open_dashboard")
    input("\nPress Enter to continue...")
    return True

def display_welcome():
    """Display welcome message and start the wizard."""
    print("\nWelcome to the Poker AI Quick Start Wizard!")
    print("\nThis wizard will guide you through the setup process for the Poker AI system.")
    print("It will help you install dependencies, set up the database, create an admin user,")
    print("start necessary services, and run a quick training session.")
    print("\nThe wizard will check your system configuration and provide recommendations")
    print("based on your hardware and software environment.")
    print("\nIf you encounter any issues during setup, refer to the README_DEPLOYMENT.md")
    print("file for detailed troubleshooting information.")
    
    wizard_state["start_time"] = datetime.now()
    wizard_state["steps_completed"].append("welcome")
    
    input("\nPress Enter to begin the setup process...")
    return True

def display_completion():
    """Display completion message."""
    print("\nSetup completed successfully!")
    
    # Calculate duration
    wizard_state["completion_time"] = datetime.now()
    duration = wizard_state["completion_time"] - wizard_state["start_time"]
    duration_str = str(duration).split('.')[0]  # Remove microseconds
    
    print(f"\nSetup completed in {duration_str}.")
    
    if wizard_state["errors"]:
        print("\nWarning: Some issues were encountered during setup:")
        for i, error in enumerate(wizard_state["errors"]):
            print(f"  {i+1}. {error}")
        print("\nRefer to the README_DEPLOYMENT.md file for troubleshooting information.")
    
    print("\nYou can now access the Poker AI system through the web interfaces:")
    print("  - Main application:  http://localhost:5010")
    print("  - Web Dashboard:     http://localhost:5003")
    print("  - Monitoring:        http://localhost:5000")
    
    print("\nFor information on using TensorBoard and other features, refer to:")
    print("  - TENSORBOARD_AND_FUNCTIONS_GUIDE.md")
    print("  - COMMON_COMMANDS.md")
    
    # Save wizard state to a file
    with open("onboarding_wizard_state.json", "w") as f:
        # Convert datetime objects to strings
        state_copy = wizard_state.copy()
        if state_copy["start_time"]:
            state_copy["start_time"] = state_copy["start_time"].isoformat()
        if state_copy["completion_time"]:
            state_copy["completion_time"] = state_copy["completion_time"].isoformat()
        
        json.dump(state_copy, f, indent=2)
    
    wizard_state["steps_completed"].append("finish")
    
    print("\nThank you for using the Poker AI Quick Start Wizard!")
    input("\nPress Enter to exit...")
    return True

def execute_step(step: Dict[str, Any]) -> bool:
    """Execute a step in the wizard."""
    print_header()
    print_step_info(step)
    
    action_name = step.get('action')
    action_func = globals().get(action_name)
    
    if action_func and callable(action_func):
        try:
            return action_func()
        except Exception as e:
            logging.error(f"Error executing step {step['id']}: {e}")
            print(f"\nError: {e}")
            wizard_state["errors"].append(f"Error in {step['id']}: {e}")
            input("\nPress Enter to continue anyway...")
            return False
    else:
        logging.error(f"Action function {action_name} not found")
        print(f"\nError: Action function {action_name} not found")
        wizard_state["errors"].append(f"Missing action function: {action_name}")
        input("\nPress Enter to continue anyway...")
        return False

def run_wizard():
    """Run the onboarding wizard."""
    try:
        while wizard_state["current_step"] < len(WIZARD_CONFIG["steps"]):
            step = WIZARD_CONFIG["steps"][wizard_state["current_step"]]
            success = execute_step(step)
            wizard_state["current_step"] += 1
    except KeyboardInterrupt:
        print("\n\nWizard interrupted. Exiting...")
        sys.exit(1)

if __name__ == "__main__":
    try:
        run_wizard()
    except KeyboardInterrupt:
        print("\n\nWizard interrupted. Exiting...")
        sys.exit(1)