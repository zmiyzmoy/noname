import os
import time
import logging
import sys
import signal
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.amp import autocast
from torch.cuda.amp import GradScaler
import torch.multiprocessing as mp
import pyspiel
# import ray - Not using Ray in this version
from tqdm.auto import tqdm
import joblib
import psutil
from sklearn.cluster import KMeans
from collections import deque
from dynamic_sizing import DynamicBetSizing
from typing import Union, Any, Tuple
from fix_openspiel_player_id import OpenSpielPlayerIdFix

# Helper function to safely convert numpy integers to Python integers
def safe_int_convert(value: Union[int, np.integer, Any]) -> int:
    """
    Safely convert numpy integer types to Python integers.
    
    Args:
        value: A value that might be a numpy integer
        
    Returns:
        Python int version of the value
    """
    # Handle numpy integer types (np.int32, np.int64, etc.)
    if isinstance(value, (np.integer, np.int32, np.int64)):
        return int(value)
    # Handle Python integer
    elif isinstance(value, int):
        return value
    # Handle list/tuple/dict containing a single value
    elif isinstance(value, (list, tuple)) and len(value) == 1:
        return safe_int_convert(value[0])
    # Handle string that might contain an integer
    elif isinstance(value, str):
        try:
            return int(value)
        except (ValueError, TypeError):
            logging.warning(f"Could not convert string {value} to int, using 0")
            return 0
    # Handle other types
    else:
        # Try to convert, but return 0 if it fails
        try:
            return int(value)
        except (TypeError, ValueError):
            logging.debug(f"Could not convert value of type {type(value)} to int, using 0")
            return 0
from typing import List, Tuple, Dict, Optional, Any
from open_spiel.python import policy
from torch.utils.tensorboard import SummaryWriter

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('poker_rl.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Import project modules 
from models.ml_models import Config, RegretNet, StrategyNet, StateProcessor, OpponentStats, RewardNormalizer, PrioritizedReplayBuffer, CardEmbedding
from utils import set_random_seed, setup_logging, safe_save_model, load_checkpoint, MultiAgentGameRunner, TournamentEvaluator
from environment import PokerEnvironment, TabularPolicy, TorchPolicy
from psro import PSROSolver, PSROWorker
from opponent_modeling import OpponentModel, analyze_board_texture, analyze_hand_strength, categorize_stack_depth
from adaptation_manager import AdaptationManager

# Add error handling for missing modules
try:
    from poker_action_selector import PokerActionSelector
except ImportError as e:
    logging.error(f"Missing required module: {e}")
    sys.exit(1)

# Add device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
logging.info(f"Using device: {device}")

def parse_args():
    parser = argparse.ArgumentParser(description="Poker Reinforcement Learning System")
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'selfplay'], default='train',
                        help='Operation mode: train, eval or selfplay')
    parser.add_argument('--base_dir', type=str, default='./poker', 
                        help='Base directory for models and logs')
    parser.add_argument('--num_iterations', type=int, default=20, 
                        help='Number of PSRO iterations')
    parser.add_argument('--num_episodes', type=int, default=100, 
                        help='Number of episodes for training or evaluation')
    parser.add_argument('--checkpoint', type=str, default='latest',
                        help='Checkpoint to load (latest, best, or specific path)')
    parser.add_argument('--seed', type=int, default=42, 
                        help='Random seed for reproducibility')
    parser.add_argument('--num_workers', type=int, default=8, 
                        help='Number of parallel workers for training')
    parser.add_argument('--eval_opponents', type=str, 
                        default='random,mccfr,tight_passive,tight_aggressive,loose_passive,loose_aggressive,maniac,calling_station',
                        help='Comma-separated list of opponents for evaluation')
    parser.add_argument('--verbose', action='store_true', 
                        help='Enable verbose output')
    
    # Advanced training options
    parser.add_argument('--batch_size', type=int, default=64, 
                        help='Batch size for neural network training')
    parser.add_argument('--learning_rate', type=float, default=0.001,
                        help='Learning rate for optimizer')
    parser.add_argument('--use_mixed_precision', action='store_true', default=True,
                        help='Use mixed precision training for better performance on GPUs')
    parser.add_argument('--enable_dynamic_adjustment', action='store_true', default=False,
                        help='Enable semi-automatic parameter adjustment based on system resources')
    parser.add_argument('--non_interactive', action='store_true', default=False,
                        help='Run in non-interactive mode (for automated testing)')
    
    return parser.parse_args()

def init_config(args):
    """Initialize configuration with command line args."""
    config = Config()
    config.BASE_DIR = args.base_dir
    config.MODEL_PATH = os.path.join(config.BASE_DIR, 'models', 'psro_model.pt')
    config.BEST_MODEL_PATH = os.path.join(config.BASE_DIR, 'models', 'psro_best.pt')
    config.LOG_DIR = os.path.join(config.BASE_DIR, 'logs')
    config.NUM_EPISODES = args.num_episodes
    config.NUM_WORKERS = args.num_workers
    
    # Create directories
    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)
    
    # Set log level
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.getLogger().setLevel(log_level)
    
    return config

def train_psro(args, config):
    """Run PSRO training."""
    # Set random seed
    set_random_seed(args.seed)
    
    # Initialize TensorBoard writer
    log_dir = os.path.join('runs', 'poker_training', f'run_{int(time.time())}')
    writer = SummaryWriter(log_dir)
    logging.info(f"TensorBoard logging enabled. Log directory: {log_dir}")
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Set learning rate and mixed precision from command line
    config.LEARNING_RATE = args.learning_rate
    config.USE_MIXED_PRECISION = args.use_mixed_precision
    
    # Try to initialize server configuration helper for optimal parameters
    try:
        logging.info("Checking for optimized server configuration...")
        from server_config_helper import get_recommended_psro_config
        server_config = get_recommended_psro_config()
        
        # Only update batch size if not explicitly set via command line
        if args.batch_size == 0:  # Default value, use server recommendation
            if config.BATCH_SIZE != server_config['batch_size']:
                logging.info(f"Using recommended batch size: {server_config['batch_size']}")
                config.BATCH_SIZE = server_config['batch_size']
        else:
            # User specified a batch size, use that instead
            logging.info(f"Using user-specified batch size: {args.batch_size}")
            config.BATCH_SIZE = args.batch_size
            
        # Update worker count from server recommendation
        if config.NUM_WORKERS != server_config['num_workers']:
            logging.info(f"Using recommended worker count: {server_config['num_workers']}")
            config.NUM_WORKERS = server_config['num_workers']
            
        logging.info(f"Final configuration: BATCH_SIZE={config.BATCH_SIZE}, NUM_WORKERS={config.NUM_WORKERS}")
    except ImportError as e:
        logging.warning(f"Server configuration helper not available: {e}. Using default parameters.")
        # Fall back to command line arguments
        if args.batch_size > 0:
            config.BATCH_SIZE = args.batch_size
    except Exception as e:
        logging.error(f"Error applying server configuration: {e}")
        # Fall back to command line arguments
        if args.batch_size > 0:
            config.BATCH_SIZE = args.batch_size
    
    # Initialize standard PSRO solver
    logging.info("Initializing PSRO solver...")
    solver = PSROSolver(config, state_processor)
    
    # Load checkpoint if specified
    if args.checkpoint and args.checkpoint != 'latest':
        solver.load_checkpoints(args.checkpoint)
    
    # Set up adaptation manager for opponent modeling
    opponent_model_path = os.path.join(config.BASE_DIR, 'models', 'opponent_models.json')
    adaptation_manager = AdaptationManager(model_path=opponent_model_path)
    
    # Initialize parameter adjustment helper if enabled
    adjustment_helper_active = args.enable_dynamic_adjustment
    if adjustment_helper_active:
        try:
            from parameter_adjuster import propose_parameter_adjustments
            logging.info("Parameter adjustment helper is ENABLED. Will check for optimal parameters periodically.")
            logging.info(f"Current settings: BATCH_SIZE={config.BATCH_SIZE}, NUM_WORKERS={config.NUM_WORKERS}")
            
            # Run an initial parameter adjustment check when enabled
            logging.info("--- Running Initial Parameter Adjustment Check ---")
            non_interactive = getattr(args, 'non_interactive', False)
            adjustment_helper_active = propose_parameter_adjustments(config, adjustment_helper_active, non_interactive)
            logging.info(f"Updated settings: BATCH_SIZE={config.BATCH_SIZE}, NUM_WORKERS={config.NUM_WORKERS}")
        except ImportError as e:
            logging.error(f"Could not import parameter adjuster: {e}")
            adjustment_helper_active = False
    
    # Define check interval for parameter adjustments
    CHECK_INTERVAL = 10  # Check every 10 iterations by default
    
    # Run PSRO iterations with TensorBoard logging
    logging.info(f"Starting PSRO training for {args.num_iterations} iterations...")
    
    # Custom br_policy_iteration with TensorBoard logging
    for iteration in range(args.num_iterations):
        logging.info(f"Starting iteration {iteration+1}/{args.num_iterations}")
        
        # Run parameter adjustment check if enabled
        if args.enable_dynamic_adjustment and adjustment_helper_active and (iteration + 1) % CHECK_INTERVAL == 0:
            logging.info(f"--- Running Parameter Adjustment Check (Iteration {iteration+1}) ---")
            try:
                # Pass the current state and get the updated state
                # Use non_interactive=True when running in automated testing
                non_interactive = getattr(args, 'non_interactive', False)
                adjustment_helper_active = propose_parameter_adjustments(config, adjustment_helper_active, non_interactive)
                if adjustment_helper_active:
                    logging.info("Parameter adjustment checks will continue.")
                else:
                    logging.info("Parameter adjustment checks have been disabled for the remainder of this run.")
            except Exception as e:
                logging.error(f"Error in parameter adjustment helper: {e}")
        
        # Run one iteration of the solver
        metrics = solver.run_iteration()
        
        # Log metrics to TensorBoard
        if metrics:
            for key, value in metrics.items():
                if isinstance(value, (int, float)):
                    writer.add_scalar(f'training/{key}', value, iteration)
            
            # Log system usage
            writer.add_scalar('system/cpu_usage', psutil.cpu_percent(), iteration)
            writer.add_scalar('system/memory_usage', psutil.virtual_memory().percent, iteration)
            
            # Log model gradients if available
            if hasattr(solver, 'regret_net') and hasattr(solver.regret_net, 'named_parameters'):
                for name, param in solver.regret_net.named_parameters():
                    if param.grad is not None:
                        writer.add_histogram(f'gradients/{name}', param.grad, iteration)
        
        # Save checkpoint if needed
        if (iteration + 1) % config.CHECKPOINT_INTERVAL == 0:
            solver.save_checkpoints(tag=f'iter_{iteration+1}')
            
            # Also run intermediate evaluation for monitoring progress
            if iteration > 0 and (iteration + 1) % (config.CHECKPOINT_INTERVAL * 2) == 0:
                logging.info(f"Running intermediate evaluation at iteration {iteration+1}")
                # Create a small subset of opponents for quick evaluation
                tmp_args = argparse.Namespace(**vars(args))
                tmp_args.eval_opponents = 'random,tight_aggressive,loose_passive'
                tmp_args.num_episodes = max(args.num_episodes // 10, 10)  # Use fewer episodes for speed
                eval_results = evaluate_agent(tmp_args, config, solver=solver)
                
                # Log evaluation results to TensorBoard
                if eval_results:
                    for key, value in eval_results.items():
                        if isinstance(value, (int, float)):
                            writer.add_scalar(f'intermediate_eval/{key}', value, iteration)
    
    # Save final checkpoint
    solver.save_checkpoints(tag='final')
    
    # Final evaluation
    logging.info("Training complete, running final evaluation...")
    eval_results = evaluate_agent(args, config, solver=solver)
    
    # Log evaluation results to TensorBoard
    if eval_results:
        for key, value in eval_results.items():
            if isinstance(value, (int, float)):
                writer.add_scalar(f'evaluation/{key}', value, args.num_iterations)
    
    # Close TensorBoard writer
    writer.close()
    
    logging.info("PSRO training completed successfully")

def evaluate_agent(args, config, solver=None):
    """Evaluate trained agent against various opponents."""
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Load solver if not provided
    if solver is None:
        solver = PSROSolver(config, state_processor)
        checkpoint_tag = args.checkpoint if args.checkpoint != 'latest' else 'final'
        if not solver.load_checkpoints(checkpoint_tag):
            logging.warning(f"Could not load checkpoint: {checkpoint_tag}")
            # Continue with the initialized solver anyway
            logging.info("Using randomly initialized model for demonstration")
    
    # Parse opponents list
    opponent_types = args.eval_opponents.split(',')
    game = pyspiel.load_game(config.GAME_NAME)
    
    # Load the adaptation manager
    opponent_model_path = os.path.join(config.BASE_DIR, 'models', 'opponent_models.json')
    adaptation_manager = AdaptationManager(model_path=opponent_model_path)
    
    # Create opponent policies
    opponent_policies = []
    for opp_type in opponent_types:
        if opp_type == 'random':
            # Random policy
            opponent_policies.append(policy.UniformRandomPolicy(game))
        elif opp_type == 'mccfr':
            # Try to load MCCFR policy if available in OpenSpiel
            try:
                from open_spiel.python.algorithms import mccfr
                
                # Check which MCCFR implementation is available (handles different OpenSpiel versions)
                if hasattr(mccfr, 'OutcomeSamplingMCCFRSolver'):
                    # Newer versions of OpenSpiel
                    opponent = mccfr.OutcomeSamplingMCCFRSolver(game)
                elif hasattr(mccfr, 'MCCFRSolver'):
                    # Older versions of OpenSpiel
                    opponent = mccfr.MCCFRSolver(game, mccfr.MCCFRSolverType.OUTCOME_SAMPLING)
                else:
                    # Try another common implementation
                    from open_spiel.python.algorithms import cfr
                    logging.warning("MCCFR not found, using CFR instead")
                    opponent = cfr.CFRSolver(game)
                
                # Train the opponent policy
                logging.info("Training CFR/MCCFR opponent (1000 iterations)")
                for _ in tqdm(range(1000), desc="Training CFR/MCCFR opponent"):
                    opponent.iteration()
                
                # Get the average policy
                opponent_policies.append(opponent.average_policy())
                logging.info("CFR/MCCFR opponent trained successfully")
            except (ImportError, AttributeError) as e:
                logging.warning(f"CFR/MCCFR not available: {e}, using random policy instead")
                opponent_policies.append(policy.UniformRandomPolicy(game))
        elif opp_type in ['tight_passive', 'tight_aggressive', 'loose_passive', 'loose_aggressive', 
                         'maniac', 'rock', 'calling_station', 'nit']:
            # Create an archetypical policy based on opponent model
            try:
                from environment import AdaptedTorchPolicy
                # Create a custom policy that uses our model but adapts actions based on archetype
                adapted_policy = AdaptedTorchPolicy(game, solver.regret_net, state_processor, 
                                                  archetype=opp_type, adaptation_manager=adaptation_manager)
                opponent_policies.append(adapted_policy)
                logging.info(f"Created adapted policy for archetype: {opp_type}")
            except Exception as e:
                logging.warning(f"Error creating adapted policy for {opp_type}: {e}")
                opponent_policies.append(policy.UniformRandomPolicy(game))
        else:
            logging.warning(f"Unknown opponent type: {opp_type}, using random policy")
            opponent_policies.append(policy.UniformRandomPolicy(game))
    
    # Add our best policy
    our_policy = TorchPolicy(game, solver.regret_net, state_processor)
    
    # Set up evaluator
    evaluator = TournamentEvaluator(config.GAME_NAME, config.NUM_PLAYERS, num_games=args.num_episodes)
    
    # Evaluate against each opponent
    logging.info("Starting evaluation against opponents...")
    
    # Store evaluation results for return and TensorBoard logging
    eval_results = {}
    
    for i, opp in enumerate(opponent_policies):
        logging.info(f"Evaluating against {opponent_types[i]}...")
        
        # Set up policies for evaluation
        eval_policies = [our_policy, opp]
        
        # Run tournament
        results = evaluator.run_tournament(eval_policies)
        
        # Log results
        our_vs_opp_score = results[0, 1]
        opp_vs_our_score = results[1, 0]
        
        logging.info(f"Results against {opponent_types[i]}:")
        logging.info(f"  Our policy vs {opponent_types[i]}: {our_vs_opp_score:.4f}")
        logging.info(f"  {opponent_types[i]} vs Our policy: {opp_vs_our_score:.4f}")
        
        # Store results in the results dictionary
        eval_results[f'our_vs_{opponent_types[i]}'] = our_vs_opp_score
        eval_results[f'{opponent_types[i]}_vs_our'] = opp_vs_our_score
        eval_results[f'net_win_rate_{opponent_types[i]}'] = our_vs_opp_score - opp_vs_our_score
    
    # Calculate overall metrics
    if opponent_policies:
        eval_results['average_win_rate'] = sum(eval_results[f'our_vs_{opp_type}'] 
                                              for i, opp_type in enumerate(opponent_types)) / len(opponent_types)
        
        # Calculate exploitability if available
        try:
            from open_spiel.python.algorithms import exploitability
            # Only run exploitability analysis for small games as it's expensive
            if config.GAME_NAME in ["kuhn_poker", "leduc_poker"]:
                exploitability_value = exploitability.exploitability(game, our_policy)
                eval_results['exploitability'] = exploitability_value
                logging.info(f"Exploitability: {exploitability_value:.6f}")
        except (ImportError, AttributeError) as e:
            logging.warning(f"Could not calculate exploitability: {e}")
    
    logging.info("Evaluation complete")
    
    return eval_results

def selfplay(args, config):
    """Run selfplay mode for demonstration with opponent modeling and adaptation."""
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize standard PSRO solver for selfplay
    logging.info("Initializing standard PSRO solver for selfplay...")
    solver = PSROSolver(config, state_processor)
    
    checkpoint_tag = args.checkpoint if args.checkpoint != 'latest' else 'final'
    if not solver.load_checkpoints(checkpoint_tag):
        logging.warning(f"Could not load checkpoint: {checkpoint_tag}")
        # Continue with the initialized solver anyway
        logging.info("Using randomly initialized model for demonstration")
    
    # Create policy
    game = pyspiel.load_game(config.GAME_NAME)
    our_policy = TorchPolicy(game, solver.regret_net, state_processor)
    
    # Create environment for selfplay
    env = PokerEnvironment(config.GAME_NAME, config.NUM_PLAYERS)
    
    # Create action selector with dynamic bet sizing
    from poker_action_selector import PokerActionSelector
    action_selector = PokerActionSelector(game, solver, state_processor, config)
    
    # Create adaptation manager for opponent modeling and strategy adaptation
    opponent_model_path = os.path.join(config.BASE_DIR, 'models', 'opponent_models.json')
    adaptation_manager = AdaptationManager(model_path=opponent_model_path, save_interval=5)
    
    # Check for parameter adjustment if enabled
    if args.enable_dynamic_adjustment:
        try:
            from parameter_adjuster import propose_parameter_adjustments
            logging.info("Parameter adjustment helper is ENABLED for selfplay.")
            logging.info(f"Current settings: BATCH_SIZE={config.BATCH_SIZE}, NUM_WORKERS={config.NUM_WORKERS}")
            
            # Run an initial parameter adjustment check
            logging.info("--- Running Parameter Adjustment Check (Selfplay Mode) ---")
            non_interactive = getattr(args, 'non_interactive', False)
            propose_parameter_adjustments(config, True, non_interactive)
            logging.info(f"Updated settings: BATCH_SIZE={config.BATCH_SIZE}, NUM_WORKERS={config.NUM_WORKERS}")
        except ImportError as e:
            logging.error(f"Could not import parameter adjuster: {e}")
    
    # Run games
    logging.info("Starting selfplay demonstration with opponent modeling...")
    
    for episode in range(args.num_episodes):
        state = env.reset()
        done = False
        episode_actions = []
        
        # Initial stacks for all players (100 BB each)
        stacks = [100.0 * config.BB] * config.NUM_PLAYERS
        pot = 0.0
        hole_cards = [None] * config.NUM_PLAYERS
        board_cards = []
        
        # Track round-specific information
        current_round = "PREFLOP"
        street_mapping = {0: "PREFLOP", 1: "FLOP", 2: "TURN", 3: "RIVER"}
        player_actions = {p: [] for p in range(config.NUM_PLAYERS)}
        round_idx = 0  # Initialize round_idx at the episode level
        
        # Track whether the last player was chance to detect player ID=-4 issues
        last_player_was_chance = False
        chance_action_counts = 0
        
        while not done:
            # Check for OpenSpiel player ID=-4 issue using our fix
            # Returns tuple (is_terminal_override, fixed_player_id)
            # Handle potential player ID=-4 cases which are actually terminal
            if OpenSpielPlayerIdFix.is_terminal_or_error(state):
                logging.info("OpenSpiel fix: Detected terminal state with player ID=-4")
                done = True
                break
            
            # Get current round safely (do this outside the node handling)
            round_idx = -1
            if hasattr(state, 'round'):
                if callable(getattr(state, 'round')):
                    round_idx = state.round()
                else:
                    round_idx = getattr(state, 'round')
            elif len(board_cards) == 0:
                round_idx = 0  # Preflop
            elif len(board_cards) <= 3:
                round_idx = 1  # Flop
            elif len(board_cards) <= 4:
                round_idx = 2  # Turn
            else:
                round_idx = 3  # River
            
            # Update current round
            current_round = street_mapping.get(round_idx, "UNKNOWN")
            
            if state.is_chance_node():
                # Handle chance node
                outcomes = state.chance_outcomes()
                action_list, prob_list = zip(*outcomes)
                action = np.random.choice(action_list, p=prob_list)
                
                # Track cards if available (simplified)
                try:
                    if hasattr(state, 'card_str'):
                        card = state.card_str(action)
                        if round_idx == 0:  # Preflop
                            # Track hole cards
                            player_idx = state.current_player() % config.NUM_PLAYERS
                            if player_idx < len(hole_cards):
                                if not hole_cards[player_idx]:
                                    hole_cards[player_idx] = [card]
                                else:
                                    hole_cards[player_idx].append(card)
                        else:  # Postflop
                            # Track board cards
                            board_cards.append(card)
                except Exception as e:
                    if args.verbose:
                        logging.warning(f"Error tracking cards: {e}")
            else:
                # Apply the OpenSpiel player ID fix
                player_id = state.current_player()
                player, is_terminal_override = OpenSpielPlayerIdFix.fix_state_player(state)
                
                # Check if we detected a terminal state (player_id = -4)
                if is_terminal_override:
                    if args.verbose:
                        logging.info(f"OpenSpiel fix: Fixed player ID from {player_id} to {player}")
                    if player_id == -4:
                        logging.info("OpenSpiel fix: Detected player ID=-4, treating as terminal state")
                        done = True
                        break
                
                # Update pot and stacks (simplified)
                try:
                    if hasattr(state, 'pot'):
                        pot = state.pot()
                    if hasattr(state, 'contribution'):
                        for p, contrib in enumerate(state.contribution()):
                            if p < len(stacks):
                                stacks[p] = 100.0 * config.BB - contrib
                except Exception as e:
                    if args.verbose:
                        logging.warning(f"Error updating pot/stacks: {e}")
                            
                # Map position names based on player index (simplistic mapping)
                positions = ["BTN", "SB", "BB", "UTG", "MP", "CO"]
                position_name = positions[player % len(positions)]
                position_idx = player % len(positions)
                
                # Check for previous actions to detect raise situations
                is_raised_pot = False
                is_bet_pot = False
                is_3bet_situation = False
                is_cbet_situation = False
                
                # Analyze the betting situation
                try:
                    if player_actions:
                        # Check for raises in the current round
                        current_round_actions = []
                        for p_actions in player_actions.values():
                            for action in p_actions:
                                # Handle different possible action formats
                                if isinstance(action, dict) and 'round' in action:
                                    if action.get('round') == current_round:
                                        current_round_actions.append(action)
                        
                        # Safely check action types
                        raise_actions = []
                        for action in current_round_actions:
                            if isinstance(action, dict) and 'action_type' in action:
                                if action.get('action_type') in ['raise', 'bet']:
                                    raise_actions.append(action)
                        
                        # Safely check for raised pot
                        is_raised_pot = False
                        is_bet_pot = False
                        for action in current_round_actions:
                            if isinstance(action, dict) and 'action_type' in action:
                                if action.get('action_type') == 'raise':
                                    is_raised_pot = True
                                if action.get('action_type') == 'bet':
                                    is_bet_pot = True
                        
                        # Check for 3-bet situation
                        if len(raise_actions) >= 1 and current_round == "PREFLOP":
                            is_3bet_situation = True
                        
                        # Check for c-bet situation
                        if current_round == "FLOP" and player in player_actions and player_actions[player]:
                            preflop_actions = []
                            for action in player_actions[player]:
                                if isinstance(action, dict) and 'round' in action:
                                    if action.get('round') == "PREFLOP":
                                        preflop_actions.append(action)
                            
                            for action in preflop_actions:
                                if isinstance(action, dict) and 'action_type' in action:
                                    if action.get('action_type') in ['raise', 'bet']:
                                        is_cbet_situation = True
                except Exception as e:
                    if args.verbose:
                        logging.warning(f"Error analyzing betting situation: {e}")
                
                # Get opponent profiles for the other players
                opponent_profiles = {}
                for opp in range(config.NUM_PLAYERS):
                    if opp != player:  # Get profiles for opponents
                        profile = adaptation_manager.get_opponent_profile(opp)
                        if profile['has_profile']:
                            opponent_profiles[opp] = profile
                
                # Select action using adaptive strategy based on opponent modeling
                try:
                    # Default hole cards if we couldn't track them
                    player_cards = (hole_cards[player] if player < len(hole_cards) and hole_cards[player] 
                                 else ["Ah", "Kd"])
                    
                    # First get base policy action probabilities
                    base_action_probs = our_policy.action_probabilities(state)
                    
                    # Apply adaptation based on opponent profiles if this player is the hero
                    adapted_probs = None
                    is_hero = player == 0  # Assume player 0 is our AI
                    
                    if is_hero and opponent_profiles:
                        # Get primary opponent ID (simplest approach: assume heads up against player 1)
                        main_opponent = 1 if 1 in opponent_profiles else next(iter(opponent_profiles))
                        
                        # Determine if we're in a bluff or value bet situation
                        is_bluff = False
                        is_value_bet = False
                        if hole_cards[player] and board_cards:
                            hand_analysis = analyze_hand_strength(hole_cards[player], board_cards)
                            is_bluff = hand_analysis['strength'] < 0.4
                            is_value_bet = hand_analysis['strength'] > 0.6
                        
                        # Ensure base_action_probs is a dictionary before passing to adaptation
                        if not isinstance(base_action_probs, dict):
                            logging.warning(f"base_action_probs is not a dictionary, type: {type(base_action_probs)}")
                            if isinstance(base_action_probs, int):
                                # Convert single integer action to a dictionary format
                                base_action_probs = {base_action_probs: 1.0}
                            else:
                                # Create uniform distribution over legal actions as fallback
                                legal_actions = state.legal_actions()
                                base_action_probs = {a: 1.0 / len(legal_actions) for a in legal_actions}
                                
                        # Apply adaptation
                        try:
                            adapted_probs = adaptation_manager.get_adapted_action_probs(
                                player_id=main_opponent,
                                original_probs=base_action_probs,
                                is_preflop=(current_round == "PREFLOP"),
                                is_bluff=is_bluff,
                                is_value_bet=is_value_bet,
                                position=position_idx
                            )
                            
                            # Verify the returned adapted_probs is a dictionary
                            if not isinstance(adapted_probs, dict):
                                logging.warning(f"Error in adaptive action selection: {adapted_probs}")
                                adapted_probs = base_action_probs  # Fallback to base actions
                                
                        except Exception as e:
                            logging.warning(f"Exception in adaptation: {e}")
                            adapted_probs = base_action_probs  # Fallback to base actions
                        
                        # Get strategic recommendation
                        recommendation = None
                        if hole_cards[player] and board_cards and args.verbose:
                            recommendation = adaptation_manager.get_hand_recommendation(
                                player_id=main_opponent,
                                hole_cards=hole_cards[player],
                                board_cards=board_cards,
                                position=position_idx,
                                street=round_idx,
                                pot_size=pot,
                                stack_size=stacks[player]
                            )
                            if recommendation and 'strategy' in recommendation:
                                logging.info(f"AI Recommendation: {recommendation['strategy']} (confidence: {recommendation['confidence']:.2f})")
                    
                    # Use adapted probabilities if available, otherwise use default
                    action_probs = adapted_probs if adapted_probs else base_action_probs
                    
                    # Validate the action probabilities
                    if action_probs is not None and isinstance(action_probs, dict):
                        # Validate that the keys are ints and values are floats
                        validated_probs = {}
                        try:
                            for k, v in action_probs.items():
                                try:
                                    key = int(k)
                                    validated_probs[key] = float(v)
                                except (ValueError, TypeError):
                                    # Skip invalid entries
                                    continue
                            
                            # Only use validated_probs if valid entries were found
                            if validated_probs:
                                action_probs = validated_probs
                        except Exception as e:
                            logging.warning(f"Error validating action probabilities: {e}")
                    
                    # Convert action_probs to the correct format if it's an integer
                    if isinstance(action_probs, int):
                        logging.info(f"Converting action_probs from int ({action_probs}) to dictionary format")
                        action_probs = {action_probs: 1.0}
                    # Handle action_probs=None case
                    elif action_probs is None:
                        logging.info("action_probs is None, using uniform distribution over legal actions")
                        legal_actions = state.legal_actions()
                        action_probs = {a: 1.0 / len(legal_actions) for a in legal_actions}
                    
                    # Use the action selector with the (potentially adapted) action probabilities
                    try:
                        action_result = action_selector.select_action(
                            state, 
                            player, 
                            stacks, 
                            max(pot, 1.0),  # Ensure pot is at least 1.0
                            board_cards, 
                            player_cards,
                            position_name,
                            opponent_stats=opponent_profiles.get(1, {}) if opponent_profiles is not None else {},  # Pass opponent stats if available
                            exploration_rate=0.1,
                            detailed_output=args.verbose,
                            action_probs=action_probs  # Pass adapted action probabilities
                        )
                    except Exception as e:
                        logging.warning(f"Error in action selection, using fallback: {e}")
                        
                        try:
                            # Log the bet options to help debug issues
                            if hasattr(state, 'pot') and state.pot() > 0 and hole_cards[player]:
                                bet_sizer = DynamicBetSizing(stacks, config)
                                bet_options = bet_sizer.calculate_bet_options(
                                    state, 
                                    max(pot, 1.0),
                                    player,
                                    position_name,
                                    board_cards or [],
                                    player_cards,
                                    {},
                                    round_idx=round_idx,
                                    is_raise=is_raised_pot
                                )
                                logging.debug(f"Calculated bet options: {bet_options}")
                        except Exception as bet_error:
                            logging.debug(f"Error calculating bet options: {bet_error}")
                        
                        # Fallback to simple selection with clean action_probs
                        # Create a fresh, empty dictionary for action probabilities
                        clean_action_probs = {}
                        for legal_action in state.legal_actions():
                            clean_action_probs[safe_int_convert(legal_action)] = 1.0 / len(state.legal_actions())
                            
                        action_result = action_selector.select_action(
                            state, 
                            player, 
                            stacks, 
                            max(pot, 1.0),
                            board_cards, 
                            player_cards,
                            position_name,
                            exploration_rate=0.1,
                            detailed_output=args.verbose,
                            action_probs=clean_action_probs  # Pass clean action probs
                        )
                    # Convert numpy int to Python int if needed
                    if isinstance(action_result['action'], (np.integer, np.int32, np.int64)):
                        action = safe_int_convert(action_result['action']) 
                    else:
                        action = action_result['action']
                    
                    # Log the action with additional details
                    if args.verbose:
                        ev = action_result.get('ev', 0)
                        method = action_result.get('method', 'unknown')
                        amount = action_result.get('amount', 0)
                        # Convert any numpy values to native Python types for serialization
                        method_str = str(method) if method else 'unknown'
                        # Ensure action is a Python int and ev/amount are native Python floats
                        episode_actions.append((safe_int_convert(player), 
                                              safe_int_convert(action), 
                                              method_str, 
                                              float(amount) if amount else 0.0, 
                                              float(ev) if ev else 0.0))
                    else:
                        # Convert player and action to ensure they're Python integers
                        episode_actions.append((safe_int_convert(player), 
                                              safe_int_convert(action)))
                    
                    # Register the action with the adaptation manager
                    # Map the numerical action ID to a string action type
                    try:
                        # Handle different possible formats of action_result
                        # Could be a dictionary, an integer, or some other type
                        if isinstance(action_result, dict):
                            # Handle the case where action_result['action'] is a numpy integer type
                            if 'action' in action_result:
                                if isinstance(action_result['action'], (np.integer, np.int32, np.int64)):
                                    action_id = int(action_result['action'])  # Convert to Python int
                                else:
                                    action_id = action_result['action']
                            else:
                                action_id = 0
                                
                            amount = action_result.get('amount', 0)
                        elif isinstance(action_result, (int, np.integer, np.int32, np.int64)):
                            action_id = int(action_result)  # Convert numpy int types to Python int
                            amount = 0
                        else:
                            # Default fallback
                            action_id = 0
                            amount = 0
                            logging.debug(f"Unknown action_result type: {type(action_result)}")
                            
                        # Action mapping: 0=fold, 1=call, 2=raise (small), 3=raise (big)
                        action_mapping = {0: 'fold', 1: 'call', 2: 'raise', 3: 'raise'}
                        action_type = action_mapping.get(action_id, 'check')  # Default to 'check' if unknown
                    except Exception as e:
                        logging.debug(f"Error processing action_result: {e}")
                        action_type = 'unknown'
                        amount = 0
                    
                    adaptation_manager.register_action(
                        player_id=player,
                        action_type=action_type,
                        position=position_idx,
                        street=round_idx,
                        poker_round=current_round,
                        amount=amount,
                        pot_size=pot,
                        stack_size=stacks[player],
                        hole_cards=hole_cards[player] if player < len(hole_cards) else None,
                        board_cards=board_cards,
                        is_hero=(player == 0),
                        is_raised_pot=is_raised_pot,
                        is_bet_pot=is_bet_pot,
                        is_3bet_situation=is_3bet_situation,
                        is_cbet_situation=is_cbet_situation
                    )
                    
                    # Track the action for betting situation analysis
                    player_actions[player].append({
                        'action_type': action_type,
                        'round': current_round,
                        'position': position_idx,
                        'amount': amount
                    })
                        
                except Exception as e:
                    # Fallback to default action selection on error
                    logging.warning(f"Error in adaptive action selection: {e}")
                    action_probs = our_policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    probs = np.array(probs) / np.sum(probs)  # Normalize
                    action = np.random.choice(actions, p=probs)
                    # Ensure action and player are Python integers, not numpy integers
                    action = safe_int_convert(action)
                    player_int = safe_int_convert(player)
                    episode_actions.append((player_int, action))
            
            # Apply action
            state, rewards, done, info = env.step(action)
        
        # Log episode results
        logging.info(f"Episode {episode+1} complete")
        if hasattr(state, 'returns'):
            rewards = state.returns()
            logging.info(f"  Final returns: {rewards}")
            
            # Register hand results with adaptation manager
            for p in range(config.NUM_PLAYERS):
                net_win = rewards[p] if p < len(rewards) else 0
                adaptation_manager.register_hand_result(
                    player_id=p,
                    net_win=net_win,
                    had_showdown=True,  # Simplified assumption
                    hole_cards=hole_cards[p] if p < len(hole_cards) else None,
                    board_cards=board_cards
                )
        
        if args.verbose:
            logging.info(f"  Actions: {episode_actions}")
    
    # Save the opponent models
    adaptation_manager.save_models()
    logging.info(f"Opponent models saved to {opponent_model_path}")
    logging.info("Selfplay demonstration with opponent modeling complete")

def main():
    args = parse_args()
    config = init_config(args)
    
    # Register signal handlers for graceful shutdown
    def signal_handler(sig, frame):
        logging.info("Received termination signal, shutting down gracefully...")
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run in selected mode
    if args.mode == 'train':
        train_psro(args, config)
    elif args.mode == 'eval':
        evaluate_agent(args, config)
    elif args.mode == 'selfplay':
        selfplay(args, config)
    else:
        logging.error(f"Unknown mode: {args.mode}")

if __name__ == "__main__":
    main()
