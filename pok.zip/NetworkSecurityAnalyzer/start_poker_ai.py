#!/usr/bin/env python3
import os
import sys
import signal
import subprocess
import time
import re
import json

# List of specific servers to stop - add all known Flask and Python servers
SERVER_PATTERNS = [
    r"python (monitoring_web\.py|admin_dashboard\.py|advanced_dashboard\.py|easy_poker_menu\.py|web_poker_menu\.py|run_onboarding_wizard\.py|web_onboarding_wizard\.py)",
    r"python.*?monitoring_web\.py",
    r"python.*?admin_dashboard\.py",
    r"python.*?advanced_dashboard\.py",
    r"python.*?easy_poker_menu\.py",
    r"python.*?web_poker_menu\.py",
    r"python.*?run_onboarding_wizard\.py",
    r"python.*?web_onboarding_wizard\.py",
    r"python.*?poker_rl\.py",
    r"python.*?cloud_trainer\.py",
    r"python.*?simple_dashboard\.py"
]

def clear_replit_workflows():
    """Remove all workflows except the consolidated app."""
    try:
        # First, we'll try to find and read the Replit workflow configuration
        replit_path = os.path.join(os.getcwd(), '.replit')
        
        if os.path.exists(replit_path):
            with open(replit_path, 'r') as f:
                replit_content = f.read()
            
            # Parse out the [run] section to get workflow configuration
            run_section = re.search(r'\[run\]\s+(.*?)(?=\[|\Z)', replit_content, re.DOTALL)
            if run_section:
                run_content = run_section.group(1)
                
                # Find all workflow configurations
                workflow_configs = re.findall(r'(\[\[\s*run\.\w+\s*\]\].*?(?=\[\[\s*run|\Z))', run_content, re.DOTALL)
                
                if workflow_configs:
                    # Keep only the consolidated app workflow
                    new_run_content = ""
                    for config in workflow_configs:
                        if "main.py" in config:
                            new_run_content += config
                    
                    # Replace the run section with only the consolidated app
                    new_replit_content = re.sub(
                        r'(\[run\]\s+).*?(?=\[|\Z)',
                        r'\1' + new_run_content,
                        replit_content,
                        flags=re.DOTALL
                    )
                    
                    # Save the updated .replit file
                    with open(replit_path, 'w') as f:
                        f.write(new_replit_content)
                    
                    print("Updated Replit workflow configuration to keep only the consolidated app.")
        
        # Also try to update workflow configuration in toml format
        try:
            import toml
            replit_nix_path = os.path.join(os.getcwd(), 'replit.nix')
            if os.path.exists(replit_nix_path):
                with open(replit_nix_path, 'r') as f:
                    config = toml.load(f)
                
                # Keep only the consolidated app in run configurations
                if 'run' in config:
                    new_run = {}
                    for key, value in config['run'].items():
                        if isinstance(value, dict) and 'command' in value and 'main.py' in value['command']:
                            new_run[key] = value
                    
                    if new_run:
                        config['run'] = new_run
                        with open(replit_nix_path, 'w') as f:
                            toml.dump(config, f)
                        print("Updated replit.nix configuration.")
        except (ImportError, Exception) as e:
            # If toml package isn't available or other error, just continue
            pass
    except Exception as e:
        print(f"Error updating Replit workflow configuration: {e}")

def get_python_processes():
    """Get a list of running Python processes matching our patterns."""
    try:
        output = subprocess.check_output(["ps", "aux"]).decode("utf-8")
        lines = output.strip().split("\n")
        python_processes = []
        
        for line in lines:
            # Exclude our main app and this script itself
            if "python" in line and "main.py" not in line and "start_poker_ai.py" not in line:
                # Check against our patterns
                for pattern in SERVER_PATTERNS:
                    if re.search(pattern, line):
                        parts = line.split()
                        pid = int(parts[1])
                        command = " ".join(parts[10:])
                        python_processes.append((pid, command))
                        break
                
        return python_processes
    except Exception as e:
        print(f"Error getting processes: {e}")
        return []

def stop_process(pid):
    """Stop a process by sending SIGTERM."""
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"Sent SIGTERM to process {pid}")
        return True
    except Exception as e:
        print(f"Error stopping process {pid}: {e}")
        return False

def kill_processes_on_ports():
    """Kill processes listening on known web server ports."""
    ports = [5000, 5001, 5002, 5003, 5004, 5005, 5020, 5050, 5060]
    
    for port in ports:
        try:
            # Find process using port
            lsof_cmd = f"lsof -i :{port}"
            output = subprocess.check_output(lsof_cmd, shell=True).decode("utf-8")
            lines = output.strip().split("\n")
            
            if len(lines) > 1:  # Skip header row
                for line in lines[1:]:
                    parts = line.split()
                    if len(parts) >= 2:
                        pid = int(parts[1])
                        name = parts[0]
                        try:
                            os.kill(pid, signal.SIGTERM)
                            print(f"Stopped process {pid} ({name}) on port {port}")
                        except Exception as e:
                            print(f"Error stopping process {pid} on port {port}: {e}")
        except Exception:
            # lsof not found or no process on port - ignore
            pass

def stop_other_servers():
    """Stop all Python server processes except main.py."""
    print("Stopping other Python server processes...")
    
    # First try killing by port (more reliable)
    try:
        kill_processes_on_ports()
    except Exception as e:
        print(f"Error trying to kill processes by port: {e}")
    
    # Then find and kill specific Python processes
    processes = get_python_processes()
    if not processes:
        print("No other Python server processes found to stop.")
    else:
        print(f"\nFound {len(processes)} other Python processes:")
        for pid, command in processes:
            print(f"PID {pid}: {command}")
        
        print("\nStopping processes...")
        for pid, command in processes:
            if stop_process(pid):
                print(f"Stopped: PID {pid} - {command}")
        
        # Wait a moment and check if any processes are still running
        time.sleep(2)
        remaining = get_python_processes()
        
        if remaining:
            print(f"\n{len(remaining)} processes still running:")
            for pid, command in remaining:
                print(f"PID {pid}: {command}")
            
            print("\nTrying to force stop remaining processes...")
            for pid, command in remaining:
                try:
                    os.kill(pid, signal.SIGKILL)
                    print(f"Sent SIGKILL to process {pid}")
                except Exception as e:
                    print(f"Error force stopping process {pid}: {e}")

def start_consolidated_app():
    """Start the consolidated Flask application."""
    print("Starting consolidated Poker AI application...")
    
    # Check if the app is already running
    try:
        output = subprocess.check_output(["ps", "aux"]).decode("utf-8")
        if "python main.py" in output:
            print("Consolidated app is already running.")
            return
    except Exception:
        pass
    
    # Start the app
    try:
        subprocess.Popen(
            ["python", "main.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        print("Started consolidated app on port 5010.")
    except Exception as e:
        print(f"Error starting app: {e}")

def main():
    """Stop other servers and start the consolidated app."""
    print("Poker AI System Startup")
    print("======================")
    
    print("Updating Replit workflow configuration...")
    clear_replit_workflows()
    
    print("\nStopping any existing server processes...")
    stop_other_servers()
    
    print("\nStarting consolidated Poker AI application...")
    start_consolidated_app()
    
    print("\nSetup complete!")
    print("Access the application at: http://localhost:5010/")
    print("======================")

if __name__ == "__main__":
    main()