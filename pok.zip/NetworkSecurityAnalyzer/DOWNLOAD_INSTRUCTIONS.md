# How to Download and Transfer the Poker AI System

## Method 1: Using Replit's "Download as Zip" Feature

The easiest way to download all project files from Replit is to use the built-in "Download as Zip" feature:

1. In the Replit interface, locate the three dots menu (...) in the top-right corner of the Files panel
2. Click on the menu and select "Download as Zip"
3. Save the zip file to your computer
4. Upload the zip file to your server using SCP, SFTP, or another file transfer method
5. Extract the files on your server:
   ```
   unzip poker_ai_system.zip -d ~/poker_ai
   ```

## Method 2: Manual Download of Core Files

If the download zip feature doesn't work or you prefer to download only the essential files, refer to the list in CORE_FILES.md for the critical files you need to transfer.

## Setting Up on Your Server

Once you have transferred the files to your server, follow these steps:

1. Navigate to the project directory:
   ```
   cd ~/poker_ai
   ```

2. Follow the steps in DEPLOYMENT_INSTRUCTIONS.md to set up your environment, database, and services.

## Important Configuration Changes

After transferring to your server, you'll need to modify these key configuration settings:

1. Database URL: Update any database connection strings to match your server's PostgreSQL setup
   ```
   export DATABASE_URL="postgresql://yourusername:yourpassword@localhost/yourdbname"
   ```

2. Port Bindings: Make sure to bind to 0.0.0.0 instead of localhost to make services accessible from other machines
   ```python
   # In main.py and other server files
   app.run(host="0.0.0.0", port=5010)
   ```

3. Server IP: Update any hardcoded URLs to use your server's IP address or domain name

## Security Notes

1. Make sure to change the default admin password (pokeradmin/pokerpwd123) immediately after setup
2. Set secure passwords for your database
3. Consider setting up a firewall to restrict access to the necessary ports only
4. For production use, set up HTTPS using Let's Encrypt or similar service

## Testing After Deployment

After deploying, test the system by:

1. Running the test script:
   ```
   python test_all_components.py
   ```

2. Starting the onboarding wizard:
   ```
   python run_onboarding_wizard.py --web --port 5060
   ```

3. Verifying the main application works:
   ```
   python main.py
   ```