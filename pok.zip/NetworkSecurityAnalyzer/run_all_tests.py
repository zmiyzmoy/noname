#!/usr/bin/env python3
"""
Run all the individual test cases with proper timeouts and generate a combined report.
"""

import os
import sys
import subprocess
import time
import datetime
import json

# Test cases to run
TEST_CASES = [
    {
        "name": "Selfplay Mode Test",
        "command": "python poker_rl.py --mode selfplay --num_episodes 1 --verbose",
        "timeout": 30,  # seconds
        "success_pattern": "Selfplay demonstration.*complete"
    },
    {
        "name": "Eval Mode Test",
        "command": "python poker_rl.py --mode eval --num_episodes 2 --eval_opponents random,tight_passive --checkpoint none --verbose",
        "timeout": 30,  # seconds
        "success_pattern": "Evaluation complete"
    },
    {
        "name": "Dynamic Parameters Test",
        "command": "python poker_rl.py --mode selfplay --num_episodes 1 --verbose --enable_dynamic_adjustment",
        "timeout": 30,  # seconds
        "success_pattern": "Dynamic adjustment enabled"
    }
]

def run_test(test_case):
    """Run a single test case and return results."""
    print(f"\n{'='*80}")
    print(f"Running Test: {test_case['name']}")
    print(f"Command: {test_case['command']}")
    print(f"{'='*80}")
    
    start_time = time.time()
    
    try:
        # Run the command with timeout
        process = subprocess.run(
            test_case['command'],
            shell=True,
            capture_output=True,
            text=True,
            timeout=test_case['timeout']
        )
        
        # Calculate duration
        duration = time.time() - start_time
        
        # Check for success pattern using regex search
        stdout = process.stdout
        import re
        success_pattern_found = bool(re.search(test_case['success_pattern'], stdout))
        
        # Filter logs to get relevant parts
        log_lines = []
        for line in stdout.split('\n'):
            if "INFO" in line or "WARNING" in line or "ERROR" in line:
                log_lines.append(line)
        
        # Prepare result
        result = {
            "name": test_case['name'],
            "command": test_case['command'],
            "exit_code": process.returncode,
            "success": process.returncode == 0,
            "success_pattern_found": success_pattern_found,
            "duration": duration,
            "stdout": stdout[-2000:] if len(stdout) > 2000 else stdout,  # Limit size
            "stderr": process.stderr[-2000:] if len(process.stderr) > 2000 else process.stderr,
            "log_lines": log_lines[-50:] if len(log_lines) > 50 else log_lines  # Last 50 log lines
        }
        
        print(f"Exit Code: {process.returncode}")
        print(f"Duration: {duration:.2f} seconds")
        print(f"Success Pattern Found: {success_pattern_found}")
        
        return result
    
    except subprocess.TimeoutExpired:
        duration = time.time() - start_time
        print(f"❌ Test timed out after {duration:.2f} seconds")
        
        return {
            "name": test_case['name'],
            "command": test_case['command'],
            "exit_code": -1,  # Custom code for timeout
            "success": False,
            "success_pattern_found": False,
            "duration": duration,
            "stdout": "*** TEST TIMED OUT ***",
            "stderr": "",
            "log_lines": ["*** TEST TIMED OUT ***"]
        }
    
    except Exception as e:
        duration = time.time() - start_time
        print(f"❌ Test failed with error: {str(e)}")
        
        return {
            "name": test_case['name'],
            "command": test_case['command'],
            "exit_code": -2,  # Custom code for error
            "success": False,
            "success_pattern_found": False,
            "duration": duration,
            "stdout": "",
            "stderr": str(e),
            "log_lines": [f"*** TEST ERROR: {str(e)} ***"]
        }

def generate_markdown_report(results, filename="test_report.md"):
    """Generate a markdown report from test results."""
    with open(filename, 'w') as f:
        # Header
        f.write("# Poker AI Functional Tests Report\n\n")
        f.write(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        # Summary
        success_count = sum(1 for r in results if r['success'] and r['success_pattern_found'])
        f.write(f"## Summary\n\n")
        f.write(f"- Total Tests: {len(results)}\n")
        f.write(f"- Successful Tests: {success_count}\n")
        f.write(f"- Failed Tests: {len(results) - success_count}\n\n")
        
        # Overall assessment
        if success_count == len(results):
            f.write("## Overall Assessment\n\n")
            f.write("✅ All tests passed successfully\n\n")
        else:
            f.write("## Overall Assessment\n\n")
            f.write("❌ Some tests failed. See detailed results below.\n\n")
        
        # Detailed results
        f.write("## Detailed Test Results\n\n")
        
        for i, result in enumerate(results):
            f.write(f"### Test Case {i+1}: {result['name']}\n\n")
            f.write(f"- **Command**: `{result['command']}`\n")
            status = "Success" if result['success'] else "Failure"
            if result['exit_code'] == -1:
                status = "Timeout"
            elif result['exit_code'] == -2:
                status = "Error"
            f.write(f"- **Exit Code**: {result['exit_code']} ({status})\n")
            f.write(f"- **Duration**: {result['duration']:.2f} seconds\n")
            f.write(f"- **Success Pattern Found**: {'Yes' if result['success_pattern_found'] else 'No'}\n\n")
            
            f.write("#### Key Log Messages\n\n")
            f.write("```\n")
            for line in result['log_lines']:
                f.write(f"{line}\n")
            f.write("```\n\n")
            
            if result['stderr']:
                f.write("#### Standard Error\n\n")
                f.write("```\n")
                f.write(result['stderr'])
                f.write("```\n\n")
            
            f.write("---\n\n")
    
    print(f"\nReport generated: {filename}")

def main():
    """Run all tests and generate report."""
    print(f"Starting Poker AI Functional Test Suite at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = []
    
    # Run all test cases
    for test_case in TEST_CASES:
        try:
            result = run_test(test_case)
            results.append(result)
        except Exception as e:
            print(f"Error running test {test_case['name']}: {e}")
    
    generate_markdown_report(results, "comprehensive_test_report.md")
    
    # Print summary
    success_count = sum(1 for r in results if r['success'] and r['success_pattern_found'])
    print(f"\nTests completed: {success_count}/{len(results)} successful")

if __name__ == "__main__":
    main()