import os
from flask import Flask, send_file, send_from_directory, render_template_string

# Create simple setup.sh file for easy installation
setup_sh = """#!/bin/bash
echo "Installing Poker AI System..."
echo "This script will install Python dependencies and initialize the database."

# Install dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Create necessary directories
mkdir -p models/
mkdir -p logs/
mkdir -p poker/logs/
mkdir -p poker/models/

# Initialize database
echo "Initializing database..."
python create_new_admin.py --username admin --password admin --email admin@example.com

echo "Installation complete! You can now run the system with:"
echo "python main.py"
"""

# Create the setup.sh file
with open('setup.sh', 'w') as f:
    f.write(setup_sh)
os.chmod('setup.sh', 0o755)

app = Flask(__name__, static_folder='static')

@app.route('/')
def home():
    # Get file size
    file_size = os.path.getsize('super_clean_poker_ai.tar.gz')
    file_size_kb = round(file_size / 1024, 0)
    
    # Create curl command for direct download to A100
    replit_url = "https://77b2eb61-43f1-42a2-a5c5-6c4ce33fc5a3-00-250d4ddm7qp7e.worf.replit.dev"
    curl_command = f"curl -L {replit_url}/download -o super_clean_poker_ai.tar.gz && mkdir -p poker_ai_system && tar -xzf super_clean_poker_ai.tar.gz -C poker_ai_system && cd poker_ai_system && pip install -r requirements.txt"
    
    return render_template_string('''
    <html>
    <head>
        <title>Poker AI System Download</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                line-height: 1.6;
            }
            .download-button {
                display: inline-block;
                background-color: #4CAF50;
                color: white;
                padding: 12px 24px;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                border-radius: 4px;
                margin-top: 20px;
                font-weight: bold;
            }
            h1, h2, h3 {
                color: #333;
            }
            .info {
                background-color: #f9f9f9;
                border-left: 4px solid #4CAF50;
                padding: 10px 20px;
                margin: 20px 0;
            }
            .alert {
                background-color: #f8f9fa;
                border-left: 4px solid #007bff;
                padding: 10px 20px;
                margin: 20px 0;
            }
            code {
                background-color: #f5f5f5;
                padding: 2px 4px;
                border-radius: 3px;
                font-family: monospace;
            }
            pre {
                background-color: #f5f5f5;
                padding: 10px;
                border-radius: 4px;
                overflow-x: auto;
            }
            .method {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 15px;
                margin-bottom: 20px;
            }
            .method h3 {
                margin-top: 0;
            }
        </style>
    </head>
    <body>
        <h1>Poker AI System - Full Project Download</h1>
        
        <div class="info">
            <p><strong>Package Size:</strong> {{ file_size_kb }}KB</p>
            <p><strong>Contents:</strong> Complete application code with all Python files and templates</p>
            <p><strong>Note:</strong> Python libraries will be installed separately via pip during setup</p>
        </div>
        
        <div class="alert">
            <p><strong>Download Information:</strong> This package contains the complete Poker AI system application code ({{ file_size_kb }}KB). All cache files and unnecessary logs have been removed to reduce download size while maintaining full functionality.</p>
        </div>
        
        <div class="method">
            <h3>Method 1: One-Command Installation</h3>
            <p>Run this single command on your A100 server:</p>
            <pre>{{ curl_command }}</pre>
            <p>This will: download the package, extract it, and install all dependencies automatically.</p>
            <a href="/download" class="download-button">Download Complete Package ({{ file_size_kb }}KB)</a>
        </div>
        
        <h2>Manual Installation Instructions</h2>
        <ol>
            <li>Download the complete package using the button above</li>
            <li>Transfer it to your A100 server</li>
            <li>Create a directory: <code>mkdir -p poker_ai_system</code></li>
            <li>Extract it: <code>tar -xzf ultra_minimal.tar.gz -C poker_ai_system</code></li>
            <li>Navigate to the directory: <code>cd poker_ai_system</code></li>
            <li>Install dependencies: <code>pip install -r requirements.txt</code></li>
            <li>Start the system: <code>python main.py</code></li>
        </ol>
        
        <div class="alert">
            <p><strong>System Requirements:</strong> The Poker AI system is optimized for A100 GPU servers. It uses PyTorch, Ray, and OpenSpiel for training and simulation. The setup script will install all required Python dependencies from requirements.txt. If you have any issues, you can manually run <code>pip install -r requirements.txt</code>.</p>
        </div>
    </body>
    </html>
    ''', 
    file_size_kb=file_size_kb,
    curl_command=curl_command)

@app.route('/download')
def download():
    return send_file('super_clean_poker_ai.tar.gz', as_attachment=True)

@app.route('/download_script')
def download_script():
    return send_from_directory('static/chunks', 'direct_download.sh', as_attachment=True)

@app.route('/chunks/<path:filename>')
def serve_chunk(filename):
    return send_from_directory('static/chunks', filename, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)