import os
import logging
import subprocess
import json
import time
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, current_app, flash
from models.db import db
from models.database import TrainingSession, SystemSetting

poker_menu_bp = Blueprint('poker_menu', __name__, template_folder='../templates')
logger = logging.getLogger(__name__)

def get_saved_models():
    """Get list of saved models."""
    models_dir = os.path.join(current_app.root_path, 'models', 'saved')
    
    if not os.path.exists(models_dir):
        os.makedirs(models_dir, exist_ok=True)
        
    models = []
    for file in os.listdir(models_dir):
        if file.endswith('.pt'):
            stats_file = file.replace('.pt', '_stats.json')
            stats_path = os.path.join(models_dir, stats_file)
            
            stats = {}
            if os.path.exists(stats_path):
                try:
                    with open(stats_path, 'r') as f:
                        stats = json.load(f)
                except:
                    pass
                    
            models.append({
                'filename': file,
                'path': os.path.join(models_dir, file),
                'created': datetime.fromtimestamp(os.path.getctime(os.path.join(models_dir, file))).strftime('%Y-%m-%d %H:%M:%S'),
                'size': round(os.path.getsize(os.path.join(models_dir, file)) / (1024 * 1024), 2),  # Size in MB
                'win_rate': stats.get('win_rate', 'Unknown'),
                'training_mode': stats.get('training_mode', 'Unknown'),
                'episodes': stats.get('episodes', 'Unknown')
            })
            
    return sorted(models, key=lambda x: x['created'], reverse=True)

@poker_menu_bp.route('/')
def index():
    """Main poker menu page."""
    models = get_saved_models()
    
    # Get settings for training options
    settings = SystemSetting.query.all()
    settings_dict = {s.name: s.value for s in settings}
    
    # Default settings if not found
    default_settings = {
        'default_training_mode': 'selfplay',
        'default_num_episodes': '100',
        'default_num_workers': '4',
    }
    
    for key, value in default_settings.items():
        if key not in settings_dict:
            settings_dict[key] = value
            
    # Get training sessions
    active_sessions = TrainingSession.query.filter_by(status='active').all()
    recent_sessions = TrainingSession.query.order_by(TrainingSession.id.desc()).limit(5).all()
    
    return render_template(
        'poker_menu/index.html',
        models=models,
        settings=settings_dict,
        active_sessions=active_sessions,
        recent_sessions=recent_sessions
    )

@poker_menu_bp.route('/start_training', methods=['POST'])
def start_training():
    """Start a training session."""
    training_mode = request.form.get('mode', 'selfplay')
    num_episodes = int(request.form.get('num_episodes', 100))
    num_workers = int(request.form.get('num_workers', 4))
    verbose = 'verbose' in request.form
    mixed_precision = 'mixed_precision' in request.form
    dynamic_params = 'dynamic_params' in request.form
    
    # Create a new training session
    session = TrainingSession(
        name=f"Training {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        training_mode=training_mode,
        num_episodes=num_episodes,
        status='active',
        start_time=datetime.now(),
        config=json.dumps({
            'mode': training_mode,
            'num_episodes': num_episodes,
            'num_workers': num_workers,
            'verbose': verbose,
            'mixed_precision': mixed_precision,
            'dynamic_params': dynamic_params
        })
    )
    
    db.session.add(session)
    db.session.commit()
    
    # Start the training process in the background
    args = [
        'python', 'poker_rl.py',
        '--mode', training_mode,
        '--num_episodes', str(num_episodes),
        '--session_id', str(session.id)
    ]
    
    if verbose:
        args.append('--verbose')
    
    if mixed_precision:
        args.append('--mixed_precision')
        
    if dynamic_params:
        args.append('--dynamic_params')
        
    if num_workers > 0:
        args.extend(['--num_workers', str(num_workers)])
    
    try:
        subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        flash(f"Training session started with {training_mode} mode and {num_episodes} episodes", "success")
    except Exception as e:
        logger.error(f"Error starting training: {e}")
        session.status = 'failed'
        db.session.commit()
        flash(f"Error starting training: {e}", "error")
    
    return redirect(url_for('poker_menu.index'))

@poker_menu_bp.route('/stop_training/<int:session_id>', methods=['POST'])
def stop_training(session_id):
    """Stop a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    if session.status == 'active':
        session.status = 'stopped'
        session.end_time = datetime.now()
        db.session.commit()
        
        # In a real implementation, we would also need to send a signal to the training process
        # to stop it, or have the training process periodically check if its status has changed
        
        flash(f"Training session {session_id} stopped", "success")
    else:
        flash(f"Training session {session_id} is not active", "warning")
    
    return redirect(url_for('poker_menu.index'))

@poker_menu_bp.route('/view_model/<path:filename>')
def view_model(filename):
    """View model details."""
    models_dir = os.path.join(current_app.root_path, 'models', 'saved')
    model_path = os.path.join(models_dir, filename)
    
    if not os.path.exists(model_path):
        flash(f"Model file not found: {filename}", "error")
        return redirect(url_for('poker_menu.index'))
    
    stats_path = model_path.replace('.pt', '_stats.json')
    stats = {}
    
    if os.path.exists(stats_path):
        try:
            with open(stats_path, 'r') as f:
                stats = json.load(f)
        except:
            pass
    
    model_info = {
        'filename': filename,
        'path': model_path,
        'created': datetime.fromtimestamp(os.path.getctime(model_path)).strftime('%Y-%m-%d %H:%M:%S'),
        'size': round(os.path.getsize(model_path) / (1024 * 1024), 2),  # Size in MB
        'win_rate': stats.get('win_rate', 'Unknown'),
        'training_mode': stats.get('training_mode', 'Unknown'),
        'episodes': stats.get('episodes', 'Unknown'),
        'stats': stats
    }
    
    return render_template('poker_menu/view_model.html', model=model_info)

@poker_menu_bp.route('/api/active_sessions')
def api_active_sessions():
    """Get active training sessions."""
    active_sessions = TrainingSession.query.filter_by(status='active').all()
    
    sessions_data = []
    for session in active_sessions:
        config = {}
        if session.config:
            try:
                config = json.loads(session.config)
            except:
                pass
        
        sessions_data.append({
            'id': session.id,
            'name': session.name,
            'mode': session.training_mode,
            'episodes': session.num_episodes,
            'progress': session.progress or 0,
            'config': config
        })
    
    return jsonify({'sessions': sessions_data})

@poker_menu_bp.route('/api/recent_sessions')
def api_recent_sessions():
    """Get recent training sessions."""
    recent_sessions = TrainingSession.query.order_by(TrainingSession.id.desc()).limit(10).all()
    
    sessions_data = []
    for session in recent_sessions:
        duration = None
        if session.start_time and session.end_time:
            duration = (session.end_time - session.start_time).total_seconds()
        
        sessions_data.append({
            'id': session.id,
            'name': session.name,
            'mode': session.training_mode,
            'episodes': session.num_episodes,
            'status': session.status,
            'start_time': session.start_time.isoformat() if session.start_time else None,
            'end_time': session.end_time.isoformat() if session.end_time else None,
            'duration': duration,
            'progress': session.progress or 0
        })
    
    return jsonify({'sessions': sessions_data})