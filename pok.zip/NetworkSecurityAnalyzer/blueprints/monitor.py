"""
Monitoring Blueprint for Poker AI System

This blueprint provides a web interface for monitoring and visualizing
the training progress of the Poker AI system.
"""
import os
import json
import time
import logging
import threading
from flask import Blueprint, render_template, jsonify, request, redirect, url_for
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import subprocess
import datetime
import random

# Configure logging
logger = logging.getLogger(__name__)

# Create Blueprint
monitor_bp = Blueprint('monitor', __name__, 
                       template_folder='templates', 
                       static_folder='static')

# Global data storage - will be moved to database in future versions
training_data = {
    'iterations': [],
    'rewards': [],
    'losses': [],
    'exploitability': [],
    'win_rates': [],
    'episodes_completed': 0,
    'last_update': time.time(),
    'model_info': {},
    'status': 'idle',
    'training_processes': {},
    'training_configs': {}
}

# Training configuration presets
default_configs = [
    {
        'id': 'default',
        'name': 'Default Configuration',
        'description': 'Balanced configuration with moderate learning rate and batch size',
        'learning_rate': 0.001,
        'batch_size': 32,
        'discount_factor': 0.99,
        'training_iterations': 1000,
        'exploration_rate': 0.1
    },
    {
        'id': 'fast',
        'name': 'Fast Training (Low Quality)',
        'description': 'Fast training with higher learning rate, suitable for quick testing',
        'learning_rate': 0.01,
        'batch_size': 64,
        'discount_factor': 0.95,
        'training_iterations': 500,
        'exploration_rate': 0.2
    },
    {
        'id': 'quality',
        'name': 'High Quality (Slow)',
        'description': 'Slower training with lower learning rate for higher quality results',
        'learning_rate': 0.0001,
        'batch_size': 16,
        'discount_factor': 0.999,
        'training_iterations': 2000,
        'exploration_rate': 0.05
    }
]

# Routes
@monitor_bp.route('/')
def index():
    """Main monitoring dashboard."""
    return render_template('monitor/index.html', now=datetime.datetime.now())

@monitor_bp.route('/api/training_data')
def get_training_data():
    """API endpoint to get current training data."""
    # Check if any training processes are still running
    processes_to_remove = []
    for process_id, process_info in training_data['training_processes'].items():
        process = process_info.get('process')
        if process and process.poll() is not None:  # Process has finished
            if process.returncode == 0:
                training_data['status'] = 'completed'
            else:
                training_data['status'] = 'error'
            processes_to_remove.append(process_id)
    
    # Remove completed processes
    for process_id in processes_to_remove:
        del training_data['training_processes'][process_id]
    
    # If no processes are running and status isn't completed or error, set to idle
    if not training_data['training_processes'] and training_data['status'] not in ['completed', 'error']:
        training_data['status'] = 'idle'
    
    # Convert NumPy arrays to lists if necessary
    clean_data = {}
    for key, value in training_data.items():
        if key != 'training_processes':  # Don't send process objects to frontend
            if hasattr(value, 'tolist'):  # Check if it's a NumPy array
                clean_data[key] = value.tolist()
            else:
                clean_data[key] = value
    
    return jsonify(clean_data)

@monitor_bp.route('/start_training', methods=['POST'])
def start_training():
    """Start a training session."""
    config_id = request.form.get('config', 'default')
    num_episodes = int(request.form.get('episodes', 100))
    
    # Find the selected config
    config = next((c for c in default_configs if c['id'] == config_id), default_configs[0])
    
    # Clear previous training data
    training_data['iterations'] = []
    training_data['rewards'] = []
    training_data['losses'] = []
    training_data['exploitability'] = []
    training_data['win_rates'] = []
    training_data['episodes_completed'] = 0
    training_data['last_update'] = time.time()
    training_data['status'] = 'running'
    
    # Store current configuration
    training_data['current_config'] = config
    
    # Build command
    cmd = [
        'python', 'poker_rl.py',
        '--mode', 'train',
        '--num_episodes', str(num_episodes),
        '--learning_rate', str(config['learning_rate']),
        '--batch_size', str(config['batch_size']),
        '--verbose'
    ]
    
    # Start training process
    process = subprocess.Popen(
        cmd, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True
    )
    
    # Generate a unique ID for this training run
    process_id = f"train_{int(time.time())}"
    
    # Store process information
    training_data['training_processes'][process_id] = {
        'process': process,
        'start_time': time.time(),
        'config': config,
        'command': ' '.join(cmd)
    }
    
    # Start a thread to monitor the process output
    threading.Thread(target=monitor_process_output, args=(process, process_id), daemon=True).start()
    
    return jsonify({
        'status': 'success', 
        'message': 'Training started',
        'process_id': process_id
    })

@monitor_bp.route('/stop_training/<process_id>', methods=['POST'])
def stop_training(process_id):
    """Stop a training session."""
    if process_id in training_data['training_processes']:
        process_info = training_data['training_processes'][process_id]
        process = process_info.get('process')
        
        if process:
            try:
                # Try to terminate gracefully
                process.terminate()
                # Wait a bit for the process to terminate
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    # If it didn't terminate, kill it
                    process.kill()
                
                training_data['status'] = 'stopped'
                del training_data['training_processes'][process_id]
                return jsonify({'status': 'success', 'message': 'Training stopped'})
            except Exception as e:
                return jsonify({'status': 'error', 'message': f'Error stopping training: {str(e)}'})
    
    return jsonify({'status': 'error', 'message': 'Training process not found'})

@monitor_bp.route('/training_configs')
def training_configs():
    """Get available training configurations."""
    return jsonify(default_configs)

def monitor_process_output(process, process_id):
    """Monitor the output of a training process and update training data."""
    for line in iter(process.stdout.readline, ''):
        # Process output line
        line = line.strip()
        if not line:
            continue
        
        try:
            # Look for metrics in the output
            if 'Episode' in line and 'reward' in line.lower():
                # Parse episode number and reward
                parts = line.split()
                episode_idx = parts.index('Episode')
                if episode_idx + 1 < len(parts):
                    try:
                        episode = int(parts[episode_idx + 1].rstrip(':,'))
                        training_data['episodes_completed'] = episode
                    except ValueError:
                        pass
                
                reward_idx = [i for i, part in enumerate(parts) if 'reward' in part.lower()]
                if reward_idx and reward_idx[0] + 1 < len(parts):
                    try:
                        reward = float(parts[reward_idx[0] + 1].rstrip(':,'))
                        training_data['rewards'].append(reward)
                        training_data['iterations'].append(episode)
                    except ValueError:
                        pass
            
            # Look for loss values
            if 'loss' in line.lower():
                # Extract loss value
                parts = line.split()
                loss_idx = [i for i, part in enumerate(parts) if 'loss' in part.lower()]
                if loss_idx and loss_idx[0] + 1 < len(parts):
                    try:
                        loss = float(parts[loss_idx[0] + 1].rstrip(':,'))
                        training_data['losses'].append(loss)
                    except ValueError:
                        pass
            
            # Look for win rate
            if 'win rate' in line.lower() or 'win_rate' in line.lower():
                # Extract win rate
                parts = line.split()
                win_idx = [i for i, part in enumerate(parts) if 'win' in part.lower() and 'rate' in parts[i+1].lower()]
                if not win_idx:
                    win_idx = [i for i, part in enumerate(parts) if 'win_rate' in part.lower()]
                
                if win_idx and win_idx[0] + 1 < len(parts):
                    try:
                        win_rate = float(parts[win_idx[0] + 1].rstrip(':,%'))
                        training_data['win_rates'].append(win_rate)
                    except ValueError:
                        pass
            
            # Update last update time
            training_data['last_update'] = time.time()
            
        except Exception as e:
            logger.error(f"Error processing output line: {str(e)}")
    
    # Process has completed
    if process_id in training_data['training_processes']:
        if process.returncode == 0:
            training_data['status'] = 'completed'
        else:
            training_data['status'] = 'error'

@monitor_bp.route('/visualize')
def visualize():
    """Visualization page for training progress."""
    return render_template('monitor/visualize.html', now=datetime.datetime.now())

@monitor_bp.route('/api/visualization/<chart_type>')
def get_visualization(chart_type):
    """Generate and return visualization of training data."""
    plt.figure(figsize=(10, 6))
    plt.grid(True)
    
    if chart_type == 'rewards':
        plt.plot(training_data['iterations'], training_data['rewards'], 'b-')
        plt.title('Average Reward per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Average Reward')
    
    elif chart_type == 'losses':
        if training_data['losses']:
            plt.plot(range(len(training_data['losses'])), training_data['losses'], 'r-')
            plt.title('Loss per Update')
            plt.xlabel('Update')
            plt.ylabel('Loss')
        else:
            plt.title('No Loss Data Available')
    
    elif chart_type == 'win_rates':
        if training_data['win_rates']:
            plt.plot(range(len(training_data['win_rates'])), training_data['win_rates'], 'g-')
            plt.title('Win Rate over Time')
            plt.xlabel('Evaluation')
            plt.ylabel('Win Rate (%)')
        else:
            plt.title('No Win Rate Data Available')
    
    # Save the figure to a buffer
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    
    # Encode the buffer as base64
    data = base64.b64encode(buf.getvalue()).decode('ascii')
    plt.close()
    
    return jsonify({'data': data})

@monitor_bp.route('/config')
def config_page():
    """Configuration page for training settings."""
    return render_template('monitor/config.html', configs=default_configs, now=datetime.datetime.now())

@monitor_bp.route('/easy_menu')
def easy_menu():
    """Simplified training menu for ease of use."""
    return render_template('monitor/easy_menu.html', configs=default_configs, now=datetime.datetime.now())

@monitor_bp.route('/run_quick_training', methods=['POST'])
def run_quick_training():
    """Run a quick training session from the easy menu."""
    num_episodes = int(request.form.get('num_episodes', 5))
    mode = request.form.get('mode', 'selfplay')
    verbose = 'verbose' in request.form
    
    # Build command
    cmd = [
        'python', 'poker_rl.py',
        '--mode', mode,
        '--num_episodes', str(num_episodes)
    ]
    
    if verbose:
        cmd.append('--verbose')
    
    # Start training process
    process = subprocess.Popen(
        cmd, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        universal_newlines=True
    )
    
    # Generate a unique ID for this training run
    process_id = f"quick_{int(time.time())}"
    
    # Store process information
    training_data['training_processes'][process_id] = {
        'process': process,
        'start_time': time.time(),
        'command': ' '.join(cmd)
    }
    training_data['status'] = 'running'
    
    # Start a thread to monitor the process output
    threading.Thread(target=monitor_process_output, args=(process, process_id), daemon=True).start()
    
    return jsonify({
        'status': 'success', 
        'message': f'{mode.capitalize()} started with {num_episodes} episodes'
    })

@monitor_bp.route('/api/logs')
def get_logs():
    """API endpoint to get training logs."""
    # Get the last few lines from the log file
    logs = []
    try:
        with open('poker_rl.log', 'r') as f:
            logs = f.readlines()[-100:]  # Get last 100 lines
    except Exception as e:
        return jsonify({'logs': [f'Error reading logs: {str(e)}']})
    
    return jsonify({'logs': logs})

@monitor_bp.route('/advanced_monitor')
def advanced_monitor():
    """Advanced monitoring page with more detailed metrics."""
    return render_template('monitor/advanced_monitor.html', now=datetime.datetime.now())

@monitor_bp.route('/api/system_info')
def get_system_info():
    """Get system information."""
    # This is a placeholder. In a real implementation, you would use
    # libraries like psutil to get actual system information.
    return jsonify({
        'cpu_usage': random.randint(5, 95),
        'memory_usage': random.randint(20, 80),
        'gpu_usage': random.randint(0, 100) if os.path.exists('/dev/nvidia0') else 0,
        'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })