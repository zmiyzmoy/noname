"""
Unified Training Interface Blueprint

This blueprint handles routes for the unified training menu interface, which combines
functionality from all training interfaces into a single cohesive interface.
"""

import os
import json
import time
import datetime
import logging
from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from flask_login import login_required, current_user
import threading
import subprocess

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create blueprint
unified_bp = Blueprint('unified', __name__, url_prefix='/training')

# Global variables to track training state
training_process = None
training_status = "idle"
training_logs = []
active_session = None
evaluation_results = None

@unified_bp.route('/')
def index():
    """Render the unified training interface."""
    return render_template('training/training_room.html')

@unified_bp.route('/api/start', methods=['POST'])
@login_required
def start_training():
    """Start a new training session."""
    global training_process, training_status, training_logs, active_session
    
    try:
        # Get parameters from request
        data = request.json
        mode = data.get('mode', 'selfplay')
        num_episodes = data.get('num_episodes', 5)
        
        # CRITICAL FIX: Force 1 worker mode to prevent memory issues
        workers = 1  # Force single worker regardless of request to prevent OOM errors
        
        batch_size = data.get('batch_size', 32)
        # Limit batch size to prevent memory issues
        batch_size = min(batch_size, 64)
        
        verbose = data.get('verbose', True)
        dynamic_params = data.get('dynamic_params', False)
        mixed_precision = data.get('mixed_precision', True)
        # use_gpu parameter removed as it's not supported in poker_rl.py
        
        logger.info(f"Set workers to 1 and limited batch size to {batch_size} for memory stability")
        
        # Clear previous logs
        training_logs = []
        
        # Create a session record
        session_id = int(time.time())
        active_session = {
            'id': session_id,
            'mode': mode,
            'num_episodes': num_episodes,
            'workers': workers,
            'batch_size': batch_size,
            'status': 'running',
            'start_time': datetime.datetime.now().isoformat(),
            'end_time': None,
            'episodes_completed': 0,
            'total_episodes': num_episodes
        }
        
        # Log the start of training
        log_message = f"Starting {mode} training with {num_episodes} episodes, {workers} workers"
        training_logs.append(log_message)
        logger.info(log_message)
        
        # Set training status to running
        training_status = "running"
        
        # Construct command to run training script
        if mode == "psro":
            # For PSRO mode, use the 'train' mode in poker_rl.py which calls train_psro
            cmd = [
                "python", "poker_rl.py",
                "--mode", "train",
                "--num_iterations", str(num_episodes),
                "--num_episodes", str(num_episodes),  # Needed for both
                "--num_workers", str(workers),
                "--batch_size", str(batch_size)
            ]
        else:
            cmd = [
                "python", "poker_rl.py",
                "--mode", mode,
                "--num_episodes", str(num_episodes),
                "--num_workers", str(workers),
                "--batch_size", str(batch_size)
            ]
        
        if verbose:
            cmd.append("--verbose")
        
        if dynamic_params:
            cmd.append("--enable_dynamic_adjustment")
            
        if mixed_precision:
            cmd.append("--use_mixed_precision")
        
        # Start training process
        training_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )
        
        # Start thread to read output
        threading.Thread(target=_read_process_output, args=(training_process,), daemon=True).start()
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'message': 'Training started successfully'
        })
        
    except Exception as e:
        logger.error(f"Error starting training: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

@unified_bp.route('/api/stop', methods=['POST'])
@login_required
def stop_training():
    """Stop the current training session."""
    global training_process, training_status, active_session
    
    try:
        if training_process and training_process.poll() is None:
            # Process is still running, terminate it
            training_process.terminate()
            training_process.wait(timeout=5)
            
            # Log the stop
            log_message = "Training stopped by user"
            training_logs.append(log_message)
            logger.info(log_message)
            
            # Update session status
            if active_session:
                active_session['status'] = 'stopped'
                active_session['end_time'] = datetime.datetime.now().isoformat()
            
            # Update training status
            training_status = "stopped"
            
            return jsonify({
                'success': True,
                'message': 'Training stopped successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'No active training process to stop'
            })
            
    except Exception as e:
        logger.error(f"Error stopping training: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

@unified_bp.route('/api/status')
def get_status():
    """Get the current training status and logs."""
    global training_status, training_logs, active_session, evaluation_results
    
    return jsonify({
        'status': training_status,
        'logs': training_logs[-20:],  # Return last 20 logs
        'active_session': active_session,
        'evaluation_results': evaluation_results
    })

@unified_bp.route('/api/models')
def get_models():
    """Get list of available models."""
    models = []
    
    # Scan the models directory for trained models
    models_dir = "models"
    if os.path.exists(models_dir) and os.path.isdir(models_dir):
        for filename in os.listdir(models_dir):
            if filename.endswith('.pt'):
                model_path = os.path.join(models_dir, filename)
                model_stats = {}
                
                # Try to load win rate from stats file if it exists
                stats_file = os.path.join(models_dir, f"{os.path.splitext(filename)[0]}_stats.json")
                if os.path.exists(stats_file):
                    try:
                        with open(stats_file, 'r') as f:
                            model_stats = json.load(f)
                    except:
                        pass
                
                models.append({
                    'id': filename,
                    'name': os.path.splitext(filename)[0],
                    'path': model_path,
                    'size': os.path.getsize(model_path),
                    'created': datetime.datetime.fromtimestamp(os.path.getctime(model_path)).isoformat(),
                    'win_rate': model_stats.get('win_rate', 'Unknown')
                })
    
    return jsonify({
        'success': True,
        'models': sorted(models, key=lambda x: x['created'], reverse=True)
    })

@unified_bp.route('/api/sessions')
def get_sessions():
    """Get list of recent training sessions."""
    sessions = []
    
    # Add active session if it exists
    if active_session:
        sessions.append(active_session)
    
    # TODO: Load previous sessions from database or file
    
    return jsonify({
        'success': True,
        'sessions': sessions
    })

@unified_bp.route('/api/evaluate', methods=['POST'])
@login_required
def evaluate_model():
    """Evaluate a model against an opponent."""
    global training_process, training_status, training_logs, evaluation_results
    
    try:
        # Get parameters from request
        data = request.json
        model_id = data.get('model_id')
        opponent_type = data.get('opponent_type', 'random')
        num_games = data.get('num_games', 100)
        
        if not model_id:
            return jsonify({
                'success': False,
                'error': 'Model ID is required'
            })
        
        # Clear previous logs and results
        training_logs = []
        evaluation_results = None
        
        # Log the start of evaluation
        log_message = f"Starting evaluation of model {model_id} against {opponent_type} opponent for {num_games} games"
        training_logs.append(log_message)
        logger.info(log_message)
        
        # Set training status to evaluating
        training_status = "evaluating"
        
        # Construct command to run evaluation script
        cmd = [
            "python", "poker_rl.py",
            "--mode", "eval",
            "--model", os.path.join("models", model_id),
            "--opponent", opponent_type,
            "--num_games", str(num_games),
            "--verbose"
        ]
        
        # Start evaluation process
        training_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )
        
        # Start thread to read output
        threading.Thread(target=_read_process_output, args=(training_process, True), daemon=True).start()
        
        return jsonify({
            'success': True,
            'message': 'Evaluation started successfully'
        })
        
    except Exception as e:
        logger.error(f"Error starting evaluation: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        })

def _read_process_output(process, is_evaluation=False):
    """Read output from the process and update logs."""
    global training_logs, training_status, active_session, evaluation_results
    
    episodes_completed = 0
    
    for line in iter(process.stdout.readline, ''):
        # Add log entry
        training_logs.append(line.strip())
        
        # Extract metrics if available
        if "Episode" in line and "completed" in line:
            try:
                # Extract episode number
                parts = line.split()
                for i, part in enumerate(parts):
                    if part == "Episode":
                        episode_num = int(parts[i+1])
                        episodes_completed = episode_num
                        
                        # Update active session if it exists
                        if active_session:
                            active_session['episodes_completed'] = episodes_completed
                            
                        break
            except:
                pass
        
        # For evaluation mode, extract results
        if is_evaluation and "Evaluation results" in line:
            evaluation_results = {}
            for _ in range(10):  # Read the next few lines for results
                result_line = process.stdout.readline().strip()
                training_logs.append(result_line)
                
                # Parse win rate
                if "Win rate:" in result_line:
                    try:
                        win_rate = float(result_line.split(":")[-1].strip().replace("%", ""))
                        evaluation_results['win_rate'] = win_rate
                    except:
                        pass
                
                # Parse draw rate
                elif "Draw rate:" in result_line:
                    try:
                        draw_rate = float(result_line.split(":")[-1].strip().replace("%", ""))
                        evaluation_results['draw_rate'] = draw_rate
                    except:
                        pass
                
                # Parse loss rate
                elif "Loss rate:" in result_line:
                    try:
                        loss_rate = float(result_line.split(":")[-1].strip().replace("%", ""))
                        evaluation_results['loss_rate'] = loss_rate
                    except:
                        pass
                
                # Parse average return
                elif "Average return:" in result_line:
                    try:
                        avg_return = float(result_line.split(":")[-1].strip())
                        evaluation_results['avg_return'] = avg_return
                    except:
                        pass
    
    # Process completed
    return_code = process.wait()
    
    if return_code == 0:
        # Successful completion
        training_status = "completed"
        log_message = "Training completed successfully"
    else:
        # Error occurred
        training_status = "failed"
        log_message = f"Training failed with return code {return_code}"
    
    training_logs.append(log_message)
    logger.info(log_message)
    
    # Update active session if it exists
    if active_session:
        active_session['status'] = training_status
        active_session['end_time'] = datetime.datetime.now().isoformat()