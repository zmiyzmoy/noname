# blueprints package

# Import all blueprints here for easy access
from blueprints.admin import admin_bp
from blueprints.monitor import monitor_bp