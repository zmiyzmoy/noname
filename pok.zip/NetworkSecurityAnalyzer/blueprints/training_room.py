"""
Training Room Blueprint for Poker AI System

This blueprint provides a unified interface for all training-related functions,
combining the various training menus into a single dashboard.
"""

import os
import json
import logging
import psutil
import subprocess
import threading
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, current_app, flash, redirect, url_for
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

# Import models
from models.db import db
from models.database import TrainingSession, User, SystemSetting

# Configure logging
logger = logging.getLogger(__name__)

# Create Blueprint
training_bp = Blueprint('training_room', __name__)

# Helper functions
def get_hardware_info():
    """Get current hardware information."""
    try:
        # CPU information
        cpu_percent = psutil.cpu_percent(interval=0.1)
        cpu_info = {
            "usage": cpu_percent,
            "cores": psutil.cpu_count(logical=False),
            "threads": psutil.cpu_count(logical=True),
            "model": "CPU"  # Simplified for now
        }
        
        # Memory information
        memory = psutil.virtual_memory()
        memory_info = {
            "percent": memory.percent,
            "used": round(memory.used / (1024 ** 3), 2),  # GB
            "total": round(memory.total / (1024 ** 3), 2)  # GB
        }
        
        # GPU information
        gpu_info = {"available": False}
        try:
            import torch
            if torch.cuda.is_available():
                gpu_info = {
                    "available": True,
                    "model": torch.cuda.get_device_name(0),
                    "usage": 0,  # Requires more work to get actual usage
                    "memory_used": 0,  # Placeholder
                    "memory_total": torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
                }
                
                # Try to get more GPU info with pynvml if available
                try:
                    from pynvml import nvmlInit, nvmlDeviceGetHandleByIndex, nvmlDeviceGetMemoryInfo, nvmlDeviceGetUtilizationRates
                    nvmlInit()
                    handle = nvmlDeviceGetHandleByIndex(0)
                    meminfo = nvmlDeviceGetMemoryInfo(handle)
                    utilization = nvmlDeviceGetUtilizationRates(handle)
                    
                    gpu_info["memory_used"] = round(meminfo.used / (1024 ** 3), 2)
                    gpu_info["usage"] = utilization.gpu
                except:
                    # Fall back to simplified info
                    gpu_info["memory_used"] = 0
                    gpu_info["usage"] = 0
        except:
            pass
        
        # Disk information
        disk = psutil.disk_usage('/')
        disk_info = {
            "percent": disk.percent,
            "used": round(disk.used / (1024 ** 3), 2),  # GB
            "total": round(disk.total / (1024 ** 3), 2)  # GB
        }
        
        return {
            "cpu": cpu_info,
            "memory": memory_info,
            "gpu": gpu_info,
            "disk": disk_info
        }
    except Exception as e:
        logger.error(f"Error getting hardware info: {e}")
        return {
            "cpu": {"usage": 0, "cores": 0, "threads": 0, "model": "Unknown"},
            "memory": {"percent": 0, "used": 0, "total": 0},
            "gpu": {"available": False},
            "disk": {"percent": 0, "used": 0, "total": 0}
        }

def get_active_training_sessions():
    """Get currently active training sessions."""
    try:
        sessions = TrainingSession.query.filter_by(status='running').all()
        return [
            {
                "id": session.id,
                "name": session.name,
                "mode": "Selfplay",  # Default mode since we don't have a direct link to config
                "episodes": session.total_episodes,
                "progress": 0,  # We don't track progress yet
                "start_time": session.start_time.strftime('%Y-%m-%d %H:%M:%S') if session.start_time else "Unknown"
            }
            for session in sessions
        ]
    except Exception as e:
        logger.error(f"Error getting active sessions: {e}")
        return []

def get_training_log():
    """Get the latest training log entries."""
    try:
        log_file = "poker_rl.log"
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                # Get last 50 lines
                lines = f.readlines()[-50:]
                return ''.join(lines)
        return "No training log available"
    except Exception as e:
        logger.error(f"Error reading training log: {e}")
        return f"Error reading training log: {e}"

def start_training_process(mode, num_episodes, num_workers, verbose, mixed_precision, dynamic_params):
    """Start a training process with the specified parameters."""
    try:
        # Build the command
        cmd = ["python", "poker_rl.py", "--mode", mode, "--num_episodes", str(num_episodes)]
        
        if num_workers:
            cmd.extend(["--num_workers", str(num_workers)])
        
        if verbose:
            cmd.append("--verbose")
        
        if mixed_precision:
            cmd.append("--mixed_precision")
        
        if dynamic_params:
            cmd.append("--dynamic_adjustment")
        
        # Start the process in the background
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            bufsize=1
        )
        
        # Create a new training session in the database
        session = TrainingSession(
            name=f"{mode.capitalize()} Training ({num_episodes} episodes)",
            status="running",
            start_time=datetime.now(),
            total_episodes=num_episodes
        )
        db.session.add(session)
        db.session.commit()
        
        # Return the process ID and session ID
        return {
            "process_id": process.pid,
            "session_id": session.id,
            "status": "started"
        }
    except Exception as e:
        logger.error(f"Error starting training: {e}")
        return {
            "error": str(e),
            "status": "failed"
        }

def stop_training_process(session_id):
    """Stop a running training process."""
    try:
        session = TrainingSession.query.get(session_id)
        if not session:
            return {"status": "error", "message": "Session not found"}
        
        # Update session status
        session.status = "stopped"
        session.end_time = datetime.now()
        db.session.commit()
        
        # TODO: Implement actual process killing logic if we store process IDs
        # For now, we'll assume the training will detect a stop flag
        
        return {"status": "success", "message": "Training stopped"}
    except Exception as e:
        logger.error(f"Error stopping training: {e}")
        return {"status": "error", "message": str(e)}

# Routes
@training_bp.route('/')
@login_required
def index():
    """Training room home page."""
    return render_template('training_room.html')

@training_bp.route('/get_system_resources')
def get_system_resources():
    """Get current system resource usage."""
    return jsonify(get_hardware_info())

@training_bp.route('/get_active_sessions')
def get_active_sessions():
    """Get active training sessions."""
    return jsonify({"sessions": get_active_training_sessions()})

@training_bp.route('/get_training_output')
def get_training_output():
    """Get latest training output."""
    return jsonify({"output": get_training_log()})

@training_bp.route('/start_quick_training', methods=['POST'])
@login_required
def start_quick_training():
    """Start a quick training session."""
    mode = request.form.get('mode', 'selfplay')
    num_episodes = int(request.form.get('num_episodes', 100))
    num_workers = int(request.form.get('num_workers', 4))
    verbose = 'verbose' in request.form
    mixed_precision = 'mixed_precision' in request.form
    dynamic_params = 'dynamic_params' in request.form
    
    result = start_training_process(
        mode, num_episodes, num_workers, verbose, mixed_precision, dynamic_params
    )
    
    if result.get('status') == 'started':
        return jsonify({"status": "success", "message": "Training started successfully"})
    else:
        return jsonify({"status": "error", "message": result.get('error', 'Unknown error')})

@training_bp.route('/stop_training', methods=['POST'])
@login_required
def stop_training():
    """Stop a training session."""
    session_id = request.form.get('session_id')
    if not session_id:
        return jsonify({"status": "error", "message": "No session ID provided"})
    
    result = stop_training_process(session_id)
    return jsonify(result)

@training_bp.route('/apply_advanced_settings', methods=['POST'])
@login_required
def apply_advanced_settings():
    """Apply advanced training settings."""
    try:
        # Get the settings
        batch_size = request.form.get('batch_size', 64)
        learning_rate = request.form.get('learning_rate', 0.001)
        training_iterations = request.form.get('training_iterations', 10)
        checkpoint = request.form.get('checkpoint', 'latest')
        eval_opponents = request.form.get('eval_opponents', 'random')
        
        # Store in system settings
        SystemSetting.set_value(db, 'default_batch_size', batch_size, 'Default batch size for training')
        SystemSetting.set_value(db, 'default_learning_rate', float(learning_rate), 'Default learning rate for training')
        SystemSetting.set_value(db, 'default_training_iterations', training_iterations, 'Default number of training iterations')
        
        # Commit changes
        db.session.commit()
        
        # Save to a config file that training processes can read
        config_data = {
            "batch_size": int(batch_size),
            "learning_rate": float(learning_rate),
            "training_iterations": int(training_iterations),
            "checkpoint": checkpoint,
            "eval_opponents": eval_opponents.split(',')
        }
        
        with open('training_config.json', 'w') as f:
            json.dump(config_data, f, indent=2)
        
        return jsonify({"status": "success", "message": "Advanced settings applied"})
    except Exception as e:
        logger.error(f"Error applying advanced settings: {e}")
        return jsonify({"status": "error", "message": str(e)})