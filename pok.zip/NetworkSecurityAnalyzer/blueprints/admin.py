"""
Admin Dashboard Blueprint for Poker AI System

This blueprint provides an administrative interface for managing
the Poker AI training system, including configuration, monitoring,
and management of training sessions.
"""
import os
import json
import logging
import subprocess
from datetime import datetime
from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

# Import database models
from models.database import (
    db, User, HardwareConfig, TrainingConfig, TrainingSession, 
    TrainingMetrics, TrainingLog, TrainingAction, SystemSetting
)

# Configure logging
logger = logging.getLogger(__name__)

# Create Blueprint
admin_bp = Blueprint('admin', __name__)

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Administrator access required.', 'danger')
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

# Routes
@admin_bp.route('/')
def index():
    """Dashboard home page."""
    if not current_user.is_authenticated:
        return redirect(url_for('admin.login'))
    
    # Get summary data for dashboard
    hardware_count = HardwareConfig.query.count()
    training_config_count = TrainingConfig.query.count()
    session_count = TrainingSession.query.count()
    active_sessions_count = TrainingSession.query.filter_by(status='running').count()
    active_sessions = TrainingSession.query.filter_by(status='running').all()
    
    # Get recent training sessions
    recent_sessions = TrainingSession.query.order_by(
        TrainingSession.created_at.desc()).limit(5).all()
        
    # Get recent logs
    recent_logs = TrainingLog.query.order_by(
        TrainingLog.timestamp.desc()).limit(10).all()
    
    return render_template('admin/index.html', 
                          hardware_count=hardware_count,
                          training_config_count=training_config_count,
                          session_count=session_count,
                          active_sessions_count=active_sessions_count,
                          active_sessions=active_sessions,
                          recent_sessions=recent_sessions,
                          recent_logs=recent_logs)

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login page."""
    if current_user.is_authenticated:
        return redirect(url_for('admin.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Username and password are required.', 'danger')
            return render_template('admin/login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash(f'Welcome, {user.username}!', 'success')
            return redirect(url_for('admin.index'))
        else:
            flash('Invalid username or password.', 'danger')
    
    return render_template('admin/login.html')

@admin_bp.route('/logout')
@login_required
def logout():
    """Log out the current user."""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('admin.login'))

@admin_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page."""
    if current_user.is_authenticated and not current_user.is_admin:
        flash('You do not have permission to register new users.', 'danger')
        return redirect(url_for('admin.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not username or not password or not confirm_password:
            flash('All fields are required.', 'danger')
            return render_template('admin/register.html')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('admin/register.html')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return render_template('admin/register.html')
        
        # Create new user
        user = User(
            username=username,
            email=f"{username}@example.com",  # providing a temporary email as it's required
            password=generate_password_hash(password),
            is_admin=True
        )
        db.session.add(user)
        db.session.commit()
        
        flash('User registered successfully. You can now log in.', 'success')
        return redirect(url_for('admin.login'))
    
    return render_template('admin/register.html')

@admin_bp.route('/hardware-configs')
@login_required
def hardware_configs():
    """List hardware configurations."""
    configs = HardwareConfig.query.all()
    return render_template('admin/hardware_configs.html', configs=configs)

@admin_bp.route('/hardware-configs/create', methods=['GET', 'POST'])
@login_required
@admin_required
def hardware_create():
    """Create a new hardware configuration."""
    if request.method == 'POST':
        name = request.form.get('name')
        cpu_count = request.form.get('cpu_count')
        ram_gb = request.form.get('ram_gb')
        gpu_type = request.form.get('gpu_type')
        gpu_memory_gb = request.form.get('gpu_memory_gb')
        storage_gb = request.form.get('storage_gb')
        
        config = HardwareConfig(
            name=name,
            cpu_count=int(cpu_count),
            ram_gb=float(ram_gb),
            gpu_type=gpu_type,
            gpu_memory_gb=float(gpu_memory_gb) if gpu_memory_gb else None,
            storage_gb=float(storage_gb)
        )
        db.session.add(config)
        db.session.commit()
        
        flash('Hardware configuration created successfully.', 'success')
        return redirect(url_for('admin.hardware_configs'))
    
    return render_template('admin/hardware_create.html')

@admin_bp.route('/hardware-configs/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def hardware_edit(config_id):
    """Edit a hardware configuration."""
    config = HardwareConfig.query.get_or_404(config_id)
    
    if request.method == 'POST':
        config.name = request.form.get('name')
        config.cpu_count = int(request.form.get('cpu_count'))
        config.ram_gb = float(request.form.get('ram_gb'))
        config.gpu_type = request.form.get('gpu_type')
        
        gpu_memory_gb = request.form.get('gpu_memory_gb')
        config.gpu_memory_gb = float(gpu_memory_gb) if gpu_memory_gb else None
        
        config.storage_gb = float(request.form.get('storage_gb'))
        
        db.session.commit()
        
        flash('Hardware configuration updated successfully.', 'success')
        return redirect(url_for('admin.hardware_configs'))
    
    return render_template('admin/hardware_edit.html', config=config)

@admin_bp.route('/hardware-configs/<int:config_id>/delete', methods=['POST'])
@login_required
@admin_required
def hardware_delete(config_id):
    """Delete a hardware configuration."""
    config = HardwareConfig.query.get_or_404(config_id)
    db.session.delete(config)
    db.session.commit()
    
    flash('Hardware configuration deleted successfully.', 'success')
    return redirect(url_for('admin.hardware_configs'))

@admin_bp.route('/training-configs')
@login_required
def training_configs():
    """List training configurations."""
    configs = TrainingConfig.query.all()
    return render_template('admin/training_configs.html', configs=configs)

@admin_bp.route('/training-configs/create', methods=['GET', 'POST'])
@login_required
@admin_required
def training_config_create():
    """Create a new training configuration."""
    if request.method == 'POST':
        name = request.form.get('name')
        algorithm = request.form.get('algorithm')
        batch_size = request.form.get('batch_size')
        learning_rate = request.form.get('learning_rate')
        discount_factor = request.form.get('discount_factor')
        exploration_rate = request.form.get('exploration_rate')
        replay_buffer_size = request.form.get('replay_buffer_size')
        target_update_freq = request.form.get('target_update_freq')
        training_iterations = request.form.get('training_iterations')
        eval_episodes = request.form.get('eval_episodes')
        
        config = TrainingConfig(
            name=name,
            algorithm=algorithm,
            batch_size=int(batch_size),
            learning_rate=float(learning_rate),
            discount_factor=float(discount_factor),
            exploration_rate=float(exploration_rate),
            replay_buffer_size=int(replay_buffer_size),
            target_update_freq=int(target_update_freq),
            training_iterations=int(training_iterations),
            eval_episodes=int(eval_episodes)
        )
        db.session.add(config)
        db.session.commit()
        
        flash('Training configuration created successfully.', 'success')
        return redirect(url_for('admin.training_configs'))
    
    return render_template('admin/training_config_create.html')

@admin_bp.route('/training-configs/<int:config_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def training_config_edit(config_id):
    """Edit a training configuration."""
    config = TrainingConfig.query.get_or_404(config_id)
    
    if request.method == 'POST':
        config.name = request.form.get('name')
        config.algorithm = request.form.get('algorithm')
        config.batch_size = int(request.form.get('batch_size'))
        config.learning_rate = float(request.form.get('learning_rate'))
        config.discount_factor = float(request.form.get('discount_factor'))
        config.exploration_rate = float(request.form.get('exploration_rate'))
        config.replay_buffer_size = int(request.form.get('replay_buffer_size'))
        config.target_update_freq = int(request.form.get('target_update_freq'))
        config.training_iterations = int(request.form.get('training_iterations'))
        config.eval_episodes = int(request.form.get('eval_episodes'))
        
        db.session.commit()
        
        flash('Training configuration updated successfully.', 'success')
        return redirect(url_for('admin.training_configs'))
    
    return render_template('admin/training_config_edit.html', config=config)

@admin_bp.route('/training-configs/<int:config_id>/delete', methods=['POST'])
@login_required
@admin_required
def training_config_delete(config_id):
    """Delete a training configuration."""
    config = TrainingConfig.query.get_or_404(config_id)
    db.session.delete(config)
    db.session.commit()
    
    flash('Training configuration deleted successfully.', 'success')
    return redirect(url_for('admin.training_configs'))

@admin_bp.route('/training-sessions')
@login_required
def training_sessions():
    """List training sessions."""
    sessions = TrainingSession.query.order_by(TrainingSession.created_at.desc()).all()
    return render_template('admin/training_sessions.html', sessions=sessions)

@admin_bp.route('/training-sessions/create', methods=['GET', 'POST'])
@login_required
@admin_required
def training_session_create():
    """Create a new training session."""
    hardware_configs = HardwareConfig.query.all()
    training_configs = TrainingConfig.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        hardware_config_id = request.form.get('hardware_config_id')
        training_config_id = request.form.get('training_config_id')
        
        session = TrainingSession(
            name=name,
            description=description,
            hardware_config_id=int(hardware_config_id),
            training_config_id=int(training_config_id),
            status='pending',
            created_by=current_user.id
        )
        db.session.add(session)
        db.session.commit()
        
        flash('Training session created successfully.', 'success')
        return redirect(url_for('admin.training_sessions'))
    
    return render_template('admin/training_session_create.html',
                          hardware_configs=hardware_configs,
                          training_configs=training_configs)

@admin_bp.route('/training-sessions/<int:session_id>')
@login_required
def training_session_detail(session_id):
    """View training session details."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Get metrics for this session
    metrics = TrainingMetrics.query.filter_by(session_id=session_id).order_by(
        TrainingMetrics.timestamp.asc()).all()
    
    # Get logs for this session
    logs = TrainingLog.query.filter_by(session_id=session_id).order_by(
        TrainingLog.timestamp.desc()).limit(50).all()
    
    # Prepare metrics for charts
    iterations = [m.iteration for m in metrics]
    rewards = [m.avg_reward for m in metrics]
    losses = [m.loss for m in metrics]
    
    return render_template('admin/training_session_detail.html',
                          session=session,
                          metrics=metrics,
                          logs=logs,
                          iterations=iterations,
                          rewards=rewards,
                          losses=losses)

@admin_bp.route('/training-sessions/<int:session_id>/start', methods=['POST'])
@login_required
@admin_required
def training_session_start(session_id):
    """Start a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    if session.status != 'pending' and session.status != 'stopped':
        flash('Cannot start a session that is not in pending or stopped state.', 'danger')
        return redirect(url_for('admin.training_session_detail', session_id=session_id))
    
    # Update session status
    session.status = 'running'
    session.started_at = datetime.now()
    db.session.commit()
    
    # Log the action
    log = TrainingLog(
        session_id=session_id,
        level='INFO',
        message=f'Training session started by {current_user.username}'
    )
    db.session.add(log)
    db.session.commit()
    
    # TODO: Start actual training process here
    # This would typically involve launching a subprocess or sending a message to a worker
    try:
        # Example of how you might start training in a subprocess
        training_config = TrainingConfig.query.get(session.training_config_id)
        cmd = [
            'python', 'poker_rl.py',
            '--mode', 'train',
            '--batch_size', str(training_config.batch_size),
            '--learning_rate', str(training_config.learning_rate),
            '--session_id', str(session_id)
        ]
        # In a real implementation, you would handle this properly (e.g., with Celery)
        subprocess.Popen(cmd)
        
        flash('Training session started successfully.', 'success')
    except Exception as e:
        session.status = 'error'
        error_message = f'Error starting training: {str(e)}'
        log = TrainingLog(
            session_id=session_id,
            level='ERROR',
            message=error_message
        )
        db.session.add(log)
        db.session.commit()
        
        flash(error_message, 'danger')
    
    return redirect(url_for('admin.training_session_detail', session_id=session_id))

@admin_bp.route('/training-sessions/<int:session_id>/stop', methods=['POST'])
@login_required
@admin_required
def training_session_stop(session_id):
    """Stop a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    if session.status != 'running':
        flash('Cannot stop a session that is not running.', 'danger')
        return redirect(url_for('admin.training_session_detail', session_id=session_id))
    
    # Update session status
    session.status = 'stopped'
    session.ended_at = datetime.now()
    db.session.commit()
    
    # Log the action
    log = TrainingLog(
        session_id=session_id,
        level='INFO',
        message=f'Training session stopped by {current_user.username}'
    )
    db.session.add(log)
    db.session.commit()
    
    # TODO: Actually stop the training process
    # This would depend on how you started it
    
    flash('Training session stopped successfully.', 'success')
    return redirect(url_for('admin.training_session_detail', session_id=session_id))

@admin_bp.route('/training-sessions/<int:session_id>/delete', methods=['POST'])
@login_required
@admin_required
def training_session_delete(session_id):
    """Delete a training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    if session.status == 'running':
        flash('Cannot delete a session that is currently running.', 'danger')
        return redirect(url_for('admin.training_sessions'))
    
    # Delete associated metrics and logs
    TrainingMetrics.query.filter_by(session_id=session_id).delete()
    TrainingLog.query.filter_by(session_id=session_id).delete()
    
    # Delete the session
    db.session.delete(session)
    db.session.commit()
    
    flash('Training session deleted successfully.', 'success')
    return redirect(url_for('admin.training_sessions'))

@admin_bp.route('/api/metrics/<int:session_id>')
@login_required
def api_get_metrics(session_id):
    """Get metrics for a training session."""
    metrics = TrainingMetrics.query.filter_by(session_id=session_id).order_by(
        TrainingMetrics.timestamp.asc()).all()
    
    result = {
        'iterations': [m.iteration for m in metrics],
        'rewards': [m.avg_reward for m in metrics],
        'losses': [m.loss for m in metrics if m.loss is not None],
        'win_rates': [m.win_rate for m in metrics if m.win_rate is not None],
    }
    
    return jsonify(result)

@admin_bp.route('/api/metrics/<int:session_id>', methods=['POST'])
def api_update_metrics(session_id):
    """Update metrics for a training session (called by training script)."""
    # Simple API key check (in a real application, use proper authentication)
    api_key = request.headers.get('X-API-Key')
    if not api_key or api_key != os.environ.get('METRICS_API_KEY', 'development_key'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.json
    
    metrics = TrainingMetrics(
        session_id=session_id,
        iteration=data.get('iteration'),
        avg_reward=data.get('avg_reward'),
        loss=data.get('loss'),
        win_rate=data.get('win_rate'),
        exploitability=data.get('exploitability'),
        extra_data=json.dumps(data.get('extra_data', {}))
    )
    db.session.add(metrics)
    
    # Update session with latest metrics
    session = TrainingSession.query.get(session_id)
    if session:
        session.current_iteration = data.get('iteration')
        session.current_reward = data.get('avg_reward')
        session.current_win_rate = data.get('win_rate')
    
    db.session.commit()
    
    return jsonify({'status': 'success'})

@admin_bp.route('/api/logs/<int:session_id>', methods=['POST'])
def api_add_log(session_id):
    """Add a log entry for a training session (called by training script)."""
    # Simple API key check (in a real application, use proper authentication)
    api_key = request.headers.get('X-API-Key')
    if not api_key or api_key != os.environ.get('METRICS_API_KEY', 'development_key'):
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.json
    
    log = TrainingLog(
        session_id=session_id,
        level=data.get('level', 'INFO'),
        message=data.get('message'),
    )
    db.session.add(log)
    db.session.commit()
    
    return jsonify({'status': 'success'})

@admin_bp.route('/system-settings', methods=['GET', 'POST'])
@login_required
@admin_required
def system_settings():
    """Manage system settings."""
    if request.method == 'POST':
        # Process each setting
        for key, value in request.form.items():
            if key.startswith('setting_'):
                setting_key = key[8:]  # Remove 'setting_' prefix
                
                # Get existing setting or create new one
                setting = SystemSetting.query.filter_by(key=setting_key).first()
                if setting:
                    setting.value = value
                else:
                    setting = SystemSetting(key=setting_key, value=value)
                    db.session.add(setting)
        
        db.session.commit()
        flash('System settings updated successfully.', 'success')
        return redirect(url_for('admin.system_settings'))
    
    # Get all settings
    settings = SystemSetting.query.all()
    settings_dict = {s.key: s.value for s in settings}
    
    return render_template('admin/system_settings.html', settings=settings_dict)

@admin_bp.route('/monitoring-dashboard')
@login_required
def monitoring_dashboard():
    """Show the monitoring dashboard."""
    # Get active training sessions
    active_sessions = TrainingSession.query.filter_by(status='running').all()
    
    return render_template('admin/monitoring_dashboard.html', sessions=active_sessions)

@admin_bp.route('/session-monitor/<int:session_id>')
@login_required
def session_monitor(session_id):
    """Monitor a specific training session."""
    session = TrainingSession.query.get_or_404(session_id)
    
    # Get recent metrics
    metrics = TrainingMetrics.query.filter_by(session_id=session_id).order_by(
        TrainingMetrics.timestamp.desc()).limit(100).all()
    metrics.reverse()  # Get them in chronological order
    
    # Get recent logs
    logs = TrainingLog.query.filter_by(session_id=session_id).order_by(
        TrainingLog.timestamp.desc()).limit(50).all()
    
    return render_template('admin/session_monitor.html',
                          session=session,
                          metrics=metrics,
                          logs=logs)