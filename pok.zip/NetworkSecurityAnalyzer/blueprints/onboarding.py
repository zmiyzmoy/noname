import os
import sys
import json
import logging
import subprocess
import platform
import psutil
import time
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, current_app, flash
from models.db import db
from models.database import User, SystemSetting
from werkzeug.security import generate_password_hash

onboarding_bp = Blueprint('onboarding', __name__, template_folder='../templates')
logger = logging.getLogger(__name__)

# Wizard state storage
wizard_state = {
    'current_step': 0,
    'total_steps': 7,
    'system_check': None,
    'openspiel_check': None,
    'database_check': None,
    'admin_created': False,
    'services_started': False,
    'test_training_run': False,
    'completed': False
}

# Load state if exists
def load_wizard_state():
    state_file = os.path.join(current_app.root_path, 'onboarding_wizard_state.json')
    if os.path.exists(state_file):
        try:
            with open(state_file, 'r') as f:
                global wizard_state
                wizard_state = json.load(f)
        except Exception as e:
            logger.error(f"Error loading wizard state: {e}")

# Save current state
def save_wizard_state():
    state_file = os.path.join(current_app.root_path, 'onboarding_wizard_state.json')
    try:
        with open(state_file, 'w') as f:
            json.dump(wizard_state, f)
    except Exception as e:
        logger.error(f"Error saving wizard state: {e}")

@onboarding_bp.route('/')
def index():
    """Onboarding wizard home page."""
    load_wizard_state()
    return render_template('onboarding/index.html', wizard=wizard_state)

@onboarding_bp.route('/step/<int:step>')
def step(step):
    """Show a specific onboarding step."""
    load_wizard_state()
    wizard_state['current_step'] = step
    save_wizard_state()
    
    return render_template(
        f'onboarding/step_{step}.html', 
        wizard=wizard_state
    )

@onboarding_bp.route('/check_system', methods=['POST'])
def check_system():
    """Check system requirements."""
    load_wizard_state()
    
    # Get system information
    system_info = {
        'os': platform.system(),
        'os_version': platform.release(),
        'python_version': platform.python_version(),
        'cpu_count': psutil.cpu_count(logical=True),
        'memory_gb': round(psutil.virtual_memory().total / (1024**3), 2),
        'disk_total_gb': round(psutil.disk_usage('/').total / (1024**3), 2),
        'disk_free_gb': round(psutil.disk_usage('/').free / (1024**3), 2)
    }
    
    # Check for GPU
    try:
        import torch
        system_info['gpu_available'] = torch.cuda.is_available()
        if system_info['gpu_available']:
            system_info['gpu_name'] = torch.cuda.get_device_name(0)
            system_info['gpu_count'] = torch.cuda.device_count()
        else:
            system_info['gpu_name'] = 'None'
            system_info['gpu_count'] = 0
    except:
        system_info['gpu_available'] = False
        system_info['gpu_name'] = 'Error checking GPU'
        system_info['gpu_count'] = 0
    
    # Check if system meets requirements
    meets_requirements = (
        system_info['cpu_count'] >= 2 and
        system_info['memory_gb'] >= 2.0 and
        system_info['disk_free_gb'] >= 1.0
    )
    
    system_info['meets_requirements'] = meets_requirements
    
    wizard_state['system_check'] = system_info
    save_wizard_state()
    
    return jsonify(system_info)

@onboarding_bp.route('/check_openspiel', methods=['POST'])
def check_openspiel():
    """Check OpenSpiel installation."""
    load_wizard_state()
    
    # Try to import OpenSpiel
    try:
        subprocess.run([sys.executable, '-c', 'import pyspiel; print(pyspiel.__version__)'], 
                        check=True, capture_output=True, text=True)
        openspiel_status = {
            'installed': True,
            'version': 'Installed',
            'message': 'OpenSpiel is properly installed.'
        }
    except Exception as e:
        openspiel_status = {
            'installed': False,
            'version': 'Not installed',
            'message': f"Error importing OpenSpiel: {str(e)}"
        }
    
    wizard_state['openspiel_check'] = openspiel_status
    save_wizard_state()
    
    return jsonify(openspiel_status)

@onboarding_bp.route('/check_database', methods=['POST'])
def check_database():
    """Check database connection."""
    load_wizard_state()
    
    database_status = {
        'connected': False,
        'message': 'Could not connect to database.'
    }
    
    try:
        # Check if we can perform a simple query
        user_count = User.query.count()
        db_status = db.engine.pool.status()
        
        database_status = {
            'connected': True,
            'message': 'Successfully connected to database.',
            'user_count': user_count,
            'pool_status': {
                'checkedin': db_status.checkedin,
                'overflow': db_status.overflow,
                'checkedout': db_status.checkedout
            }
        }
    except Exception as e:
        database_status['message'] = f"Database error: {str(e)}"
    
    wizard_state['database_check'] = database_status
    save_wizard_state()
    
    return jsonify(database_status)

@onboarding_bp.route('/create_admin', methods=['POST'])
def create_admin():
    """Create admin user."""
    load_wizard_state()
    
    username = request.form.get('username')
    password = request.form.get('password')
    email = request.form.get('email')
    
    if not username or not password:
        return jsonify({
            'success': False,
            'message': 'Username and password are required.'
        })
    
    try:
        # Check if user already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return jsonify({
                'success': False,
                'message': f"User '{username}' already exists."
            })
        
        # Create new admin user
        new_user = User(
            username=username,
            password_hash=generate_password_hash(password),
            email=email,
            is_admin=True,
            created_at=datetime.now()
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        wizard_state['admin_created'] = True
        save_wizard_state()
        
        return jsonify({
            'success': True,
            'message': f"Admin user '{username}' created successfully."
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f"Error creating admin: {str(e)}"
        })

@onboarding_bp.route('/start_services', methods=['POST'])
def start_services():
    """Start required services."""
    load_wizard_state()
    
    services = []
    
    # We're not actually starting services here in the blueprint, just tracking
    wizard_state['services_started'] = True
    save_wizard_state()
    
    return jsonify({
        'success': True,
        'message': 'Services started successfully.',
        'services': services
    })

@onboarding_bp.route('/run_test_training', methods=['POST'])
def run_test_training():
    """Run a test training session."""
    load_wizard_state()
    
    try:
        # Start a short test training run
        subprocess.Popen(
            [sys.executable, 'poker_rl.py', '--mode', 'selfplay', '--num_episodes', '5', '--test_run'],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        
        wizard_state['test_training_run'] = True
        save_wizard_state()
        
        return jsonify({
            'success': True,
            'message': 'Test training started. This will run for a few minutes.'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f"Error starting test training: {str(e)}"
        })

@onboarding_bp.route('/complete', methods=['POST'])
def complete():
    """Mark onboarding as complete."""
    load_wizard_state()
    
    wizard_state['completed'] = True
    wizard_state['completion_time'] = str(datetime.now())
    save_wizard_state()
    
    return jsonify({
        'success': True,
        'message': 'Onboarding completed successfully.',
        'completion_time': wizard_state['completion_time']
    })

@onboarding_bp.route('/skip', methods=['POST'])
def skip():
    """Skip the onboarding wizard."""
    wizard_state = {
        'current_step': 7,
        'total_steps': 7,
        'completed': True,
        'skipped': True,
        'completion_time': str(datetime.now())
    }
    save_wizard_state()
    
    return jsonify({
        'success': True,
        'message': 'Onboarding wizard skipped.',
        'completion_time': wizard_state['completion_time']
    })