import os
import logging
import time
import json
import psutil
import torch
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, redirect, url_for
from models.db import db
from models.database import TrainingSession, SystemSetting, HardwareConfig

advanced_bp = Blueprint('advanced', __name__, template_folder='../templates')
logger = logging.getLogger(__name__)

# Helper function to get system metrics
def get_system_metrics():
    cpu_percent = psutil.cpu_percent(interval=0.1)
    memory = psutil.virtual_memory()
    
    # Try to get GPU info if available
    gpu_info = {'available': False}
    try:
        if torch.cuda.is_available():
            gpu_info = {
                'available': True,
                'device_name': torch.cuda.get_device_name(0),
                'memory_total': torch.cuda.get_device_properties(0).total_memory / (1024**3),
                'memory_used': (torch.cuda.get_device_properties(0).total_memory - torch.cuda.memory_reserved(0)) / (1024**3),
                'utilization': 0  # Need pynvml for proper utilization
            }
    except:
        pass
        
    disk = psutil.disk_usage('/')
    
    return {
        'timestamp': time.time(),
        'cpu': {
            'percent': cpu_percent,
            'cores': psutil.cpu_count(logical=True)
        },
        'memory': {
            'total': round(memory.total / (1024**3), 2),
            'used': round(memory.used / (1024**3), 2),
            'percent': memory.percent
        },
        'gpu': gpu_info,
        'disk': {
            'total': round(disk.total / (1024**3), 2),
            'used': round(disk.used / (1024**3), 2),
            'percent': disk.percent
        }
    }

# Route to display the advanced dashboard
@advanced_bp.route('/')
def index():
    # Fetch all training sessions
    sessions = TrainingSession.query.order_by(TrainingSession.id.desc()).all()
    active_sessions = [s for s in sessions if s.status == 'active']
    
    # Get hardware configs
    hardware_configs = HardwareConfig.query.all()
    
    # Fetch system metrics
    metrics = get_system_metrics()
    
    return render_template(
        'advanced/index.html',
        sessions=sessions,
        active_sessions=active_sessions,
        active_sessions_count=len(active_sessions),
        metrics=metrics,
        hardware_configs=hardware_configs
    )

# API route to get system metrics
@advanced_bp.route('/api/metrics')
def api_metrics():
    return jsonify(get_system_metrics())

# API route to get training session metrics
@advanced_bp.route('/api/session_metrics/<int:session_id>')
def session_metrics(session_id):
    session = TrainingSession.query.get_or_404(session_id)
    
    try:
        if session.metrics:
            return jsonify(json.loads(session.metrics))
        else:
            return jsonify({
                'error': 'No metrics available for this session',
                'win_rates': [],
                'latest_win_rate': 0,
                'iteration': 0
            })
    except Exception as e:
        logger.error(f"Error fetching session metrics: {e}")
        return jsonify({
            'error': str(e),
            'win_rates': [],
            'latest_win_rate': 0,
            'iteration': 0
        })

# Route to display detailed session view
@advanced_bp.route('/session/<int:session_id>')
def session_detail(session_id):
    session = TrainingSession.query.get_or_404(session_id)
    
    # Get hardware config if available
    hardware = None
    if session.hardware_config_id:
        hardware = HardwareConfig.query.get(session.hardware_config_id)
    
    return render_template(
        'advanced/session_detail.html',
        session=session,
        hardware=hardware
    )

# Route to update session status
@advanced_bp.route('/session/<int:session_id>/update_status', methods=['POST'])
def update_session_status(session_id):
    session = TrainingSession.query.get_or_404(session_id)
    status = request.form.get('status')
    
    if status in ['active', 'paused', 'completed', 'failed']:
        session.status = status
        db.session.commit()
        
    return redirect(url_for('advanced.session_detail', session_id=session_id))

# Route to display hardware configuration
@advanced_bp.route('/hardware')
def hardware():
    hardware_configs = HardwareConfig.query.all()
    return render_template('advanced/hardware.html', configs=hardware_configs)

# Route to create/edit hardware configuration
@advanced_bp.route('/hardware/edit/<int:config_id>', methods=['GET', 'POST'])
def edit_hardware(config_id):
    if config_id == 0:  # New config
        config = HardwareConfig()
    else:
        config = HardwareConfig.query.get_or_404(config_id)
        
    if request.method == 'POST':
        config.name = request.form.get('name')
        config.cpu_count = int(request.form.get('cpu_count', 1))
        config.ram_gb = float(request.form.get('ram_gb', 1.0))
        config.gpu_name = request.form.get('gpu_name', '')
        config.gpu_memory_gb = float(request.form.get('gpu_memory_gb', 0.0))
        config.gpu_count = int(request.form.get('gpu_count', 0))
        config.notes = request.form.get('notes', '')
        
        if config_id == 0:
            db.session.add(config)
            
        db.session.commit()
        return redirect(url_for('advanced.hardware'))
        
    return render_template('advanced/edit_hardware.html', config=config)

# Route to delete hardware configuration
@advanced_bp.route('/hardware/delete/<int:config_id>', methods=['POST'])
def delete_hardware(config_id):
    config = HardwareConfig.query.get_or_404(config_id)
    
    # Check if any sessions are using this config
    sessions_using = TrainingSession.query.filter_by(hardware_config_id=config_id).count()
    
    if sessions_using == 0:
        db.session.delete(config)
        db.session.commit()
    
    return redirect(url_for('advanced.hardware'))

# API route to get model evaluations
@advanced_bp.route('/api/model_evaluations')
def model_evaluations():
    # In a real implementation, this would fetch actual model evaluation data
    evaluations = [
        {"model": "PSRO_v1", "win_rate": 0.65, "exploitability": 0.15},
        {"model": "PSRO_v2", "win_rate": 0.72, "exploitability": 0.12},
        {"model": "PSRO_v3", "win_rate": 0.78, "exploitability": 0.09}
    ]
    
    return jsonify(evaluations)

# Route for system settings
@advanced_bp.route('/settings', methods=['GET', 'POST'])
def system_settings():
    if request.method == 'POST':
        # Update settings
        for key, value in request.form.items():
            if key.startswith('setting_'):
                setting_name = key[8:]  # Remove 'setting_' prefix
                setting = SystemSetting.query.filter_by(name=setting_name).first()
                
                if setting:
                    setting.value = value
                else:
                    new_setting = SystemSetting(name=setting_name, value=value)
                    db.session.add(new_setting)
                    
        db.session.commit()
        return redirect(url_for('advanced.system_settings'))
    
    # Get all settings
    settings = SystemSetting.query.all()
    settings_dict = {s.name: s.value for s in settings}
    
    # Ensure required settings exist
    required_settings = {
        'default_training_mode': 'selfplay',
        'default_num_episodes': '100',
        'default_num_workers': '4',
        'enable_tensorboard': 'true',
        'enable_auto_checkpointing': 'true',
        'checkpointing_interval': '10'
    }
    
    for name, default_value in required_settings.items():
        if name not in settings_dict:
            new_setting = SystemSetting(name=name, value=default_value)
            db.session.add(new_setting)
            settings_dict[name] = default_value
            
    db.session.commit()
    
    return render_template('advanced/settings.html', settings=settings_dict)