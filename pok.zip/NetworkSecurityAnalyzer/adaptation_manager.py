import os
import time
import logging
import numpy as np
import torch
import json
from typing import Dict, List, Optional, Tuple, Union, Any
from collections import defaultdict

from opponent_modeling import OpponentModel, analyze_board_texture, analyze_hand_strength, categorize_stack_depth

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)

class AdaptationManager:
    """
    Manages strategy adaptation based on opponent modeling.
    
    This class integrates opponent models with the AI's strategy to create
    dynamic, opponent-specific adaptations during gameplay.
    """
    
    def __init__(self, model_path: str = None, save_interval: int = 50):
        """
        Initialize the adaptation manager.
        
        Args:
            model_path: Path to load/save opponent models
            save_interval: How often to save the model (in number of hands)
        """
        self.opponent_model = OpponentModel(model_path)
        self.model_path = model_path or "./poker/models/opponent_models.json"
        self.save_interval = save_interval
        self.hand_counter = 0
        self.last_save_time = time.time()
        self.hand_results = defaultdict(list)  # Store results for adaptation feedback
        self.action_history = defaultdict(list)  # Store action history for analysis
        self.game_state_history = []  # Store recent game states for analysis
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        
        logging.info("AdaptationManager initialized")
    
    def register_action(self, player_id: int, action_type: str, position: int, street: int,
                       poker_round: str, amount: float = 0, pot_size: float = 0,
                       stack_size: float = 100, hole_cards: Optional[List[str]] = None,
                       board_cards: Optional[List[str]] = None, is_hero: bool = False,
                       is_raised_pot: bool = False, is_bet_pot: bool = False,
                       is_3bet_situation: bool = False, is_cbet_situation: bool = False) -> None:
        """
        Register an observed action to update opponent models.
        
        Args:
            player_id: Unique identifier for the player
            action_type: Type of action (bet, call, raise, fold, check)
            position: Table position (0-5, where 0 is SB, 1 is BB, etc.)
            street: Betting street (0=preflop, 1=flop, 2=turn, 3=river)
            poker_round: String representation of round ("PREFLOP", "FLOP", etc.)
            amount: Amount bet/called/raised
            pot_size: Current pot size
            stack_size: Player's stack size
            hole_cards: Player's hole cards (if known, usually only for hero)
            board_cards: Community cards on the board
            is_hero: Whether this is the AI player's action
            is_raised_pot: Whether there was a raise before this action
            is_bet_pot: Whether there was a bet before this action
            is_3bet_situation: Whether this is a 3-bet situation
            is_cbet_situation: Whether this is a continuation bet situation
        """
        # Don't process if essential data is missing
        if player_id is None or action_type is None:
            return
        
        # Normalize action type (lowercase)
        action_type = action_type.lower()
        
        # Determine opportunities
        is_raise_opportunity = is_raised_pot or is_bet_pot
        is_check_raise_opportunity = action_type == 'check' and is_bet_pot
        
        # Analyze board texture if board cards are available
        board_texture = 'high_card'
        if board_cards:
            texture_analysis = analyze_board_texture(board_cards)
            # Determine the predominant texture
            if texture_analysis['draw_heavy'] > 0.5:
                board_texture = 'draw_heavy'
            elif texture_analysis['paired'] > 0.5:
                board_texture = 'paired'
            elif texture_analysis['static'] > 0.5:
                board_texture = 'static'
        
        # Determine stack depth category
        stack_depth = categorize_stack_depth(stack_size)
        
        # Analyze hand strength if hole cards are available (usually only for hero)
        hand_strength = None
        is_bluff = False
        is_value_bet = False
        if hole_cards and board_cards and (action_type in ['bet', 'raise']):
            strength_analysis = analyze_hand_strength(hole_cards, board_cards)
            hand_strength = strength_analysis['strength']
            # Simplified bluff/value classification
            is_bluff = hand_strength < 0.4 and action_type in ['bet', 'raise']
            is_value_bet = hand_strength > 0.6 and action_type in ['bet', 'raise']
        
        # Update opponent model
        self.opponent_model.update_opponent_stats(
            player_id=player_id,
            action_type=action_type,
            position=position,
            street=street,
            is_raise_opportunity=is_raise_opportunity,
            is_3bet_opportunity=is_3bet_situation,
            is_cbet_opportunity=is_cbet_situation,
            is_check_raise_opportunity=is_check_raise_opportunity,
            stack_depth=stack_depth,
            board_texture=board_texture,
            # Other fields remain default unless we have more information
            went_to_showdown=False,
            won_at_showdown=False,
            was_bluffing=is_bluff if is_hero else False,
            had_strong_hand=is_value_bet if is_hero else False,
            stack_to_pot=stack_size / max(1.0, pot_size),
            bet_sizing=amount / max(1.0, pot_size) if amount > 0 else 0
        )
        
        # Store action history for more complex pattern analysis
        self.action_history[player_id].append({
            'action_type': action_type,
            'position': position,
            'street': street,
            'round': poker_round,
            'amount': amount,
            'pot_size': pot_size,
            'stack_size': stack_size,
            'board_texture': board_texture,
            'timestamp': time.time()
        })
        
        # Trim action history if it gets too long
        if len(self.action_history[player_id]) > 100:
            self.action_history[player_id] = self.action_history[player_id][-100:]
        
        # Increment hand counter for periodic saving
        if action_type in ['fold', 'check'] and street == 3:  # End of a hand
            self.hand_counter += 1
            if self.hand_counter % self.save_interval == 0:
                self.save_models()
    
    def register_hand_result(self, player_id: int, net_win: float, had_showdown: bool = False,
                            hole_cards: Optional[List[str]] = None, board_cards: Optional[List[str]] = None) -> None:
        """
        Register the result of a hand to update adaptation feedback.
        
        Args:
            player_id: Unique identifier for the player
            net_win: Amount won or lost in the hand
            had_showdown: Whether the hand went to showdown
            hole_cards: Player's hole cards (if revealed)
            board_cards: Final community cards
        """
        # Store hand result
        self.hand_results[player_id].append({
            'net_win': net_win,
            'had_showdown': had_showdown,
            'hole_cards': hole_cards,
            'board_cards': board_cards,
            'timestamp': time.time()
        })
        
        # Trim result history if it gets too long
        if len(self.hand_results[player_id]) > 50:
            self.hand_results[player_id] = self.hand_results[player_id][-50:]
        
        # Update adaptation weights based on recent results
        if player_id == 0:  # Assuming player_id 0 is the hero
            recent_results = self.hand_results[player_id][-10:]
            if recent_results:
                total_win = sum(result['net_win'] for result in recent_results)
                self.opponent_model.update_adaptation_weights(total_win)
    
    def get_adapted_action_probs(self, player_id: int, original_probs: Union[Dict[int, float], int, Any],
                               is_preflop: bool = False, is_bluff: bool = False,
                               is_value_bet: bool = False, position: int = 0) -> Dict[int, float]:
        """
        Get adapted action probabilities based on opponent modeling.
        
        Args:
            player_id: Unique identifier for the opponent
            original_probs: Original action probabilities from the base strategy (can be a dict, int, or other)
            is_preflop: Whether this is a preflop decision
            is_bluff: Whether we're considering a bluff
            is_value_bet: Whether we're considering a value bet
            position: Table position (0-5)
            
        Returns:
            Adjusted action probabilities (always a dictionary)
        """
        try:
            # Handle case where original_probs is an integer (single action)
            if isinstance(original_probs, int):
                logging.warning(f"AdaptationManager: Converting single action {original_probs} to dictionary")
                # Convert single action to a dictionary with 100% probability for that action
                original_probs = {original_probs: 1.0}
                
            # Handle cases where original_probs is not a dictionary
            elif not isinstance(original_probs, dict):
                logging.warning(f"AdaptationManager: Invalid original_probs type: {type(original_probs)}. Creating uniform distribution.")
                # Create a uniform distribution over standard actions
                original_probs = {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25}
            
            # Get adapted action probabilities, which are guaranteed to be dictionaries
            # due to the fixes in opponent_model.adjust_action_probabilities
            adapted_probs = self.opponent_model.adjust_action_probabilities(
                player_id=player_id,
                action_probs=original_probs,
                is_preflop=is_preflop,
                is_bluff=is_bluff,
                is_value_bet=is_value_bet,
                position=position
            )
            
            return adapted_probs
            
        except Exception as e:
            logging.warning(f"Error in get_adapted_action_probs: {e}")
            # Return a safe fallback
            return {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25}
    
    def get_opponent_profile(self, player_id: int) -> Dict[str, Any]:
        """
        Get a comprehensive profile of an opponent.
        
        Args:
            player_id: Unique identifier for the opponent
            
        Returns:
            Dictionary containing opponent profile
        """
        # Get opponent stats
        stats = self.opponent_model.get_opponent_stats(player_id)
        if not stats:
            return {'hands_played': 0, 'has_profile': False}
        
        # Get counter strategy
        counter_strategy = self.opponent_model.get_counter_strategy(player_id)
        
        # Analyze recent results against this opponent
        recent_results = self.hand_results.get(player_id, [])
        win_rate = 0
        if recent_results:
            total_win = sum(result['net_win'] for result in recent_results)
            win_rate = total_win / len(recent_results)
        
        # Create comprehensive profile
        profile = {
            'hands_played': stats['hands_played'],
            'has_profile': True,
            'play_style': {
                'vpip': stats['vpip'],
                'pfr': stats['pfr'],
                'af': stats['af'],
                'three_bet': stats.get('three_bet', 0),
                'cbet': stats.get('cbet', 0),
                'fold_to_3bet': stats.get('fold_to_3bet', 0),
                'fold_to_cbet': stats.get('fold_to_cbet', 0),
                'check_raise_freq': stats.get('check_raise_freq', 0)
            },
            'archetypes': stats.get('archetypes', {}),
            'exploit_patterns': stats.get('exploit_patterns', {}),
            'counter_strategy': counter_strategy,
            'win_rate': win_rate
        }
        
        return profile
    
    def get_hand_recommendation(self, player_id: int, hole_cards: List[str], board_cards: Optional[List[str]] = None,
                               position: int = 0, street: int = 0, pot_size: float = 0.0, stack_size: float = 100.0) -> Dict[str, Any]:
        """
        Get specific recommendations for how to play against this opponent in current hand.
        
        Args:
            player_id: Unique identifier for the opponent
            hole_cards: Hero's hole cards
            board_cards: Community cards
            position: Hero's position
            street: Current street
            pot_size: Current pot size
            stack_size: Hero's stack size
            
        Returns:
            Dictionary containing hand-specific recommendations
        """
        # Get opponent profile
        profile = self.get_opponent_profile(player_id)
        if not profile['has_profile'] or profile['hands_played'] < 20:
            return {'recommendation': 'Use default strategy - insufficient data on opponent',
                   'confidence': 0.0}
        
        # Analyze hand strength
        hand_analysis = analyze_hand_strength(hole_cards, board_cards or [])
        hand_strength = hand_analysis['strength']
        
        # Analyze board texture (if board exists)
        texture = {}
        if board_cards:
            texture = analyze_board_texture(board_cards)
        
        # Basic recommendations based on opponent type and hand strength
        recommendation = {
            'hand_strength': hand_strength,
            'board_texture': texture,
            'confidence': min(0.5, profile['hands_played'] / 100)  # Confidence scales with data
        }
        
        # Opponent archetypes
        archetypes = profile['archetypes']
        top_archetype = max(archetypes.items(), key=lambda x: x[1])[0] if archetypes else None
        
        # Adjust recommendations based on opponent type and situation
        if top_archetype == 'tight_passive':
            if hand_strength > 0.7:
                recommendation['strategy'] = 'Value bet thinly'
                recommendation['bet_sizing'] = 'Small (pot * 0.5-0.7)'
                recommendation['confidence'] += 0.1
            elif hand_strength < 0.4:
                recommendation['strategy'] = 'Bluff more often'
                recommendation['bet_sizing'] = 'Small (pot * 0.5)'
                recommendation['confidence'] += 0.1
        
        elif top_archetype == 'loose_passive':
            if hand_strength > 0.6:
                recommendation['strategy'] = 'Value bet widely'
                recommendation['bet_sizing'] = 'Large (pot * 0.75-1.0)'
                recommendation['confidence'] += 0.2
            else:
                recommendation['strategy'] = 'Minimize bluffing'
                recommendation['confidence'] += 0.2
        
        elif top_archetype == 'tight_aggressive':
            if hand_strength > 0.8:
                recommendation['strategy'] = 'Slow play strong hands'
                recommendation['confidence'] += 0.15
            elif hand_strength < 0.5:
                recommendation['strategy'] = 'Fold more marginal hands'
                recommendation['confidence'] += 0.15
        
        elif top_archetype == 'loose_aggressive':
            if hand_strength > 0.7:
                recommendation['strategy'] = 'Call down lighter with strong hands'
                recommendation['confidence'] += 0.15
            elif hand_strength < 0.3:
                recommendation['strategy'] = 'Avoid bluffing'
                recommendation['confidence'] += 0.2
        
        elif top_archetype == 'maniac':
            if hand_strength > 0.6:
                recommendation['strategy'] = 'Trap with strong hands, let them bluff'
                recommendation['confidence'] += 0.2
            else:
                recommendation['strategy'] = 'Fold weak hands, do not try to bluff'
                recommendation['confidence'] += 0.2
        
        elif top_archetype == 'rock':
            if hand_strength > 0.5:
                recommendation['strategy'] = 'Raise their limps, steal their blinds'
                recommendation['confidence'] += 0.2
            else:
                recommendation['strategy'] = 'Bluff more often'
                recommendation['confidence'] += 0.15
        
        elif top_archetype == 'calling_station':
            if hand_strength > 0.6:
                recommendation['strategy'] = 'Value bet thin, larger sizing'
                recommendation['bet_sizing'] = 'Large (pot * 0.75-1.0)'
                recommendation['confidence'] += 0.2
            else:
                recommendation['strategy'] = 'Minimise bluffing completely'
                recommendation['confidence'] += 0.2
        
        # Add recommendations based on specific exploits
        exploit_patterns = profile['exploit_patterns']
        if 'folds_to_3bet' in exploit_patterns and exploit_patterns['folds_to_3bet'] > 0.7:
            if street == 0 and hand_strength > 0.4:
                recommendation['exploit'] = 'Consider 3-betting as a semi-bluff'
                recommendation['confidence'] += 0.1
        
        if 'folds_to_cbet' in exploit_patterns and exploit_patterns['folds_to_cbet'] > 0.7:
            if street == 1:
                recommendation['exploit'] = 'C-bet frequently on flop'
                recommendation['confidence'] += 0.1
        
        if 'river_calling_station' in exploit_patterns and exploit_patterns['river_calling_station'] > 0.7:
            if street == 3 and hand_strength > 0.6:
                recommendation['exploit'] = 'Value bet very thinly on river'
                recommendation['confidence'] += 0.1
        
        # Cap confidence at 0.9
        recommendation['confidence'] = min(0.9, recommendation['confidence'])
        
        return recommendation
    
    def save_models(self) -> None:
        """Save opponent models to file."""
        self.opponent_model.save_model(self.model_path)
        self.last_save_time = time.time()
    
    def load_models(self) -> None:
        """Load opponent models from file."""
        if os.path.exists(self.model_path):
            self.opponent_model.load_model(self.model_path)


def test_adaptation_manager():
    """Test the adaptation manager functionality."""
    print("Testing AdaptationManager...")
    
    # Create a temporary model path
    model_path = "./poker/models/test_opponent_models.json"
    
    # Create adaptation manager
    manager = AdaptationManager(model_path=model_path, save_interval=10)
    
    # Simulate some actions
    player_id = 42
    hero_id = 0
    
    # Simulate a few hands
    for hand in range(30):
        # Preflop actions
        manager.register_action(
            player_id=player_id,
            action_type='fold' if hand % 3 == 0 else 'raise',
            position=2,
            street=0,
            poker_round="PREFLOP",
            amount=5.0 if hand % 3 != 0 else 0.0,
            pot_size=3.0,
            stack_size=100.0,
            is_hero=False,
            is_3bet_situation=hand % 5 == 0
        )
        
        # Hero actions (if villain raised)
        if hand % 3 != 0:
            manager.register_action(
                player_id=hero_id,
                action_type='call',
                position=3,
                street=0,
                poker_round="PREFLOP",
                amount=5.0,
                pot_size=8.0,
                stack_size=95.0,
                hole_cards=['As', 'Ks'], 
                is_hero=True,
                is_raised_pot=True
            )
            
            # Flop actions
            board_cards = ['Jh', '7s', '2d']
            manager.register_action(
                player_id=hero_id,
                action_type='check',
                position=3,
                street=1,
                poker_round="FLOP",
                pot_size=13.0,
                stack_size=95.0,
                hole_cards=['As', 'Ks'],
                board_cards=board_cards,
                is_hero=True
            )
            
            manager.register_action(
                player_id=player_id,
                action_type='bet',
                position=2,
                street=1,
                poker_round="FLOP",
                amount=10.0,
                pot_size=13.0,
                stack_size=95.0,
                board_cards=board_cards,
                is_hero=False,
                is_cbet_situation=True
            )
            
            # Hero calls or folds
            manager.register_action(
                player_id=hero_id,
                action_type='call' if hand % 2 == 0 else 'fold',
                position=3,
                street=1,
                poker_round="FLOP",
                amount=10.0 if hand % 2 == 0 else 0.0,
                pot_size=23.0,
                stack_size=95.0,
                hole_cards=['As', 'Ks'],
                board_cards=board_cards,
                is_hero=True,
                is_bet_pot=True
            )
            
            # Register hand result
            if hand % 2 == 0:  # Hero called
                # Turn and river checks by both players
                board_cards = ['Jh', '7s', '2d', 'Qc', '5h']
                
                # Register showdown (hero wins with Ace high)
                manager.register_hand_result(
                    player_id=hero_id,
                    net_win=23.0,
                    had_showdown=True,
                    hole_cards=['As', 'Ks'],
                    board_cards=board_cards
                )
                
                manager.register_hand_result(
                    player_id=player_id,
                    net_win=-23.0,
                    had_showdown=True,
                    hole_cards=['Jc', '8s'],
                    board_cards=board_cards
                )
            else:  # Hero folded
                manager.register_hand_result(
                    player_id=hero_id,
                    net_win=-5.0,
                    had_showdown=False,
                    hole_cards=['As', 'Ks']
                )
                
                manager.register_hand_result(
                    player_id=player_id,
                    net_win=13.0,
                    had_showdown=False
                )
    
    # Get opponent profile
    profile = manager.get_opponent_profile(player_id)
    print(f"Opponent profile: {json.dumps(profile, indent=2)}")
    
    # Get hand recommendation
    recommendation = manager.get_hand_recommendation(
        player_id=player_id,
        hole_cards=['Ah', 'Qh'],
        board_cards=['Kh', '10h', '3s'],
        position=3,
        street=1,
        pot_size=20.0,
        stack_size=90.0
    )
    print(f"Hand recommendation: {json.dumps(recommendation, indent=2)}")
    
    # Test adaptation of action probabilities
    original_probs = {0: 0.2, 1: 0.3, 2: 0.5}  # fold, call, raise
    adapted_probs = manager.get_adapted_action_probs(
        player_id=player_id,
        original_probs=original_probs,
        is_preflop=False,
        is_bluff=True,
        position=3
    )
    print(f"Original probs: {original_probs}")
    print(f"Adapted probs: {adapted_probs}")
    
    # Save models
    manager.save_models()
    print(f"Saved model to {model_path}")
    
    return True


if __name__ == "__main__":
    test_adaptation_manager()