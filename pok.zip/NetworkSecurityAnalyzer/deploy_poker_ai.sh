#!/bin/bash
# Poker AI Deployment Script
# This script installs dependencies and launches all necessary components
# of the Poker AI system. Run with sudo permissions for proper installation.

set -e # Exit on any error

# Text colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Current directory
CURRENT_DIR=$(pwd)

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}       POKER AI DEPLOYMENT SCRIPT                 ${NC}"
echo -e "${BLUE}==================================================${NC}"

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install system dependencies
install_system_dependencies() {
    echo -e "${YELLOW}Installing system dependencies...${NC}"
    
    apt-get update
    apt-get install -y \
        build-essential \
        python3 \
        python3-pip \
        python3-dev \
        python3-venv \
        git \
        libopenmpi-dev \
        supervisor \
        nginx
    
    echo -e "${GREEN}System dependencies installed successfully!${NC}"
}

# Function to create and activate virtual environment
setup_virtual_environment() {
    echo -e "${YELLOW}Setting up Python virtual environment...${NC}"
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
    fi
    
    source venv/bin/activate
    
    echo -e "${GREEN}Virtual environment activated!${NC}"
}

# Function to install Python dependencies
install_python_dependencies() {
    echo -e "${YELLOW}Installing Python dependencies...${NC}"
    
    pip install --upgrade pip
    pip install -r requirements.txt
    
    echo -e "${GREEN}Python dependencies installed successfully!${NC}"
}

# Function to generate requirements.txt if it doesn't exist
generate_requirements() {
    echo -e "${YELLOW}Generating requirements.txt...${NC}"
    
    cat > requirements.txt << EOF
dash
dash-bootstrap-components
flask
flask-login
flask-migrate
flask-sqlalchemy
gunicorn
imageio
joblib
matplotlib
numpy
open-spiel
plotly
psutil
psycopg2-binary
pynvml
ray
requests
scikit-learn
scipy
sqlalchemy
tensorboard
torch
tqdm
werkzeug
EOF
    
    echo -e "${GREEN}requirements.txt generated!${NC}"
}

# Function to set up database
setup_database() {
    echo -e "${YELLOW}Setting up PostgreSQL database...${NC}"
    
    if ! command_exists psql; then
        apt-get install -y postgresql postgresql-contrib
    fi
    
    # Create a PostgreSQL database (customize as needed)
    if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw poker_ai; then
        echo -e "${GREEN}Database already exists, skipping creation.${NC}"
    else
        sudo -u postgres createdb poker_ai
        sudo -u postgres psql -c "CREATE USER poker_user WITH PASSWORD 'poker_password';"
        sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE poker_ai TO poker_user;"
        
        # Set environment variable for database connection
        export DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"
        
        # Add environment variable to bashrc for persistence
        if ! grep -q "DATABASE_URL" ~/.bashrc; then
            echo 'export DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"' >> ~/.bashrc
        fi
        
        echo -e "${GREEN}Database created and configured!${NC}"
    fi
    
    # Run migrations (if needed)
    source venv/bin/activate
    python main.py db upgrade
}

# Function to set up Supervisor
setup_supervisor() {
    echo -e "${YELLOW}Setting up Supervisor to manage services...${NC}"
    
    # Create supervisor configuration directory if it doesn't exist
    mkdir -p /etc/supervisor/conf.d/
    
    # Create configuration for main Flask application
    cat > /etc/supervisor/conf.d/poker_ai_main.conf << EOF
[program:poker_ai_main]
command=${CURRENT_DIR}/venv/bin/python ${CURRENT_DIR}/main.py
directory=${CURRENT_DIR}
user=$(whoami)
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stdout_logfile=${CURRENT_DIR}/logs/main_flask.log
stderr_logfile=${CURRENT_DIR}/logs/main_flask_err.log
environment=DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"
EOF

    # Create configuration for monitoring web
    cat > /etc/supervisor/conf.d/poker_ai_monitor.conf << EOF
[program:poker_ai_monitor]
command=${CURRENT_DIR}/venv/bin/python ${CURRENT_DIR}/monitoring_web.py
directory=${CURRENT_DIR}
user=$(whoami)
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stdout_logfile=${CURRENT_DIR}/logs/monitor_web.log
stderr_logfile=${CURRENT_DIR}/logs/monitor_web_err.log
environment=DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"
EOF

    # Create configuration for web poker menu
    cat > /etc/supervisor/conf.d/poker_ai_web_menu.conf << EOF
[program:poker_ai_web_menu]
command=${CURRENT_DIR}/venv/bin/python ${CURRENT_DIR}/web_poker_menu.py
directory=${CURRENT_DIR}
user=$(whoami)
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stdout_logfile=${CURRENT_DIR}/logs/web_menu.log
stderr_logfile=${CURRENT_DIR}/logs/web_menu_err.log
environment=DATABASE_URL="postgresql://poker_user:poker_password@localhost/poker_ai"
EOF

    # Create Nginx configuration for reverse proxy
    cat > /etc/nginx/sites-available/poker_ai << EOF
server {
    listen 80;
    server_name _;  # Replace with your domain name if available

    # Main Flask app (Consolidated)
    location / {
        proxy_pass http://127.0.0.1:5010;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    # Web Poker Dashboard
    location /dashboard/ {
        proxy_pass http://127.0.0.1:5003/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    # Monitoring Web
    location /monitor/ {
        proxy_pass http://127.0.0.1:5000/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF

    # Enable the site
    ln -sf /etc/nginx/sites-available/poker_ai /etc/nginx/sites-enabled/

    # Create logs directory
    mkdir -p ${CURRENT_DIR}/logs

    # Reload supervisor and nginx
    supervisorctl reload
    nginx -t && service nginx reload
    
    echo -e "${GREEN}Supervisor and Nginx configured successfully!${NC}"
}

# Function to start the system
start_system() {
    echo -e "${YELLOW}Starting Poker AI system...${NC}"
    
    # Create admin user (if needed)
    source venv/bin/activate
    python create_new_admin.py
    
    # Start all services with Supervisor
    supervisorctl update
    supervisorctl start all
    
    echo -e "${GREEN}Poker AI system started successfully!${NC}"
    echo -e "${BLUE}Main application: http://localhost/   (port 5010)${NC}"
    echo -e "${BLUE}Web Dashboard:    http://localhost/dashboard/   (port 5003)${NC}"
    echo -e "${BLUE}Monitoring:       http://localhost/monitor/   (port 5000)${NC}"
}

# Function to run manual commands (for testing)
run_manual() {
    echo -e "${YELLOW}Running system components manually...${NC}"
    
    source venv/bin/activate
    
    # Start main Flask app
    python main.py &
    MAIN_PID=$!
    
    # Start monitoring web
    python monitoring_web.py &
    MONITOR_PID=$!
    
    # Start web poker menu
    python web_poker_menu.py &
    WEB_MENU_PID=$!
    
    echo -e "${GREEN}Services started manually with the following PIDs:${NC}"
    echo "Main Flask app (PID: $MAIN_PID)"
    echo "Monitoring web (PID: $MONITOR_PID)"
    echo "Web poker menu (PID: $WEB_MENU_PID)"
    echo -e "${YELLOW}Press Ctrl+C to stop all services${NC}"
    
    # Keep the script running until interrupted
    trap "kill $MAIN_PID $MONITOR_PID $WEB_MENU_PID; echo -e '${RED}Services stopped${NC}'" SIGINT
    wait
}

# Function to show help
show_help() {
    echo -e "${BLUE}Usage: $0 [OPTION]${NC}"
    echo "Options:"
    echo "  install         Install all dependencies and set up the system"
    echo "  start           Start all services using Supervisor"
    echo "  manual          Run all services manually in the terminal (for testing)"
    echo "  help            Show this help message"
}

# Run a single training or evaluation
run_training() {
    echo -e "${YELLOW}Running a single training session...${NC}"
    
    source venv/bin/activate
    python poker_rl.py --mode train --num_episodes 100 --num_iterations 10 --verbose
    
    echo -e "${GREEN}Training complete!${NC}"
}

# Run self-play demonstration
run_selfplay() {
    echo -e "${YELLOW}Running a self-play demonstration...${NC}"
    
    source venv/bin/activate
    python poker_rl.py --mode selfplay --num_episodes 5 --verbose
    
    echo -e "${GREEN}Self-play complete!${NC}"
}

# Main script logic
case "$1" in
    "install")
        install_system_dependencies
        setup_virtual_environment
        generate_requirements
        install_python_dependencies
        setup_database
        setup_supervisor
        echo -e "${GREEN}Installation complete! Use '$0 start' to start the system.${NC}"
        ;;
    "start")
        start_system
        ;;
    "manual")
        run_manual
        ;;
    "train")
        run_training
        ;;
    "selfplay")
        run_selfplay
        ;;
    "help")
        show_help
        ;;
    *)
        echo -e "${RED}Invalid option: $1${NC}"
        show_help
        exit 1
        ;;
esac

exit 0