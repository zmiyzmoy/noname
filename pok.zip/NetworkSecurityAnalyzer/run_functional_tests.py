#!/usr/bin/env python3
"""
Functional Test Suite for Poker AI

This script automates running the specified test cases with minimal parameters
and generates a detailed summary report of the outcomes.
"""

import os
import sys
import subprocess
import time
import datetime
import re
import logging
import psutil
import string
import json
from typing import Dict, List, Any, Tuple, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Test cases to run - each is a dictionary with test parameters
TEST_CASES = [
    {
        "name": "Selfplay Mode Test",
        "command": "python poker_rl.py --mode selfplay --num_episodes 1 --verbose",
        "timeout": 30,  # seconds
        "success_patterns": [
            r"Selfplay demonstration.*complete",
            r"Opponent model saved"
        ],
        "error_patterns": [
            r"Error.*Traceback",
            r"Exception:.*"
        ],
        "feature": "selfplay"
    },
    {
        "name": "Evaluation Mode Test",
        "command": "python poker_rl.py --mode eval --num_episodes 2 --eval_opponents random,tight_passive --checkpoint none --verbose",
        "timeout": 30,  # seconds
        "success_patterns": [
            r"Evaluation complete"
        ],
        "error_patterns": [
            r"Error.*Traceback",
            r"Exception:.*"
        ],
        "feature": "evaluation"
    },
    {
        "name": "Dynamic Parameters Test",
        "command": "python poker_rl.py --mode selfplay --num_episodes 1 --verbose --enable_dynamic_adjustment --non_interactive",
        "timeout": 30,  # seconds
        "success_patterns": [
            r"Parameter adjustment helper is ENABLED",
            r"Selfplay demonstration.*complete"
        ],
        "error_patterns": [
            r"Error.*Traceback",
            r"Could not import parameter adjuster"
        ],
        "feature": "dynamic_parameters"
    }
]

def clear_log_files():
    """Clear log files before each test."""
    log_files = ['poker_rl.log', 'cloud_training.log', 'admin_dashboard.log']
    for log_file in log_files:
        if os.path.exists(log_file):
            try:
                open(log_file, 'w').close()
                logging.info(f"Cleared log file: {log_file}")
            except Exception as e:
                logging.error(f"Error clearing log file {log_file}: {e}")

def get_last_n_lines(file_path, n=20):
    """Get the last n lines from a file."""
    if not os.path.exists(file_path):
        return []
    
    try:
        with open(file_path, 'r') as f:
            # Try to read all lines and get the last n
            lines = f.readlines()
            return lines[-n:] if lines else []
    except Exception as e:
        logging.error(f"Error reading file {file_path}: {e}")
        return []

def find_errors_in_log(log_file):
    """Find ERROR messages in the log file."""
    errors = []
    if not os.path.exists(log_file):
        return errors
    
    try:
        with open(log_file, 'r') as f:
            for line in f:
                if "ERROR" in line:
                    errors.append(line.strip())
    except Exception as e:
        logging.error(f"Error reading log file {log_file}: {e}")
    
    return errors

def check_success_pattern(log_content, patterns):
    """Check if any of the success patterns are found in the log content."""
    if not patterns:
        return False
    
    text = " ".join(log_content) if isinstance(log_content, list) else log_content
    for pattern in patterns:
        if re.search(pattern, text):
            return True
    return False

def monitor_resources(process):
    """Monitor CPU and RAM usage of a process."""
    if not process:
        return {}
    
    try:
        # Get the current process
        p = psutil.Process(process.pid)
        
        # Get CPU and memory usage
        cpu_percent = p.cpu_percent(interval=0.1)
        memory_info = p.memory_info()
        memory_percent = p.memory_percent()
        
        return {
            'cpu_percent': cpu_percent,
            'memory_rss_mb': memory_info.rss / (1024 * 1024),
            'memory_percent': memory_percent
        }
    except Exception as e:
        logging.error(f"Error monitoring resources: {e}")
        return {}

def run_test(test_case):
    """Run a test case and collect results."""
    logging.info(f"\n{'='*80}")
    logging.info(f"Running Test: {test_case['name']}")
    logging.info(f"Command: {test_case['command']}")
    logging.info(f"{'='*80}")
    
    # Clear log files before each test
    clear_log_files()
    
    # Prepare result object
    result = {
        "name": test_case['name'],
        "command": test_case['command'],
        "feature": test_case.get('feature', 'unknown'),
        "success": False,
        "success_pattern_found": False,
        "stdout": "",
        "stderr": "",
        "log_content": [],
        "errors": [],
        "resources": {},
        "exit_code": None,
        "duration": 0,
        "recommendation": ""
    }
    
    start_time = time.time()
    
    # Start the process
    try:
        process = subprocess.Popen(
            test_case['command'],
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        # Set up stdout and stderr reading
        stdout_lines = []
        stderr_lines = []
        
        def read_stdout():
            while True:
                line = process.stdout.readline()
                if not line:
                    break
                stdout_lines.append(line.strip())
                sys.stdout.write(line)
        
        def read_stderr():
            while True:
                line = process.stderr.readline()
                if not line:
                    break
                stderr_lines.append(line.strip())
                sys.stderr.write(line)
        
        # Monitor resources during execution
        resource_samples = []
        timeout = test_case.get('timeout', 30)
        timeout_time = start_time + timeout
        
        while process.poll() is None:
            # Check for timeout
            if time.time() > timeout_time:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                
                result["stdout"] = "*** TEST TIMED OUT ***\n" + "\n".join(stdout_lines)
                result["stderr"] = "\n".join(stderr_lines)
                result["exit_code"] = -1  # Custom code for timeout
                result["duration"] = time.time() - start_time
                result["success"] = False
                result["errors"].append("Test timed out after {:.2f} seconds".format(result["duration"]))
                
                logging.warning(f"Test timed out after {result['duration']:.2f} seconds")
                return result
            
            # Sample resource usage
            resource_info = monitor_resources(process)
            if resource_info:
                resource_samples.append(resource_info)
            
            # Allow other processes to run and avoid busy-waiting
            time.sleep(0.1)
        
        # Process finished, collect output
        remaining_stdout, remaining_stderr = process.communicate()
        
        if remaining_stdout:
            stdout_lines.extend(remaining_stdout.strip().split('\n'))
        if remaining_stderr:
            stderr_lines.extend(remaining_stderr.strip().split('\n'))
        
        # Save outputs to result
        result["stdout"] = "\n".join(stdout_lines)
        result["stderr"] = "\n".join(stderr_lines)
        result["exit_code"] = process.returncode
        result["duration"] = time.time() - start_time
        result["success"] = process.returncode == 0
        
        # Get log content
        log_file = 'poker_rl.log'
        result["log_content"] = get_last_n_lines(log_file, 50)
        
        # Check for success patterns in stdout, stderr, and logs
        all_output = result["stdout"] + "\n" + result["stderr"] + "\n" + "\n".join(result["log_content"])
        result["success_pattern_found"] = check_success_pattern(all_output, test_case.get('success_patterns', []))
        
        # Find errors in logs
        result["errors"] = find_errors_in_log(log_file)
        
        # Calculate average resource usage
        if resource_samples:
            result["resources"] = {
                'cpu_percent': sum(s.get('cpu_percent', 0) for s in resource_samples) / len(resource_samples),
                'memory_rss_mb': sum(s.get('memory_rss_mb', 0) for s in resource_samples) / len(resource_samples),
                'memory_percent': sum(s.get('memory_percent', 0) for s in resource_samples) / len(resource_samples)
            }
        
        # Generate recommendation based on results
        if not result["success"] or not result["success_pattern_found"]:
            result["recommendation"] = "Investigate issues with this feature."
        elif test_case.get('feature') == 'dynamic_parameters' and "Parameter adjustment helper is ENABLED" not in all_output:
            result["recommendation"] = "Dynamic parameter adjustment may not be correctly implemented or logging is insufficient."
        
        logging.info(f"Test completed in {result['duration']:.2f} seconds, exit code: {result['exit_code']}")
        logging.info(f"Success pattern found: {result['success_pattern_found']}")
        
        return result
    
    except Exception as e:
        logging.error(f"Error running test: {e}")
        result["exit_code"] = -2  # Custom code for error
        result["duration"] = time.time() - start_time
        result["success"] = False
        result["errors"].append(str(e))
        return result

def generate_report(test_results):
    """Generate a markdown report from test results."""
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total_tests = len(test_results)
    successful_tests = sum(1 for r in test_results if r['success'] and r['success_pattern_found'])
    failed_tests = total_tests - successful_tests
    
    # Map features to their test results
    feature_status = {}
    feature_notes = {}
    
    for result in test_results:
        feature = result.get('feature', 'unknown')
        status = "✅ Pass" if result['success'] and result['success_pattern_found'] else "❌ Fail"
        
        feature_status[feature] = status
        
        if status == "✅ Pass":
            if feature == 'dynamic_parameters':
                if "Parameter adjustment helper is ENABLED" in result['stdout']:
                    feature_notes[feature] = "Dynamic parameter adjustment is correctly enabled and logged"
                else:
                    feature_notes[feature] = "Test passed but explicit parameter adjustment logs not found"
            else:
                feature_notes[feature] = "All core functionality working as expected"
        else:
            if result['errors']:
                feature_notes[feature] = f"Issues detected: {result['errors'][0]}"
            else:
                feature_notes[feature] = "Test failed but no specific errors identified"
    
    # Generate the report using the template
    try:
        with open('test_report_template.md', 'r') as f:
            template = f.read()
    except FileNotFoundError:
        template = """# Poker AI Functional Tests Report

Generated: {{generation_date}}

## Summary

- Total Tests: {{total_tests}}
- Successful Tests: {{successful_tests}}
- Failed Tests: {{failed_tests}}

## Overall Assessment

{{overall_assessment}}

## Core Features Status

| Feature | Status | Notes |
|---------|--------|-------|
| Selfplay Mode | {{selfplay_status}} | {{selfplay_notes}} |
| Evaluation Mode | {{eval_status}} | {{eval_notes}} |
| Training Mode | {{train_status}} | {{train_notes}} |
| Dynamic Parameter Adjustment | {{dynamic_params_status}} | {{dynamic_params_notes}} |
| Opponent Modeling | {{opponent_modeling_status}} | {{opponent_modeling_notes}} |

## Detailed Test Results

{{detailed_results}}

## Recommendations

{{recommendations}}"""
    
    # Generate overall assessment
    if successful_tests == total_tests:
        overall_assessment = "✅ All core modes (`train`, `eval`, `selfplay`) appear to be functional based on these minimal tests."
    elif successful_tests > 0:
        overall_assessment = f"⚠️ Some tests passed ({successful_tests}/{total_tests}), but there are issues that need to be addressed."
    else:
        overall_assessment = "❌ All tests failed. Significant issues detected that must be resolved."
    
    # Generate detailed results section
    detailed_results = ""
    for i, result in enumerate(test_results):
        detailed_results += f"### Test Case {i+1}: {result['name']}\n\n"
        detailed_results += f"- **Command**: `{result['command']}`\n"
        
        status = "Success" if result['exit_code'] == 0 else "Failure"
        if result['exit_code'] == -1:
            status = "Timeout"
        elif result['exit_code'] == -2:
            status = "Error"
            
        detailed_results += f"- **Exit Code**: {result['exit_code']} ({status})\n"
        detailed_results += f"- **Duration**: {result['duration']:.2f} seconds\n"
        detailed_results += f"- **Success Pattern Found**: {'Yes' if result['success_pattern_found'] else 'No'}\n\n"
        
        if result['resources']:
            detailed_results += f"- **Resource Usage**:\n"
            detailed_results += f"  - CPU: {result['resources']['cpu_percent']:.1f}%\n"
            detailed_results += f"  - Memory: {result['resources']['memory_rss_mb']:.1f} MB ({result['resources']['memory_percent']:.1f}%)\n\n"
        
        detailed_results += "#### Key Log Messages\n\n"
        detailed_results += "```\n"
        if result['log_content']:
            for line in result['log_content'][-20:]:  # Last 20 lines
                detailed_results += f"{line}\n"
        else:
            detailed_results += "No log entries found.\n"
        detailed_results += "```\n\n"
        
        if result['stderr']:
            detailed_results += "#### Standard Error\n\n"
            detailed_results += "```\n"
            detailed_results += result['stderr']
            detailed_results += "\n```\n\n"
        
        detailed_results += "---\n\n"
    
    # Generate recommendations
    recommendations = []
    
    # Add specific recommendations based on test results
    for result in test_results:
        if result['recommendation']:
            recommendations.append(f"- {result['name']}: {result['recommendation']}")
    
    # Add general recommendations if needed
    if not feature_status.get('selfplay', '').startswith('✅'):
        recommendations.append("- Fix selfplay mode functionality as it is fundamental to the system.")
    
    if feature_status.get('dynamic_parameters', '').startswith('❌'):
        recommendations.append("- Review the dynamic parameter adjustment implementation. Ensure parameter_adjuster.py is correctly imported and used.")
    
    # Final recommendation
    if not recommendations:
        recommendations = ["- All tests passed successfully. No specific recommendations at this time."]
    
    # Format the recommendations
    recommendations_text = "\n".join(recommendations)
    
    # Replace template placeholders
    report = template
    report = report.replace('{{generation_date}}', now)
    report = report.replace('{{total_tests}}', str(total_tests))
    report = report.replace('{{successful_tests}}', str(successful_tests))
    report = report.replace('{{failed_tests}}', str(failed_tests))
    report = report.replace('{{overall_assessment}}', overall_assessment)
    
    # Feature status replacements
    report = report.replace('{{selfplay_status}}', feature_status.get('selfplay', 'Not Tested'))
    report = report.replace('{{eval_status}}', feature_status.get('evaluation', 'Not Tested'))
    report = report.replace('{{train_status}}', feature_status.get('training', 'Not Tested'))
    report = report.replace('{{dynamic_params_status}}', feature_status.get('dynamic_parameters', 'Not Tested'))
    report = report.replace('{{opponent_modeling_status}}', feature_status.get('opponent_modeling', 'Not Tested'))
    
    # Feature notes replacements
    report = report.replace('{{selfplay_notes}}', feature_notes.get('selfplay', 'Not tested'))
    report = report.replace('{{eval_notes}}', feature_notes.get('evaluation', 'Not tested'))
    report = report.replace('{{train_notes}}', feature_notes.get('training', 'Not tested'))
    report = report.replace('{{dynamic_params_notes}}', feature_notes.get('dynamic_parameters', 'Not tested'))
    report = report.replace('{{opponent_modeling_notes}}', feature_notes.get('opponent_modeling', 'Not tested'))
    
    report = report.replace('{{detailed_results}}', detailed_results)
    report = report.replace('{{recommendations}}', recommendations_text)
    
    # Write report to file
    with open('test_report.md', 'w') as f:
        f.write(report)
    
    logging.info(f"Test report generated: test_report.md")
    return report

def main():
    """Run the test suite."""
    logging.info(f"Starting Poker AI Functional Test Suite at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = []
    
    for test_case in TEST_CASES:
        try:
            result = run_test(test_case)
            results.append(result)
        except Exception as e:
            logging.error(f"Error running test {test_case['name']}: {e}")
    
    # Generate report
    generate_report(results)
    
    # Print summary
    success_count = sum(1 for r in results if r['success'] and r['success_pattern_found'])
    logging.info(f"\nTests completed: {success_count}/{len(results)} successful")
    
    # Return success status for CI/CD
    return success_count == len(results)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)