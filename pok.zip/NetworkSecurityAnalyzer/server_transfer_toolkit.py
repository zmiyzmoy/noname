#!/usr/bin/env python
"""
One-Click Server Transfer Toolkit for Poker AI System

This toolkit simplifies the process of packing, transferring, and deploying
the Poker AI system to a new server with minimal manual intervention.

Usage:
  python server_transfer_toolkit.py pack   # Create a deployment package
  python server_transfer_toolkit.py config # Create configuration files for the new server
  python server_transfer_toolkit.py deploy # Run on the new server to deploy the system
  python server_transfer_toolkit.py all    # Run complete process
"""

import os
import sys
import json
import time
import shutil
import logging
import tarfile
import datetime
import subprocess
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Any, Union

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='transfer_toolkit.log',
    filemode='a'
)

# Add console handler
console = logging.StreamHandler()
console.setLevel(logging.INFO)
formatter = logging.Formatter('%(levelname)s: %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)

logger = logging.getLogger('server_transfer_toolkit')

# List of files/directories to exclude from the package
EXCLUDE_PATTERNS = [
    '.git',
    '__pycache__',
    '*.pyc',
    '*.pyo',
    '*.pyd',
    '.DS_Store',
    '.idea',
    '.vscode',
    'venv',
    'env',
    'node_modules',
    'logs/*.log',
    'transfer_toolkit.log',
    '*.tar.gz',
    'poker_ai_system_*.tar.gz',
    'transfer.sh',
    'deploy.sh',
    'uv.lock',
]

# Essential files/directories that must be included
ESSENTIAL_FILES = [
    'main.py',
    'models.py',
    'psro.py',
    'poker_rl.py',
    'state_processor.py',
    'environment.py',
    'adaptation_manager.py',
    'requirements.txt',
    'pyproject.toml',
    'README.md',
    'INSTRUCTIONS.md',
    'DEPLOYMENT_INSTRUCTIONS.md',
    'README_DEPLOYMENT.md',
    'README_SERVER_TRANSFER.md',
    'templates/',
    'static/',
    'blueprints/',
    'models/',
    'poker/',
]

def is_excluded(path: str) -> bool:
    """Check if a path should be excluded from the package."""
    for pattern in EXCLUDE_PATTERNS:
        if pattern.endswith('/'):
            if path.startswith(pattern):
                return True
        elif pattern.startswith('*'):
            if path.endswith(pattern[1:]):
                return True
        elif pattern in path:
            return True
    return False

def create_package() -> str:
    """Create a deployment package containing all necessary files."""
    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    package_filename = f"poker_ai_system_{timestamp}.tar.gz"
    
    logger.info("Creating deployment package...")
    
    try:
        with tarfile.open(package_filename, "w:gz") as tar:
            # Add essential files
            for file_path in ESSENTIAL_FILES:
                if os.path.exists(file_path):
                    if os.path.isdir(file_path):
                        for root, dirs, files in os.walk(file_path):
                            for file in files:
                                full_path = os.path.join(root, file)
                                if not is_excluded(full_path):
                                    logger.debug(f"Adding {full_path} to package")
                                    tar.add(full_path)
                    else:
                        logger.debug(f"Adding {file_path} to package")
                        tar.add(file_path)
                else:
                    logger.warning(f"Essential file/directory not found: {file_path}")
            
            # Add other important files (discovered by scanning the directory)
            for root, dirs, files in os.walk('.'):
                if root.startswith('./'):
                    root = root[2:]
                elif root == '.':
                    root = ''
                
                # Filter out excluded directories
                dirs[:] = [d for d in dirs if not is_excluded(os.path.join(root, d))]
                
                for file in files:
                    full_path = os.path.join(root, file) if root else file
                    if not is_excluded(full_path) and full_path not in ESSENTIAL_FILES:
                        if any(full_path.startswith(ef) for ef in ESSENTIAL_FILES if ef.endswith('/')):
                            continue  # Skip files in essential directories (already added)
                        logger.debug(f"Adding {full_path} to package")
                        tar.add(full_path)
        
        logger.info(f"Deployment package created: {package_filename}")
        return package_filename
    except Exception as e:
        logger.error(f"Error creating deployment package: {e}")
        return ""

def create_config() -> Dict[str, Any]:
    """Create configuration files for the new server."""
    logger.info("Starting configuration wizard...")
    
    config = {}
    
    # Database configuration
    print("\n===== Database Configuration =====")
    config['database'] = {}
    config['database']['name'] = input("Database name [poker_ai]: ") or "poker_ai"
    config['database']['user'] = input("Database user [postgres]: ") or "postgres"
    config['database']['password'] = input("Database password [postgres]: ") or "postgres"
    config['database']['host'] = input("Database host [localhost]: ") or "localhost"
    config['database']['port'] = input("Database port [5432]: ") or "5432"
    
    # Server configuration
    print("\n===== Server Configuration =====")
    config['server'] = {}
    config['server']['hostname'] = input("Target server hostname: ")
    config['server']['ssh_user'] = input("SSH username: ")
    config['server']['ssh_key'] = input("SSH private key path [~/.ssh/id_rsa]: ") or "~/.ssh/id_rsa"
    config['server']['deploy_path'] = input("Deployment path [/opt/poker_ai]: ") or "/opt/poker_ai"
    
    # Web server configuration
    print("\n===== Web Server Configuration =====")
    config['web'] = {}
    config['web']['port'] = input("Web server port [5010]: ") or "5010"
    config['web']['domain'] = input("Domain name (optional): ")
    
    # Deployment preferences
    print("\n===== Deployment Preferences =====")
    config['deployment'] = {}
    config['deployment']['use_systemd'] = input("Use systemd for service management? [Y/n]: ").lower() != 'n'
    config['deployment']['use_nginx'] = input("Use Nginx as a reverse proxy? [Y/n]: ").lower() != 'n'
    config['deployment']['create_venv'] = input("Create Python virtual environment? [Y/n]: ").lower() != 'n'
    
    # Save configuration to file
    with open('transfer_config.json', 'w') as f:
        json.dump(config, f, indent=2)
    
    logger.info("Configuration saved to transfer_config.json")
    
    # Create deployment script
    create_deployment_script(config)
    
    # Create transfer script
    package_filename = input("\nEnter the deployment package filename (created earlier): ")
    create_transfer_script(config, package_filename)
    
    return config

def create_deployment_script(config: Dict[str, Any]) -> None:
    """Create deployment script for the new server."""
    script_content = """#!/bin/bash
# Poker AI System Deployment Script
# This script is generated automatically by the Server Transfer Toolkit
# It should be run on the target server to set up the system

set -e
LOG_FILE="deploy.log"

function log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

log "Starting Poker AI deployment..."

# Create deployment directory
"""
    
    deploy_path = config['server']['deploy_path']
    script_content += f'log "Creating deployment directory at {deploy_path}"\n'
    script_content += f'mkdir -p {deploy_path}\n'
    script_content += f'cd {deploy_path}\n\n'
    
    # Extract deployment package
    script_content += 'log "Extracting deployment package..."\n'
    script_content += 'tar -xzf poker_ai_system_*.tar.gz\n\n'
    
    # Set up Python environment
    if config['deployment']['create_venv']:
        script_content += 'log "Creating Python virtual environment..."\n'
        script_content += 'python3 -m venv venv\n'
        script_content += 'source venv/bin/activate\n'
        script_content += 'pip install --upgrade pip\n'
        script_content += 'pip install -r requirements.txt\n\n'
    else:
        script_content += 'log "Installing Python dependencies..."\n'
        script_content += 'pip3 install -r requirements.txt\n\n'
    
    # Set up database
    db_config = config['database']
    script_content += 'log "Setting up database..."\n'
    script_content += f'export DATABASE_URL="postgresql://{db_config["user"]}:{db_config["password"]}@{db_config["host"]}:{db_config["port"]}/{db_config["name"]}"\n'
    script_content += 'sudo -u postgres psql -c "CREATE DATABASE ' + db_config['name'] + ' WITH OWNER ' + db_config['user'] + ';" || true\n\n'
    
    # Set up systemd service if requested
    if config['deployment']['use_systemd']:
        script_content += 'log "Setting up systemd service..."\n'
        script_content += 'cat > poker-ai.service << EOL\n'
        script_content += '[Unit]\n'
        script_content += 'Description=Poker AI System\n'
        script_content += 'After=network.target postgresql.service\n\n'
        script_content += '[Service]\n'
        script_content += f'WorkingDirectory={deploy_path}\n'
        
        if config['deployment']['create_venv']:
            script_content += f'ExecStart={deploy_path}/venv/bin/python {deploy_path}/main.py\n'
        else:
            script_content += f'ExecStart=python3 {deploy_path}/main.py\n'
            
        script_content += 'Restart=always\n'
        script_content += 'RestartSec=5\n'
        script_content += 'StandardOutput=syslog\n'
        script_content += 'StandardError=syslog\n'
        script_content += 'SyslogIdentifier=poker-ai\n'
        script_content += f'Environment="DATABASE_URL=postgresql://{db_config["user"]}:{db_config["password"]}@{db_config["host"]}:{db_config["port"]}/{db_config["name"]}"\n\n'
        script_content += '[Install]\n'
        script_content += 'WantedBy=multi-user.target\n'
        script_content += 'EOL\n\n'
        script_content += 'sudo mv poker-ai.service /etc/systemd/system/\n'
        script_content += 'sudo systemctl daemon-reload\n'
        script_content += 'sudo systemctl enable poker-ai\n'
        script_content += 'sudo systemctl start poker-ai\n\n'
    
    # Set up Nginx if requested
    if config['deployment']['use_nginx']:
        web_port = config['web']['port']
        domain = config['web']['domain'] or f"localhost"
        
        script_content += 'log "Setting up Nginx..."\n'
        script_content += 'sudo apt-get update\n'
        script_content += 'sudo apt-get install -y nginx\n'
        script_content += 'cat > poker-ai.nginx << EOL\n'
        script_content += 'server {\n'
        script_content += '    listen 80;\n'
        script_content += f'    server_name {domain};\n\n'
        script_content += '    location / {\n'
        script_content += f'        proxy_pass http://127.0.0.1:{web_port};\n'
        script_content += '        proxy_set_header Host $host;\n'
        script_content += '        proxy_set_header X-Real-IP $remote_addr;\n'
        script_content += '    }\n'
        script_content += '}\n'
        script_content += 'EOL\n\n'
        script_content += 'sudo mv poker-ai.nginx /etc/nginx/sites-available/poker-ai\n'
        script_content += 'sudo ln -sf /etc/nginx/sites-available/poker-ai /etc/nginx/sites-enabled/\n'
        script_content += 'sudo nginx -t && sudo systemctl restart nginx\n\n'
    
    # Final success message
    script_content += 'log "Poker AI System deployment complete!"\n'
    script_content += f'log "You can access the system at http://{domain}:{web_port}"\n'
    
    with open('deploy.sh', 'w') as f:
        f.write(script_content)
    
    os.chmod('deploy.sh', 0o755)
    logger.info("Deployment script created: deploy.sh")

def create_transfer_script(config: Dict[str, Any], package_filename: str) -> None:
    """Create script to transfer files to the new server."""
    script_content = """#!/bin/bash
# Poker AI System Transfer Script
# This script is generated automatically by the Server Transfer Toolkit
# It should be run on the source server to transfer files to the target server

set -e

echo "Starting Poker AI system transfer..."
"""
    
    server = config['server']
    hostname = server['hostname']
    ssh_user = server['ssh_user']
    ssh_key = server['ssh_key']
    deploy_path = server['deploy_path']
    
    # Transfer deployment package and script
    script_content += f'echo "Transferring files to {ssh_user}@{hostname}..."\n'
    script_content += f'scp -i {ssh_key} {package_filename} deploy.sh {ssh_user}@{hostname}:~\n\n'
    
    # Create deployment directory and move files
    script_content += 'echo "Setting up deployment directory..."\n'
    script_content += f'ssh -i {ssh_key} {ssh_user}@{hostname} "mkdir -p {deploy_path} && mv ~/{package_filename} ~/deploy.sh {deploy_path}/"\n\n'
    
    # Run deployment script
    script_content += 'echo "Running deployment script..."\n'
    script_content += f'ssh -i {ssh_key} {ssh_user}@{hostname} "cd {deploy_path} && ./deploy.sh"\n\n'
    
    # Final success message
    script_content += 'echo "Poker AI System transfer complete!"\n'
    script_content += f'echo "You can access the system at http://{hostname}:{config["web"]["port"]}"\n'
    
    with open('transfer.sh', 'w') as f:
        f.write(script_content)
    
    os.chmod('transfer.sh', 0o755)
    logger.info("Transfer script created: transfer.sh")

def deploy() -> None:
    """Deploy the system on the new server."""
    if not os.path.exists('deploy.sh'):
        logger.error("Deployment script not found. This function should be run on the target server.")
        return
    
    logger.info("Starting deployment process...")
    subprocess.run(['./deploy.sh'], check=True)

def create_installer() -> None:
    """Create a simple installer script for the target server."""
    script_content = """#!/bin/bash
# Poker AI System Installer
# This script downloads and installs the Poker AI system

set -e

echo "Poker AI System Installer"
echo "========================="
echo

# Check for required tools
command -v curl >/dev/null 2>&1 || { echo "Error: curl is required but not installed. Please install curl and try again."; exit 1; }
command -v tar >/dev/null 2>&1 || { echo "Error: tar is required but not installed. Please install tar and try again."; exit 1; }

# Create temporary directory
TEMP_DIR=$(mktemp -d)
cd $TEMP_DIR

echo "Downloading Poker AI system package..."
curl -L -o poker_ai_system.tar.gz "$PACKAGE_URL"

echo "Extracting package..."
mkdir -p poker_ai
tar -xzf poker_ai_system.tar.gz -C poker_ai

cd poker_ai

echo "Running setup script..."
./deploy.sh

echo "Installation complete!"
"""
    
    with open('install.sh', 'w') as f:
        f.write(script_content)
    
    os.chmod('install.sh', 0o755)
    logger.info("Installer script created: install.sh")

def run_complete_process() -> None:
    """Run the complete process: pack, configure, and prepare for transfer."""
    package_filename = create_package()
    if not package_filename:
        logger.error("Failed to create deployment package. Aborting.")
        return
    
    config = create_config()
    create_transfer_script(config, package_filename)
    
    logger.info("\nComplete process finished successfully!")
    logger.info(f"1. Package created: {package_filename}")
    logger.info("2. Configuration complete: transfer_config.json")
    logger.info("3. Deployment script created: deploy.sh")
    logger.info("4. Transfer script created: transfer.sh")
    logger.info("\nNext steps:")
    logger.info("1. Run ./transfer.sh to transfer and deploy the system to the target server")
    logger.info("2. Follow the instructions in the server output to complete the setup")

def main() -> None:
    """Main function to parse arguments and execute commands."""
    parser = argparse.ArgumentParser(description="Server Transfer Toolkit for Poker AI System")
    parser.add_argument('command', choices=['pack', 'config', 'deploy', 'all'],
                       help='Command to execute: pack, config, deploy, or all')
    args = parser.parse_args()
    
    if args.command == 'pack':
        create_package()
    elif args.command == 'config':
        create_config()
    elif args.command == 'deploy':
        deploy()
    elif args.command == 'all':
        run_complete_process()

if __name__ == "__main__":
    main()