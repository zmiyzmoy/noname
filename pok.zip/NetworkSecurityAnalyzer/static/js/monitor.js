
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh data every 10 seconds
    setInterval(function() {
        fetch('/api/training_data')
            .then(response => response.json())
            .then(data => {
                document.getElementById('status').textContent = data.status;
                document.getElementById('last-update').textContent = data.last_update;
                document.getElementById('episodes').textContent = data.episodes_completed;
                
                // Update action list
                const actionList = document.querySelector('.action-list');
                actionList.innerHTML = '';
                
                if (data.recent_actions && data.recent_actions.length > 0) {
                    data.recent_actions.forEach(action => {
                        const actionItem = document.createElement('div');
                        actionItem.className = 'action-item';
                        actionItem.textContent = action;
                        actionList.appendChild(actionItem);
                    });
                } else {
                    const actionItem = document.createElement('div');
                    actionItem.className = 'action-item';
                    actionItem.textContent = 'No recent actions.';
                    actionList.appendChild(actionItem);
                }
            })
            .catch(error => console.error('Error:', error));
    }, 10000);
});
    