# Poker AI with PSRO

A reinforcement learning system for training poker AI using Policy Space Response Oracles (PSRO) with PyTorch and OpenSpiel. This AI model can learn No-Limit Texas Hold'em strategies through self-play.

## Documentation Overview

This project now has consolidated documentation for easier navigation. Please refer to these guides:

- [Deployment Guide](DEPLOYMENT_GUIDE.md) - Complete instructions for installing and setting up the system
- [Transfer Guide](TRANSFER_GUIDE.md) - Instructions for downloading and transferring the system between servers
- [Command Reference](COMMAND_REFERENCE.md) - Comprehensive list of commands for all system operations
- [System Guide](SYSTEM_GUIDE.md) - Details of system architecture, core files, and functions
- [Testing Guide](TESTING_GUIDE.md) - How to test the system and interpret results
- [Documentation Guide](DOCUMENTATION_GUIDE.md) - Overview of all documentation in this project

## Quick Start

### Option 1: Web-Based Onboarding Wizard (Recommended)

For new users, the easiest way to get started is with the onboarding wizard:

```bash
python run_onboarding_wizard.py --web --port 5060
```

Then open your browser to http://localhost:5060 and follow the guided setup process.

### Option 2: Automatic Deployment Script

```bash
# Make the script executable
chmod +x deploy_poker_ai.sh

# Install dependencies and set up the system
sudo ./deploy_poker_ai.sh install

# Start the system
sudo ./deploy_poker_ai.sh start
```

### Option 3: Manual Setup

1. Install required Python packages:
   ```bash
   pip install -r requirements.txt
   ```

2. Set up the database:
   ```bash
   export DATABASE_URL="postgresql://username:password@localhost/poker_ai"
   ```

3. Create an admin user:
   ```bash
   python create_new_admin.py
   ```

4. Start the main Flask application:
   ```bash
   python main.py
   ```

## Web Interfaces

Once installed, you can access these web interfaces:

- **Main Dashboard**: http://localhost:5010/ - Consolidated interface with access to all features
- **Training Dashboard**: http://localhost:5003/ - Web-based training menu
- **Monitoring Dashboard**: http://localhost:5000/ - Real-time training monitoring
- **Admin Dashboard**: http://localhost:5002/ - Advanced administration interface

## Features

- **PSRO Algorithm Implementation**: Policy Space Response Oracles for discovering effective poker strategies
- **Neural Network Architecture**: Deep neural networks for strategy and regret modeling
- **Cloud Optimized**: Scripts for training on Google Cloud A100 GPUs with spot instance support
- **Checkpointing**: Built-in checkpointing for graceful recovery from spot instance preemption
- **JSON Interface**: Interface for using the trained model via JSON input/output
- **Enhanced Opponent Modeling**: Track opponent tendencies like VPIP, PFR, and street-specific aggression
- **Advanced Analytics**: 
  - Comprehensive metrics tracking and visualization tools
  - Animated learning curves with milestone markers
  - Position-based win rate analysis
  - Learning plateau detection
- **CFR+ Integration**:
  - Hybrid PSRO-CFR learning algorithm combining deep learning with tabular methods
  - Advantage-weighted regret updates for faster convergence
  - Immediate counterfactual regret calculation for more stable learning
  - Neural network mapping to abstract information states
  - Adaptive strategy refinement through subgame solving
- **Web Monitoring Interface**:
  - Real-time training progress visualization in your browser
  - Live metrics tracking with charts and graphs
  - No complex port forwarding required
  - Automatic template generation for easy customization
- **Admin Dashboard**:
  - User authentication and multi-user support
  - Hardware monitoring and resource allocation
  - Training configuration management
  - Session history and metrics storage
  - Hardware configuration management
  - Training parameter configuration
  - Training session tracking and monitoring
  - PostgreSQL database integration for persistent storage
  - Real-time visualization with dynamic charts

## Requirements

- Python 3.7+
- PyTorch 1.8+
- OpenSpiel
- Ray (for distributed computing)
- NumPy, SciPy, Matplotlib, etc.
- Flask and Flask extensions (Flask-Login, Flask-SQLAlchemy, Flask-Migrate)
- PostgreSQL (for admin dashboard and configuration storage)
- Dash and Plotly (for interactive visualizations)
- Gunicorn (for production web server deployment)

## Getting Started

### Installation

1. Install dependencies:

```bash
pip install torch numpy ray open-spiel joblib scikit-learn matplotlib tqdm
pip install flask flask-login flask-sqlalchemy flask-migrate psycopg2-binary gunicorn dash dash-bootstrap-components plotly
```

2. Clone the repository:

```bash
git clone <repository-url>
cd poker-ai
```

### Basic Usage

1. Initialize the model:

```bash
python init_model.py
```

2. Run self-play training:

```bash
python poker_rl.py --mode selfplay --num_episodes 5 --verbose
```

3. Run a full training session:

```bash
python cloud_trainer.py --mode train --num_episodes 1000 --verbose
```

### Advanced Usage

#### Training on Google Cloud A100 GPUs

1. Update configuration in `create_gcp_spot_instance.sh` with your GCP project, zone, and bucket details.

2. Run the script to create a spot VM with A100 GPU:

```bash
chmod +x create_gcp_spot_instance.sh
./create_gcp_spot_instance.sh
```

3. The VM will automatically start training using the startup script.

#### Inference with JSON Input

1. Create a JSON file with poker hand scenarios (see `sample_hand.json` for format).

2. Run inference:

```bash
python poker_json_inference.py --input sample_hand.json --output results.json
```

3. View the recommendations in `results.json`.

#### Poker Hand JSON Analyzer

The system includes a powerful poker hand analyzer that provides detailed recommendations for specific hand scenarios. This tool uses the trained model to evaluate poker situations and advise on optimal play.

1. Create a JSON file with your hand scenario:

```json
{
  "version": "1.0",
  "scenarios": [
    {
      "hand_id": "HAND_001",
      "description": "Example hand for decision-making at the flop",
      "game_info": {
        "game_type": "NL_HOLDEM",
        "table_type": "6MAX",
        "blinds": {
          "small_blind": 1.0,
          "big_blind": 2.0
        },
        "current_round": "FLOP",
        "num_players": 6
      },
      "hero_info": {
        "position": "BTN",
        "hole_cards": ["Ah", "Kh"],
        "stack_size": 95.5
      },
      "board_cards": {
        "flop": ["Jh", "Ts", "2c"],
        "turn": null,
        "river": null
      },
      "pot_info": {
        "current_pot": 12.5,
        "current_bet": 4.5,
        "to_call": 4.5,
        "min_raise": 9.0
      }
    }
  ]
}
```

2. Analyze the hand:

```bash
python poker_json_analyzer.py --input your_hand.json --output analysis.json --verbose
```

3. The analysis output includes:
   - Recommended action with confidence score
   - Expected value (EV) of each action
   - Alternative actions with their EVs
   - Descriptive explanation of the recommendation

4. For a sample demonstration:

```bash
python sample_usage.py
```

This script creates a sample hand, analyzes it, and displays the results.

#### Analyzing Training Results

```bash
python analyze_training.py --metrics_file ./poker/logs/metrics.json --output_dir ./analysis
```

This will generate charts and an HTML report of the training progress.

#### Web Monitoring Interface

The system includes a browser-based monitoring interface that allows you to track training progress in real-time without complex port forwarding or firewalls.

1. Start the web monitoring server:

```bash
python monitoring_web.py
```

2. Open your browser and navigate to http://localhost:5000 to see the live training dashboard.

3. For simulating training data (demonstration purposes):

```bash
python web_monitoring_demo.py --num_iterations 50 --update_interval 2
```

4. You can also automatically track real training progress by using the built-in integration in cloud_trainer.py:

```bash
python cloud_trainer.py --mode train --num_episodes 1000 --verbose
```

The monitoring interface shows:
- Current training status
- Episodes completed
- Recent actions and decisions
- Live charts of rewards and losses
- Automatically updates every 30 seconds

#### Admin Dashboard

The system includes a comprehensive admin dashboard for managing training configurations, hardware resources, and monitoring training sessions with a user-friendly web interface.

1. Start the admin dashboard:

```bash
python admin_dashboard.py
```

2. Open your browser and navigate to http://localhost:5000 to access the dashboard.

3. Create an account and log in (the first user will automatically become an admin).

4. Set up hardware configurations:
   - Define CPU and GPU resources
   - Specify memory limits
   - Enable/disable CUDA acceleration

5. Create training configurations:
   - Choose game type (6-max, heads-up, etc.)
   - Set batch size, learning rate, and number of episodes
   - Configure CFR integration parameters

6. Start and monitor training sessions:
   - Combine hardware and training configurations
   - Monitor progress with real-time charts
   - View logs and performance metrics
   - Stop or restart sessions as needed

The admin dashboard requires PostgreSQL for storing configurations and training data:

```bash
# Set up PostgreSQL environment variables
export DATABASE_URL=postgresql://user:password@localhost:5432/poker_ai

# Start the admin dashboard
python admin_dashboard.py
```

Key features of the admin dashboard:
- Multi-user authentication and authorization
- Real-time training monitoring with interactive charts
- Comprehensive hardware and training configuration management
- Training session scheduling and control
- Detailed performance metrics and analysis tools
- Log viewing and filtering capabilities

#### CFR+ Integration

The system implements a hybrid PSRO-CFR algorithm that combines the strengths of both approaches:

- **PSRO (Policy Space Response Oracles)** excels at large-scale strategy discovery and exploring diverse policy spaces, but can be sample-inefficient.
- **CFR+ (Counterfactual Regret Minimization Plus)** converges quickly to Nash equilibrium in smaller games but struggles with complex state spaces.

Our hybrid approach:
1. Uses PSRO with neural networks to learn global strategies across the full game
2. Periodically switches to CFR+ to refine strategies in important subgames
3. Maps between neural network representations and tabular CFR states
4. Integrates improvements from both algorithms throughout training

##### Advanced CFR+ Features

- **Advantage-Weighted Updates**: Weights the regret updates based on the advantage function to accelerate convergence
- **Immediate Counterfactual Regret**: Updates regrets immediately after each state rather than waiting for terminal states
- **Dynamic Alternation**: Alternates between PSRO and CFR based on configurable frequency
- **State Abstraction**: Uses K-means clustering to map complex game states to a reasonable number of information states for CFR

##### Usage Example

```bash
python poker_rl.py --mode train --num_episodes 10 --num_iterations 5 --use_cfr --cfr_alternation_freq 2 --cfr_iters_per_step 5 --use_advantage_weighted --use_immediate_cfr --verbose
```

Command line options for CFR integration:
- `--use_cfr`: Enable the hybrid PSRO-CFR solver (default: True)
- `--cfr_alternation_freq`: How often to switch to CFR (every N iterations)
- `--cfr_iters_per_step`: Number of CFR iterations to run in each CFR step
- `--use_advantage_weighted`: Use advantage-weighted CFR for faster convergence
- `--use_immediate_cfr`: Use immediate counterfactual regret updates
- `--advantage_weight`: Weight for advantage term in CFR (default: 0.1)

You can also run a simplified demonstration of the CFR integration with Kuhn poker:

```bash
python cfr_demo.py --game kuhn_poker --iterations 50 --use_advantage_weighted --use_immediate_cfr
```

## Project Structure

- `poker_rl.py`: Main script for running training and evaluation
- `models.py`: Neural network model definitions
- `environment.py`: Poker environment wrapper for OpenSpiel
- `psro.py`: Implementation of the PSRO algorithm with hybrid PSRO-CFR integration
- `cfr_integration.py`: Counterfactual Regret Minimization Plus (CFR+) implementation
- `cfr_demo.py`: Demonstration of the CFR+ integration and comparison to PSRO
- `cloud_trainer.py`: Optimized training script for cloud GPUs
- `cloud_spot_runner.py`: Script for managing training on preemptible instances
- `poker_json_inference.py`: Script for performing inference with JSON input/output
- `poker_json_analyzer.py`: Advanced poker hand analyzer with detailed recommendations
- `sample_usage.py`: Example script demonstrating how to use the JSON analyzer
- `dynamic_sizing.py`: Dynamic bet sizing framework based on game state and opponent profiles
- `poker_action_selector.py`: Integration of AI decisions with dynamic bet sizing
- `analyze_training.py`: Script for analyzing and visualizing training results
- `state_processor.py`: Processes game states with CFR state abstraction mappings
- `monitoring_web.py`: Web-based monitoring interface for real-time training visualization
- `monitoring_server.py`: Server component for the monitoring interface
- `web_monitoring_demo.py`: Demonstration script for the web monitoring interface
- `admin_dashboard.py`: Admin dashboard with user authentication and training management
- `models/database.py`: Database models for the admin dashboard
- `templates/`: HTML templates for the admin dashboard and monitoring interface
  - `base.html`: Base template with common layout and styling
  - `dashboard.html`: Main dashboard template
  - `sessions/`: Templates for training session management
  - `hardware/`: Templates for hardware configuration management
  - `training/`: Templates for training configuration management
  - `monitor/`: Templates for monitoring interface
  - `settings/`: Templates for system settings

## Training for 100K+ Hands

For training on a large number of hands (100K+), use the cloud trainer script:

```bash
python cloud_trainer.py --mode train --num_episodes 100000 --checkpoint_dir ./poker/checkpoints --save_interval 5
```

This will save checkpoints every 5 iterations, and can be resumed if interrupted.

## License

[MIT License](LICENSE)

## Acknowledgments

- OpenSpiel library by DeepMind for poker game implementation
- Policy Space Response Oracles (PSRO) algorithm by Lanctot et al.
- Counterfactual Regret Minimization Plus (CFR+) algorithm by Tammelin et al.
- Advantage-Weighted Regression techniques for reinforcement learning