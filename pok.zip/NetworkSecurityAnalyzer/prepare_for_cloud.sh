#!/bin/bash
# Script to prepare the Poker AI system for deployment to Google Cloud
# This version excludes large files to reduce download size

echo "Preparing Poker AI system for deployment to Google Cloud..."

# Create a timestamp for the archive
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
ARCHIVE_NAME="poker_ai_system_slim_${TIMESTAMP}.tar.gz"

# Clean up existing large archives
echo "Cleaning up existing archives..."
find . -maxdepth 1 -name "poker_ai_system_*.tar.gz" -delete
find ./export -name "*.tar.gz" -delete

# Keep only the most recent model files
echo "Cleaning up model files (keeping only final and best)..."
mkdir -p ./poker/models/archive
find ./poker/models -name "psro_model.pt.iteration_*" -exec mv {} ./poker/models/archive/ \;
echo "Moved $(ls -la ./poker/models/archive | wc -l) model files to archive directory"

# Exclude unnecessary files
echo "Creating exclusion list..."
cat > .cloudignore <<EOL
# System and cache directories
.git
.replit
.cache
.pythonlibs
.local
.upm
.config
.cloudignore

# Large archives and compressed files
*.tar.gz
*.zip
*.rar

# Python cache files
__pycache__
*.pyc
*.pyo
*.pyd
.ipynb_checkpoints
.pytest_cache

# Logs and temporary files
*.log
*/logs/*.log
runs/*/events.*

# Archived model files
*/models/archive
EOL

# Create the archive
echo "Creating slim archive $ARCHIVE_NAME..."
tar --exclude-from=.cloudignore -czf $ARCHIVE_NAME .

# Calculate SHA256 checksum
echo "Calculating checksum..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    CHECKSUM=$(shasum -a 256 $ARCHIVE_NAME | awk '{print $1}')
else
    # Linux
    CHECKSUM=$(sha256sum $ARCHIVE_NAME | awk '{print $1}')
fi

# Create a verification file
echo "Creating verification file..."
cat > ${ARCHIVE_NAME}.checksum <<EOL
Filename: $ARCHIVE_NAME
Size: $(du -h $ARCHIVE_NAME | awk '{print $1}')
Checksum (SHA256): $CHECKSUM
Created: $(date)
EOL

# Restore model files
echo "Restoring model files..."
mv ./poker/models/archive/* ./poker/models/ 2>/dev/null || true
rmdir ./poker/models/archive

echo ""
echo "✅ Done!"
echo "Created $ARCHIVE_NAME ($(du -h $ARCHIVE_NAME | awk '{print $1}'))"
echo "   This slim archive excludes cache, old archives, and historical model files"
echo "   The original files in your project remain unchanged"
echo ""
echo "Verify with: cat ${ARCHIVE_NAME}.checksum"
echo ""
echo "To deploy using Docker, follow instructions in CLOUD_DEPLOYMENT.md"
echo "To deploy using Server Transfer Tool, run:"
echo "  python server_transfer_toolkit.py --target-server YOUR_SERVER_IP --target-user YOUR_USERNAME"