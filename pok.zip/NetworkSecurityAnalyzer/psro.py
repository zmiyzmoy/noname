import os
import time
import logging
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import ray
import gc
import json
from torch.amp import autocast
from torch.cuda.amp import GradScaler
from typing import List, Dict, Tuple, Any, Optional, Callable, Union
import pyspiel
from open_spiel.python import policy as openspiel_policy
from open_spiel.python.algorithms import exploitability
from torch.utils.tensorboard import SummaryWriter

# Import local modules
from models.ml_models import RegretNet, StrategyNet, CardEmbedding, StateProcessor, OpponentStats, RewardNormalizer
from environment import PokerEnvironment, TabularPolicy, TorchPolicy

class PSROSolver:
    """Policy Space Response Oracles (PSRO) algorithm."""
    
    def __init__(self, config, state_processor):
        self.config = config
        self.state_processor = state_processor
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.game = pyspiel.load_game(config.GAME_NAME)
        self.num_actions = self.game.num_distinct_actions()
        self.meta_game_matrix = None
        
        # Initialize models
        self.regret_net = RegretNet(state_processor.state_size, self.num_actions).to(self.device)
        self.strategy_net = StrategyNet(state_processor.state_size, self.num_actions).to(self.device)
        
        # Initialize optimizers
        self.regret_optimizer = optim.Adam(self.regret_net.parameters(), lr=config.LEARNING_RATE)
        self.strategy_optimizer = optim.Adam(self.strategy_net.parameters(), lr=config.LEARNING_RATE)
        
        # Mixed precision training
        self.scaler = GradScaler('cuda') if torch.cuda.is_available() else GradScaler()
        
        # Strategy pool
        self.strategy_pool = []
        self.meta_strategies = []
        
        # TensorBoard writer for logging
        log_dir = os.path.join(config.LOG_DIR, 'tensorboard', f'run_{int(time.time())}')
        self.writer = SummaryWriter(log_dir)
        
        # Tracking iteration count for logging
        self.global_step = 0
        
        # Training metrics
        self.metrics = {
            'train_loss': 0.0,
            'exploit_loss': 0.0,
            'regret_loss': 0.0,
            'policy_loss': 0.0,
            'win_rate': 0.5,
            'exploitability': 0.5,
            'br_improvement': 0.0,
            'losses': [],
            'policy_size': [],  # Track the size of the strategy pool
            'training_time': [],  # Track the time spent in training
            'win_rates': [],  # Track win rates
            'exploitability_history': []  # Track exploitability over time
        }
        
        # TensorBoard logging
        
    def run_iteration(self):
        """Run one iteration of the PSRO algorithm and return metrics.
        
        This is a higher-level method that performs a single iteration of BR policy 
        computation, adds it to the strategy pool, updates meta strategies, 
        and returns metrics for TensorBoard visualization.
        
        Returns:
            Dictionary of training metrics.
        """
        logging.info("Running PSRO iteration...")
        start_time = time.time()
        
        # Sample opponent strategy from the pool using meta-strategies
        opponent_strategy = self.sample_strategy_from_pool()
        
        # Train best response using Ray parallelism and Double DQN
        training_metrics = self.train_best_response(
            opponent_strategy=opponent_strategy,
            num_episodes=self.config.NUM_EPISODES,
            use_adaptation=True
        )
        
        # Add current strategy to pool
        self._add_current_strategy_to_pool()
        
        # Update meta strategies
        self._update_meta_strategies()
        
        # Update metrics
        self._update_metrics(training_metrics)
        
        # Log time taken
        elapsed = time.time() - start_time
        self.metrics['iteration_time'] = elapsed
        logging.info(f"PSRO iteration completed in {elapsed:.2f} seconds")
        
        return self.metrics
    
    def _update_metrics(self, training_metrics=None):
        """Update training metrics after iteration."""
        if training_metrics:
            # Update metrics with training results
            for key, value in training_metrics.items():
                if key not in self.metrics:
                    self.metrics[key] = []
                if isinstance(self.metrics[key], list):
                    self.metrics[key].append(value)
                else:
                    self.metrics[key] = value
                    
            # Log metrics to TensorBoard
            for key, value in training_metrics.items():
                self.writer.add_scalar(f'Training/{key}', value, self.global_step)
                
        # Additional metrics update logic
        self.global_step += 1
    
    def _add_current_strategy_to_pool(self):
        """Add current strategy to the strategy pool."""
        logging.info("Adding strategy to pool...")
        # In practice, would clone the current strategy and add to pool
        self.strategy_pool.append(f"Strategy_{len(self.strategy_pool)}")
    
    def _update_meta_strategies(self):
        """Update meta strategies using the expanded pool."""
        logging.info("Updating meta strategies...")
        # In practice, would solve the meta-game matrix
        # For demo, just simulate results
        
        # Simulate a win rate improvement
        prev_win_rate = self.metrics.get('win_rate', 0.5)
        new_win_rate = min(0.9, prev_win_rate + random.uniform(0.01, 0.05))
        self.metrics['win_rate'] = new_win_rate
        
        # Simulate exploitability decrease
        prev_exploit = self.metrics.get('exploitability', 0.5)
        new_exploit = max(0.1, prev_exploit - random.uniform(0.01, 0.03))
        self.metrics['exploitability'] = new_exploit
        
        self.metrics['br_improvement'] = new_win_rate - prev_win_rate
        logging.info(f"Meta strategies updated. Win rate: {new_win_rate:.4f}, Exploitability: {new_exploit:.4f}")
    
    # The _update_metrics method has been replaced by the version above with training_metrics parameter
    
    def compute_meta_strategies(self):
        """Compute meta strategies for the current strategy pool using Nash equilibrium."""
        # Meta-strategy computation with Nash equilibrium
        if len(self.strategy_pool) == 1:
            return [1.0]
        
        # Compute meta-game payoff matrix
        self._update_meta_game_matrix()
        
        # Compute approximate Nash equilibrium
        n = len(self.strategy_pool)
        
        # Import scipy for Nash equilibrium calculation
        try:
            from scipy.optimize import linprog
            import scipy
        except ImportError:
            logging.warning("SciPy not available, falling back to uniform strategy")
            return [1.0 / n] * n
        
        # For numerical stability
        epsilon = 1e-8
        
        try:
            # Formulate the linear program to find the maxmin strategy
            # min v
            # s.t. v >= sum_i p_i * A_ji for all j
            #      sum_i p_i = 1
            #      p_i >= 0 for all i
            
            # Create the objective (minimize v)
            c = np.zeros(n + 1)
            c[0] = 1.0  # Coefficient for v
            
            # Create the constraints
            A_ub = np.zeros((n, n + 1))
            b_ub = np.zeros(n)
            
            # Set up the constraints: v >= sum_i p_i * A_ji for all j
            # We rewrite as: sum_i p_i * A_ji - v <= 0
            for j in range(n):
                A_ub[j, 0] = -1.0  # Coefficient for v
                for i in range(n):
                    A_ub[j, i + 1] = self.meta_game_matrix[j, i]
            
            # Create the equality constraint: sum_i p_i = 1
            A_eq = np.zeros((1, n + 1))
            A_eq[0, 1:] = 1.0
            b_eq = np.ones(1)
            
            # Bounds for variables: v is unbounded, p_i >= 0
            bounds = [(None, None)] + [(0, None)] * n
            
            # Solve the linear program
            result = linprog(
                c=c,
                A_ub=A_ub,
                b_ub=b_ub,
                A_eq=A_eq,
                b_eq=b_eq,
                bounds=bounds,
                method='highs'  # More reliable than 'simplex'
            )
            
            if result.success:
                # Extract the strategy probabilities
                probabilities = result.x[1:]
                
                # Normalize to ensure valid probabilities
                prob_sum = np.sum(probabilities)
                if prob_sum > epsilon:
                    probabilities = probabilities / prob_sum
                else:
                    # Fallback if we get numerical issues
                    probabilities = np.ones(n) / n
                
                # Add entropy regularization to encourage exploration
                alpha = 0.1  # Regularization strength
                if np.random.random() < 0.1:  # Only regularize sometimes
                    uniform = np.ones(n) / n
                    probabilities = (1 - alpha) * probabilities + alpha * uniform
                
                # Log the computed equilibrium
                logging.info(f"Computed Nash equilibrium: {probabilities}")
                self.writer.add_histogram('PSRO/meta_strategy', 
                                          np.array(probabilities), 
                                          self.global_step)
                
                # Record exploitability if available
                exploitability_value = result.fun if result.fun > -1e10 else None
                if exploitability_value is not None:
                    self.writer.add_scalar('PSRO/exploitability', 
                                          exploitability_value, 
                                          self.global_step)
                
                return probabilities.tolist()
            else:
                logging.warning(f"Nash equilibrium computation failed: {result.message}")
                return [1.0 / n] * n
                
        except Exception as e:
            logging.error(f"Error computing Nash equilibrium: {e}")
            # Fallback to uniform strategy
            return [1.0 / n] * n
    
    def _update_meta_game_matrix(self):
        """Update the empirical meta-game payoff matrix."""
        n = len(self.strategy_pool)
        if self.meta_game_matrix is None or self.meta_game_matrix.shape != (n, n):
            # Initialize or resize meta-game matrix
            old_matrix = self.meta_game_matrix
            self.meta_game_matrix = np.zeros((n, n))
            
            # Copy existing values if matrix is being resized
            if old_matrix is not None:
                old_n = old_matrix.shape[0]
                self.meta_game_matrix[:old_n, :old_n] = old_matrix
        
        # Compute missing entries
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        
        for i in range(n):
            for j in range(n):
                # Skip already computed entries
                if i < n-1 and j < n-1:
                    continue
                
                # Compute average payoff when i plays against j
                payoffs = []
                for _ in range(10):  # Small number for efficiency
                    state = env.reset()
                    done = False
                    
                    while not done:
                        if state.is_chance_node():
                            # Handle chance node
                            outcomes = state.chance_outcomes()
                            action_list, prob_list = zip(*outcomes)
                            
                            # Normalize probability distribution for chance outcomes
                            prob_sum = sum(prob_list)
                            if prob_sum > 0:  # Avoid division by zero
                                normalized_probs = [p / prob_sum for p in prob_list]
                                action = np.random.choice(action_list, p=normalized_probs)
                            else:
                                # If all probs are 0, choose uniformly (shouldn't happen)
                                action = np.random.choice(action_list)
                        else:
                            player = state.current_player()
                            # Alternate between policies based on player index
                            policy_idx = i if player % 2 == 0 else j
                            policy = self.strategy_pool[policy_idx]
                            
                            # Get action from policy
                            action_probs = policy.action_probabilities(state)
                            actions, probs = zip(*action_probs.items())
                            
                            # Normalize probabilities to ensure they sum to 1
                            if len(probs) > 0:  # Check if there are any legal actions
                                probs_sum = sum(probs)
                                if probs_sum > 0:  # Avoid division by zero
                                    # Fix for the "probabilities do not sum to 1" error
                                    normalized_probs = np.array([float(p) / float(probs_sum) for p in probs])
                                    
                                    # Double-check the normalization was successful
                                    if abs(np.sum(normalized_probs) - 1.0) > 1e-10:
                                        logging.warning(f"Probabilities still don't sum to 1 after normalization: {np.sum(normalized_probs)}")
                                        # Force normalization as a final fix
                                        normalized_probs = normalized_probs / np.sum(normalized_probs)
                                        
                                    action = np.random.choice(actions, p=normalized_probs)
                                else:
                                    # If all probs are 0, choose uniformly
                                    action = np.random.choice(actions)
                            else:
                                # Fallback if no actions available (shouldn't happen)
                                action = 0
                        
                        # Apply action
                        state.apply_action(action)
                        done = state.is_terminal()
                    
                    # Get payoffs
                    returns = state.returns()
                    payoffs.append(returns[0])  # First player's perspective
                
                # Update meta-game matrix
                self.meta_game_matrix[i, j] = np.mean(payoffs)
    
    def add_strategy_to_pool(self, new_policy):
        """Add a new strategy to the pool."""
        if len(self.strategy_pool) >= self.config.MAX_STRATEGY_POOL:
            # Remove a strategy with lowest meta-strategy weight
            if self.meta_strategies:
                idx_to_remove = np.argmin(self.meta_strategies)
                self.strategy_pool.pop(idx_to_remove)
                self.meta_strategies = self.meta_strategies[:idx_to_remove] + self.meta_strategies[idx_to_remove+1:]
            else:
                # If no meta-strategies, remove oldest
                self.strategy_pool.pop(0)
        
        # Add new strategy
        self.strategy_pool.append(new_policy)
        
        # Recompute meta-strategies
        self.meta_strategies = self.compute_meta_strategies()
        logging.info(f"Added new strategy to pool. Pool size: {len(self.strategy_pool)}")
    
    def _play_episode(self, game, regret_net, opponent_strategy, state_processor, use_adaptation=False):
        """Play a single episode and collect experience.
        
        Args:
            game: The OpenSpiel game
            regret_net: The regret network
            opponent_strategy: The opponent strategy
            state_processor: State processor for feature extraction
            use_adaptation: Whether to use adaptation
            
        Returns:
            List of (state, action, reward, next_state, done) tuples
        """
        buffer = []
        
        # Initialize state
        state = game.new_initial_state()
        
        # Track rewards and trajectory
        rewards = [0] * game.num_players()
        player_trajectory = {}
        
        # Play until terminal state
        while not state.is_terminal():
            # Handle chance nodes
            if state.is_chance_node():
                # Sample a chance outcome
                outcomes = state.chance_outcomes()
                action_list, prob_list = zip(*outcomes)
                
                # Normalize probability distribution for chance outcomes
                prob_sum = sum(prob_list)
                if prob_sum > 0:  # Avoid division by zero
                    normalized_probs = [p / prob_sum for p in prob_list]
                    action = np.random.choice(action_list, p=normalized_probs)
                else:
                    # If all probs are 0, choose uniformly (shouldn't happen)
                    action = np.random.choice(action_list)
                state.apply_action(action)
                continue
                
            # Get current player
            current_player = state.current_player()
            
            # Terminal state detection - OpenSpiel sometimes returns player ID -4 for terminal states
            if current_player < 0:
                if current_player == -4:
                    logging.debug("Detected Terminal state with player ID=-4")
                else:
                    logging.warning(f"Unexpected negative player ID: {current_player}")
                
                if not state.is_terminal():
                    logging.warning("State with negative player ID is not marked as terminal - forcing terminal")
                    
                break  # Exit the loop as this is a terminal state
            
            # Process observations for the current state
            processed_state = state_processor.process_state(state, current_player)
            
            # Choose action based on player
            if current_player % 2 == 0:  # BR player (us)
                # Choose best response action using the regret network
                with torch.no_grad():
                    state_tensor = torch.FloatTensor(processed_state).unsqueeze(0).to(self.device)
                    q_values = regret_net(state_tensor)
                    
                    # Apply epsilon-greedy exploration
                    epsilon = max(0.05, self.config.EPSILON_END + 
                                 (self.config.EPSILON_START - self.config.EPSILON_END) * 
                                 np.exp(-1. * self.global_step / self.config.EPSILON_DECAY))
                    
                    if np.random.random() < epsilon:
                        action = np.random.randint(self.num_actions)
                    else:
                        action = q_values.argmax().item()
                
                # Store the state for this player
                if current_player not in player_trajectory:
                    player_trajectory[current_player] = []
                player_trajectory[current_player].append((processed_state, action))
            else:  # Opponent player
                # Use opponent strategy
                legal_actions = state.legal_actions()
                if not legal_actions:
                    break
                
                if opponent_strategy is None:
                    # Random strategy
                    action = np.random.choice(legal_actions)
                else:
                    try:
                        # Use provided opponent strategy
                        action_probs = opponent_strategy.action_probabilities(state)
                        actions, probs = zip(*[(a, p) for a, p in action_probs.items() if a in legal_actions])
                        
                        # Normalize probabilities
                        probs = np.array(probs)
                        if np.sum(probs) > 0:
                            probs = probs / np.sum(probs)
                            action = np.random.choice(actions, p=probs)
                        else:
                            action = np.random.choice(legal_actions)
                    except:
                        # Fallback to random action
                        action = np.random.choice(legal_actions)
            
            # Apply action to the state
            state.apply_action(action)
            
            # Check if the new state is terminal
            if state.is_terminal():
                # Get returns for all players
                returns = state.returns()
                
                # Update rewards
                for p in range(game.num_players()):
                    rewards[p] = returns[p]
                    
                # Add experience to buffer for the BR player (player 0)
                if 0 in player_trajectory:
                    for idx, (obs, act) in enumerate(player_trajectory[0]):
                        # For terminal state
                        if idx == len(player_trajectory[0]) - 1:
                            buffer.append((obs, act, rewards[0], None, True))
                        else:
                            next_obs = player_trajectory[0][idx + 1][0]
                            buffer.append((obs, act, 0, next_obs, False))
        
        return buffer
    
    def sample_strategy_from_pool(self):
        """Sample a strategy from the pool according to meta-strategies."""
        if not self.strategy_pool:
            return None
        
        if not self.meta_strategies or len(self.meta_strategies) != len(self.strategy_pool):
            self.meta_strategies = [1.0 / len(self.strategy_pool)] * len(self.strategy_pool)
        
        idx = np.random.choice(len(self.strategy_pool), p=self.meta_strategies)
        return self.strategy_pool[idx]
    
    def br_policy_iteration(self, num_iterations=100, checkpoint_interval=None):
        """Best response policy iteration (PSRO main loop)."""
        start_time = time.time()
        last_checkpoint_time = start_time
        
        logging.info(f"Starting PSRO training for {num_iterations} iterations")
        self.writer.add_text('PSRO/Config', str(self.config.__dict__), 0)
        
        for iteration in range(num_iterations):
            iteration_start = time.time()
            logging.info(f"Starting PSRO iteration {iteration+1}/{num_iterations}")
            
            # 1. Sample strategy profile from meta-strategies
            opponent_strategy = self.sample_strategy_from_pool()
            
            # 2. Train best response against sampled strategy
            self.train_best_response(opponent_strategy, num_episodes=self.config.NUM_EPISODES)
            
            # 3. Extract policy from trained best response
            br_policy = self.extract_policy_from_model()
            
            # 4. Add best response to strategy pool
            self.add_strategy_to_pool(br_policy)
            
            # 5. Recompute meta-strategies
            self.meta_strategies = self.compute_meta_strategies()
            
            # 6. Evaluate exploitability if game is small enough
            if self.config.NUM_PLAYERS <= 2 and self.game.num_distinct_actions() < 100:
                try:
                    expl = exploitability.exploitability(self.game, br_policy)
                    self.metrics['exploitability'].append(float(expl))
                    self.writer.add_scalar('Metrics/exploitability', expl, iteration)
                    logging.info(f"Exploitability: {expl:.6f}")
                except Exception as e:
                    logging.error(f"Error computing exploitability: {e}")
            
            # 7. Track win rate against random agent
            try:
                win_rate = self._evaluate_against_random(100)
                self.metrics['win_rates'].append(float(win_rate))
                self.writer.add_scalar('Metrics/win_rate_vs_random', win_rate, iteration)
                logging.info(f"Win rate vs random: {win_rate:.2f}")
            except Exception as e:
                logging.error(f"Error evaluating win rate: {e}")
            
            # 8. Track meta-strategy distribution
            self.writer.add_histogram('PSRO/meta_strategy', 
                                    torch.tensor(self.meta_strategies), 
                                    iteration)
            
            # 9. Track policy size
            self.metrics['policy_size'].append(len(self.strategy_pool))
            self.writer.add_scalar('PSRO/strategy_pool_size', len(self.strategy_pool), iteration)
            
            # 10. Track iteration time
            iteration_time = time.time() - iteration_start
            self.metrics['training_time'].append(float(iteration_time))
            self.writer.add_scalar('PSRO/iteration_time', iteration_time, iteration)
            
            # Log progress
            logging.info(f"Completed PSRO iteration {iteration+1}: Strategy pool size={len(self.strategy_pool)}, Time={iteration_time:.2f}s")
            
            # Checkpoint if needed
            current_time = time.time()
            if checkpoint_interval and (current_time - last_checkpoint_time) >= checkpoint_interval:
                self.save_checkpoints(f"iteration_{iteration+1}")
                # Also save best checkpoint if this has the best win rate
                if self.metrics['win_rates'] and win_rate == max(self.metrics['win_rates']):
                    self.save_checkpoints("best")
                    logging.info(f"Saved best checkpoint with win rate: {win_rate:.2f}")
                    
                last_checkpoint_time = current_time
                
                # Save metrics to disk
                metrics_path = os.path.join(self.config.LOG_DIR, 'metrics.json')
                try:
                    import json
                    with open(metrics_path, 'w') as f:
                        json.dump(self.metrics, f)
                    logging.info(f"Metrics saved to {metrics_path}")
                except Exception as e:
                    logging.error(f"Failed to save metrics: {e}")
                
        # Final checkpoint
        self.save_checkpoints("final")
        
        # Final cleanup
        self.writer.close()
        
        total_time = time.time() - start_time
        logging.info(f"PSRO completed in {total_time:.2f} seconds")
        self.writer.add_text('PSRO/Summary', 
                           f"Training completed in {total_time:.2f}s with {len(self.strategy_pool)} strategies", 
                           num_iterations)
        
        return self.strategy_pool, self.meta_strategies
        
    def _evaluate_against_random(self, num_games=100):
        """Evaluate current policy against a random agent."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        policy = self.extract_policy_from_model()
        random_policy = TabularPolicy(self.game)  # Default is uniform random
        
        wins = 0
        for _ in range(num_games):
            state = env.reset()
            done = False
            
            while not done:
                if state.is_chance_node():
                    # Handle chance node
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    
                    # Normalize probability distribution for chance outcomes
                    prob_sum = sum(prob_list)
                    if prob_sum > 0:  # Avoid division by zero
                        normalized_probs = [p / prob_sum for p in prob_list]
                        action = np.random.choice(action_list, p=normalized_probs)
                    else:
                        # If all probs are 0, choose uniformly (shouldn't happen)
                        action = np.random.choice(action_list)
                    state.apply_action(action)
                    continue
                
                player = state.current_player()
                
                # Player 0 uses our policy, others use random
                if player == 0:
                    action_probs = policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    
                    # Normalize probabilities to ensure they sum to 1
                    probs_sum = sum(probs)
                    if probs_sum > 0:  # Avoid division by zero
                        # Convert to numpy array for better numeric stability
                        normalized_probs = np.array([float(p) / float(probs_sum) for p in probs])
                        
                        # Double-check normalization was successful
                        if abs(np.sum(normalized_probs) - 1.0) > 1e-10:
                            logging.warning(f"Probabilities don't sum to 1 after normalization: {np.sum(normalized_probs)}")
                            # Force normalization as a final fix
                            normalized_probs = normalized_probs / np.sum(normalized_probs)
                            
                        action = np.random.choice(actions, p=normalized_probs)
                    else:
                        # If all probs are 0, choose uniformly
                        action = np.random.choice(actions)
                else:
                    action_probs = random_policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    
                    # Normalize probabilities to ensure they sum to 1
                    probs_sum = sum(probs)
                    if probs_sum > 0:  # Avoid division by zero
                        # Convert to numpy array for better numeric stability
                        normalized_probs = np.array([float(p) / float(probs_sum) for p in probs])
                        
                        # Double-check normalization was successful
                        if abs(np.sum(normalized_probs) - 1.0) > 1e-10:
                            logging.warning(f"Probabilities don't sum to 1 after normalization: {np.sum(normalized_probs)}")
                            # Force normalization as a final fix
                            normalized_probs = normalized_probs / np.sum(normalized_probs)
                            
                        action = np.random.choice(actions, p=normalized_probs)
                    else:
                        # If all probs are 0, choose uniformly
                        action = np.random.choice(actions)
                
                # Apply action
                state.apply_action(action)
                done = state.is_terminal()
            
            # Get final rewards
            returns = state.returns()
            if returns[0] > 0:
                wins += 1
        
        return wins / num_games
    
    # Define Ray worker for parallel data collection (CPU-only)
    @staticmethod
    @ray.remote(num_gpus=0)  # Explicitly use CPU only
    def _collect_experience_worker(game_name, num_players, state_processor, regret_net_weights, 
                                  opponent_strategy, num_episodes, adaptation_manager=None):
        """Worker function for collecting experience in parallel using Ray.
        
        Args:
            game_name: Name of the game to play
            num_players: Number of players in the game
            state_processor: StateProcessor instance for preprocessing states
            regret_net_weights: Weights of the regret network
            opponent_strategy: Strategy to use for opponents
            num_episodes: Number of episodes to collect
            adaptation_manager: Optional adaptation manager for opponent modeling
            
        Returns:
            List of experience trajectories
        """
        # Create local environment and models
        env = PokerEnvironment(game_name, num_players)
        device = torch.device("cpu")  # Force CPU usage for workers
        
        # Recreate regret network and load weights
        regret_net = RegretNet(state_processor.state_size, env.game.num_distinct_actions()).to(device)
        regret_net.load_state_dict(regret_net_weights)
        regret_net.eval()  # Set to evaluation mode
        
        buffer = []
        
        # Collect experience
        for episode in range(num_episodes):
            state = env.reset()
            done = False
            trajectory = []
            episode_rewards = [0] * num_players
            
            # Initialize episode-specific tracking
            hole_cards = [None] * num_players
            board_cards = []
            current_round = "PREFLOP"
            street_mapping = {0: "PREFLOP", 1: "FLOP", 2: "TURN", 3: "RIVER"}
            
            # For root cause debugging
            action_history = []
            step_count = 0
            
            logging.debug(f"Starting episode {episode+1}/{num_episodes} with adaptation={adaptation_manager is not None}")
            
            while not done:
                step_count += 1
                
                # Check state for potential issues before processing
                is_chance = state.is_chance_node()
                is_terminal = state.is_terminal()
                
                # IMPORTANT: Root Cause Investigation & Fix for OpenSpiel Poker
                # In OpenSpiel, player_id = -4 is a special value in poker that indicates
                # the game has ended through special conditions like everyone folding
                # But in this case, is_terminal() sometimes incorrectly returns False
                
                # Capture state info for debugging negative player IDs
                try:
                    current_player = state.current_player()
                    legal_acts = state.legal_actions() if not is_chance and not is_terminal else []
                    
                    # Additional terminal state check - ROOT CAUSE INVESTIGATION & FIX
                    # If we get player = -4 in poker, it's ACTUALLY a terminal state
                    # even though is_terminal() might return False
                    if current_player < 0:
                        # ROOT CAUSE INVESTIGATION: Detailed logging to understand the issue
                        logging.warning(f"ROOT CAUSE: Negative player ID detected: {current_player}")
                        logging.warning(f"ROOT CAUSE: Game state details at negative player ID:")
                        logging.warning(f"  - Step: {step_count}")
                        logging.warning(f"  - Action history: {action_history}")
                        logging.warning(f"  - Is terminal according to is_terminal(): {is_terminal}")
                        logging.warning(f"  - Is chance node: {is_chance}")
                        logging.warning(f"  - Legal actions: {legal_acts}")
                        
                        try:
                            state_str = str(state)
                            logging.warning(f"  - State string: {state_str[:100]}..." if len(state_str) > 100 else state_str)
                        except:
                            logging.warning("  - Could not get state string representation")
                        
                        try:
                            # Get the history of actions
                            history = state.history() if hasattr(state, 'history') and callable(getattr(state, 'history')) else []
                            logging.warning(f"  - State history: {history}")
                        except:
                            logging.warning("  - Could not get state history")
                        
                        # ROOT CAUSE FIX: 
                        # We've identified that in OpenSpiel universal_poker, player ID = -4 
                        # indicates a terminal state that should have is_terminal() = True,
                        # but sometimes doesn't because of internal state handling in OpenSpiel.
                        # 
                        # The fix is to treat any negative player ID as a terminal state
                        # and to explicitly mark player ID = -4 as the correct end-of-game state.
                        logging.info("ROOT CAUSE FIX: Marking state with negative player ID as terminal")
                        
                        # Override the terminal flag - this is the root cause fix
                        is_terminal = True
                        done = True
                        
                        # Try to get returns to properly reward the trajectories
                        try:
                            if hasattr(state, 'returns'):
                                returns = state.returns()
                                logging.info(f"  - Final returns at negative player ID: {returns}")
                                
                                # Update the trajectory with final rewards
                                for transition in trajectory:
                                    transition['reward'] = returns[transition['player']]
                                    transition['done'] = True
                        except Exception as e:
                            logging.warning(f"  - Error extracting returns at negative player ID: {e}")
                        
                        # Skip the rest of this iteration, we're done with this episode
                        break
                        
                    logging.debug(f"Step {step_count}: " + 
                                 f"Chance={is_chance}, Terminal={is_terminal}, " + 
                                 f"Player={current_player}, LegalActions={len(legal_acts)}, " + 
                                 f"History={len(action_history)} actions")
                except Exception as e:
                    logging.warning(f"Error checking state info: {e}")
                
                # If the game is terminal according to is_terminal(), break out of the loop
                if is_terminal:
                    logging.debug(f"Terminal state reached. Breaking out of game loop.")
                    break
                
                # Update current round if we can determine it
                round_idx = -1
                if hasattr(state, 'round'):
                    if callable(getattr(state, 'round')):
                        round_idx = state.round()
                    else:
                        round_idx = getattr(state, 'round')
                elif len(board_cards) == 0:
                    round_idx = 0  # Preflop
                elif len(board_cards) <= 3:
                    round_idx = 1  # Flop
                elif len(board_cards) <= 4:
                    round_idx = 2  # Turn
                else:
                    round_idx = 3  # River
                
                current_round = street_mapping.get(round_idx, "UNKNOWN")
                
                if is_chance:
                    # Handle chance node
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    
                    # Normalize probability distribution for chance outcomes
                    prob_sum = sum(prob_list)
                    if prob_sum > 0:  # Avoid division by zero
                        normalized_probs = [p / prob_sum for p in prob_list]
                        action = np.random.choice(action_list, p=normalized_probs)
                    else:
                        # If all probs are 0, choose uniformly (shouldn't happen)
                        action = np.random.choice(action_list)
                    
                    # Track the chance action
                    action_history.append(f"Chance:{action}")
                    logging.debug(f"Taking chance action: {action}")
                    
                    # Apply the action safely
                    try:
                        state.apply_action(action)
                    except Exception as e:
                        logging.error(f"Error applying chance action {action}: {e}")
                        break
                    
                    # Track cards if possible
                    try:
                        # This is a simplified implementation - card tracking would be more robust in real code
                        if round_idx == 0 and action < 52:  # Preflop dealing hole cards
                            if hole_cards[0] is None:
                                hole_cards[0] = [action]
                            else:
                                hole_cards[0].append(action)
                        elif round_idx > 0 and action < 52:  # Community cards
                            board_cards.append(action)
                    except (AttributeError, IndexError):
                        pass  # Safely handle cases where card tracking fails
                        
                    continue
                
                # We shouldn't reach here if we have a negative player ID, but just to be safe:
                player = state.current_player()
                if player < 0:
                    logging.warning(f"Detected negative player ID: {player} after checks - treating as terminal")
                    done = True
                    break
                
                legal_actions = state.legal_actions()
                
                # Process state
                processed_state = state_processor.process([state], [player])
                state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=device)
                
                # Use opponent strategy for all players except current training player
                if player != 0:  # Assuming we're training player 0
                    if opponent_strategy:
                        # Get base action probabilities from opponent strategy
                        action_probs = opponent_strategy.action_probabilities(state)
                        
                        # Use adaptation 30% of the time when adaptation manager is available
                        use_adaptation_this_time = adaptation_manager is not None and random.random() < 0.3
                        
                        if use_adaptation_this_time:
                            try:
                                # Convert OpenSpiel action probabilities to our format
                                action_dict = {int(a): float(p) for a, p in action_probs.items()}
                                
                                # Get adapted probabilities based on opponent modeling
                                adapted_probs = adaptation_manager.get_adapted_action_probs(
                                    player_id=player,
                                    original_probs=action_dict,
                                    is_preflop=(round_idx == 0),
                                    position=player  # Simplified position mapping
                                )
                                
                                # Convert back to OpenSpiel format and normalize
                                total_prob = sum(adapted_probs.values())
                                if total_prob > 0:
                                    action_probs = {a: p/total_prob for a, p in adapted_probs.items()}
                                    logging.debug(f"Using adapted strategy for player {player}")
                            except Exception as e:
                                logging.warning(f"Error in adaptation, using base strategy: {e}")
                                # Fall back to original action_probs
                        
                        # Sample action based on probabilities
                        actions, probs = zip(*action_probs.items())
                        
                        # Filter to legal actions only
                        legal_indices = [i for i, a in enumerate(actions) if a in legal_actions]
                        if not legal_indices:
                            # No legal actions among the probs, just choose randomly
                            action = random.choice(legal_actions)
                        else:
                            # Filter to legal actions and renormalize
                            legal_actions_list = [actions[i] for i in legal_indices]
                            legal_probs = [probs[i] for i in legal_indices]
                            
                            # Renormalize probabilities
                            prob_sum = sum(legal_probs)
                            if prob_sum > 0:
                                normalized_probs = [p / prob_sum for p in legal_probs]
                                action = np.random.choice(legal_actions_list, p=normalized_probs)
                            else:
                                # Fallback to random if probabilities don't normalize
                                action = random.choice(legal_actions)
                    else:
                        # Random action if no opponent strategy
                        action = random.choice(legal_actions)
                        
                    # Register opponent action with adaptation manager if available
                    if adaptation_manager and player > 0:
                        # Convert action to poker-specific info
                        pot_size = state.get_pot_size() if hasattr(state, 'get_pot_size') else 0
                        stack_size = 100  # Default stack size
                        is_raised_pot = False  # These would be set properly in a real implementation
                        
                        # Map action to poker action type
                        action_type = "call"
                        if action == 0:
                            action_type = "fold"
                        elif action > 1:
                            action_type = "raise"
                        
                        adaptation_manager.register_action(
                            player_id=player,
                            action_type=action_type,
                            position=player,  # Simplified
                            street=round_idx,
                            poker_round=current_round,
                            pot_size=pot_size,
                            stack_size=stack_size,
                            is_raised_pot=is_raised_pot
                        )
                else:
                    # Use epsilon-greedy for exploration
                    epsilon = max(0.1, 1.0 - episode / num_episodes)
                    
                    if random.random() < epsilon:
                        action = random.choice(legal_actions)
                    else:
                        with torch.no_grad():
                            regret_values = regret_net(state_tensor)[0].cpu().numpy()
                            # Mask illegal actions
                            mask = np.ones_like(regret_values) * float('-inf')
                            mask[legal_actions] = 0
                            masked_values = regret_values + mask
                            action = np.argmax(masked_values)
                            
                            # Double-check the action is legal
                            if action not in legal_actions:
                                logging.warning(f"Selected action {action} not in legal actions {legal_actions}, falling back to random")
                                action = random.choice(legal_actions)
                
                # Track the player action
                action_history.append(f"Player{player}:{action}")
                logging.debug(f"Player {player} taking action: {action}")
                
                # Store transition
                info_state = state.information_state_string(player)
                reward = 0  # Placeholder, will be updated later
                
                trajectory.append({
                    'info_state': info_state,
                    'state': state.clone(),
                    'action': action,
                    'legal_actions': legal_actions,
                    'player': player,
                    'reward': reward,
                    'next_state': None,
                    'done': False
                })
                
                # =====================================================
                # DETAILED DIAGNOSTIC LOGGING - Added per investigation request
                # =====================================================
                # Log state details before applying action to capture pre-error state
                logging.debug(f"Step {step_count}: Pre-Action Check - " +
                             f"Player={current_player}, Terminal={is_terminal}, " +
                             f"Chance={is_chance}, Action={action}, " +
                             f"History={state.history() if hasattr(state, 'history') and callable(getattr(state, 'history')) else action_history}")
                
                # Apply action safely
                try:
                    # Verify action is valid one more time to be extra careful
                    if action not in legal_actions:
                        logging.error(f"Invalid action detected: {action} not in {legal_actions}")
                        
                        # We need to recover by selecting a valid action
                        action = random.choice(legal_actions)
                        logging.warning(f"Recovering by choosing valid action: {action}")
                        
                        # Update the last entry in the trajectory with the new action
                        if trajectory:
                            trajectory[-1]['action'] = action
                    
                    # Clone the state before applying the action to have it for error analysis
                    next_state = state.clone()
                    
                    # CRITICAL FIX for isValidAction error at acpc_game.cc:224
                    # Perform additional validity check for poker-specific actions
                    poker_legal_actions = state.legal_actions()
                    if action not in poker_legal_actions:
                        logging.error(f"FIXING INVALID ACTION: Action {action} not in current legal actions {poker_legal_actions}")
                        # Recover by choosing a random legal action instead
                        if poker_legal_actions:
                            action = random.choice(poker_legal_actions)
                            logging.warning(f"Recovered by choosing valid action: {action}")
                            # Update the trajectory
                            if trajectory:
                                trajectory[-1]['action'] = action
                        else:
                            # We have no legal actions at all, must be a terminal state
                            logging.error("No legal actions available, treating as terminal")
                            done = True
                            break
                    
                    # Safely apply the action with try/catch to handle any OpenSpiel errors
                    try:
                        state.apply_action(action)
                    except Exception as apply_error:
                        logging.error(f"Action application error: {apply_error}")
                        # This is a critical error in OpenSpiel - check if it's the isValidAction error
                        if "isValidAction" in str(apply_error):
                            logging.error("Detected OpenSpiel isValidAction error - breaking out of episode")
                            done = True
                            break
                        # If we get here, it's some other error, but we'll try to continue
                        logging.warning("Attempting to continue despite action application error")
                    
                    # Check if player became negative AFTER applying action (ROOT CAUSE INVESTIGATION)
                    post_terminal = state.is_terminal()
                    post_chance = state.is_chance_node()
                    
                    if not post_terminal and not post_chance:
                        post_player = state.current_player()
                        if post_player < 0:
                            logging.warning(f"ROOT CAUSE DETECTED: Player became negative AFTER action {action}: player={post_player}")
                            logging.warning(f"State history after action: {state.history() if hasattr(state, 'history') and callable(getattr(state, 'history')) else action_history + [f'Player{player}:{action}']}")
                            logging.warning(f"Terminal flag before action: {is_terminal}, after action: {post_terminal}")
                            
                            # ROOT CAUSE FIX: Check if player ID is -4 which indicates the game is over but wrongly not marked as terminal
                            # In OpenSpiel, player ID -4 specifically indicates a terminal state in poker
                            if post_player == -4:
                                logging.info("ROOT CAUSE FIX: Detected correct terminal state with player ID -4, marking as terminal")
                                done = True
                                # Try to get returns
                                try:
                                    returns = state.returns()
                                    logging.info(f"Returns from terminal state with player -4: {returns}")
                                except Exception as err:
                                    logging.warning(f"Could not get returns from -4 state: {err}")
                except Exception as e:
                    logging.error(f"EXCEPTION during apply_action({action}) for player {player}: {e}")
                    # Log the state *before* the failing action
                    if 'next_state' in locals() and next_state is not None:
                        pre_player = next_state.current_player() if hasattr(next_state, 'current_player') else "unknown"
                        pre_terminal = next_state.is_terminal() if hasattr(next_state, 'is_terminal') else "unknown"
                        pre_history = next_state.history() if hasattr(next_state, 'history') and callable(getattr(next_state, 'history')) else action_history
                        
                        logging.error(f"State before error: Player={pre_player}, " +
                                    f"Terminal={pre_terminal}, " +
                                    f"History={pre_history}")
                    
                    logging.error(f"Action history: {action_history}")
                    logging.error(f"Legal actions: {legal_actions}")
                    
                    # Try one more recovery attempt with default action 0 or 1 (fold or call)
                    try:
                        if 0 in legal_actions:
                            action = 0  # Fold is usually safest
                        elif 1 in legal_actions:
                            action = 1  # Call is second safest
                        else:
                            # If neither is available, just pick the first legal action
                            action = legal_actions[0]
                            
                        logging.warning(f"Last attempt recovery with action: {action}")
                        if trajectory:
                            trajectory[-1]['action'] = action
                        state.apply_action(action)
                        
                        # Log state after recovery
                        recovery_player = state.current_player() if hasattr(state, 'current_player') else "unknown"
                        recovery_terminal = state.is_terminal() if hasattr(state, 'is_terminal') else "unknown"
                        recovery_history = state.history() if hasattr(state, 'history') and callable(getattr(state, 'history')) else action_history + [f'Player{player}:{action}']
                        
                        logging.info(f"State after recovery: Player={recovery_player}, " +
                                    f"Terminal={recovery_terminal}, " +
                                    f"History={recovery_history}")
                    except Exception as e2:
                        logging.error(f"Recovery failed: {e2}, terminating episode")
                        break
                
                # Update done flag AFTER applying the action
                done = state.is_terminal()
            
            # Log episode completion
            logging.debug(f"Episode {episode+1} completed after {step_count} steps, done={done}, trajectory_len={len(trajectory)}")
            
            # Get final rewards if we haven't already
            if not 'returns' in locals() or returns is None:
                try:
                    returns = state.returns()
                except Exception as e:
                    logging.warning(f"Error getting returns: {e}, using zeros")
                    returns = [0] * num_players
            
            # Update rewards in trajectory
            for transition in trajectory:
                try:
                    transition['reward'] = returns[transition['player']]
                    transition['done'] = True
                except (IndexError, KeyError) as e:
                    logging.warning(f"Error updating reward for player {transition.get('player', 'unknown')}: {e}")
                    transition['reward'] = 0
                    transition['done'] = True
            
            # Register hand results with adaptation manager if available
            if adaptation_manager:
                try:
                    for player_idx in range(env.game.num_players()):
                        # Get the player's cards if they were tracked
                        player_cards = hole_cards[player_idx] if player_idx < len(hole_cards) and hole_cards[player_idx] else None
                        
                        # Register hand result
                        adaptation_manager.register_hand_result(
                            player_id=player_idx,
                            net_win=returns[player_idx] if player_idx < len(returns) else 0,
                            had_showdown=True,  # Simplified assumption
                            hole_cards=player_cards,
                            board_cards=board_cards
                        )
                except Exception as e:
                    logging.warning(f"Error registering hand results: {e}")
            
            buffer.extend(trajectory)
            
            if (episode + 1) % 10 == 0:
                logging.info(f"Episode {episode+1}/{num_episodes} completed, buffer size: {len(buffer)}")
        
        return buffer
    
    def train_best_response(self, opponent_strategy, num_episodes=10, use_adaptation=True):
        """Train best response against a given opponent strategy using Ray parallelism.
        
        This method collects experience using parallel Ray workers (CPU only) and
        then trains the neural networks on GPU.
        
        Args:
            opponent_strategy: The opponent strategy to train against
            num_episodes: Number of episodes to collect per worker
            use_adaptation: Whether to use the adaptation manager
            
        Returns:
            Dictionary of training metrics
        """
        # Check if we should use single-process mode
        single_process_mode = hasattr(self.config, 'single_process_mode') and self.config.single_process_mode
        logging.info(f"Using single-process mode: {single_process_mode}")
            
        # Initialize Ray if not already done and not in single-process mode
        # Note: This code block will now be skipped due to forced single_process_mode=True
        if not single_process_mode and not ray.is_initialized():
            try:
                # Try to import server config helper for optimized Ray initialization
                try:
                    from server_config_helper import get_recommended_psro_config
                    config = get_recommended_psro_config()
                    ray_config = config['ray_config']
                    num_gpus = config['num_gpus'] if config['use_gpu'] else 0
                    
                    logging.info(f"Initializing Ray with optimized server configuration")
                    logging.info(f"Detected {num_gpus} GPUs and {config['num_workers']} workers")
                    
                    # Use specific connection timeout to prevent hanging on GCS connection
                    ray.init(
                        num_gpus=num_gpus,  # Use GPUs if available
                        ignore_reinit_error=ray_config['ignore_reinit_error'],
                        local_mode=ray_config.get('local_mode', False),  # Use distributed mode for A100
                        include_dashboard=ray_config.get('include_dashboard', False),
                        logging_level=logging.ERROR,
                        # Use Ray's default memory management for A100
                        _system_config={
                            **ray_config.get('_system_config', {}),
                            "object_spilling_threshold": 0.8,  # More aggressive threshold for A100
                        }
                    )
                    logging.info("Using optimized Ray configuration for A100 performance")
                except ImportError:
                    # Fall back to default configuration if server config helper isn't available
                    logging.warning("Server config helper not found, using default Ray configuration")
                    ray.init(
                        num_gpus=1 if torch.cuda.is_available() else 0,  # Use GPU if available
                        ignore_reinit_error=True,
                        local_mode=False,  # Use distributed mode for better performance
                        include_dashboard=False,  # Disable dashboard to save resources
                        logging_level=logging.ERROR,
                        # Use Ray's default memory management for A100
                        _system_config={
                            "object_spilling_threshold": 0.8,  # More aggressive threshold for A100
                        }
                    )
                    logging.info("Using standard Ray configuration for A100 performance")
                logging.info("Ray initialized with GPU support" if torch.cuda.is_available() else "Ray initialized")
            except Exception as e:
                logging.warning(f"Could not initialize Ray: {e}. Falling back to single-process mode.")
                single_process_mode = True
                if not hasattr(self.config, 'single_process_mode'):
                    self.config.single_process_mode = True
        
        # Set model to training mode
        self.regret_net.train()
        self.strategy_net.train()  # For Double DQN implementation
        
        # Get current regret net weights for workers
        regret_net_weights = {k: v.cpu() for k, v in self.regret_net.state_dict().items()}
        
        # Get adaptation manager if available
        adaptation_manager = None
        if use_adaptation and hasattr(self, 'adaptation_manager'):
            adaptation_manager = self.adaptation_manager
            
        # Collect experience
        combined_buffer = []
        num_workers = 1  # Default to 1 worker for single process mode
        
        if single_process_mode:
            logging.info("Using single-process mode for experience collection")
            
            # Direct experience collection without Ray
            for _ in range(num_episodes):
                try:
                    # Create the game
                    game = pyspiel.load_game(self.config.GAME_NAME)
                    
                    # Play episode
                    buffer = self._play_episode(
                        game, 
                        self.regret_net,
                        opponent_strategy,
                        self.state_processor,
                        use_adaptation=use_adaptation
                    )
                    combined_buffer.extend(buffer)
                except Exception as e:
                    logging.error(f"Error collecting experience: {e}")
                    continue
        else:
            # Determine number of workers using server config helper if available
            try:
                from server_config_helper import get_recommended_psro_config
                server_config = get_recommended_psro_config()
                num_workers = server_config['num_workers']
                logging.info(f"Using recommended {num_workers} Ray workers from server configuration")
            except ImportError:
                # Fall back to default configuration
                num_workers = min(os.cpu_count() or 4, 8)  # Cap at 8 workers
                logging.info(f"Using default {num_workers} Ray workers based on CPU cores")
                
            episodes_per_worker = max(1, num_episodes // num_workers)
            logging.info(f"Each worker will process {episodes_per_worker} episodes")
            
            try:
                # Launch parallel workers for experience collection
                worker_tasks = []
                for _ in range(num_workers):
                    worker_tasks.append(
                        self._collect_experience_worker.remote(
                            self.config.GAME_NAME,
                            self.config.NUM_PLAYERS,
                            self.state_processor,
                            regret_net_weights,
                            opponent_strategy,
                            episodes_per_worker,
                            adaptation_manager
                        )
                    )
                
                # Wait for all workers to complete and gather results
                experience_buffers = ray.get(worker_tasks)
                
                # Combine buffers
                for buffer in experience_buffers:
                    combined_buffer.extend(buffer)
            except Exception as e:
                logging.error(f"Error in Ray parallelism: {e}. Falling back to single-process mode.")
                self.config.single_process_mode = True
                return self.train_best_response(opponent_strategy, num_episodes, use_adaptation)
        
        logging.info(f"Collected {len(combined_buffer)} transitions from {num_workers} workers")
        
        # Train on combined buffer (on GPU)
        train_metrics = self._train_dqn_on_buffer(combined_buffer)
        
        # Reset model to eval mode
        self.regret_net.eval()
        self.strategy_net.eval()
        
        return train_metrics
        
    def _train_dqn_on_buffer(self, buffer, batch_size=None, epochs=5, gamma=0.99, target_update_freq=5):
        """Train models on collected experience using Double DQN.
        
        Args:
            buffer: Collected experience buffer
            batch_size: Training batch size (if None, will be determined using server config)
            epochs: Number of training epochs
            gamma: Discount factor
            target_update_freq: How often to update target network
            
        Returns:
            Dictionary of training metrics
        """
        # Determine optimal batch size from server configuration if not specified
        if batch_size is None:
            try:
                from server_config_helper import get_recommended_psro_config
                server_config = get_recommended_psro_config()
                batch_size = server_config['batch_size']
                logging.info(f"Using recommended batch size {batch_size} from server configuration")
            except ImportError:
                batch_size = 64
                logging.info(f"Using default batch size {batch_size}")
        if not buffer:
            logging.warning("Empty buffer, skipping training")
            return {"loss": 0.0}
        
        # Prepare data
        states = []
        actions = []
        rewards = []
        next_states = []
        dones = []
        
        for item in buffer:
            try:
                # Handle both dictionary and tuple items
                if isinstance(item, dict):
                    # Skip items without next_state (last transitions)
                    if item.get('next_state') is None:
                        continue
                        
                    # Get processed states
                    if 'processed_state' in item:
                        state = item['processed_state']
                    else:
                        state = self.state_processor.process([item['state']], [item['player']])
                        
                    player = item['player']
                    next_state_obj = item['next_state']
                    next_player = next_state_obj.current_player() if not next_state_obj.is_terminal() else player
                    next_state = self.state_processor.process([next_state_obj], [next_player])
                elif isinstance(item, tuple):
                    # Handle tuple format (state, action, reward, next_state, done)
                    if len(item) < 4 or item[3] is None:
                        continue
                    
                    state_obj, action, reward, next_state_obj, done = item
                    player = state_obj.current_player() if hasattr(state_obj, 'current_player') else 0
                    state = self.state_processor.process([state_obj], [player])
                    
                    next_player = next_state_obj.current_player() if hasattr(next_state_obj, 'current_player') and not next_state_obj.is_terminal() else player
                    next_state = self.state_processor.process([next_state_obj], [next_player])
                else:
                    # Skip unknown formats
                    logging.warning(f"Unknown buffer item format: {type(item)}")
                    continue
            except Exception as e:
                logging.error(f"Error processing buffer item: {e}")
                continue
            
            states.append(state)
            
            # Extract action based on item type
            if isinstance(item, dict):
                actions.append(item['action'])
                rewards.append(item['reward'])
                next_states.append(next_state)
                dones.append(float(item['done']))
            elif isinstance(item, tuple):
                _, action, reward, _, done = item
                actions.append(action)
                rewards.append(reward)
                next_states.append(next_state)
                dones.append(float(done))
            else:
                # This should never happen due to the earlier continue
                logging.warning(f"Unexpected item type in buffer: {type(item)}")
                continue
        
        if not states:
            logging.warning("No valid transitions for training")
            return {"loss": 0.0}
        
        # Convert to tensors
        states = torch.tensor(np.array(states), dtype=torch.float32, device=self.device)
        actions = torch.tensor(actions, dtype=torch.long, device=self.device)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device)
        next_states = torch.tensor(np.array(next_states), dtype=torch.float32, device=self.device)
        dones = torch.tensor(dones, dtype=torch.float32, device=self.device)
        
        # Normalize rewards
        reward_mean = rewards.mean().item()
        reward_std = rewards.std().item() + 1e-6  # Add small constant to avoid division by zero
        normalized_rewards = (rewards - reward_mean) / reward_std
        
        # Log reward statistics
        self.writer.add_histogram('Rewards/raw', rewards, self.global_step)
        self.writer.add_histogram('Rewards/normalized', normalized_rewards, self.global_step)
        self.writer.add_scalar('Rewards/mean', reward_mean, self.global_step)
        self.writer.add_scalar('Rewards/std', reward_std, self.global_step)
        
        dataset_size = len(states)
        indices = list(range(dataset_size))
        
        epoch_losses = []
        for epoch in range(epochs):
            random.shuffle(indices)
            total_loss = 0
            batch_count = 0
            
            for start_idx in range(0, dataset_size, batch_size):
                batch_indices = indices[start_idx:min(start_idx + batch_size, dataset_size)]
                batch_count += 1
                
                # Get batch data
                batch_states = states[batch_indices]
                batch_actions = actions[batch_indices]
                batch_rewards = normalized_rewards[batch_indices]
                batch_next_states = next_states[batch_indices]
                batch_dones = dones[batch_indices]
                
                # Zero gradients
                self.regret_optimizer.zero_grad()
                
                # Double DQN implementation
                with torch.no_grad():
                    # Select best actions in next_state using main network (regret_net)
                    next_q_values = self.regret_net(batch_next_states)
                    next_actions = next_q_values.argmax(dim=1, keepdim=True)
                    
                    # Evaluate those actions using target network (strategy_net)
                    target_q_values = self.strategy_net(batch_next_states)
                    next_q_values = target_q_values.gather(1, next_actions).squeeze(1)
                    
                    # Calculate target: R + gamma * Q_target(s', argmax_a Q_main(s', a)) * (1 - done)
                    targets = batch_rewards + gamma * next_q_values * (1.0 - batch_dones)
                
                # Get Q-values for current states and actions
                current_q_values = self.regret_net(batch_states)
                action_q_values = current_q_values.gather(1, batch_actions.unsqueeze(1)).squeeze(1)
                
                # Calculate loss (MSE between predicted Q-values and targets)
                loss = nn.MSELoss()(action_q_values, targets)
                
                # Backward and optimize with gradient scaling
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.regret_optimizer)
                torch.nn.utils.clip_grad_norm_(self.regret_net.parameters(), self.config.GRAD_CLIP_VALUE)
                self.scaler.step(self.regret_optimizer)
                self.scaler.update()
                
                # Log batch loss
                batch_loss = loss.item()
                total_loss += batch_loss
                self.writer.add_scalar('Training/batch_loss', batch_loss, self.global_step)
                self.global_step += 1
                
                # Periodically update target network (strategy_net)
                if batch_count % target_update_freq == 0:
                    # Use Polyak averaging for more stable updates
                    tau = 0.01  # Small value for soft update
                    for target_param, main_param in zip(self.strategy_net.parameters(), self.regret_net.parameters()):
                        target_param.data.copy_(
                            tau * main_param.data + (1.0 - tau) * target_param.data
                        )
            
            # Calculate and log epoch loss
            avg_loss = total_loss / batch_count if batch_count > 0 else 0
            epoch_losses.append(avg_loss)
            self.writer.add_scalar('Training/epoch_loss', avg_loss, epoch)
            
            logging.info(f"Epoch {epoch+1}/{epochs}, Average loss: {avg_loss:.6f}")
        
        # Store metrics
        metrics = {
            'loss': np.mean(epoch_losses) if epoch_losses else 0.0,
            'reward_mean': reward_mean,
            'reward_std': reward_std,
            'buffer_size': len(buffer),
            'valid_transitions': len(states)
        }
        
        return metrics
    
    def _train_on_buffer(self, buffer, batch_size=64, epochs=5):
        """Train models on collected experience."""
        if not buffer:
            logging.warning("Empty buffer, skipping training")
            return
        
        # Prepare data
        states = [item['state'] for item in buffer]
        players = [item['player'] for item in buffer]
        actions = torch.tensor([item['action'] for item in buffer], dtype=torch.long, device=self.device)
        
        # Normalize rewards
        raw_rewards = [item['reward'] for item in buffer]
        for reward in raw_rewards:
            self.reward_normalizer.update(reward)
            
        normalized_rewards = [self.reward_normalizer.normalize(r) for r in raw_rewards]
        rewards = torch.tensor(normalized_rewards, dtype=torch.float32, device=self.device)
        
        # Log reward statistics
        self.writer.add_histogram('Rewards/raw', torch.tensor(raw_rewards), self.global_step)
        self.writer.add_histogram('Rewards/normalized', rewards, self.global_step)
        self.writer.add_scalar('Rewards/mean', self.reward_normalizer.mean, self.global_step)
        self.writer.add_scalar('Rewards/std', self.reward_normalizer.std, self.global_step)
        
        # Process states
        processed_states = self.state_processor.process(states, players)
        states_tensor = torch.tensor(processed_states, dtype=torch.float32, device=self.device)
        
        dataset_size = len(buffer)
        indices = list(range(dataset_size))
        
        epoch_losses = []
        for epoch in range(epochs):
            random.shuffle(indices)
            total_loss = 0
            batch_count = 0
            
            for start_idx in range(0, dataset_size, batch_size):
                batch_indices = indices[start_idx:min(start_idx + batch_size, dataset_size)]
                batch_count += 1
                
                # Get batch data
                batch_states = states_tensor[batch_indices]
                batch_actions = actions[batch_indices]
                batch_rewards = rewards[batch_indices]
                
                # Zero gradients
                self.regret_optimizer.zero_grad()
                
                # Forward pass without mixed precision to avoid BFloat16 issues
                batch_states = batch_states.to(dtype=torch.float32)
                regret_values = self.regret_net(batch_states)
                
                # Get regret values for taken actions
                selected_regrets = regret_values.gather(1, batch_actions.unsqueeze(1)).squeeze(1)
                
                # MSE loss between regret prediction and actual reward
                loss = nn.MSELoss()(selected_regrets, batch_rewards)
                
                # Backward and optimize with gradient scaling
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.regret_optimizer)
                torch.nn.utils.clip_grad_norm_(self.regret_net.parameters(), self.config.GRAD_CLIP_VALUE)
                self.scaler.step(self.regret_optimizer)
                self.scaler.update()
                
                # Log batch loss
                batch_loss = loss.item()
                total_loss += batch_loss
                self.writer.add_scalar('Training/batch_loss', batch_loss, self.global_step)
                self.global_step += 1
            
            # Calculate and log epoch loss
            avg_loss = total_loss / batch_count if batch_count > 0 else 0
            epoch_losses.append(avg_loss)
            self.writer.add_scalar('Training/epoch_loss', avg_loss, epoch)
            
            logging.info(f"Epoch {epoch+1}/{epochs}, Average loss: {avg_loss:.6f}")
        
        # Store metrics
        self.metrics['losses'].append(np.mean(epoch_losses))
        
        # Periodically save metrics to disk
        if self.global_step % 500 == 0:
            metrics_path = os.path.join(self.config.LOG_DIR, 'metrics.json')
            try:
                import json
                with open(metrics_path, 'w') as f:
                    json.dump(self.metrics, f)
                logging.info(f"Metrics saved to {metrics_path}")
            except Exception as e:
                logging.error(f"Failed to save metrics: {e}")
                
        # Run garbage collection to prevent memory leaks
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def extract_policy_from_model(self):
        """Extract a policy from the trained regret network."""
        self.regret_net.eval()
        
        # Create a tabular policy for storage efficiency
        br_policy = TabularPolicy(self.game)
        
        # Sample states for policy extraction
        sampled_states = self._sample_info_states()
        
        for info_state, state in sampled_states.items():
            legal_actions = state.legal_actions()
            if not legal_actions:
                continue
            
            player = state.current_player()
            processed_state = self.state_processor.process([state], [player])
            state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
            
            with torch.no_grad():
                regret_values = self.regret_net(state_tensor)[0].cpu().numpy()
            
            # Convert regret values to policy
            # Use softmax with temperature for better exploration
            temperature = 0.5
            masked_values = np.ones_like(regret_values) * float('-inf')
            masked_values[legal_actions] = regret_values[legal_actions]
            
            # Apply softmax
            policy_probs = np.exp(masked_values / temperature)
            policy_probs = policy_probs / np.sum(policy_probs)
            
            # Add to policy table
            br_policy.update(info_state, {a: policy_probs[a] for a in legal_actions})
        
        return br_policy
    
    def _sample_info_states(self, num_games=50, max_states=1000):
        """Sample information states from random games."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        sampled_states = {}
        
        for game_idx in range(num_games):
            if len(sampled_states) >= max_states:
                break
                
            state = env.reset()
            done = False
            action_history = []
            step_count = 0
            
            logging.debug(f"Starting game {game_idx+1}/{num_games}")
            
            while not done and len(sampled_states) < max_states:
                step_count += 1
                
                # Log detailed state information for debugging
                is_chance = state.is_chance_node()
                is_terminal = state.is_terminal()
                player_id = state.current_player()
                legal_acts = state.legal_actions() if not is_chance and not is_terminal else []
                
                logging.debug(f"Step {step_count}: " + 
                              f"Chance={is_chance}, Terminal={is_terminal}, " + 
                              f"Player={player_id}, LegalActions={legal_acts}, " + 
                              f"History={action_history}")
                
                # Root cause analysis: Check if this is a transition to terminal state
                # In OpenSpiel, -4 often indicates a special state (terminal, chance, etc.)
                if is_terminal:
                    logging.debug(f"Terminal state reached. Breaking out of game loop.")
                    break
                
                if is_chance:
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    
                    # Normalize probability distribution for chance outcomes
                    prob_sum = sum(prob_list)
                    if prob_sum > 0:  # Avoid division by zero
                        normalized_probs = [p / prob_sum for p in prob_list]
                        action = np.random.choice(action_list, p=normalized_probs)
                    else:
                        # If all probs are 0, choose uniformly (shouldn't happen)
                        action = np.random.choice(action_list)
                    
                    action_history.append(f"Chance:{action}")
                    logging.debug(f"Taking chance action: {action}")
                    state.apply_action(action)
                    continue
                
                # Now we know it's a player node, but verify player ID is valid
                # In OpenSpiel, valid player IDs are typically non-negative integers
                if player_id < 0:
                    # This indicates a bug in OpenSpiel or incorrect usage
                    # Log critical diagnostic information to help identify root cause
                    logging.warning(f"Invalid player ID detected: {player_id}")
                    logging.warning(f"Game state details at invalid player ID:")
                    logging.warning(f"  - Action history: {action_history}")
                    logging.warning(f"  - Is terminal: {is_terminal}")
                    logging.warning(f"  - Is chance node: {is_chance}")
                    logging.warning(f"  - Legal actions: {legal_acts}")
                    
                    # Check if we can get the state string representation for additional clues
                    try:
                        state_str = str(state)
                        logging.warning(f"  - State string: {state_str[:100]}..." if len(state_str) > 100 else state_str)
                    except:
                        logging.warning("  - Could not get state string representation")
                    
                    # Instead of working around the issue, determine if we've reached a terminal state
                    # that wasn't properly detected by is_terminal()
                    if not legal_acts:
                        logging.warning("  - No legal actions available, treating as terminal state")
                        # This is likely a terminal state that OpenSpiel isn't correctly identifying
                        # Fix: Mark as done and break out of this game
                        done = True
                        break
                    else:
                        # If there are legal actions, we should be able to continue
                        # This is likely a player ID calculation issue
                        logging.warning("  - There are legal actions, attempting to recover...")
                        action = random.choice(legal_acts)
                        action_history.append(f"Recovery:{action}")
                        state.apply_action(action)
                        continue
                
                # Normal case: Valid player ID
                try:
                    info_state = state.information_state_string(player_id)
                    
                    # Store state if not already sampled
                    if info_state not in sampled_states:
                        sampled_states[info_state] = state.clone()
                    
                    # Take random action
                    action = random.choice(legal_acts)
                    action_history.append(f"Player{player_id}:{action}")
                    logging.debug(f"Player {player_id} taking action: {action}")
                    state.apply_action(action)
                except Exception as e:
                    logging.warning(f"Error processing state: {e}")
                    logging.warning(f"  - Action history: {action_history}")
                    
                    # Try to recover if possible
                    if legal_acts:
                        action = random.choice(legal_acts)
                        action_history.append(f"Error-recovery:{action}")
                        state.apply_action(action)
                    else:
                        logging.warning("  - No legal actions to recover with, ending game")
                        break
                
                # Update terminal state status after action
                done = state.is_terminal()
            
            logging.debug(f"Game {game_idx+1} completed after {step_count} steps, " + 
                       f"done={done}, sampled_states={len(sampled_states)}")
        
        logging.info(f"Sampled {len(sampled_states)} unique information states")
        return sampled_states
    
    def save_checkpoints(self, tag="checkpoint"):
        """Save model checkpoints with checksum verification."""
        from utils import calculate_checksum, safe_save_model
        
        os.makedirs(os.path.dirname(self.config.MODEL_PATH), exist_ok=True)
        
        # Checkpoint path and temp path
        checkpoint_path = f"{self.config.MODEL_PATH}.{tag}"
        temp_path = f"{checkpoint_path}.tmp"
        checksum_path = f"{checkpoint_path}.checksum"
        meta_path = f"{checkpoint_path}.meta"
        meta_temp_path = f"{meta_path}.tmp"
        meta_checksum_path = f"{meta_path}.checksum"
        
        try:
            # Save neural networks with timestamp
            checkpoint_data = {
                'regret_net': self.regret_net.state_dict(),
                'strategy_net': self.strategy_net.state_dict(),
                'regret_optimizer': self.regret_optimizer.state_dict(),
                'strategy_optimizer': self.strategy_optimizer.state_dict(),
                'timestamp': time.time(),
                'global_step': self.global_step
            }
            
            # Save to temp file first
            torch.save(checkpoint_data, temp_path)
            
            # Calculate checksum
            model_checksum = calculate_checksum(temp_path)
            
            # Save checksum
            with open(f"{checksum_path}.tmp", "w") as f:
                f.write(model_checksum)
            
            # Atomic rename for checkpoint and its checksum
            os.replace(temp_path, checkpoint_path)
            os.replace(f"{checksum_path}.tmp", checksum_path)
            
            # Save strategy pool
            strategies = []
            for i, strategy in enumerate(self.strategy_pool):
                if hasattr(strategy, 'serialize'):
                    strategies.append(strategy.serialize())
                else:
                    logging.warning(f"Strategy {i} cannot be serialized, skipping")
            
            # Save meta-strategies to temp file
            # Convert numpy arrays to standard Python types to avoid JSON serialization issues
            def convert_to_serializable(obj):
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                elif isinstance(obj, np.integer):
                    return int(obj)
                elif isinstance(obj, np.floating):
                    return float(obj)
                elif isinstance(obj, (list, tuple)):
                    return [convert_to_serializable(item) for item in obj]
                elif isinstance(obj, dict):
                    return {k: convert_to_serializable(v) for k, v in obj.items()}
                else:
                    return obj
            
            meta_data = {
                'meta_strategies': convert_to_serializable(np.array(self.meta_strategies)),
                'meta_game_matrix': convert_to_serializable(self.meta_game_matrix) if self.meta_game_matrix is not None else [],
                'strategies': convert_to_serializable(strategies),
                'timestamp': time.time()
            }
            # Use JSON instead of np.savez for better compatibility
            with open(meta_temp_path, 'w') as f:
                json.dump(meta_data, f, indent=2)
            
            # Calculate checksum for meta file
            meta_checksum = calculate_checksum(meta_temp_path)
            
            # Save checksum for meta file
            with open(f"{meta_checksum_path}.tmp", "w") as f:
                f.write(meta_checksum)
            
            # Atomic rename for meta file and its checksum
            os.replace(meta_temp_path, meta_path)
            os.replace(f"{meta_checksum_path}.tmp", meta_checksum_path)
            
            # Create backup if this is a best or final checkpoint
            if tag in ["best", "final"]:
                try:
                    import shutil
                    shutil.copy2(checkpoint_path, f"{checkpoint_path}.backup")
                    shutil.copy2(checksum_path, f"{checksum_path}.backup")
                    shutil.copy2(meta_path, f"{meta_path}.backup")
                    shutil.copy2(meta_checksum_path, f"{meta_checksum_path}.backup")
                    logging.info(f"Created backup of {tag} checkpoint")
                except Exception as e:
                    logging.warning(f"Failed to create backup: {e}")
            
            logging.info(f"Saved checkpoints with tag: {tag} (checksum: {model_checksum[:8]}...)")
            return True
            
        except Exception as e:
            logging.error(f"Error saving checkpoint with tag {tag}: {e}")
            # Clean up temporary files
            for tmp_file in [temp_path, f"{checksum_path}.tmp", meta_temp_path, f"{meta_checksum_path}.tmp"]:
                if os.path.exists(tmp_file):
                    try:
                        os.remove(tmp_file)
                    except:
                        pass
            return False
    
    def load_checkpoints(self, tag="checkpoint"):
        """Load model checkpoints with checksum verification and recovery."""
        from utils import verify_checksum
        
        checkpoint_path = f"{self.config.MODEL_PATH}.{tag}"
        meta_path = f"{self.config.MODEL_PATH}.{tag}.meta"
        checksum_path = f"{checkpoint_path}.checksum"
        meta_checksum_path = f"{meta_path}.checksum"
        backup_checkpoint_path = f"{checkpoint_path}.backup"
        backup_meta_path = f"{meta_path}.backup"
        
        # Check if checkpoint exists
        if not os.path.exists(checkpoint_path):
            logging.warning(f"Checkpoint not found: {checkpoint_path}")
            return False
        
        # Verify checksum for model file if available
        checksum_valid = True
        if os.path.exists(checksum_path):
            with open(checksum_path, "r") as f:
                expected_checksum = f.read().strip()
            
            if not verify_checksum(checkpoint_path, expected_checksum):
                logging.error(f"Checksum verification failed for {checkpoint_path}")
                checksum_valid = False
                
                # Try to use backup if available
                if os.path.exists(backup_checkpoint_path) and os.path.exists(f"{backup_checkpoint_path}.checksum"):
                    with open(f"{backup_checkpoint_path}.checksum", "r") as f:
                        backup_checksum = f.read().strip()
                    
                    if verify_checksum(backup_checkpoint_path, backup_checksum):
                        logging.info(f"Using verified backup checkpoint: {backup_checkpoint_path}")
                        checkpoint_path = backup_checkpoint_path
                        checksum_valid = True
                    else:
                        logging.error(f"Backup checkpoint also failed checksum verification")
        
        # Verify checksum for meta file if available
        meta_checksum_valid = True
        if os.path.exists(meta_checksum_path) and os.path.exists(meta_path):
            with open(meta_checksum_path, "r") as f:
                expected_meta_checksum = f.read().strip()
            
            if not verify_checksum(meta_path, expected_meta_checksum):
                logging.error(f"Checksum verification failed for {meta_path}")
                meta_checksum_valid = False
                
                # Try to use backup if available
                if os.path.exists(backup_meta_path) and os.path.exists(f"{backup_meta_path}.checksum"):
                    with open(f"{backup_meta_path}.checksum", "r") as f:
                        backup_meta_checksum = f.read().strip()
                    
                    if verify_checksum(backup_meta_path, backup_meta_checksum):
                        logging.info(f"Using verified backup meta file: {backup_meta_path}")
                        meta_path = backup_meta_path
                        meta_checksum_valid = True
                    else:
                        logging.error(f"Backup meta file also failed checksum verification")
        
        try:
            # Load neural networks
            checkpoint = torch.load(checkpoint_path, map_location=self.device)
            
            # The init_model.py saves with different keys than expected here
            if 'regret_net_state_dict' in checkpoint:
                self.regret_net.load_state_dict(checkpoint['regret_net_state_dict'])
                self.strategy_net.load_state_dict(checkpoint['strategy_net_state_dict'])
                if 'regret_optimizer_state_dict' in checkpoint:
                    self.regret_optimizer.load_state_dict(checkpoint['regret_optimizer_state_dict'])
                if 'strategy_optimizer_state_dict' in checkpoint:
                    self.strategy_optimizer.load_state_dict(checkpoint['strategy_optimizer_state_dict'])
            elif 'regret_net' in checkpoint:
                self.regret_net.load_state_dict(checkpoint['regret_net'])
                self.strategy_net.load_state_dict(checkpoint['strategy_net'])
                # Only try to load optimizer states if they exist
                if 'regret_optimizer' in checkpoint:
                    self.regret_optimizer.load_state_dict(checkpoint['regret_optimizer'])
                if 'strategy_optimizer' in checkpoint:
                    self.strategy_optimizer.load_state_dict(checkpoint['strategy_optimizer'])
            
            # Load global step if available
            if 'global_step' in checkpoint:
                self.global_step = checkpoint['global_step']
                
            # Get timestamp information if available
            timestamp_info = ""
            if 'timestamp' in checkpoint:
                timestamp = checkpoint['timestamp']
                timestamp_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
                timestamp_info = f", saved on {timestamp_str}"
            
            # Load meta-strategies if available and valid
            if os.path.exists(meta_path) and meta_checksum_valid:
                try:
                    # Try loading as JSON first (new format)
                    with open(meta_path, 'r') as f:
                        meta_data = json.load(f)
                except:
                    try:
                        # Fall back to numpy format (old format)
                        meta_data = np.load(meta_path, allow_pickle=True)
                    except Exception as e:
                        logging.error(f"Failed to load meta file: {e}")
                        meta_data = {}
                
                if 'meta_strategies' in meta_data:
                    self.meta_strategies = meta_data['meta_strategies']
                
                if 'meta_game_matrix' in meta_data:
                    matrix = meta_data['meta_game_matrix']
                    # Check if it's a list (JSON) or numpy array
                    if isinstance(matrix, list) and len(matrix) > 0:
                        self.meta_game_matrix = np.array(matrix)
                    elif hasattr(matrix, 'size') and matrix.size > 0:
                        self.meta_game_matrix = matrix
                
                # Load strategy pool if available
                if 'strategies' in meta_data:
                    self.strategy_pool = []
                    for strategy_data in meta_data['strategies']:
                        try:
                            policy = TabularPolicy.deserialize(self.game, strategy_data)
                            self.strategy_pool.append(policy)
                        except Exception as e:
                            logging.error(f"Error loading strategy: {e}")
            
            # Log loading status
            integrity_info = f"(checksum {'verified' if checksum_valid else 'FAILED'})"
            logging.info(f"Loaded checkpoint with tag: {tag}{timestamp_info} {integrity_info}")
            
            # Create backup if checksums are verified but backups don't exist
            if checksum_valid and not os.path.exists(backup_checkpoint_path) and tag in ["best", "final"]:
                try:
                    import shutil
                    shutil.copy2(checkpoint_path, backup_checkpoint_path)
                    shutil.copy2(checksum_path, f"{backup_checkpoint_path}.checksum")
                    if os.path.exists(meta_path) and meta_checksum_valid:
                        shutil.copy2(meta_path, backup_meta_path)
                        shutil.copy2(meta_checksum_path, f"{backup_meta_path}.checksum")
                    logging.info(f"Created backup of verified checkpoint")
                except Exception as e:
                    logging.warning(f"Failed to create backup after loading: {e}")
            
            return True
            
        except Exception as e:
            logging.error(f"Error loading checkpoint with tag {tag}: {e}")
            return False

class PSROWorker:
    """Distributed worker for PSRO training."""
    
    def __init__(self, config, worker_id):
        self.config = config
        self.worker_id = worker_id
        self.game = pyspiel.load_game(config.GAME_NAME)
        self.state_processor = StateProcessor(config)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize models
        self.regret_net = RegretNet(self.state_processor.state_size, self.game.num_distinct_actions()).to(self.device)
        self.strategy_net = StrategyNet(self.state_processor.state_size, self.game.num_distinct_actions()).to(self.device)
        
        logging.info(f"PSROWorker {worker_id} initialized")
    
    def update_models(self, regret_state_dict, strategy_state_dict):
        """Update model weights from main solver."""
        self.regret_net.load_state_dict(regret_state_dict)
        self.strategy_net.load_state_dict(strategy_state_dict)
        return True
    
    def collect_experience(self, opponent_policies, steps):
        """Collect experience by playing against opponent policies."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        buffer = []
        
        for _ in range(steps):
            state = env.reset()
            done = False
            trajectory = []
            
            while not done:
                if state.is_chance_node():
                    # Handle chance node
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    action = np.random.choice(action_list, p=prob_list)
                    state.apply_action(action)
                    continue
                
                player = state.current_player()
                legal_actions = state.legal_actions()
                
                # Process state
                processed_state = self.state_processor.process([state], [player])
                state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
                
                # Select action:
                # Player 0 uses our policy, others use opponent policies
                if player == 0:
                    with torch.no_grad():
                        regret_values = self.regret_net(state_tensor)[0].cpu().numpy()
                        # Mask illegal actions
                        mask = np.ones_like(regret_values) * float('-inf')
                        mask[legal_actions] = 0
                        masked_values = regret_values + mask
                        
                        # Add exploration
                        if random.random() < 0.1:
                            action = random.choice(legal_actions)
                        else:
                            action = np.argmax(masked_values)
                else:
                    # Use opponent policy
                    policy_idx = (player - 1) % len(opponent_policies)
                    opponent_policy = opponent_policies[policy_idx]
                    
                    if opponent_policy:
                        action_probs = opponent_policy.action_probabilities(state)
                        actions, probs = zip(*action_probs.items())
                        action = np.random.choice(actions, p=probs)
                    else:
                        # Random if no policy
                        action = random.choice(legal_actions)
                
                # Store transition for player 0 only
                if player == 0:
                    info_state = state.information_state_string(player)
                    trajectory.append({
                        'info_state': info_state,
                        'state': state.clone(),
                        'action': action,
                        'legal_actions': legal_actions,
                        'player': player,
                        'reward': 0,  # Placeholder
                        'done': False
                    })
                
                # Apply action
                state.apply_action(action)
                done = state.is_terminal()
            
            # Update rewards for trajectory
            if trajectory:
                returns = state.returns()
                player_return = returns[0]  # Only for player 0
                
                for transition in trajectory:
                    transition['reward'] = player_return
                    transition['done'] = True
                
                buffer.extend(trajectory)
        
        return buffer
