#!/usr/bin/env python3
"""
Test All Components Script

This script tests all major components of the Poker AI system to ensure
they're working correctly after deployment.
"""

import os
import sys
import time
import subprocess
import requests
import logging
import argparse
import signal
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('system_test.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Default ports for services
DEFAULT_PORTS = {
    "main": 5010,
    "web_poker": 5003,
    "monitor": 5000,
    "admin": 5001,
    "advanced_admin": 5002
}

# Test status
class TestStatus:
    PASSED = 0
    FAILED = 1
    SKIPPED = 2

# Global test results
test_results = {}

def run_command(command, timeout=60):
    """Run a shell command and return its output."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, f"Command failed with exit code {e.returncode}: {e.stderr}"
    except subprocess.TimeoutExpired:
        return False, f"Command timed out after {timeout} seconds"
    except Exception as e:
        return False, f"Error running command: {str(e)}"

def check_service(name, port):
    """Check if a service is running on a specific port."""
    try:
        response = requests.get(f"http://localhost:{port}")
        if response.status_code == 200:
            test_results[f"{name}_service"] = TestStatus.PASSED
            logging.info(f"✅ {name} service is running on port {port}")
            return True
        else:
            test_results[f"{name}_service"] = TestStatus.FAILED
            logging.error(f"❌ {name} service returned status code {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        test_results[f"{name}_service"] = TestStatus.FAILED
        logging.error(f"❌ {name} service is not running on port {port}")
        return False
    except Exception as e:
        test_results[f"{name}_service"] = TestStatus.FAILED
        logging.error(f"❌ Error checking {name} service: {str(e)}")
        return False

def test_database_connection():
    """Test database connection using the execute_sql_tool."""
    try:
        # Try to import sqlalchemy
        import sqlalchemy
        from sqlalchemy import create_engine, text
        
        # Get database URL from environment variable
        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            test_results["database"] = TestStatus.SKIPPED
            logging.warning("⚠️ DATABASE_URL environment variable not set, skipping database test")
            return False
        
        # Create engine and test connection
        engine = create_engine(database_url)
        with engine.connect() as connection:
            result = connection.execute(text("SELECT 1"))
            row = result.fetchone()
            if row and row[0] == 1:
                test_results["database"] = TestStatus.PASSED
                logging.info("✅ Database connection successful")
                return True
            else:
                test_results["database"] = TestStatus.FAILED
                logging.error("❌ Database connection test failed")
                return False
    except ImportError:
        test_results["database"] = TestStatus.SKIPPED
        logging.warning("⚠️ SQLAlchemy not installed, skipping database test")
        return False
    except Exception as e:
        test_results["database"] = TestStatus.FAILED
        logging.error(f"❌ Database connection error: {str(e)}")
        return False

def test_pytorch():
    """Test PyTorch installation."""
    try:
        import torch
        test_results["pytorch"] = TestStatus.PASSED
        logging.info(f"✅ PyTorch {torch.__version__} is installed")
        logging.info(f"   CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            logging.info(f"   CUDA version: {torch.version.cuda}")
            logging.info(f"   GPU device: {torch.cuda.get_device_name(0)}")
        return True
    except ImportError:
        test_results["pytorch"] = TestStatus.FAILED
        logging.error("❌ PyTorch is not installed")
        return False
    except Exception as e:
        test_results["pytorch"] = TestStatus.FAILED
        logging.error(f"❌ Error testing PyTorch: {str(e)}")
        return False

def test_openspiel():
    """Test OpenSpiel installation."""
    try:
        import pyspiel
        test_results["openspiel"] = TestStatus.PASSED
        logging.info(f"✅ OpenSpiel is installed")
        
        # Try creating a poker game
        game_string = ("universal_poker(betting=nolimit,numPlayers=6,numRounds=4,"
                   "blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,"
                   "stack=100 100 100 100 100 100,numSuits=4,numRanks=13,"
                   "numHoleCards=2,numBoardCards=0 3 1 1)")
        
        try:
            game = pyspiel.load_game(game_string)
            logging.info(f"✅ Successfully created poker game")
            # Get game type to verify it's working
            game_type = game.get_type()
            logging.info(f"   Game type: {game_type.short_name()}")
            logging.info(f"   Dynamics: {game_type.dynamics}")
            return True
        except Exception as e:
            test_results["openspiel"] = TestStatus.FAILED
            logging.error(f"❌ Error creating poker game: {str(e)}")
            return False
            
    except ImportError:
        test_results["openspiel"] = TestStatus.FAILED
        logging.error("❌ OpenSpiel is not installed")
        return False
    except Exception as e:
        test_results["openspiel"] = TestStatus.FAILED
        logging.error(f"❌ Error testing OpenSpiel: {str(e)}")
        return False

def test_player_id_fix():
    """Test the OpenSpiel player ID=-4 fix."""
    try:
        from fix_openspiel_player_id import OpenSpielPlayerIdFix
        import pyspiel
        
        # Test basic functionality
        assert OpenSpielPlayerIdFix.is_valid_player_id(0) == True
        assert OpenSpielPlayerIdFix.is_valid_player_id(1) == True
        assert OpenSpielPlayerIdFix.is_valid_player_id(-1) == True  # Chance node
        assert OpenSpielPlayerIdFix.is_valid_player_id(-4) == False  # Error case
        
        # Get actual result from fix_state_player
        class DummyState:
            def current_player(self):
                return -4
            
            def is_terminal(self):
                return True
                
        dummy_state = DummyState()
        player, is_terminal = OpenSpielPlayerIdFix.fix_state_player(dummy_state)
        
        if is_terminal:
            test_results["player_id_fix"] = TestStatus.PASSED
            logging.info("✅ OpenSpiel player ID=-4 fix is working")
            return True
        else:
            test_results["player_id_fix"] = TestStatus.FAILED
            logging.error("❌ OpenSpiel player ID=-4 fix failed to detect terminal state")
            return False
    except ImportError:
        test_results["player_id_fix"] = TestStatus.FAILED
        logging.error("❌ fix_openspiel_player_id module not found")
        return False
    except Exception as e:
        test_results["player_id_fix"] = TestStatus.FAILED
        logging.error(f"❌ Error testing player ID fix: {str(e)}")
        return False

def test_poker_rl():
    """Test poker_rl.py with a minimal run."""
    try:
        success, output = run_command("python poker_rl.py --mode selfplay --num_episodes 1")
        if success:
            test_results["poker_rl"] = TestStatus.PASSED
            logging.info("✅ poker_rl.py selfplay test passed")
            return True
        else:
            test_results["poker_rl"] = TestStatus.FAILED
            logging.error(f"❌ poker_rl.py selfplay test failed: {output}")
            return False
    except Exception as e:
        test_results["poker_rl"] = TestStatus.FAILED
        logging.error(f"❌ Error testing poker_rl.py: {str(e)}")
        return False

def test_web_services():
    """Test all web services."""
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {
            executor.submit(check_service, "main", DEFAULT_PORTS["main"]): "main",
            executor.submit(check_service, "web_poker", DEFAULT_PORTS["web_poker"]): "web_poker",
            executor.submit(check_service, "monitor", DEFAULT_PORTS["monitor"]): "monitor"
        }
        
        # Optionally check admin dashboards if specified
        if args.admin:
            futures[executor.submit(check_service, "admin", DEFAULT_PORTS["admin"])] = "admin"
            futures[executor.submit(check_service, "advanced_admin", DEFAULT_PORTS["advanced_admin"])] = "advanced_admin"
        
        # Wait for all tests to complete
        for future in as_completed(futures):
            service_name = futures[future]
            try:
                result = future.result()
                logging.debug(f"Service test for {service_name} completed with result: {result}")
            except Exception as e:
                logging.error(f"Error testing {service_name}: {str(e)}")

def print_summary():
    """Print a summary of all test results."""
    logging.info("\n" + "="*60)
    logging.info("TEST SUMMARY")
    logging.info("="*60)
    
    passed = sum(1 for status in test_results.values() if status == TestStatus.PASSED)
    failed = sum(1 for status in test_results.values() if status == TestStatus.FAILED)
    skipped = sum(1 for status in test_results.values() if status == TestStatus.SKIPPED)
    
    for test_name, status in test_results.items():
        status_str = "✅ PASSED" if status == TestStatus.PASSED else "❌ FAILED" if status == TestStatus.FAILED else "⚠️ SKIPPED"
        logging.info(f"{test_name.ljust(25)}: {status_str}")
    
    logging.info("-"*60)
    logging.info(f"PASSED: {passed}, FAILED: {failed}, SKIPPED: {skipped}, TOTAL: {len(test_results)}")
    logging.info("="*60)
    
    return failed == 0

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Test all components of the Poker AI system')
    parser.add_argument('--admin', action='store_true', help='Test admin dashboards')
    parser.add_argument('--database', action='store_true', help='Test database connection')
    parser.add_argument('--pytorch', action='store_true', help='Test PyTorch installation')
    parser.add_argument('--openspiel', action='store_true', help='Test OpenSpiel installation')
    parser.add_argument('--fix', action='store_true', help='Test OpenSpiel player ID=-4 fix')
    parser.add_argument('--poker-rl', action='store_true', help='Test poker_rl.py')
    parser.add_argument('--all', action='store_true', help='Run all tests')
    parser.add_argument('--output', type=str, help='Save test results to JSON file')
    
    return parser.parse_args()

def main():
    """Main test function."""
    logging.info("Starting Poker AI system tests")
    logging.info(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Run tests based on arguments
    if args.all or args.database:
        test_database_connection()
    
    if args.all or args.pytorch:
        test_pytorch()
    
    if args.all or args.openspiel:
        test_openspiel()
    
    if args.all or args.fix:
        test_player_id_fix()
    
    if args.all or args.poker_rl:
        test_poker_rl()
    
    # Always test web services
    test_web_services()
    
    # Print summary of results
    success = print_summary()
    
    # Save results to JSON file if requested
    if args.output:
        # Convert enum values to strings for JSON serialization
        json_results = {
            k: "PASSED" if v == TestStatus.PASSED else "FAILED" if v == TestStatus.FAILED else "SKIPPED"
            for k, v in test_results.items()
        }
        
        # Add timestamp
        json_results["timestamp"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        with open(args.output, 'w') as f:
            json.dump(json_results, f, indent=2)
        
        logging.info(f"Test results saved to {args.output}")
    
    return 0 if success else 1

if __name__ == "__main__":
    # Handle keyboard interrupts gracefully
    try:
        args = parse_arguments()
        sys.exit(main())
    except KeyboardInterrupt:
        logging.info("\nTesting interrupted by user")
        sys.exit(130)  # Standard exit code for SIGINT