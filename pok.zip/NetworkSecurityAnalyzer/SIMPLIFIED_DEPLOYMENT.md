# Simplified Poker AI Deployment Guide

## Quick Setup Using the Onboarding Wizard

The onboarding wizard is designed to handle most of the setup process automatically, making deployment much simpler.

### Step 1: Download the Project 

Download all files from this Replit project using the "Download as Zip" feature:
- Click the three dots menu (...) in the Files panel
- Select "Download as Zip"
- Save the zip file to your computer

### Step 2: Transfer to Your Server

- Upload the zip file to your server using SCP, SFTP, or another file transfer method
- Extract the files:
  ```bash
  unzip poker_ai.zip -d ~/poker_ai
  cd ~/poker_ai
  ```

### Step 3: Install Python and PostgreSQL

Make sure Python 3.10+ and PostgreSQL are installed on your server:
```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv postgresql postgresql-contrib
```

### Step 4: Set Up Python Environment
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt  # If this file exists
```

If requirements.txt doesn't exist, install the core packages:
```bash
pip install torch numpy flask flask-login flask-sqlalchemy flask-migrate psycopg2-binary open-spiel ray
```

### Step 5: Configure Database

Create a PostgreSQL database and user:
```bash
sudo -u postgres psql -c "CREATE DATABASE poker_ai;"
sudo -u postgres psql -c "CREATE USER pokeradmin WITH PASSWORD 'your_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE poker_ai TO pokeradmin;"
```

Set the database URL environment variable:
```bash
export DATABASE_URL="postgresql://pokeradmin:your_password@localhost/poker_ai"
```

### Step 6: Run the Onboarding Wizard

Simply run the onboarding wizard, which will handle the rest of the setup:
```bash
python web_onboarding_wizard.py --port 5060
```

Then open http://your-server-ip:5060 in your browser to complete the guided setup process. The wizard will:
- Check system requirements
- Set up the database tables
- Create an admin user
- Start necessary services
- Run a test training session

### Step 7: Start the Main Application

After completing the onboarding wizard, you can start the main application:
```bash
python main.py
```

Access the application at http://your-server-ip:5010

### For Production Deployment

For a production environment, consider:

1. Running the app as a service (using systemd):
```bash
sudo nano /etc/systemd/system/poker-ai.service
```

```
[Unit]
Description=Poker AI System
After=network.target

[Service]
User=your_username
WorkingDirectory=/home/your_username/poker_ai
Environment="PATH=/home/your_username/poker_ai/venv/bin"
Environment="DATABASE_URL=postgresql://pokeradmin:your_password@localhost/poker_ai"
ExecStart=/home/your_username/poker_ai/venv/bin/python main.py

[Install]
WantedBy=multi-user.target
```

Enable and start the service:
```bash
sudo systemctl enable poker-ai
sudo systemctl start poker-ai
```

2. Setting up Nginx as a reverse proxy:
```
server {
    listen 80;
    server_name your_domain_or_ip;

    location / {
        proxy_pass http://localhost:5010;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Troubleshooting

If you encounter issues:

1. Check if the database URL is set correctly
2. Ensure all necessary ports are available (5010, 5060)
3. Look at the logs in `web_onboarding_wizard.log` and `poker_rl.log`
4. Verify that PostgreSQL is running: `sudo systemctl status postgresql`

## Security

Remember to:
- Change the default admin password
- Use a strong database password
- Set up a firewall to restrict access to the necessary ports
- Consider using HTTPS for production environments