import os
from flask import Flask, send_file, send_from_directory, render_template_string

app = Flask(__name__, static_folder='static')

@app.route('/')
def home():
    # Get file size
    file_size = os.path.getsize('poker_ai_system_slim.zip')
    file_size_kb = round(file_size / 1024, 0)
    
    # Create curl command for direct download to A100
    replit_url = "https://77b2eb61-43f1-42a2-a5c5-6c4ce33fc5a3-00-250d4ddm7qp7e.worf.replit.dev"
    curl_command = f"curl -L {replit_url}/download -o poker_ai_system_slim.zip && unzip poker_ai_system_slim.zip -d poker_ai_system && cd poker_ai_system && chmod +x setup.sh && ./setup.sh"
    
    return render_template_string('''
    <html>
    <head>
        <title>Poker AI System Download</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                line-height: 1.6;
            }
            .download-button {
                display: inline-block;
                background-color: #4CAF50;
                color: white;
                padding: 12px 24px;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                border-radius: 4px;
                margin-top: 20px;
                font-weight: bold;
            }
            h1, h2, h3 {
                color: #333;
            }
            .info {
                background-color: #f9f9f9;
                border-left: 4px solid #4CAF50;
                padding: 10px 20px;
                margin: 20px 0;
            }
            .alert {
                background-color: #f8f9fa;
                border-left: 4px solid #007bff;
                padding: 10px 20px;
                margin: 20px 0;
            }
            code {
                background-color: #f5f5f5;
                padding: 2px 4px;
                border-radius: 3px;
                font-family: monospace;
            }
            pre {
                background-color: #f5f5f5;
                padding: 10px;
                border-radius: 4px;
                overflow-x: auto;
            }
            .method {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 15px;
                margin-bottom: 20px;
            }
            .method h3 {
                margin-top: 0;
            }
        </style>
    </head>
    <body>
        <h1>Poker AI System - Slim Download</h1>
        
        <div class="info">
            <p><strong>Package Size:</strong> {{ file_size_kb }}KB</p>
            <p><strong>Contents:</strong> Core application code, configuration files, and system templates</p>
            <p><strong>Note:</strong> Libraries will be installed separately via pip</p>
        </div>
        
        <div class="alert">
            <p><strong>Optimization:</strong> We've created an ultra-slim version of the Poker AI system that's much easier to transfer. The ZIP file is only {{ file_size_kb }}KB and contains all the essential code, but not the Python libraries (which will be installed from requirements.txt).</p>
        </div>
        
        <div class="method">
            <h3>Method 1: One-Command Installation</h3>
            <p>Run this single command on your A100 server:</p>
            <pre>{{ curl_command }}</pre>
            <p>This will: download the ZIP, extract it, and install dependencies automatically.</p>
            <a href="/download" class="download-button">Download Slim ZIP ({{ file_size_kb }}KB)</a>
        </div>
        
        <h2>Manual Installation Instructions</h2>
        <ol>
            <li>Download the ZIP file using the button above</li>
            <li>Transfer it to your A100 server</li>
            <li>Extract it: <code>unzip poker_ai_system_slim.zip -d poker_ai_system</code></li>
            <li>Navigate to the directory: <code>cd poker_ai_system</code></li>
            <li>Run the setup script: <code>chmod +x setup.sh && ./setup.sh</code></li>
            <li>Start the system: <code>python main.py</code></li>
        </ol>
        
        <div class="alert">
            <p><strong>Note:</strong> The setup script will install all required Python dependencies from requirements.txt. If you have any issues with the automatic installation, you can manually run <code>pip install -r requirements.txt</code>.</p>
        </div>
    </body>
    </html>
    ''', 
    file_size_kb=file_size_kb,
    curl_command=curl_command)

@app.route('/download')
def download():
    return send_file('poker_ai_system_slim.zip', as_attachment=True)

@app.route('/download_script')
def download_script():
    return send_from_directory('static/chunks', 'direct_download.sh', as_attachment=True)

@app.route('/chunks/<path:filename>')
def serve_chunk(filename):
    return send_from_directory('static/chunks', filename, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)